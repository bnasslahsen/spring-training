package com.bnpparibas.bddf.collect.exposition.apidoc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.inject.Inject;
import javax.ws.rs.core.MediaType;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.bnpparibas.bddf.collect.exposition.BddfCollectApplication;
import com.bnpparibas.bddf.config.SpringProfileConstants;

@RunWith(SpringRunner.class)

@SpringBootTest(classes = { BddfCollectApplication.class })

@ActiveProfiles({ SpringProfileConstants.SPRING_PROFILE_TEST, SpringProfileConstants.SPRING_PROFILE_SWAGGER })
public class Swagger2MarkupTest {

	private static final String API_URI = "/v2/api-docs";

	@Inject
	private WebApplicationContext context;

	private MockMvc mockMvc;

	private File projectDir;

	@Before
	public void setup() throws IOException {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.context).build();

		final ClassPathResource pathfileRes = new ClassPathResource("config/application.yml");
		projectDir = pathfileRes.getFile().getParentFile().getParentFile().getParentFile().getParentFile();
	}

	@Test
	public void convertSwaggerToJson() throws Exception {
		final MvcResult mvcResult = this.mockMvc.perform(get(API_URI).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();
		final MockHttpServletResponse response = mvcResult.getResponse();
		final String swaggerJson = response.getContentAsString();
		Files.createDirectories(Paths.get(outputDirForFormat()));
		try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(outputDirForFormat(), "swagger.json"), StandardCharsets.UTF_8)) {
			writer.write(swaggerJson);
		}
	}

	private String outputDirForFormat() throws IOException {
		return new File(projectDir, "target/swagger").getAbsolutePath();
	}

}
