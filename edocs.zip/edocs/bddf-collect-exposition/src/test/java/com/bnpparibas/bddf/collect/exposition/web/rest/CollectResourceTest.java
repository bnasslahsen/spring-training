
package com.bnpparibas.bddf.collect.exposition.web.rest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.inject.Inject;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.bnpparibas.bddf.collect.application.service.collect.CollectActions;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.exposition.web.rest.client.CollectResource;
import com.bnpparibas.bddf.rest.ConnectedManager;
import com.bnpparibas.bddf.rest.Context;

/***
 * Test class for the CollectResource REST controller.**
 *
 * @see CollectResource
 */

@RunWith(SpringRunner.class)
@SpringBootTest(classes = BddfCollectApplicationTest.class)
@AutoConfigureMockMvc
@ActiveProfiles("test")
public class CollectResourceTest {

	public static final String USER_ID = "123456";

	@Inject
	private CollectActions collectActions;

	private MockMvc restUserMockMvc;

	@Before
	public void setup() {
		final CollectResource collectResource = new CollectResource(collectActions);
		final Context context = new Context(USER_ID, Channel.SPIRIT.getValue());
		ConnectedManager.set(context);
		this.restUserMockMvc = MockMvcBuilders.standaloneSetup(collectResource).build();
	}

	@Test
	@SqlGroup(value = { @Sql(scripts = "classpath:insert-collect.sql", executionPhase = ExecutionPhase.BEFORE_TEST_METHOD) })
	public void testGetCollectByID() throws Exception {
		restUserMockMvc.perform(get("/api/collects/client/9dbfeb13-206a-494d-811e-158e2cbd8953").accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
}
