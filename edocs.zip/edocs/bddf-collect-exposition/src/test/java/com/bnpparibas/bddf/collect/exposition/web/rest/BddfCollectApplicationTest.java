package com.bnpparibas.bddf.collect.exposition.web.rest;

import java.net.UnknownHostException;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.cassandra.CassandraDataAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import com.bnpparibas.bddf.config.BddfProperties;
import com.bnpparibas.bddf.web.rest.support.AbstractSpringBootLauncher;

@ComponentScan(basePackages = "com.bnpparibas.bddf")
@EnableAutoConfiguration(exclude = { CassandraDataAutoConfiguration.class })
@SpringBootApplication
@EnableConfigurationProperties(BddfProperties.class)
@EnableAspectJAutoProxy
public class BddfCollectApplicationTest extends AbstractSpringBootLauncher {

	public static void main(String[] args) throws UnknownHostException {
		AbstractSpringBootLauncher.launch(BddfCollectApplicationTest.class, args);
	}

	@Bean
	public CorsFilter corsFilter() {
		final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		final CorsConfiguration config = new CorsConfiguration();
		config.setAllowCredentials(true);
		config.addAllowedOrigin("*");
		config.addAllowedHeader("*");
		config.addAllowedMethod("OPTIONS");
		config.addAllowedMethod("HEAD");
		config.addAllowedMethod("GET");
		config.addAllowedMethod("PUT");
		config.addAllowedMethod("POST");
		config.addAllowedMethod("DELETE");
		config.addAllowedMethod("PATCH");
		source.registerCorsConfiguration("/**", config);
		return new CorsFilter(source);
	}

}
