package com.bnpparibas.bddf.collect.exposition.web.rest.collab;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.CollectDTO;
import com.bnpparibas.bddf.collect.application.dto.CollectDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.UpdateDTO;
import com.bnpparibas.bddf.collect.application.service.collect.CollectActions;
import com.bnpparibas.bddf.collect.exposition.web.constants.SwaggerDoc;
import com.bnpparibas.bddf.rest.ConnectedManager;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * REST controller for managing collect ressource.
 */
@RestController
@RequestMapping("/api/collects")
public class CollectCollabResource {

	private final CollectActions collectAction;

	public CollectCollabResource(CollectActions collectService) {
		this.collectAction = collectService;
	}

	/**
	 * GET /collects/{id} : get collect by ID.
	 *
	 * @param id
	 *            Identifiant de la collecte
	 *
	 * @return the ResponseEntity with status 200 (OK) and the collect in body
	 */
	@GetMapping(value = "/collab/{id}", produces = "application/json")
	@ApiOperation(notes = "Ce service retourne l'ensemble du contenu d'une collecte donnée", nickname = "getCollectByIdCollab", value = "getCollectById")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<CollectAllDetailsDTO> getCollectById(@ApiParam(value = "UUID de la collecte souhaitée") @PathVariable(required = true) UUID id) {
		final CollectAllDetailsDTO collect = collectAction.getCollect(id, ConnectedManager.get());
		return new ResponseEntity<>(collect, HttpStatus.OK);
	}

	/**
	 * GET /collects :
	 *
	 * @param owners
	 *            Liste des propriétaires de la collecte
	 *
	 * @param journeyCodes
	 *            Codes parcous
	 *
	 * @return the ResponseEntity with status 200 (OK) and the list of collects in body
	 */
	@GetMapping(value = "/collab", produces = "application/json")
	@ApiOperation(notes = "Ce service permet à une application métier de rechercher l’ensemble des collectes correspondant à un ou plusieurs IUP titulaire pour un code parcours donné", nickname = "getCollectsCollab", value = "getCollects")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<Set<CollectDetailsDTO>> getCollects(@ApiParam(value = "IUP des titulaires") @RequestParam(required = true) List<String> owners,
			@ApiParam(value = "Liste des codes parcours") @RequestParam(required = false) List<String> journeyCodes) {
		final Set<CollectDetailsDTO> collects = collectAction.getCollectsByOwners(owners, journeyCodes, ConnectedManager.get());
		return new ResponseEntity<>(collects, HttpStatus.OK);
	}

	@PostMapping(value = "/collab", produces = "application/json")
	@ApiOperation(notes = SwaggerDoc.NOTES_COLLECT_POST, nickname = SwaggerDoc.NICKNAME_COLLECT_POST_COLLAB, value = "saveCollect")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	@ResponseStatus(code = HttpStatus.CREATED)
	public ResponseEntity<CollectDTO> saveCollect(@RequestBody(required = true) @Valid CollectAllDetailsDTO collect) {
		final CollectDTO newCollect = collectAction.saveCollect(collect, ConnectedManager.get());
		return new ResponseEntity<>(newCollect, HttpStatus.CREATED);
	}

	@PutMapping(value = "/collab/{idCollect}/status", produces = "application/json")
	@ApiOperation(notes = "Ce service permet de mettre à jour le statut d’une collecte donnée", nickname = "updateCollectCollab", value = "updateCollect")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<UpdateDTO> cancelCollect(@ApiParam(value = "UUID de la collecte souhaitée") @PathVariable UUID idCollect,
			@ApiParam(value = "AB pour abandonner la collect\nCL pour clôre la collecte", allowableValues = "AB,CL") @RequestParam String status) {
		return new ResponseEntity<>(UpdateDTO.now(collectAction.endCollect(idCollect, status, ConnectedManager.get())), HttpStatus.OK);
	}

	@PutMapping(value = "/collab/{idCollect}", produces = "application/json")
	@ApiOperation(notes = "Ce service permet de mettre à jour les propriétaires de la collect", nickname = "ownerCollectCollab", value = "ownerCollect")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<UpdateDTO> updateCollect(@ApiParam(value = "UUID de la collecte souhaitée") @PathVariable UUID idCollect, @RequestBody(required = true) @Valid CollectAllDetailsDTO collect) {
		collectAction.updateCollect(idCollect, collect, ConnectedManager.get());
		return new ResponseEntity<>(UpdateDTO.now(), HttpStatus.OK);
	}

}
