package com.bnpparibas.bddf.collect.exposition.web.rest.security;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

@Component
public class JwtAuthenticationProvider implements AuthenticationProvider {

	public JwtAuthenticationProvider() {
		super();
	}

	@Override
	public Authentication authenticate(Authentication arg0) {
		return null;
	}

	@Override
	public boolean supports(Class<?> arg0) {
		return false;
	}

}
