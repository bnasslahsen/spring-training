package com.bnpparibas.bddf.collect.exposition.config;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bnpparibas.bddf.config.BddfProperties;
import com.google.common.base.Strings;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import springfox.documentation.service.Parameter;

/** Swagger SpringFox configuration. */
@Configuration
@EnableSwagger2
public class SwaggerDocumentationConfig {

	/** Default construtor */
	public SwaggerDocumentationConfig() {
		super();
	}

	@Autowired
	private BddfProperties bddfProperties;

	private ApiInfo apiInfo() {
		final Contact contact = new Contact(bddfProperties.getSwagger().getContactName(),
				bddfProperties.getSwagger().getContactUrl(), bddfProperties.getSwagger().getContactEmail());

		final ApiInfoBuilder builder = new ApiInfoBuilder().title(bddfProperties.getSwagger().getTitle())
				.description(bddfProperties.getSwagger().getDescription())
				.version(bddfProperties.getSwagger().getVersion())
				.termsOfServiceUrl(bddfProperties.getSwagger().getTermsOfServiceUrl())
				.license(bddfProperties.getSwagger().getLicense())
				.licenseUrl(bddfProperties.getSwagger().getLicenseUrl());

		if (!Strings.isNullOrEmpty(contact.getName())) {
			builder.contact(contact);
		}
		return builder.build();

	}

	@Bean
	public Docket customImplementation() {
		// Add header
		final ParameterBuilder aChannelParameterBuilder = new ParameterBuilder();
		final ParameterBuilder aUserIdParameterBuilder = new ParameterBuilder();
		final ParameterBuilder aMediaParameterBuilder = new ParameterBuilder();
		aUserIdParameterBuilder.name("userId").modelRef(new ModelRef("string")).parameterType("header").required(false)
				.build();
		aChannelParameterBuilder.name("channel").modelRef(new ModelRef("string")).parameterType("header")
				.required(false).build();
		aMediaParameterBuilder.name("media").modelRef(new ModelRef("string")).parameterType("header").required(false)
				.build();
		final List<Parameter> aParameters = new ArrayList<>();
		aParameters.add(aMediaParameterBuilder.build());
		aParameters.add(aChannelParameterBuilder.build());
		aParameters.add(aUserIdParameterBuilder.build());
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.bnpparibas.bddf.collect.exposition.web")).build()
				.globalOperationParameters(aParameters).directModelSubstitute(LocalDate.class, java.sql.Date.class)
				.directModelSubstitute(ZonedDateTime.class, java.util.Date.class).apiInfo(apiInfo());
	}
}
