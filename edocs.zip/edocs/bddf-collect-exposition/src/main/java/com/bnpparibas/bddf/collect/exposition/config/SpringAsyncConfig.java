package com.bnpparibas.bddf.collect.exposition.config;

import java.util.concurrent.Executor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
@EnableAsync
public class SpringAsyncConfig {

	@Value("${threads.poolSize.firstIteration}")
	private Integer threadsPoolSizeFirstIteration;
	@Value("${threads.poolSize.gdn}")
	private Integer threadsPoolSizeGdn;
	@Value("${threads.poolSize.jmc}")
	private Integer threadsPoolSizeJmc;
	@Value("${threads.poolSize.audit}")
	private Integer threadsPoolSizeAudit;
	@Value("${threads.poolSize.saveRef}")
	private Integer threadsPoolSizeSaveRef;
	@Value("${threads.poolSize.sendEventMQ}")
	private Integer threadsPoolSizeSendEventMQ;
	@Value("${threads.poolSize.sendJMC}")
	private Integer threadsPoolSizeSendJMC;
	@Value("${threads.poolSize.batchAmi}")
	private Integer threadsPoolSizeBatchAmi;

	@Bean(name = "firstIterationTaskExecutor")
	public Executor firstIterationPoolTaskExecutor() {
		final ThreadPoolTaskExecutor threadPool = new ThreadPoolTaskExecutor();
		threadPool.setCorePoolSize(threadsPoolSizeFirstIteration);
		threadPool.setMaxPoolSize(threadsPoolSizeFirstIteration);
		return threadPool;
	}

	@Bean(name = "gdnTaskExecutor")
	public Executor gdnPoolTaskExecutor() {
		final ThreadPoolTaskExecutor threadPool = new ThreadPoolTaskExecutor();
		threadPool.setCorePoolSize(threadsPoolSizeGdn);
		threadPool.setMaxPoolSize(threadsPoolSizeGdn);
		return threadPool;
	}

	@Bean(name = "jmcTaskExecutor")
	public Executor jmcPoolTaskExecutor() {
		final ThreadPoolTaskExecutor threadPool = new ThreadPoolTaskExecutor();
		threadPool.setCorePoolSize(threadsPoolSizeJmc);
		threadPool.setMaxPoolSize(threadsPoolSizeJmc);
		return threadPool;
	}

	@Bean(name = "auditTaskExecutor")
	public Executor auditPoolTaskExecutor() {
		final ThreadPoolTaskExecutor threadPool = new ThreadPoolTaskExecutor();
		threadPool.setCorePoolSize(threadsPoolSizeAudit);
		threadPool.setMaxPoolSize(threadsPoolSizeAudit);
		return threadPool;
	}

	@Bean(name = "saveRefTaskExecutor")
	public Executor saveRefPoolTaskExecutor() {
		final ThreadPoolTaskExecutor threadPool = new ThreadPoolTaskExecutor();
		threadPool.setCorePoolSize(threadsPoolSizeSaveRef);
		threadPool.setMaxPoolSize(threadsPoolSizeSaveRef);
		return threadPool;
	}

	@Bean(name = "sendEventMQTaskExecutor")
	public Executor sendEventMQTaskExecutor() {
		final ThreadPoolTaskExecutor threadPool = new ThreadPoolTaskExecutor();
		threadPool.setCorePoolSize(threadsPoolSizeSendEventMQ);
		threadPool.setMaxPoolSize(threadsPoolSizeSendEventMQ);
		return threadPool;
	}

	@Bean(name = "sendJMCTaskExecutor")
	public Executor sendJMCTaskExecutor() {
		final ThreadPoolTaskExecutor threadPool = new ThreadPoolTaskExecutor();
		threadPool.setCorePoolSize(threadsPoolSizeSendJMC);
		threadPool.setMaxPoolSize(threadsPoolSizeSendJMC);
		return threadPool;
	}

	@Bean(name = "sendAmiBatchTaskExecutor")
	public Executor sendAmiBatchTaskExecutor() {
		final ThreadPoolTaskExecutor threadPool = new ThreadPoolTaskExecutor();
		threadPool.setCorePoolSize(threadsPoolSizeBatchAmi);
		threadPool.setMaxPoolSize(threadsPoolSizeBatchAmi);
		return threadPool;
	}

}