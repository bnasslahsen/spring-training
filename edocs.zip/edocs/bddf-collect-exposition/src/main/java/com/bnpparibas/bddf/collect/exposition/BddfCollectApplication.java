package com.bnpparibas.bddf.collect.exposition;

import java.net.UnknownHostException;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import com.bnpparibas.bddf.config.BddfProperties;
import com.bnpparibas.bddf.web.rest.support.AbstractSpringBootLauncher;

@ComponentScan(basePackages = "com.bnpparibas.bddf")
@SpringBootApplication
@EnableConfigurationProperties(BddfProperties.class)
@EnableDiscoveryClient
@EnableScheduling
@EnableAspectJAutoProxy
@EnableCircuitBreaker
@EnableBatchProcessing
@EnableCaching
public class BddfCollectApplication extends AbstractSpringBootLauncher {

	public BddfCollectApplication() {
		super();
		setRegisterErrorPageFilter(false);
	}

	public static void main(String[] args) throws UnknownHostException {
		AbstractSpringBootLauncher.launch(BddfCollectApplication.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(BddfCollectApplication.class);
	}

	@Bean
	public CorsFilter corsFilter() {
		final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		final CorsConfiguration config = new CorsConfiguration();
		config.setAllowCredentials(true);
		config.addAllowedOrigin("*");
		config.addAllowedHeader("*");
		config.addAllowedMethod("OPTIONS");
		config.addAllowedMethod("HEAD");
		config.addAllowedMethod("GET");
		config.addAllowedMethod("PUT");
		config.addAllowedMethod("POST");
		config.addAllowedMethod("DELETE");
		config.addAllowedMethod("PATCH");
		source.registerCorsConfiguration("/**", config);
		return new CorsFilter(source);
	}

}
