package com.bnpparibas.bddf.collect.exposition.web.rest.security;

import java.io.IOException;
import java.util.Collections;
import java.util.Optional;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.rest.ConnectedManager;
import com.bnpparibas.bddf.rest.Context;
import com.bnpparibas.bddf.web.rest.jwt.JwtTools;

/*
 * Spring Security Filter
 *
 * @author b49543
 *
 */
@Component
public class JwtSecurityFilter implements Filter {

	private static final Logger LOG = LoggerFactory.getLogger(JwtSecurityFilter.class);

	@Value("${spring.cloud.client.hostname}")
	private String hostName;
	@Value("${spring.application.name}")
	private String appName;

	@Autowired
	private JwtTools jwtTools;

	public JwtSecurityFilter() {
		super();
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// EMPTY
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		LOG.debug("Invoking doFilter");
		final HttpServletRequest httpRequest = (HttpServletRequest) request;

		String connectedId = jwtTools.extractUserIdFromHeaderRequest(httpRequest);
		final String canal = jwtTools.extractChannelFromHeaderRequest(httpRequest);
		final String media = jwtTools.extractMediaFromHeaderRequest(httpRequest);

		try {
			// get customer number connected

			if (Channel.API.getValue().equals(canal)) {
				connectedId = "";

			}

			LOG.debug("connected Id received = {}", connectedId);

			LOG.debug("canal received = {}", canal);

			LOG.debug("media received = {}", media);

			if (!Optional.ofNullable(canal).isPresent()) {
				SecurityContextHolder.clearContext();
				ConnectedManager.clear();
			}

			if (!Optional.ofNullable(connectedId).isPresent()) {
				SecurityContextHolder.clearContext();
				ConnectedManager.clear();

			}

			if (Optional.ofNullable(connectedId).isPresent() && Optional.ofNullable(canal).isPresent()) {

				LOG.debug("Validation of header is OK. ");
				final Context context = new Context(connectedId, canal, media);
				ConnectedManager.set(context);

				final UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken("", null, Collections.emptyList());
				SecurityContextHolder.getContext().setAuthentication(authentication);
			}
		} catch (final Exception e) {
			LOG.error(e.getMessage(), e);
			SecurityContextHolder.clearContext();
			ConnectedManager.clear();
		} finally {
			// continue through the filter chain
			chain.doFilter(request, response);
			SecurityContextHolder.clearContext();
			ConnectedManager.clear();
		}
	}

	@Override
	public void destroy() {
		// EMPTY
	}

}
