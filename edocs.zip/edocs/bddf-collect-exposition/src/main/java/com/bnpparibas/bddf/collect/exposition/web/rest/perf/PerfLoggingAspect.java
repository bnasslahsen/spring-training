package com.bnpparibas.bddf.collect.exposition.web.rest.perf;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;

@ConditionalOnProperty(name = "param.logForPerf")
@Aspect
@Component
public class PerfLoggingAspect {

	private static final Logger LOG = LoggerFactory.getLogger(PerfLoggingAspect.class);

	@Pointcut("execution(* com.bnpparibas.bddf.collect.exposition.web.rest.client.*.*(..) ) || execution(* com.bnpparibas.bddf.collect.exposition.web.rest.collab.*.*(..) )")
	public void businessMethods() {
	}

	@Around("businessMethods()")
	public Object profile(ProceedingJoinPoint pjp) throws Throwable {
		final long start = System.currentTimeMillis();
		final Object output = pjp.proceed();
		final long elapsedTime = System.currentTimeMillis() - start;
		LoggerHelper.logForPerfTest(LOG, " Temps pour exposition." + pjp.getSignature().getName() + " : " + elapsedTime + " ms");
		return output;
	}
}
