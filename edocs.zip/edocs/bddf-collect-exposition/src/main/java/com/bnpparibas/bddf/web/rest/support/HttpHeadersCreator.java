package com.bnpparibas.bddf.web.rest.support;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;

/**
 * Utility class to provide alert information in response HTTP header
 * 
 * @author b49835
 *
 */
public final class HttpHeadersCreator {

	private static final Logger LOG = LoggerFactory.getLogger(HttpHeadersCreator.class);

	private HttpHeadersCreator() {
	}

	private static HttpHeaders createAlert(String message, String param) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("X-bddf-alert", message);
		headers.add("X-bddf-params", param);
		return headers;
	}

	public static HttpHeaders createWarning(String param) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("X-bddf-alert", "bddf.warning");
		headers.add("X-bddf-params", param);
		return headers;
	}

	public static HttpHeaders createEntityCreationAlert(String entityName, String param) {
		return createAlert("bddf." + entityName + ".created", param);
	}

	public static HttpHeaders createEntityUpdateAlert(String entityName, String param) {
		return createAlert("bddf." + entityName + ".updated", param);
	}

	public static HttpHeaders createEntityDeletionAlert(String entityName, String param) {
		return createAlert("bddf." + entityName + ".deleted", param);
	}

	public static HttpHeaders createFailureAlert(String entityName, String errorKey, String defaultMessage) {
		LOG.error("Creation of alert in HTTP response header, {}", defaultMessage);
		HttpHeaders headers = new HttpHeaders();
		headers.add("X-bddf-error", "error." + errorKey);
		headers.add("X-bddf-params", entityName);
		return headers;
	}
}
