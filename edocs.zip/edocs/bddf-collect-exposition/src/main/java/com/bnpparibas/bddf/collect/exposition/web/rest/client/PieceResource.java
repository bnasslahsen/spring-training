package com.bnpparibas.bddf.collect.exposition.web.rest.client;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.validation.SmartValidator;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDataDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDataMiniatureDTO;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActions;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.PieceRecivedFormat;
import com.bnpparibas.bddf.errors.TechnicalException;
import com.bnpparibas.bddf.rest.ConnectedManager;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.hystrix.exception.HystrixRuntimeException;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * REST controller for managing piece ressource.
 */
@RestController
@RequestMapping("/api/collects")
public class PieceResource {

	private static final Logger LOGGER = LoggerFactory.getLogger(PieceResource.class);

	private final PieceActions pieceActions;

	@Autowired
	private SmartValidator validator;

	public PieceResource(PieceActions pieceActions) {
		this.pieceActions = pieceActions;
	}

	/**
	 * GET /collects/{idCollect}/types/{idType}/pieces/{idPiece} : get piece by ID.
	 *
	 * @param idCollect
	 *            Collect ID.
	 *
	 * @param idType
	 *            Type ID.
	 *
	 * @param idPiece
	 *            Piece ID.
	 *
	 * @param encoded
	 *            encoded
	 *
	 * @return the ResponseEntity with status 200 (OK) and the piece in body
	 *
	 */
	@GetMapping(value = "/client/{idCollect}/types/{idType}/pieces/{idPiece}")
	@ApiOperation(notes = "Ce service permet de récupérer la pièce préalablement chargée", value = "getPiece", nickname = "getPieceClient")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée"),
			@ApiResponse(code = 503, message = "Service momentanément indisponible") })
	public ResponseEntity<Object> getPiece(@ApiParam(value = "UUID de la collecte souhaitée") @PathVariable UUID idCollect, @ApiParam(value = "UUID du type souhaité") @PathVariable UUID idType,
			@ApiParam(value = "UUID de la piéce souhaitée") @PathVariable UUID idPiece, @ApiParam(value = "UUID de la pièce à récupérer") @RequestParam(defaultValue = "true") boolean encoded) {
		ResponseEntity<Object> response;
		final PieceDataDTO piece = pieceActions.getPieceData(idCollect, idType, idPiece, ConnectedManager.get());
		if (piece == null) {
			response = new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
		} else if (encoded) {
			response = new ResponseEntity<>(piece, HttpStatus.OK);
		} else {
			final HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Disposition", "inline; filename=" + Optional.ofNullable(piece.getLabel()).map(p -> p.replaceAll("[^\\p{ASCII}]", "")).orElse("fileName"));
			headers.add("Content-Type", piece.getContentType());
			response = new ResponseEntity<>(piece.getContent().array(), headers, HttpStatus.OK);
		}
		return response;
	}

	@GetMapping(value = "/client/{idCollect}/types/{idType}/pieces/{idPiece}/thumbnail")
	@ApiOperation(notes = "Ce service permet de récupérer une miniature d'une pièce préalablement chargée", nickname = "getThumbnailClient", value = "getPieceThumbnail")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<PieceDataMiniatureDTO> getThumbnail(@ApiParam(value = "UUID de la collecte souhaitée") @PathVariable UUID idCollect, @ApiParam(value = "UUID du type souhaité") @PathVariable UUID idType,
			@ApiParam(value = "UUID de la piéce souhaitée") @PathVariable UUID idPiece) {
		return new ResponseEntity<>(pieceActions.getThumbnail(idCollect, idType, idPiece, ConnectedManager.get()), HttpStatus.OK);
	}

	@PostMapping(value = "/client/{idCollect}/types/{idType}/pieces", produces = "application/json")
	@ApiOperation(notes = "Ce service permet de charger des pièces pour un type donné :\n - Pièces numériques : charger des pièces temporairement.\n - Pièces papiers : signaler une pièce reçue au format papier.\n\nIl fournit en retour l’ID de la pièce chargée.", value = "addPiece", nickname = "addPieceClient")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<UUID> addPiece(@ApiParam(value = "UUID de la collecte souhaitée") @PathVariable UUID idCollect, @ApiParam(value = "UUID du type souhaité") @PathVariable UUID idType,
			@ApiParam(value = "Pièce souhaitée:\n - Piéce numérique: {\"label\":\"page1.jpg\", \"receivedFormat\":\"NUM\"}\n - Pièce papier (ex au status=VA): { \"label\":\"page1.jpg\", \"receivedFormat\":\"PAP\", \"status\":\"VA\" }") @RequestPart String piece,
			@RequestPart(required = false) MultipartFile file) throws IOException, NoSuchMethodException, MethodArgumentNotValidException, MissingServletRequestParameterException, InterruptedException {

		final ObjectMapper objectMapper = new ObjectMapper();
		try {
			final PieceDTO pieceDTO = objectMapper.readValue(piece, PieceDTO.class);
			final BindingResult result = new BeanPropertyBindingResult(pieceDTO, PieceDTO.class.getSimpleName());
			if (!Optional.ofNullable(file).isPresent() && PieceRecivedFormat.NUM.name().equals(pieceDTO.getReceivedFormat())) {
				throw new MissingServletRequestParameterException("file", MultipartFile.class.getSimpleName());
			}
			if (Channel.isClient(ConnectedManager.get().getCanal())) {
				pieceDTO.setOwnerId(ConnectedManager.get().getCustomerId());
				validator.validate(pieceDTO, result, PieceDTO.Client.class);
			}
			if (result.hasErrors()) {
				final int pieceResult = 2;
				throw new MethodArgumentNotValidException(new MethodParameter(this.getClass().getDeclaredMethod("addPiece", UUID.class, UUID.class, String.class, MultipartFile.class), pieceResult), result);
			}

			UUID pieceId;
			if (PieceRecivedFormat.PAP.name().equals(pieceDTO.getReceivedFormat())) {
				pieceId = pieceActions.addPiece(idCollect, idType, pieceDTO, null, null, ConnectedManager.get());
			} else {
				pieceDTO.setSize(file.getSize());
				pieceId = pieceActions.addPiece(idCollect, idType, pieceDTO, ByteBuffer.wrap(file.getBytes()), file.getContentType(), ConnectedManager.get());
			}
			return new ResponseEntity<>(pieceId, HttpStatus.CREATED);
		} catch (final JsonProcessingException e) {
			throw new HttpMessageNotReadableException(e.getMessage(), e);
		} catch (final HystrixRuntimeException e) {
			LOGGER.info("Exception :", e);
			throw new TechnicalException(HttpStatus.INTERNAL_SERVER_ERROR, CollectErrorConstants.ERR_TECH_TIMEOUT, "", "");
		}
	}

	@PutMapping(value = "/client/{idCollect}/types/{idType}/pieces", produces = "application/json")
	@ApiOperation(notes = "Ce service permet pour un type donné :\n - d’envoyer au système d’archivage GDN les pièces temporaires préalablement chargées via le addPiece\n - de supprimer des pièces existantes (les pièces non restituées sont supprimées)", value = "updatePieces", nickname = "updatePiecesClient")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<Boolean> updatePieces(@ApiParam(value = "UUID de la collecte souhaitée") @PathVariable UUID idCollect, @ApiParam(value = "UUID du type souhaité") @PathVariable UUID idType,
			@ApiParam(value = "Détails de la ressource pieces d'un type (ou sous-type) de la collecte (tel que restitué dans le getCollectById) en modifiant les statuts souhaités") @RequestBody @Valid List<PieceDTO> pieces) throws InterruptedException {
		try {
			pieceActions.updatePieces(idCollect, idType, pieces, ConnectedManager.get());
			return new ResponseEntity<>(true, HttpStatus.OK);
		} catch (final HystrixRuntimeException e) {
			LOGGER.info("Exception :", e);
			throw new TechnicalException(HttpStatus.INTERNAL_SERVER_ERROR, CollectErrorConstants.ERR_TECH_TIMEOUT, "", "");
		}

	}

	@DeleteMapping(value = "/client/{idCollect}/types/{idType}/pieces/{idPiece}", produces = "application/json")
	@ApiOperation(notes = "Ce service permet de supprimer une pièce", value = "deletePiece", nickname = "deletePieceClient")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<Boolean> deletePiece(@ApiParam(value = "UUID de la collecte souhaitée") @PathVariable UUID idCollect, @ApiParam(value = "UUID du type souhaité") @PathVariable UUID idType,
			@ApiParam(value = "UUID de la pièce à supprimer") @PathVariable UUID idPiece) {
		pieceActions.deletePiece(idCollect, idType, idPiece, ConnectedManager.get());
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.NO_CONTENT);
	}

}
