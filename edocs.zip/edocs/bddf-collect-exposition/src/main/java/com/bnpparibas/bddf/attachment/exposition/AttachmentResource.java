package com.bnpparibas.bddf.attachment.exposition;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bnpparibas.bddf.attachment.application.AttachmentAction;
import com.bnpparibas.bddf.attachment.application.AttachmentDTO;
import com.bnpparibas.bddf.attachment.application.ResponseAttachmentDTO;
import com.bnpparibas.bddf.attachment.application.ResponsePutAttachementDTO;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.errors.TechnicalException;
import com.bnpparibas.bddf.rest.ConnectedManager;
import com.bnpparibas.bddf.web.rest.errors.ErrorMessage;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * REST controller for managing attachment ressource.
 */
@RestController
@RequestMapping("/api/attachments")
public class AttachmentResource {

	private static final Logger LOG = LoggerFactory.getLogger(AttachmentResource.class);

	@Autowired
	private AttachmentAction attachmentAction;

	@PostMapping(value = "/", produces = "application/json")
	@ApiOperation(notes = "Ce service permet de charger une pièce jointe à la volée", nickname = "addAttachment", value = "addAttachment")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles", response = ErrorMessage.class), @ApiResponse(code = 401, message = "Non  authentifié") })
	@ResponseStatus(code = HttpStatus.CREATED)
	public ResponseEntity<ResponseAttachmentDTO> addAttachment(@ApiParam(value = "sending Application Code (Ex : AP12247)}") @RequestParam(required = true) String sendingApplicationCode, @RequestPart(required = false) MultipartFile file) {
		UUID uuid;
		try {
			final AttachmentDTO attachmentDTO = new AttachmentDTO(ConnectedManager.get().getCustomerId(), ConnectedManager.get().getCanal(), sendingApplicationCode, file.getOriginalFilename(), file.getContentType(), file.getSize(),
					ByteBuffer.wrap(file.getBytes()));
			uuid = attachmentAction.addAttachment(attachmentDTO, ConnectedManager.get());
			return new ResponseEntity<>(new ResponseAttachmentDTO(uuid.toString()), HttpStatus.CREATED);
		} catch (final IOException e) {
			LOG.error(e.getMessage(), e);
			throw new TechnicalException(HttpStatus.BAD_REQUEST, CollectErrorConstants.ERR_TECH_ADD_ATTACHMENT_BAD_FORMAT);
		}
	}

	@PutMapping(value = "/{idAttachment}/validate", produces = "application/json")
	@ApiOperation(notes = "Ce service permet de valider une pièce jointe:\n - d’envoyer au système d’archivage le fichier temporaires préalablement chargées via  addAttachment\n", value = "validateAttachment", nickname = "validateAttachment")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié") })
	@ResponseStatus(code = HttpStatus.CREATED)

	public ResponseEntity<ResponsePutAttachementDTO> validateAttachment(@ApiParam(value = "UUID de fichier") @PathVariable UUID idAttachment) {
		final String idGDN = attachmentAction.validateAttachment(idAttachment, ConnectedManager.get());
		return new ResponseEntity<>(new ResponsePutAttachementDTO(idGDN), HttpStatus.CREATED);
	}

	@DeleteMapping(value = "/{idAttachment}")
	@ApiOperation(notes = "Ce service permet de supprimer une pièce jointe temporaire:\n", value = "deleteAttachment", nickname = "deleteAttachment")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles", response = ErrorMessage.class), @ApiResponse(code = 401, message = "Non  authentifié") })
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public ResponseEntity<Void> deleteAttachment(@ApiParam(value = "UUID de fichier") @PathVariable UUID idAttachment) {
		attachmentAction.deleteAttachment(idAttachment, ConnectedManager.get());
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	@GetMapping(value = "/{idAttachment}")
	@ApiOperation(notes = "Ce service permet de récupérer une pièce jointe temporaire:\n", value = "getAttachment", nickname = "getAttachment")
	@ApiResponses({ @ApiResponse(code = 200, message = "Attachment in binary format"), @ApiResponse(code = 404, message = "Attachment Not found", response = ErrorMessage.class),
			@ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles", response = ErrorMessage.class), @ApiResponse(code = 401, message = "Non  authentifié"),

	})
	@ResponseStatus(code = HttpStatus.OK)
	public ResponseEntity<Object> getAttachment(@ApiParam(value = "UUID de fichier") @PathVariable UUID idAttachment, @ApiParam(value = "UUID de l'attachement à récupérer") @RequestParam(defaultValue = "true") boolean encoded) {
		ResponseEntity<Object> response;
		final AttachmentDTO attachmentDTO = attachmentAction.getAttachment(idAttachment, ConnectedManager.get());
		if (attachmentDTO == null) {
			response = new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
		} else if (encoded) {
			response = new ResponseEntity<>(attachmentDTO, HttpStatus.OK);
		} else {
			final HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Disposition", "inline; filename=" + attachmentDTO.getFileName());
			headers.add("Content-Type", attachmentDTO.getMimeType());
			response = new ResponseEntity<>(attachmentDTO.getFile().array(), headers, HttpStatus.OK);
		}
		return response;

	}

}
