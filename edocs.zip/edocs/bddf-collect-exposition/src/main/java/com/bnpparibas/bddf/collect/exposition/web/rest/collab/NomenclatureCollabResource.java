package com.bnpparibas.bddf.collect.exposition.web.rest.collab;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bnpparibas.bddf.collect.application.service.nomenclature.NomenclatureAction;
import com.bnpparibas.bddf.collect.application.service.nomenclature.NomenclatureDto;
import com.bnpparibas.bddf.rest.ConnectedManager;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/api/collects")
public class NomenclatureCollabResource {

	@Autowired
	NomenclatureAction nomenclatureAction;

	@ApiOperation(notes = "Ce service retourne la nomenclature du genre et des pays", value = "getNomenclature", nickname = "getNomenclature")
	@GetMapping(value = "/collab/nomenclature", produces = "application/json")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<List<NomenclatureDto>> getNomenclature() {
		final List<NomenclatureDto> nomenCla = nomenclatureAction.getNomemclature(ConnectedManager.get());
		return new ResponseEntity<>(nomenCla, HttpStatus.OK);

	}

}
