package com.bnpparibas.bddf.collect.exposition.web.rest.client;

import java.util.UUID;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.collect.application.dto.UpdateDTO;
import com.bnpparibas.bddf.collect.application.service.type.TypeActions;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.errors.TechnicalException;
import com.bnpparibas.bddf.rest.ConnectedManager;
import com.netflix.hystrix.exception.HystrixRuntimeException;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * REST controller for managing type ressource.
 */
@RestController
@RequestMapping("/api/collects")
public class TypeRessource {

	private static final Logger LOGGER = LoggerFactory.getLogger(TypeRessource.class);

	private final TypeActions typeActions;

	public TypeRessource(TypeActions typeActions) {
		this.typeActions = typeActions;
	}

	/**
	 * GET /collects/{idCollect}/types/{idType} : get type by ID.
	 *
	 * @param idCollect
	 *            Collect ID.
	 *
	 * @param idType
	 *            Type ID.
	 *
	 * @return the ResponseEntity with status 200 (OK) and the type in body
	 *
	 */
	@GetMapping(value = "/client/{idCollect}/types/{idType}", produces = "application/json")
	@ApiOperation(notes = "Ce service permet de récupérer l’ensemble des métadonnées d'un type et de ces pièces", value = "getType", nickname = "getTypeClient")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<SubTypeDTO> getType(@ApiParam(value = "UUID de la collecte souhaitée") @PathVariable UUID idCollect, @ApiParam(value = "UUID du type souhaité") @PathVariable UUID idType) {
		final SubTypeDTO type = typeActions.getType(idCollect, idType, ConnectedManager.get());
		return new ResponseEntity<>(type, HttpStatus.OK);
	}

	@PostMapping(value = "/client/{idCollect}/families/{idFamily}/types", produces = "application/json")
	@ApiOperation(notes = "Ce service permet d'ajouter un type dans une famille", nickname = "addTypeClient", value = "addType")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<UpdateDTO> addType(@ApiParam(value = "UUID de la collecte souhaitée") @PathVariable UUID idCollect, @ApiParam(value = "UUID de la famille souhaitée") @PathVariable UUID idFamily,
			@ApiParam(value = "Détails de la ressource type de la collecte") @RequestBody @Valid TypeDTO type) throws InterruptedException {
		try {
			typeActions.addType(idCollect, idFamily, type, ConnectedManager.get());
			return new ResponseEntity<>(UpdateDTO.now(), HttpStatus.OK);
		} catch (final HystrixRuntimeException e) {
			LOGGER.info("Exception : ", e);
			throw new TechnicalException(HttpStatus.INTERNAL_SERVER_ERROR, CollectErrorConstants.ERR_TECH_TIMEOUT, "", "");
		}
	}
	
	@DeleteMapping(value = "/client/{idCollect}/types/{idType}", produces = "application/json")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	@ApiOperation(notes = "Ce service permet de supprimer un type", nickname = "deleteType", value = "deleteType")
	public ResponseEntity<Boolean> deleteType(@ApiParam(value = "UUID de la collecte souhaitée") @PathVariable UUID idCollect, @ApiParam(value = "UUID du type souhaité") @PathVariable UUID idType) {
		typeActions.deleteType(idCollect, idType, ConnectedManager.get());
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.NO_CONTENT);
	}

}
