package com.bnpparibas.bddf.collect.exposition.web.rest.client;

import java.util.Set;
import java.util.UUID;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.CollectDTO;
import com.bnpparibas.bddf.collect.application.dto.CollectDetailsDTO;
import com.bnpparibas.bddf.collect.application.service.collect.CollectActions;
import com.bnpparibas.bddf.collect.exposition.web.constants.SwaggerDoc;
import com.bnpparibas.bddf.rest.ConnectedManager;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * REST controller for managing collect ressource.
 */
@RestController
@RequestMapping("/api/collects")
public class CollectResource {

	private final CollectActions collectAction;

	public CollectResource(CollectActions collectService) {
		this.collectAction = collectService;
	}

	/**
	 * GET /collects/{id} : get collect by ID.
	 *
	 * @param id
	 *            Collect id.
	 *
	 * @return the ResponseEntity with status 200 (OK) and the collect in body
	 */
	@ApiOperation(notes = "Ce service retourne l'ensemble du contenu d'une collecte donnée", value = "getCollectById", nickname = "getCollectByIdClient")
	@GetMapping(value = "/client/{id}", produces = "application/json")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<CollectAllDetailsDTO> getCollectById(@ApiParam(value = "UUID de la collecte souhaitée") @PathVariable UUID id) {
		final CollectAllDetailsDTO collect = collectAction.getCollect(id, ConnectedManager.get());
		return new ResponseEntity<>(collect, HttpStatus.OK);
	}

	@PostMapping(value = "/client", produces = "application/json")
	@ApiOperation(notes = SwaggerDoc.NOTES_COLLECT_POST, nickname = SwaggerDoc.NICKNAME_COLLECT_POST_CLIENT, value = "saveCollect")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<CollectDTO> saveCollect(@RequestBody(required = true) @Valid CollectAllDetailsDTO collect) {
		final CollectDTO newCollect = collectAction.saveCollect(collect, ConnectedManager.get());
		return new ResponseEntity<>(newCollect, HttpStatus.CREATED);
	}

	/**
	 * GET /collects :
	 *
	 * @return the ResponseEntity with status 200 (OK) and the list of collects in body
	 */
	@GetMapping(value = "/client", produces = "application/json")
	@ApiOperation(notes = "Ce service permet à une application métier de rechercher l’ensemble des collectes correspondant à un client pour un code parcours donné", nickname = "getCollectsClient", value = "getCollects")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<Set<CollectDetailsDTO>> getCollects() {
		final Set<CollectDetailsDTO> collects = collectAction.getCollectsClient(ConnectedManager.get());
		return new ResponseEntity<>(collects, HttpStatus.OK);
	}

}
