package com.bnpparibas.bddf.collect.exposition.web.rest.client;

import java.util.UUID;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.service.family.FamilyActions;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.errors.TechnicalException;
import com.bnpparibas.bddf.rest.ConnectedManager;
import com.netflix.hystrix.exception.HystrixRuntimeException;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/api/collects")
public class FamilyResource {

	private static final Logger LOGGER = LoggerFactory.getLogger(FamilyResource.class);

	private final FamilyActions familyActions;

	public FamilyResource(FamilyActions familyActions) {
		this.familyActions = familyActions;
	}

	@PostMapping(value = "/client/{idCollect}/families", consumes = "application/json")
	@ApiOperation(notes = "Ce service permet d'ajouter une  famille à une collecte existante", nickname = "addFamilyClient", value = "addFamily")
	@ApiResponses({ @ApiResponse(code = 400, message = "Erreur dans la requête. Se référer à la listes des erreurs possibles"), @ApiResponse(code = 401, message = "Non  authentifié"), @ApiResponse(code = 403, message = "Authentification non authorisée") })
	public ResponseEntity<UUID> addFamily(@ApiParam(value = "UUID de la collecte souhaitée") @PathVariable UUID idCollect, @ApiParam(value = "Détails de la ressource famille à ajouter dans la collecte") @RequestBody @Valid FamilyDTO family)
			throws InterruptedException {
		try {
			final UUID idFamilyCreated = familyActions.addFamily(idCollect, family, ConnectedManager.get());
			return new ResponseEntity<>(idFamilyCreated, HttpStatus.CREATED);
		} catch (final HystrixRuntimeException e) {
			LOGGER.info("Exception : ", e);
			throw new TechnicalException(HttpStatus.INTERNAL_SERVER_ERROR, CollectErrorConstants.ERR_TECH_TIMEOUT, "", "");
		}
	}

}
