package com.bnpparibas.bddf.collect.exposition.web.constants;

public final class SwaggerDoc {

	public static final String NOTES_COLLECT_POST = "Ce service permet de créer une collecte. Il fournit en retour l’ID de la collecte créée au format UUID.";
	public static final String NICKNAME_COLLECT_POST_COLLAB = "saveCollectCollab";
	public static final String NICKNAME_COLLECT_POST_CLIENT = "saveCollectClient";

	private SwaggerDoc() {
		super();
	}

}
