package com.bnpparibas.bddf.collect.infrastructure.event.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
public class EventMarshaller {

	@Bean
	@Primary
	public Jaxb2Marshaller getMarshaller() {
		final Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setPackagesToScan("com.bnp.schema.em.event", "com.bnpp.pcc.cretopicevent", "com.bnp.schema.edoc.collectevent", "com.bnp.schema.edoc.pieceevent", "com.bnp.schema.edoc.typeevent");
		final Map<String, Object> map = new HashMap<>();
		map.put("jaxb.formatted.output", true);
		jaxb2Marshaller.setMarshallerProperties(map);
		return jaxb2Marshaller;
	}

	@Bean(value = "marshallerDigicom")
	public Jaxb2Marshaller getMarshallerDigicom() {
		final Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setPackagesToScan("com.bnp.schema.edoc.notification");
		final Map<String, Object> map = new HashMap<>();
		map.put("jaxb.formatted.output", true);
		jaxb2Marshaller.setMarshallerProperties(map);
		return jaxb2Marshaller;
	}
}
