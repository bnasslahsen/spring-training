package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.entity.ClientNotificationEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.TypeEntity;

@Repository
public interface ClientNotificationJpaRepository extends JpaRepository<ClientNotificationEntity, String> {

	@Query("select n from ClientNotificationEntity n where typeId = :typeId")
	ClientNotificationEntity findByTypeId(@Param("typeId") String typeId);

	@Query("select count(n) from ClientNotificationEntity n where typeId = :typeId")
	int count(@Param("typeId") String typeId);

	@Query("select distinct(n.collectId) from ClientNotificationEntity n where notificationNumber = 0 or (notificationNumber < :maxNotifications and lastNotificationDate <= :relaunchDate)")
	List<String> findByNotificationNumber(@Param("maxNotifications") Integer maxNotifications, @Param("relaunchDate") Timestamp relaunchDate);
	

	@Modifying
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	@Query(value = "UPDATE client_notification SET notification_number = notification_number+1, last_notification_date = :lastNotificationDate  WHERE collect_id = :collectId and notification_number < :maxNotifications", nativeQuery = true)
	void updateNotificationNumber(@Param("collectId") String collectId, @Param("maxNotifications") Integer maxNotifications, @Param("lastNotificationDate") Timestamp lastNotificationDate);

	@Query("select t from TypeEntity t, ClientNotificationEntity cN where cN.collectId=:collectId and cN.typeId=t.id")
	List<TypeEntity> findTypesbyCollectId(@Param("collectId") String collectId);
	
	

}
