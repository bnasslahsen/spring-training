package com.bnpparibas.bddf.collect.infrastructure.entity;

import java.sql.Timestamp;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.domain.Persistable;

@Entity
@Table(name = "AMI_BATCH")
public class AmiBatchEntity implements java.io.Serializable, Persistable<String> {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String typeId;
	private String journeyCode;
	private Timestamp initialSent;
	private Timestamp lastSent;
	private String status;
	private boolean isNew;

	@Id
	@Column(name = "TYPE_ID", unique = true, nullable = false, length = 100)
	public String getTypeId() {
		return typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	@Column(name = "INITIAL_SENT")
	public Timestamp getInitialSent() {
		return Optional.ofNullable(this.initialSent).map(d -> (Timestamp) d.clone()).orElse(null);

	}

	public void setInitialSent(Timestamp initialSent) {
		this.initialSent = Optional.ofNullable(initialSent).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Column(name = "LAST_SENT")
	public Timestamp getLastSent() {
		return Optional.ofNullable(this.lastSent).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setLastSent(Timestamp lastSent) {
		this.lastSent = Optional.ofNullable(lastSent).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Column(name = "STATUS", length = 5)
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "JOURNEY_CODE", length = 6)
	public String getJourneyCode() {
		return journeyCode;
	}

	public void setJourneyCode(String journeyCode) {
		this.journeyCode = journeyCode;
	}

	@Override
	@Transient
	public String getId() {
		return typeId;
	}
	
	@Override
	@Transient
	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}


}
