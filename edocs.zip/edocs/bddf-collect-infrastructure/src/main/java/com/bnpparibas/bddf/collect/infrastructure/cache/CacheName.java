package com.bnpparibas.bddf.collect.infrastructure.cache;

public final class CacheName {
	public static final String NOMENCLATURES = "nomenclatures";

	private CacheName() {
		throw new IllegalAccessError("constant class");
	}
	
}
