package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.MDC;
import org.springframework.batch.core.Step;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.support.CompositeItemWriter;
import org.springframework.batch.item.support.PassThroughItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.infrastructure.entity.DocReferenceEntity;

@Component
public class BatchPurgeDocReference extends AbstractBatchPurge {

	@Autowired
	private PurgeDocReferenceWriter purgeDocReferenceWriter;
	@Autowired
	private PurgeDocReferenceItemReader purgeDocReferenceReader;

	@Value("${app.name}")
	protected String appName;

	int deletedPieces;

	public BatchPurgeDocReference() {
		super("COLLECT_PURGE_DOC_REFERENCE", BATCH_PIECE);
	}

	@Override
	protected Step step(Map<String, Long> res) {
		return stepBuilderFactory.get("step1_" + getBatchName()).<DocReferenceEntity, DocReferenceEntity> chunk(getBatchSize()).reader(reader()).processor(new PassThroughItemProcessor<DocReferenceEntity>()).writer(writer(res)).build();
	}

	protected ItemWriter<DocReferenceEntity> writer(Map<String, Long> res) {
		final ItemWriter<DocReferenceEntity> countPiecesItemWriter = new CountPiecesReferenceItemWriter(res);
		final CompositeItemWriter<DocReferenceEntity> compositeItemWriter = new CompositeItemWriter<>();
		final List<ItemWriter<? super DocReferenceEntity>> delegates = new ArrayList<>();
		delegates.add(purgeDocReferenceWriter);
		delegates.add(countPiecesItemWriter);
		compositeItemWriter.setDelegates(delegates);
		return compositeItemWriter;
	}

	protected ItemReader<DocReferenceEntity> reader() {
		return purgeDocReferenceReader;
	}

	@Scheduled(cron = "${purge.piece-reference.cron}")
	@Override
	public void scheduledStart() {
		MDC.put("UserID", getBatchName());
		MDC.put("AppName", appName);
		startBatch();
	}
}
