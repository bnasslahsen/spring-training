package com.bnpparibas.bddf.collect.infrastructure.entity;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.domain.Persistable;

@Entity
@Table(name = "piece")
public class PieceEntity implements java.io.Serializable, Persistable<String> {

	private static final long serialVersionUID = 1L;
	private String id;
	private TypeEntity type;
	private String label;
	private String ownerId;
	private String employeeId;
	private String channel;
	private Timestamp acquisitionDate;
	private Timestamp updateDate;
	private Long size;
	private String receivedFormat;
	private String status;
	private String idDocGdn;
	private String rejectionReason;
	private String rejectionComment;
	private String state;
	private String contentType;
	private String referencePieceId;
	private String referenceGdnId;
	private String statusControl;
	private String listTypesJmc;
	private String typeControl;
	private String extractionControl;
	private String coherenceControl;
	private Integer controlIterationAchieved;
	private Integer deletedNas;
	private Integer position;
	private String rejectionProfile;
	private Set<IndexePiece> indexePieces = new HashSet<IndexePiece>(0);
	private String statusSentToGdn;
	private Boolean displayCommentToClient;
	private boolean isNew;

	public PieceEntity() {
	}

	public PieceEntity(String id, TypeEntity type) {
		this.id = id;
		this.type = type;
	}

	public PieceEntity(String id, TypeEntity type, String label, String ownerId, String employeeId, String channel, Timestamp acquisitionDate, Timestamp updateDate, long sizePiece, String receivedFormat, String status, String idDocGdn,
			String rejectionReason, String rejectionComment, String state, String contentType, String referencePieceId, String referenceGdnId, String statusControl, String typesJmc, String typeControl, String extractionControl, String coherenceControl,
			Integer controlIterationAchieved, Integer position) {
		this.id = id;
		this.type = type;
		this.label = label;
		this.ownerId = ownerId;
		this.employeeId = employeeId;
		this.channel = channel;
		this.acquisitionDate = Optional.ofNullable(acquisitionDate).map(d -> (Timestamp) d.clone()).orElse(null);
		this.updateDate = Optional.ofNullable(updateDate).map(d -> (Timestamp) d.clone()).orElse(null);
		this.size = sizePiece;
		this.receivedFormat = receivedFormat;
		this.status = status;
		this.idDocGdn = idDocGdn;
		this.rejectionReason = rejectionReason;
		this.rejectionComment = rejectionComment;
		this.state = state;
		this.contentType = contentType;
		this.referencePieceId = referencePieceId;
		this.referenceGdnId = referenceGdnId;
		this.statusControl = statusControl;
		this.listTypesJmc = typesJmc;
		this.typeControl = typeControl;
		this.extractionControl = extractionControl;
		this.coherenceControl = coherenceControl;
		this.controlIterationAchieved = controlIterationAchieved;
		this.position = position;
	}

	@Override
	@Id
	@Column(name = "ID", unique = true, nullable = false, length = 100)
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TYPE_ID", nullable = false)
	public TypeEntity getType() {
		return this.type;
	}

	public void setType(TypeEntity type) {
		this.type = type;
	}

	@Column(name = "LABEL", length = 200)
	public String getLabel() {
		return this.label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	@Column(name = "OWNER_ID", length = 17)
	public String getOwnerId() {
		return this.ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	@Column(name = "EMPLOYEE_ID", length = 17)
	public String getEmployeeId() {
		return this.employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	@Column(name = "CHANNEL", length = 3)
	public String getChannel() {
		return this.channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	@Column(name = "ACQUISITION_DATE")
	public Timestamp getAcquisitionDate() {
		return Optional.ofNullable(this.acquisitionDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setAcquisitionDate(Timestamp acquisitionDate) {
		this.acquisitionDate = Optional.ofNullable(acquisitionDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Column(name = "UPDATE_DATE")
	public Timestamp getUpdateDate() {
		return Optional.ofNullable(this.updateDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = Optional.ofNullable(updateDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Column(name = "SIZE_PIECE", precision = 22, scale = 0)
	public Long getSize() {
		return this.size;
	}

	public void setSize(Long sizePiece) {
		this.size = sizePiece;
	}

	@Column(name = "RECEIVED_FORMAT", length = 45)
	public String getReceivedFormat() {
		return this.receivedFormat;
	}

	public void setReceivedFormat(String receivedFormat) {
		this.receivedFormat = receivedFormat;
	}

	@Column(name = "STATUS", length = 2)
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "ID_DOC_GDN", length = 45)
	public String getIdDocGdn() {
		return this.idDocGdn;
	}

	public void setIdDocGdn(String idDocGdn) {
		this.idDocGdn = idDocGdn;
	}

	@Column(name = "REJECTION_REASON", length = 200)
	public String getRejectionReason() {
		return this.rejectionReason;
	}

	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}

	@Column(name = "REJECTION_COMMENT", length = 200)
	public String getRejectionComment() {
		return this.rejectionComment;
	}

	public void setRejectionComment(String rejectionComment) {
		this.rejectionComment = rejectionComment;
	}

	@Column(name = "STATE", length = 10)
	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Column(name = "CONTENT_TYPE", length = 50)
	public String getContentType() {
		return this.contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	@Column(name = "REFERENCE_PIECE_ID", length = 50)
	public String getReferencePieceId() {
		return this.referencePieceId;
	}

	public void setReferencePieceId(String referencePieceId) {
		this.referencePieceId = referencePieceId;
	}

	@Column(name = "REFERENCE_GDN_ID", length = 50)
	public String getReferenceGdnId() {
		return this.referenceGdnId;
	}

	public void setReferenceGdnId(String referenceGdnId) {
		this.referenceGdnId = referenceGdnId;
	}

	@Column(name = "STATUS_CONTROL", length = 5)
	public String getStatusControl() {
		return this.statusControl;
	}

	public void setStatusControl(String statusControl) {
		this.statusControl = statusControl;
	}

	@Column(name = "TYPES_JMC", length = 200)
	public String getListTypesJmc() {
		return this.listTypesJmc;
	}

	public void setListTypesJmc(String typesJmc) {
		this.listTypesJmc = typesJmc;
	}

	@Column(name = "TYPE_CONTROL", length = 20)
	public String getTypeControl() {
		return this.typeControl;
	}

	public void setTypeControl(String typeControl) {
		this.typeControl = typeControl;
	}

	@Column(name = "EXTRACTION_CONTROL", length = 20)
	public String getExtractionControl() {
		return this.extractionControl;
	}

	public void setExtractionControl(String extractionControl) {
		this.extractionControl = extractionControl;
	}

	@Column(name = "COHERENCE_CONTROL", length = 20)
	public String getCoherenceControl() {
		return this.coherenceControl;
	}

	public void setCoherenceControl(String coherenceControl) {
		this.coherenceControl = coherenceControl;
	}

	@Column(name = "CONTROL_ITERATION_ACHIEVED")
	public Integer getControlIterationAchieved() {
		return this.controlIterationAchieved;
	}

	public void setControlIterationAchieved(Integer controlIterationAchieved) {
		this.controlIterationAchieved = controlIterationAchieved;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "piece", cascade = CascadeType.ALL)
	public Set<IndexePiece> getIndexePieces() {
		return this.indexePieces;
	}

	public void setIndexePieces(Set<IndexePiece> indexePieces) {
		this.indexePieces = indexePieces;
	}

	@Column(name = "DELETED_NAS")
	public Integer getDeletedNas() {
		return deletedNas;
	}

	public void setDeletedNas(Integer deletedNas) {
		this.deletedNas = deletedNas;
	}

	@Column(name = "POSITION")
	public Integer getPosition() {
		return position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	@Override
	@Transient
	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	@Column(name = "REJECTION_PROFILE", length = 2)
	public String getRejectionProfile() {
		return rejectionProfile;
	}

	public void setRejectionProfile(String rejectionProfile) {
		this.rejectionProfile = rejectionProfile;
	}

	@Column(name = "STATUS_SENT_TO_GDN", length = 50)
	public String getStatusSentToGdn() {
		return statusSentToGdn;
	}

	public void setStatusSentToGdn(String statusSentToGdn) {
		this.statusSentToGdn = statusSentToGdn;
	}

	@Column(name = "DISPLAY_COMMENT_CLIENT", precision = 1, scale = 0)
	public Boolean getDisplayCommentToClient() {
		return displayCommentToClient;
	}

	public void setDisplayCommentToClient(Boolean displayCommentToClient) {
		this.displayCommentToClient = displayCommentToClient;
	}

}
