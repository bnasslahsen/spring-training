package com.bnpparibas.bddf.collect.infrastructure.nas;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.UUID;

public interface ThumbnailService {

	public void writeThumbnailPdf(UUID id, ByteBuffer bytes) throws IOException;

	public void writeImageThumbnail(UUID id, ByteBuffer bytes) throws IOException;
}
