package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.sql.Timestamp;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bnpp.jdf.connector.IJdfConnectorConstants;
import com.bnpp.jdf.connector.exception.AbstractConnectorException;
import com.bnpp.jdf.deletedoc.query.DeleteDocI;
import com.bnpparibas.bddf.collect.infrastructure.entity.DocReferenceEntity;
import com.bnpparibas.bddf.collect.infrastructure.gdn.service.GdnService;

@Component
public class PurgeDocReferenceWriter implements ItemWriter<DocReferenceEntity> {
	private static final Logger LOG = LoggerFactory.getLogger(PurgeDocReferenceWriter.class);
	@Value("${app.name}")
	private String appName;
	@Autowired
	private GdnService gdnService;
	@Autowired
	private PurgeUtils docReferenceUtils;
	int deletedPieces;

	@Override
	public void write(List<? extends DocReferenceEntity> docRefs) throws Exception {

		docRefs.forEach(docRef -> {
			if (StringUtils.isNotEmpty(docRef.getReferenceGdnId())) {
				deleteDocGdn(docRef.getReferenceGdnId(), docRef.getId().getOwnerId());
				deletedPieces++;
			}
			docReferenceUtils.delete(docRef);
		});

	}

	public static Timestamp getExpirationDateFromMonthsRetention(Integer months) {
		final ZonedDateTime todayMidnight = ZonedDateTime.now(ZoneId.systemDefault()).truncatedTo(ChronoUnit.DAYS);
		return Timestamp.from(todayMidnight.plusMonths(-months).toInstant());
	}

	private void deleteDocGdn(String idDocGdn, String ownerId) {
		final DeleteDocI deleteDocI = new DeleteDocI();
		deleteDocI.setDocumentId(idDocGdn);
		deleteDocI.setOwningApplication(appName);

		final Map<String, String> params = new HashMap<>();

		params.put(IJdfConnectorConstants.CALLING_USER, Optional.ofNullable(ownerId).orElse("999999"));

		try {
			gdnService.deleteDoc(deleteDocI, params);
		} catch (final AbstractConnectorException e) {
			LOG.error(e.getMessage(), e);
		}
	}
}
