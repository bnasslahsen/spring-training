package com.bnpparibas.bddf.collect.infrastructure.event.process;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import javax.jms.Message;
import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Repository;
import org.springframework.xml.transform.StringResult;

import com.bnp.schema.edoc.notification.ObjectFactory;
import com.bnp.schema.edoc.notification.Variable;
import com.bnp.schema.edoc.notification.VariablesList;
import com.bnpparibas.bddf.collect.domain.event.ClientNotificationSender;
import com.bnpparibas.bddf.collect.domain.event.type.TypeReceivedType;
import com.bnpparibas.bddf.collect.domain.notification.NotificationDIGICOMMessage;
import com.bnpparibas.bddf.collect.domain.notification.NotificationMessage;
import com.bnpparibas.bddf.collect.domain.notification.enums.ConstantNotification;
import com.bnpparibas.bddf.collect.domain.notification.enums.RecipientChannelNotification;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.infrastructure.entity.EventEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.TimestampUtils;
import com.bnpparibas.bddf.collect.infrastructure.repository.EventRepository;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.RepositoryImpl
@Repository
public class ClientNotificationSenderImpl implements ClientNotificationSender {
	private static final Logger LOGGER = LoggerFactory.getLogger(ClientNotificationSenderImpl.class);

	@Autowired
	private EventRepository eventRepository;

	@Value("${jms.mq.queue-notification}")
	private String destination;

	@Value("${jms.mq.queue-DIGICOM}")
	private String destinationDiGiCOM;

	@Autowired
	@Qualifier(value = "marshallerDigicom")
	private Jaxb2Marshaller marshaller;

	private final JmsTemplate jmsTemplate;

	public ClientNotificationSenderImpl(JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}

	@Override
	public void sendNotification(List<NotificationMessage> notificationMessages, String collectId) {
		LOGGER.info("Sending notification : secured Message");
		Optional.ofNullable(notificationMessages).ifPresent(messages -> messages.forEach(securedMessage -> {

			final EventEntity eventToSend = new EventEntity(securedMessage.getNotificationMessage(), getEventType(securedMessage.getPushRecipientCanal()).getLabel(), TimestampUtils.getNow(), "TO_SEND", collectId, "", "", Channel.API.getValue(), "9999",
					null);
			eventToSend.setId(UUID.randomUUID().toString());
			eventToSend.setReplays(0);
			eventRepository.saveEvent(eventToSend);
			try {
				// send Message
				sendMessage(securedMessage);
				// update event in database
				eventToSend.setStatus("SENT");
				eventRepository.saveEvent(eventToSend);
			} catch (final JmsException e) {
				LOGGER.error(e.getMessage(), e);
			}
		}));
	}

	@Override
	public void sendNotificationDIGICOM(List<NotificationDIGICOMMessage> notificationDIGICOMmessages, String collectId) {
		LOGGER.info("Sending Notification DIGICOM Message : xml Message");
		Optional.ofNullable(notificationDIGICOMmessages).ifPresent(messages -> messages.forEach(securedMessage -> {
			final String xml = jaxbObjectToXML(securedMessage);
			final EventEntity eventToSend = new EventEntity(xml, TypeReceivedType.NOTIFIED_DIGICOM.getLabel(), TimestampUtils.getNow(), "TO_SEND", collectId, "", "", Channel.SPIRIT.getValue(), "9999", null);
			eventToSend.setId(UUID.randomUUID().toString());
			eventToSend.setReplays(0);
			eventRepository.saveEvent(eventToSend);
			try {
				jmsTemplate.convertAndSend(destinationDiGiCOM, xml);
				eventToSend.setStatus("SENT");
				eventRepository.saveEvent(eventToSend);
			} catch (final JmsException e) {
				LOGGER.error(e.getMessage(), e);
			}
		}));
	}

	public void sendMessage(NotificationMessage notification) {
		jmsTemplate.send(destination, session -> {
			LOGGER.debug("SenderId: {} : IdRP: {} : IdTypeMessage: {} : PushRecipientCanal: {} : " + notification.getSenderId(), notification.getIdRP(), notification.getTypeMessageId(), notification.getPushRecipientCanal());
			final Message message = session.createTextMessage(notification.getNotificationMessage());
			return message;
		});
	}

	public void sendMessageDigicom(NotificationDIGICOMMessage notification) {
		final String xml = jaxbObjectToXML(notification);
		jmsTemplate.convertAndSend(destinationDiGiCOM, xml);
	}

	private TypeReceivedType getEventType(String recipientCanal) {
		TypeReceivedType evenType = TypeReceivedType.NOTIFIED_EMAIL;
		if (RecipientChannelNotification.MESSAGE_SECUR_BNP.getCode().equals(recipientCanal)) {
			evenType = TypeReceivedType.NOTIFIED_MS;
		}
		return evenType;
	}

	private String jaxbObjectToXML(NotificationDIGICOMMessage notification) {
		final JAXBElement<com.bnp.schema.edoc.notification.Message> jaxbElement = new JAXBElement(new QName("bnp.com/schema/edoc/notification", ConstantNotification.MESSAGE_DIGICOM.getLibelle()), com.bnp.schema.edoc.notification.Message.class, null,
				constructMessage(notification));
		final StringResult result = new StringResult();
		marshaller.marshal(jaxbElement, result);
		return result.toString().replace(ConstantNotification.REMOVE_NAMESPACE.getLibelle(), "");
	}

	private com.bnp.schema.edoc.notification.Message constructMessage(NotificationDIGICOMMessage notification) {
		final ObjectFactory objectFatory = new ObjectFactory();
		final com.bnp.schema.edoc.notification.Message msg = objectFatory.createMessage();
		BeanUtils.copyProperties(notification, msg);
		final Map<String, String> map = notification.getMapVariablesList();
		final VariablesList varList = new VariablesList();
		for (final Map.Entry<String, String> entry : map.entrySet()) {
			final Variable variable = new Variable();
			variable.setName(entry.getKey());
			variable.setValue(entry.getValue());
			varList.getVariable().add(variable);
		}
		msg.setVariablesList(varList);
		return msg;
	}
}
