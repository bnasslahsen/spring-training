package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.IntStream;

import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.helper.DateUtil;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnService;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.validation.ValidationPiece;
import com.bnpparibas.bddf.collect.domain.piece.validation.ValidationPieceService;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.infrastructure.batch.distributed.AbstractBatch;
import com.bnpparibas.bddf.email.BddfMailMessage;
import com.bnpparibas.bddf.email.MailService;
import com.bnpparibas.bddf.rest.Context;

@Component
@Transactional(transactionManager = "transactionManagerDB")
public class CollectValidationPieces extends AbstractBatch {

	private static final String LIGNE = "--------------|--------------------------------------|--------------------------------------|--------------------------------------|------------------------------|--------|\n";
	private static final String TITRE = "Code parcours |           Id collecte                |             Id type                  |           Id collecte                |      Date d'acquisition      | Statut |\n";

	private static final DateTimeFormatter FORMATTER_DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	@Autowired
	private PieceGdnService pieceGdnService;
	@Autowired
	private CollectRepository collectRepository;
	@Autowired
	private TypeRepository typeRepository;
	@Autowired
	private MailService mailService;
	@Autowired
	private Environment environment;
	@Autowired
	private PieceRepository pieceRepository;
	@Autowired
	private ValidationPieceService validationPieceService;
	@Value("${app.name}")
	private String appName;

	private int nbPieces;
	private int nbPiecesOk;
	private int nbPiecesKo;
	private int nbPiecesKo1;
	private int nbPiecesKo2;
	private int nbPiecesKo3;

	public CollectValidationPieces() {
		super("COLLECT_VALIDATION_PIECES");
	}

	@Override
	public void execute() {
		validatePieces();
	}

	public void sendEmail(StringBuilder emailBodyKo1, StringBuilder emailBodyKo2, StringBuilder emailBodyKo3) {
		if (nbPieces > 0) {
			final StringBuilder emailBody = new StringBuilder();
			emailBody.append("Bonjour,\n\n");
			if (nbPiecesKo == 0) {
				emailBody.append(nbPiecesOk);
				emailBody.append(" pièce(s) est/sont envoyée(s) avec succès en GDN.\n");
			} else {
				emailBody.append("L'envoi en GDN de " + nbPiecesKo + " pièce(s) a échoué parmis " + nbPieces + " pièce(s) traitée(s).\n");
			}
			if (nbPiecesKo1 > 0) {
				emailBody.append("\nVoici les pièces qui ont échoué pour la première fois :\n");
				emailBody.append(LIGNE);
				emailBody.append(TITRE);
				emailBody.append(LIGNE);
				emailBody.append(emailBodyKo1);
			}
			if (nbPiecesKo2 > 0) {
				emailBody.append("\nVoici les pièces qui ont échoué pour la deuxième fois :\n");
				emailBody.append(LIGNE);
				emailBody.append(TITRE);
				emailBody.append(LIGNE);
				emailBody.append(emailBodyKo2);
			}
			if (nbPiecesKo3 > 0) {
				emailBody.append("\nVoici les pièces qui ont échoué pour la troisième fois, elles ne seront plus rejouées par ce batch :\n");
				emailBody.append(LIGNE);
				emailBody.append(TITRE);
				emailBody.append(LIGNE);
				emailBody.append(emailBodyKo3);
			}
			final BddfMailMessage mailMessage = new BddfMailMessage(environment.getProperty("rejoue-pieces-ec.mail.sender"), new String[] { environment.getProperty("rejoue-pieces-ec.mail.recipient") }, getEmailSubject(), emailBody.toString(), false);
			mailService.sendMail(mailMessage);
		}
	}

	private String getEmailSubject() {
		final StringBuilder subject = new StringBuilder(256);
		subject.append(nbPiecesKo);
		subject.append(" - Erreur rejoue pièce VA_EC/RC_EC - ");
		subject.append(FORMATTER_DATE.format(LocalDateTime.ofInstant(new Date().toInstant(), ZoneId.systemDefault())));
		final String host = environment.getProperty("spring.cloud.client.hostname");
		final String hostParse = Optional.ofNullable(host).map(v -> v.contains(".") ? v.substring(0, v.indexOf('.')) : v).orElse("");
		subject.append(hostParse);
		return subject.toString();
	}

	private void validatePieces() {
		// Renvoie à GDN des pièces qui n'ont pas pu passer à j-1, j-2 et j-3 pour vérification
		emptyVars();
		final StringBuilder emailBodyKo1 = new StringBuilder();
		final StringBuilder emailBodyKo2 = new StringBuilder();
		final StringBuilder emailBodyKo3 = new StringBuilder();

		IntStream.rangeClosed(1, 3).forEach(i -> validationPieceService.getByCreationDate(calculDate(DateUtil.todayMidnight(), i)).forEach(validationPiece -> {
			final int tries = validationPiece.getTriesNumber();
			if (tries < 3) {
				final Collect collect = collectRepository.findOne(UUID.fromString(validationPiece.getCollectId()));
				final Type type = typeRepository.findOne(UUID.fromString(validationPiece.getCollectId()), UUID.fromString(validationPiece.getTypeId()));
				final Piece piece = pieceRepository.getPiece(UUID.fromString(validationPiece.getCollectId()), UUID.fromString(validationPiece.getTypeId()), UUID.fromString(validationPiece.getPieceId()));
				final boolean isSaveOnGdnOk = pieceGdnService.updateTypeOnGdnForBatch(collect, type, piece, validationPiece.getRemovedPieces(), new Context(validationPiece.getUserId(), validationPiece.getChannel()), validationPiece.getNewTypeStatus(),
						validationPiece.getUserId(), validationPiece.getChannel(), Instant.now());
				if (isSaveOnGdnOk) {
					nbPiecesOk++;
					validationPieceService.delete(validationPiece);
				} else {
					fillEmailBody(emailBodyKo1, emailBodyKo2, emailBodyKo3, validationPiece, tries, collect);
				}
				nbPieces++;
			}
		}));
		sendEmail(emailBodyKo1, emailBodyKo2, emailBodyKo3);
	}

	private void fillEmailBody(final StringBuilder emailBodyKo1, final StringBuilder emailBodyKo2, final StringBuilder emailBodyKo3, ValidationPiece validationPiece, final int tries, final Collect collect) {
		validationPiece.setTriesNumber(tries + 1);
		validationPieceService.update(validationPiece);
		switch (validationPiece.getTriesNumber()) {
		case 1:
			addToEmailBody(emailBodyKo1, validationPiece, collect.getJourneyCode());
			nbPiecesKo1++;
			break;
		case 2:
			addToEmailBody(emailBodyKo2, validationPiece, collect.getJourneyCode());
			nbPiecesKo2++;
			break;
		case 3:
			addToEmailBody(emailBodyKo3, validationPiece, collect.getJourneyCode());
			nbPiecesKo3++;
			break;
		default:
			break;
		}
		nbPiecesKo++;
	}

	public static Date calculDate(Date currentDate, int days) {
		final GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(currentDate);
		calendar.add(Calendar.DAY_OF_WEEK, -days);
		return calendar.getTime();
	}

	private void addToEmailBody(StringBuilder email, ValidationPiece validationPiece, String journeyCode) {
		email.append(journeyCode);
		email.append("        | ");
		email.append(validationPiece.getCollectId());
		email.append(" | ");
		email.append(validationPiece.getTypeId());
		email.append(" | ");
		email.append(validationPiece.getPieceId());
		email.append(" | ");
		email.append(validationPiece.getAquisitionDate());
		email.append(" | ");
		email.append(validationPiece.getStatus());
		email.append("  |\n");
		email.append(LIGNE);
	}

	@Scheduled(cron = "${rejoue-pieces-ec.cron}")
	@Override
	public void scheduledStart() {
		MDC.put("UserID", getBatchName());
		MDC.put("AppName", appName);
		startBatch();

	}

	public void emptyVars() {
		nbPieces = 0;
		nbPiecesOk = 0;
		nbPiecesKo = 0;
		nbPiecesKo1 = 0;
		nbPiecesKo2 = 0;
		nbPiecesKo3 = 0;
	}

	public PieceGdnService getPieceGdnService() {
		return pieceGdnService;
	}

	public void setPieceGdnService(PieceGdnService pieceGdnService) {
		this.pieceGdnService = pieceGdnService;
	}

	public CollectRepository getCollectRepository() {
		return collectRepository;
	}

	public void setCollectRepository(CollectRepository collectRepository) {
		this.collectRepository = collectRepository;
	}

	public TypeRepository getTypeRepository() {
		return typeRepository;
	}

	public void setTypeRepository(TypeRepository typeRepository) {
		this.typeRepository = typeRepository;
	}

	public MailService getMailService() {
		return mailService;
	}

	public void setMailService(MailService mailService) {
		this.mailService = mailService;
	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

}
