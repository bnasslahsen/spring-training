package com.bnpparibas.bddf.collect.infrastructure.entity;

import java.sql.Timestamp;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.domain.Persistable;

@Entity
@Table(name = "event")
public class EventEntity implements java.io.Serializable, Persistable<String> {

	private static final long serialVersionUID = 1L;
	private String id;
	private String content;
	private String nomenclatureRef;
	private Timestamp dtSent;
	private String status;
	private boolean isNew;
	private String collectId;
	private String typeId;
	private String pieceId;
	private String media;
	private String channel;
	private String userId;
	private int replays;

	public EventEntity() {
	}

	public EventEntity(String id) {
		this.id = id;
	}

	public EventEntity(String content, String nomenclatureRef, Timestamp dtSent, String status, String collectId, String typeId, String media, String channel, String userId, String pieceId) {
		this.content = content;
		this.nomenclatureRef = nomenclatureRef;
		this.dtSent = Optional.ofNullable(dtSent).map(d -> (Timestamp) d.clone()).orElse(null);
		this.status = status;
		this.collectId = collectId;
		this.typeId = typeId;
		this.media = media;
		this.channel = channel;
		this.userId = userId;
		this.pieceId = pieceId;
	}

	@Override
	@Id
	@Column(name = "ID", unique = true, nullable = false, length = 200)
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Lob
	@Column(name = "CONTENT")
	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Column(name = "NOMENCLATURE_REF")
	public String getNomenclatureRef() {
		return this.nomenclatureRef;
	}

	public void setNomenclatureRef(String nomenclatureRef) {
		this.nomenclatureRef = nomenclatureRef;
	}

	@Column(name = "DT_SENT")
	public Timestamp getDtSent() {
		return Optional.ofNullable(this.dtSent).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setDtSent(Timestamp dtSent) {
		this.dtSent = Optional.ofNullable(dtSent).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Column(name = "STATUS", length = 10)
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	@Transient
	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	@Column(name = "COLLECT_ID", length = 200)
	public String getCollectId() {
		return this.collectId;
	}

	public void setCollectId(String collectId) {
		this.collectId = collectId;
	}

	@Column(name = "TYPE_ID", length = 200)
	public String getTypeId() {
		return this.typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	@Column(name = "MEDIA", length = 3)
	public String getMedia() {
		return this.media;
	}

	public void setMedia(String media) {
		this.media = media;
	}

	@Column(name = "CHANNEL", length = 3)
	public String getChannel() {
		return this.channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	@Column(name = "USER_ID", length = 17)
	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Column(name = "REPLAYS")
	public int getReplays() {
		return replays;
	}

	public void setReplays(int replays) {
		this.replays = replays;
	}

	@Column(name = "PIECE_ID", length = 200)
	public String getPieceId() {
		return pieceId;
	}

	public void setPieceId(String pieceId) {
		this.pieceId = pieceId;
	}

}
