package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bnpparibas.bddf.collect.infrastructure.entity.NomenclatureEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.NomenclatureIdEntity;

@Repository
public interface NomenclatureJpaRepository extends JpaRepository<NomenclatureEntity, NomenclatureIdEntity> {


}
