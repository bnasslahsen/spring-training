package com.bnpparibas.bddf.collect.infrastructure.batch.piece;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditEvent;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.infrastructure.batch.distributed.AbstractBatch;
import com.bnpparibas.bddf.collect.infrastructure.batch.purge.BatchPurgeDocReference;
import com.bnpparibas.bddf.collect.infrastructure.entity.CollectEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.PieceEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.TypeEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.PieceJpaRepository;
import com.bnpparibas.bddf.rest.Context;

@Component
@Transactional(transactionManager = "transactionManagerDB")
public class PieceDpEcToDpErrBatch extends AbstractBatch {

	@Autowired
	private PieceJpaRepository pieceJpaRepository;

	@Autowired
	private Environment environment;

	@Autowired
	private CollectEventHandler collectEventHandler;

	private static final Logger LOG = LoggerFactory.getLogger(BatchPurgeDocReference.class);

	@Autowired
	private AuditGenerator auditGenerator;

	public PieceDpEcToDpErrBatch() {
		super("COLLECTE_PIECE_DP_EC_TO_DP_ERR");
	}

	// Disabe for MEP 26/11 @Scheduled(cron = "${piece.dpec-to-dperr.cron}")
	@Override
	public void scheduledStart() {
		startBatch();
	}

	@Override
	@Transactional
	public void execute() {
		final long acquisitionDelay = Long.parseLong(environment.getProperty("piece.dpec-to-dperr.acquisition-delay"));
		final Timestamp acquisitionDate = new Timestamp((new Date()).getTime() - acquisitionDelay);
		final List<PieceEntity> dpEcPieces = pieceJpaRepository.findByDateAndStatus(acquisitionDate, PieceStatus.DP_EC.getLabel());
		dpEcPieces.forEach(pieceEntity -> {
			// Changement statut pièce DP_EC -> DP_ERR
			pieceJpaRepository.updateStatus(PieceStatus.DP_ERR.getLabel(), pieceEntity.getId());
			// Envoie Audit_Event
			final TypeEntity typeEntity = pieceEntity.getType();
			final CollectEntity collectEntity = typeEntity.getFamily().getCollect();
			final AuditEvent auditEvent = auditGenerator.newAudit(new Context("", Channel.API.getValue(), ""), AuditValue.ERROR_VERS_GDN, typeEntity.getLabel()).setIdCollect(UUID.fromString(collectEntity.getId()))
					.setJourneyCode(collectEntity.getJourneyCode()).setIdType(UUID.fromString(typeEntity.getId()));
			collectEventHandler.sendAuditEvent(auditEvent);
			LOG.info("Batch passage des pièces DP_EC -> DP_err : pieceId " + pieceEntity.getId());
		});
	}

}
