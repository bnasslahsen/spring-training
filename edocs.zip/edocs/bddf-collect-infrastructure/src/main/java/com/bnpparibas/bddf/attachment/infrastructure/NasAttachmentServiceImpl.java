package com.bnpparibas.bddf.attachment.infrastructure;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bnpparibas.bddf.attachment.domain.NasAttachmentService;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.errors.TechnicalException;

@Service
public class NasAttachmentServiceImpl implements NasAttachmentService {

	@Value("${files.attachment.path}")
	private String fileDirectory;

	@Override
	public void add(UUID id, String contentType, ByteBuffer bytes) {
		try {
			Files.write(piecePath(id), bytes.array());
		} catch (final Exception e) {
			throw new TechnicalException(CollectErrorConstants.ERR_NAS_WRITE, e);
		}
	}

	private Path piecePath(UUID id) {
		return Paths.get(fileDirectory + id.toString());
	}

	@Override
	public void delete(UUID idAttachment) {
		try {
			Files.delete(piecePath(idAttachment));
		} catch (final Exception e) {
			throw new TechnicalException(CollectErrorConstants.ERR_NAS_DELETE, e);
		}

	}

	@Override
	public ByteBuffer get(UUID idAttachment) {
		try {
			return ByteBuffer.wrap(Files.readAllBytes(piecePath(idAttachment)));
		} catch (final IOException e) {
			throw new TechnicalException(CollectErrorConstants.ERR_NAS_READ_PIECE, e);
		}

	}

}
