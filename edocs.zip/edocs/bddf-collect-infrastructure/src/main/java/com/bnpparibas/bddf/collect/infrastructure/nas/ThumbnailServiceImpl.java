package com.bnpparibas.bddf.collect.infrastructure.nas;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Component
public class ThumbnailServiceImpl implements ThumbnailService {

	private static final float MAX_WIDTH = 250;
	private static final float MAX_HEIGHT = 200;

	private final String fileDirectory;

	public ThumbnailServiceImpl(Environment environment) {
		this.fileDirectory = environment.getProperty("files.path");

	}

	private Path piecePathThumbnail(UUID id) {
		return Paths.get(new StringBuilder().append(fileDirectory).append(id.toString()).append("_thumbnail").toString());
	}

	@Override
	@HystrixCommand(commandKey = "generateThumbnail")
	public void writeImageThumbnail(UUID id, ByteBuffer bytes) throws IOException {
		final BufferedImage img1 = ImageIO.read(new ByteArrayInputStream(bytes.array()));
		final float width = img1.getWidth(null);
		final float height = img1.getHeight(null);
		final float rmax = Math.max(width / MAX_WIDTH, height / MAX_HEIGHT);
		final int w = (int) (width / rmax);
		final int h = (int) (height / rmax);
		final Image img = img1.getScaledInstance(w, h, Image.SCALE_SMOOTH);
		final BufferedImage bufferedImage = new BufferedImage(w, h, BufferedImage.TYPE_USHORT_565_RGB);
		final Graphics2D bGr = bufferedImage.createGraphics();
		bGr.drawImage(img, 0, 0, null);
		bGr.dispose();
		final ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(bufferedImage, "jpg", baos);
		Files.write(piecePathThumbnail(id), baos.toByteArray());

	}

	@Override
	@HystrixCommand(commandKey = "generateThumbnail")
	public void writeThumbnailPdf(UUID id, ByteBuffer bytes) throws IOException {
		PDDocument document = null;
		try {
			document = PDDocument.load(bytes.array());
			final PDFRenderer renderer = new PDFRenderer(document);
			final float scale = Math.min(MAX_WIDTH / document.getPage(0).getBBox().getWidth(), MAX_HEIGHT / document.getPage(0).getBBox().getHeight());
			final ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write(renderer.renderImage(0, scale), "jpg", baos);
			Files.write(piecePathThumbnail(id), baos.toByteArray());
		} finally {
			if (document != null) {
				document.close();
			}
		}
	}

}
