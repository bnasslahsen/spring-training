package com.bnpparibas.bddf.collect.infrastructure.batch.monitoring;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.bnpparibas.bddf.collect.infrastructure.entity.ViewMonitoringDailyEntity;
import com.bnpparibas.bddf.collect.infrastructure.repository.ViewAuditDailyRepository;
import com.bnpparibas.bddf.email.BddfMailMessage;
import com.bnpparibas.bddf.email.MailService;

@Component
@Transactional(transactionManager = "transactionManagerDB")
public class MonitoringDailyBatch extends AbstractBatchMonitoring {

	private static final int LAST_HOUR = 23;
	private static final int LAST_MINUTE = 59;
	private static final int LAST_SECOND = 59;
	private static final int LAST_MILLISECOND = 999;
	private static final int INIT_SIZE = 256;
	private static final int COUNTER_0 = 0;
	private static final int COUNTER_1 = 1;
	private static final int COUNTER_2 = 2;
	private static final int COUNTER_3 = 3;
	private static final int COUNTER_4 = 4;
	private static final int COUNTER_5 = 5;
	private static final int COUNTER_6 = 6;

	private static final Logger LOG = LoggerFactory.getLogger(MonitoringDailyBatch.class);


	private static final DateTimeFormatter FORMATTER_DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	@Autowired
	private ViewAuditDailyRepository viewAuditDailyRepository;
	@Autowired
	private MailService mailService;
	@Autowired
	private Environment environment;
	@Autowired
	private TemplateEngine emailTemplateEngine;

	public MonitoringDailyBatch() {
		super("COLLECT_MONITORING_DAY");
	}

	@Scheduled(cron = "${monitoring.cron.daily}")
	@Override
	public void scheduledStart() {
		startBatch();
	}

	@Override
	public void execute() {
		try {
			final List<ViewMonitoringDailyEntity> monitorings = viewAuditDailyRepository.findAll();

			final BddfMailMessage mailMessage = buildMailMessage(monitorings);
			mailService.sendMail(mailMessage);
		} catch (final Exception e) {
			LOG.error(e.getMessage(), e);
		}
	}

	public static Date beginOfDay(Date date) {
		final Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);

		return cal.getTime();
	}

	public static Date endOfDay(Date date) {
		final Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		cal.set(Calendar.HOUR_OF_DAY, LAST_HOUR);
		cal.set(Calendar.MINUTE, LAST_MINUTE);
		cal.set(Calendar.SECOND, LAST_SECOND);
		cal.set(Calendar.MILLISECOND, LAST_MILLISECOND);

		return cal.getTime();
	}

	public BddfMailMessage buildMailMessage(final List<ViewMonitoringDailyEntity> monitorings) {
		final List<Counter> counters = new ArrayList<>();
		final Context context = new Context();
		final ArrayList<LineDaily> lines = new ArrayList<>();
		final ArrayList<LineDaily> totalList = new ArrayList<>();
		counters.add(new Counter());
		counters.add(new Counter());
		counters.add(new Counter());
		counters.add(new Counter());
		counters.add(new Counter());
		counters.add(new Counter());
		counters.add(new Counter());

		monitorings.stream().filter(mon -> !"Total".equals(mon.getJourneyCode())).collect(Collectors.groupingBy(ViewMonitoringDailyEntity::getJourneyCode)).forEach((jouneyCode, list) -> lines.add(toMailLine(jouneyCode, list, counters)));

		final StringBuilder object = new StringBuilder(INIT_SIZE);
		object.append("E-DOC DAILY MONITORING ");
		object.append(FORMATTER_DATE.format(LocalDateTime.ofInstant(new Date().toInstant(), ZoneId.systemDefault())));
		object.append(" >  CO : ");
		object.append(counters.get(COUNTER_0).getCount());
		object.append(" - DP : ");
		object.append(counters.get(COUNTER_1).getCount());
		object.append(" - VA : ");
		object.append(counters.get(COUNTER_3).getCount());
		object.append(" - RF : ");
		object.append(counters.get(COUNTER_4).getCount());
		object.append(" - ");
		final String host = environment.getProperty("spring.cloud.client.hostname");
		final String hostParse = extractHost(host);
		object.append(hostParse);

		final LineDaily total = new LineDaily();
		total.setLibelle("Total");
		total.setCollecte(String.valueOf(counters.get(COUNTER_0).getCount()));
		total.setDepotNum(String.valueOf(counters.get(COUNTER_1).getCount()));
		total.setAcceptNum(String.valueOf(counters.get(COUNTER_2).getCount()));
		total.setValidNum(String.valueOf(counters.get(COUNTER_3).getCount()));
		total.setRefusNum(String.valueOf(counters.get(COUNTER_4).getCount()));
		total.setValidPap(String.valueOf(counters.get(COUNTER_5).getCount()));
		total.setRefusPap(String.valueOf(counters.get(COUNTER_6).getCount()));
		totalList.add(total);
		
		context.setVariable("lines", lines);
		context.setVariable("totalList", totalList);
		String emailString = emailTemplateEngine.process("daily.html", context);
		
		return new BddfMailMessage(environment.getProperty("monitoring.mail.sender"), new String[] { environment.getProperty("monitoring.mail.recipient") }, object.toString(), emailString, true);
	}

	private LineDaily toMailLine(String journeyCode, List<ViewMonitoringDailyEntity> list, List<Counter> counters) {
		final ViewMonitoringDailyEntity viewAuditDaily = list.get(0);

		final LineDaily line = new LineDaily();
		
		line.setParcours(journeyCode);
		line.setLibelle(viewAuditDaily.getProductLabel());
		
		final long nbCollectCreate = viewAuditDaily.getCollectDay();
		counters.get(COUNTER_0).increase(nbCollectCreate);
		line.setCollecte(String.valueOf(nbCollectCreate));

		final long nbPieceNumAdd = viewAuditDaily.getDepotDayNum();
		counters.get(COUNTER_1).increase(nbPieceNumAdd);
		line.setDepotNum(String.valueOf(nbPieceNumAdd));

		final long nbPieceNumAccepted = viewAuditDaily.getAcceptDayNum();
		counters.get(COUNTER_2).increase(nbPieceNumAccepted);
		line.setAcceptNum(String.valueOf(nbPieceNumAccepted));
		
		final long nbPieceNumValid = viewAuditDaily.getValidDayNum();
		counters.get(COUNTER_3).increase(nbPieceNumValid);
		line.setValidNum(String.valueOf(nbPieceNumValid));

		final long nbPieceNumRf = viewAuditDaily.getRefusDayNum();
		counters.get(COUNTER_4).increase(nbPieceNumRf);
		line.setRefusNum(String.valueOf(nbPieceNumRf));

		final long nbPiecePapValid = viewAuditDaily.getValidDayPap();
		counters.get(COUNTER_5).increase(nbPiecePapValid);
		line.setValidPap(String.valueOf(nbPiecePapValid));

		final long nbPiecePapRf = viewAuditDaily.getRefusDayPap();
		counters.get(COUNTER_6).increase(nbPiecePapRf);
		line.setRefusPap(String.valueOf(nbPiecePapRf));

		return line;
	}

	public MailService getMailService() {
		return mailService;
	}

	public void setMailService(MailService mailService) {
		this.mailService = mailService;
	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

}
