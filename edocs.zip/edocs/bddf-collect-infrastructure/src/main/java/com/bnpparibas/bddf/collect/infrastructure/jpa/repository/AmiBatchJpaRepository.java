package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bnpparibas.bddf.collect.infrastructure.entity.AmiBatchEntity;

@Repository
public interface AmiBatchJpaRepository extends JpaRepository<AmiBatchEntity, String> {

	@Query("select aB from AmiBatchEntity aB where status in :status")
	List<AmiBatchEntity> findByStatus(@Param("status") Collection<String> status);

}
