package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.infrastructure.batch.distributed.AbstractBatch;
import com.bnpparibas.bddf.collect.infrastructure.entity.AuditEventEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.TimestampUtils;
import com.bnpparibas.bddf.collect.infrastructure.nas.PieceNasService;
import com.bnpparibas.bddf.collect.infrastructure.repository.EventRepository;

public abstract class AbstractBatchPurge extends AbstractBatch {

	private static final Logger LOG = LoggerFactory.getLogger(AbstractBatchPurge.class);

	protected static final String MSG_DELETED_PIECE = "Pièces supprimées";
	protected static final String MSG_DELETED_NAS_PIECE = "Pièces supprimées du NAS";
	protected static final String MSG_DELETED_REF_PIECE = "Pièces de référence supprimées";
	protected static final String MSG_COLLECT_ABANDONED = "Collecte abandonnée";
	protected static final String MSG_COLLECT_CLOSED = "Collecte clôturée";

	protected static final String BATCH_COLLECT = "COLLECT";
	protected static final String BATCH_PIECE = "PIECE";
	protected static final String FIND_COLLECTS_BEFORE_AND_BY_STATUS = "findByCreationDateLessThanEqualAndStatus";

	@Value("${collect-abandon.ttl.month}")
	private Integer collectAbandonTTLMonth;
	@Value("${collect-abandon.ttl.day}")
	private Integer collectAbandonTTLDay;
	@Value("${purge.collect-ab.ttl.month}")
	private Integer purgeCollectAbTTLMonth;
	@Value("${purge.collect-ab.ttl.day}")
	private Integer purgeCollectAbTTLDay;
	@Value("${purge.collect-cl.ttl.month}")
	private Integer purgeCollectClTTLMonth;
	@Value("${purge.collect-cl.ttl.day}")
	private Integer purgeCollectClTTLDay;
	@Value("${purge.piece-tp-dp.ttl.month}")
	private Integer purgePieceTpTTLMonth;
	@Value("${purge.piece-tp-dp.ttl.day}")
	private Integer purgePieceTpTTLDay;
	private String batchType;
	@Value("${purge.collect-ab.batchSize}")
	private int batchSize;

	@Autowired
	protected PieceNasService pieceNasDao;
	@Autowired
	protected StepBuilderFactory stepBuilderFactory;
	@Value("${app.name}")
	protected String appName;
	@Autowired
	private EventRepository eventRepository;
	@Autowired
	private MessageSource messageSource;

	@Autowired
	protected JobBuilderFactory jobBuilderFactory;
	@Autowired
	private JobLauncher jobLauncher;
	private static final String OK_AB = "OK_AB";
	private static final String OK_CL = "OK_CL";

	public AbstractBatchPurge(String batchName, String batchType) {
		super(batchName);
		this.batchType = batchType;
	}

	protected void sendMonitoring(AuditValue audit, String auditType, Long nb) {
		final AuditEventEntity monitoring = new AuditEventEntity();
		monitoring.setDateCreation(TimestampUtils.getNow());
		monitoring.setCodeAP(appName);
		monitoring.setCodeAT(appName);
		monitoring.setIdTech(UUID.randomUUID().toString());
		monitoring.setCodeEvent(audit.getCode());
		monitoring.setMessage(messageSource.getMessage(audit.getLabel(), new String[] { auditType, nb.toString() }, Locale.FRENCH));
		monitoring.setChannel(Channel.API.getValue());
		switch (batchType) {
		case BATCH_COLLECT:
			monitoring.setTotalCollect((int) nb.longValue());
			break;
		case BATCH_PIECE:
			monitoring.setTotalPieces((int) nb.longValue());
			break;
		default:
			break;
		}

		eventRepository.saveAuditEvent(monitoring);
	}

	@Override
	public void execute() {
		final Map<String, Long> res = BatchResult.defaultRes();
		final JobParameters param = new JobParametersBuilder().addString("JobID", getBatchName() + " " + String.valueOf(System.currentTimeMillis())).toJobParameters();
		try {
			jobLauncher.run(job(res), param);
		} catch (JobExecutionAlreadyRunningException | JobRestartException | JobInstanceAlreadyCompleteException | JobParametersInvalidException e) {
			LOG.info("erreur batch {}", getBatchName(), e);
		}
		sendMonitoring(res);
	}

	private void sendMonitoring(final Map<String, Long> res) {
		if (isResultOK(res)) {
			switch (getBatchName()) {
			case "COLLECT_PURGE_COLLECT_CL":
				sendMonitoring(AuditValue.PURGE_OK, MSG_COLLECT_CLOSED, res.get(BatchResult.OK.getValue()));
				break;
			case "COLLECT_PURGE_COLLECT_AB":
				sendMonitoring(AuditValue.PURGE_OK, MSG_COLLECT_ABANDONED, res.get(BatchResult.OK.getValue()));
				break;
			case "COLLECT_PURGE_DOC_REFERENCE":
				sendMonitoring(AuditValue.PURGE_DOC_REFERENCE_OK, res.get(BatchResult.OK.getValue()) + " Pièces de référence supprimées", res.get(BatchResult.OK.getValue()));
				break;
			case "BATCH_COLLECT_EC_TO_AB":
				sendMonitoring(AuditValue.BATCH_COLLECT_EC_TO_AB, res.get(OK_AB));
				break;

			case "BATCH_COLLECT_EC_TO_CL":
				sendMonitoring(AuditValue.BATCH_COLLECT_EC_TO_CL, res.get(OK_CL));
				break;
			case "COLLECT_PURGE_PIECE":
				sendMonitoring(AuditValue.PURGE_OK, res.get(BatchResult.OK.getValue()));
				break;

			default:
				break;
			}

		}
		if (!isResultOK(res)) {
			switch (getBatchName()) {
			case "COLLECT_PURGE_COLLECT_CL":
				sendMonitoring(AuditValue.ERROR_PURGE, MSG_COLLECT_CLOSED, res.get(BatchResult.KO.getValue()));
				break;
			case "COLLECT_PURGE_COLLECT_AB":
				sendMonitoring(AuditValue.ERROR_PURGE, MSG_COLLECT_ABANDONED, res.get(BatchResult.KO.getValue()));
				break;
			case "COLLECT_PURGE_DOC_REFERENCE":
				sendMonitoring(AuditValue.ERROR_PURGE, "Suppression des pièces de référence interrompue", res.get(BatchResult.KO.getValue()));
				break;
			default:
				break;
			}

		}
	}

	private boolean isResultOK(Map<String, Long> res) {
		if (res.get(BatchResult.OK.getValue()) >= 0) {
			return true;
		}
		return false;

	}

	protected Job job(Map<String, Long> res) {
		return jobBuilderFactory.get("job_" + getBatchName()).incrementer(new RunIdIncrementer()).flow(step(res)).end().build();
	}

	protected abstract Step step(Map<String, Long> res);

	protected void sendMonitoring(AuditValue audit, Long nb) {
		final AuditEventEntity monitoring = new AuditEventEntity();
		monitoring.setDateCreation(TimestampUtils.getNow());
		monitoring.setCodeAP(appName);
		monitoring.setCodeAT(appName);
		monitoring.setIdTech(UUID.randomUUID().toString());
		monitoring.setCodeEvent(audit.getCode());
		monitoring.setTotalCollect((int) nb.longValue());
		monitoring.setMessage(messageSource.getMessage(audit.getLabel(), new String[] { nb.toString() }, Locale.FRENCH));
		monitoring.setChannel(Channel.API.getValue());
		eventRepository.saveAuditEvent(monitoring);
	}

	public Instant buildPurgeDate(PurgeType type) {

		ZonedDateTime todayMidnight = ZonedDateTime.now(ZoneId.systemDefault()).truncatedTo(ChronoUnit.DAYS);

		switch (type) {
		case COL_EC_AB:
			todayMidnight = todayMidnight.minusMonths(collectAbandonTTLMonth);
			todayMidnight = todayMidnight.minusDays(collectAbandonTTLDay);
			break;
		case COL_AB_SU:
			todayMidnight = todayMidnight.minusMonths(purgeCollectAbTTLMonth);
			todayMidnight = todayMidnight.minusDays(purgeCollectAbTTLDay);
			break;
		case COL_CL_SU:
			todayMidnight = todayMidnight.minusMonths(purgeCollectClTTLMonth);
			todayMidnight = todayMidnight.minusDays(purgeCollectClTTLDay);
			break;
		default:
			throw new IllegalArgumentException();
		}

		return todayMidnight.toInstant();

	}

	public String getBatchType() {
		return batchType;
	}

	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}

	public int getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}

}
