package com.bnpparibas.bddf.collect.infrastructure.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bnpparibas.bddf.collect.domain.ami.batch.AmiBatchRepository;
import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.domain.type.AmiBatch;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.AmiBatchMapper;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.AmiBatchJpaRepository;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.RepositoryImpl
@Repository
public class AmiBatchRepositoryImpl implements AmiBatchRepository {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AmiBatchRepositoryImpl.class);
	
	@Autowired
	private AmiBatchJpaRepository amiBatchJpaRepository;
	@Autowired
	private AmiBatchMapper amiBatchMapper;
	
	
	@Override
	public void saveAmiBatch(AmiBatch amiBatch) {
		amiBatchJpaRepository.save(amiBatchMapper.toAmiBatchEntity(amiBatch, false));
		
	}


	@Override
	public void update(AmiBatch amiBatch) {
		LoggerHelper.logForPerfTest(LOGGER, "Début appel amiBatchjpaRepository pour le type "+ amiBatch.getTypeId() + " (thread id " + Thread.currentThread().getId() + ")");
		amiBatchJpaRepository.save(amiBatchMapper.toAmiBatchEntity(amiBatch, false));
		LoggerHelper.logForPerfTest(LOGGER, "Fin appel amiBatchjpaRepository pour le type "+ amiBatch.getTypeId() + " (thread id " + Thread.currentThread().getId() + ")");
		
	}

	
}
