package com.bnpparibas.bddf.attachment.infrastructure;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.attachment.domain.NasAttachmentService;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.infrastructure.batch.distributed.AbstractBatch;
import com.bnpparibas.bddf.collect.infrastructure.batch.purge.BatchResult;
import com.bnpparibas.bddf.errors.TechnicalException;

@Component
@Transactional(transactionManager = "transactionManagerDB")
public class BatchPurgeAttachment extends AbstractBatch {

	private static final Logger LOG = LoggerFactory.getLogger(BatchPurgeAttachment.class);

	@Autowired
	private AttachmentJpaRepository attachmentJpaRepository;
	
	@Autowired
	private NasAttachmentService nasAttachmentService;

	@Value("${purge.attachment.ttl.month}")
	private Integer purgeAttachmentMonth;
	@Value("${purge.attachment.ttl.day}")
	private Integer purgeAttachmentDay;
	@Value("${app.name}")
	protected String appName;


	public BatchPurgeAttachment() {
		super("COLLECTE_PURGE_ATTACHMENT");
	}

	@Override
	@Transactional
	public void execute() {
		final Instant instantTimeOutAttachment = buildPurgeDate();
		// Inactif document
		final List<AttachmentEntity> outDatedAttachments = attachmentJpaRepository.findAttachmentsOlderThan(Timestamp.from(instantTimeOutAttachment));
		// Delete from PieceEntity only Inactif pieces
		if (CollectionUtils.isNotEmpty(outDatedAttachments)) {
			attachmentJpaRepository.deleteAll(outDatedAttachments);
		}
		// Deleting from NAS
		if (CollectionUtils.isNotEmpty(outDatedAttachments)) {
			final Map<String, Long> res = outDatedAttachments.stream().map(this::purgeAttachment).reduce(BatchResult.defaultRes(), BatchResult::groupMaps);
			LOG.info("batch purge attachment : {0} was deleted OK", res.get(BatchResult.OK.getValue()));
			LOG.info("batch purge attachment : {0} was deleted KO", res.get(BatchResult.KO.getValue()));
		}
	}

	private Instant buildPurgeDate() {
		ZonedDateTime todayMidnight = ZonedDateTime.now(ZoneId.systemDefault()).truncatedTo(ChronoUnit.DAYS);
		todayMidnight = todayMidnight.minusMonths(purgeAttachmentMonth);
		todayMidnight = todayMidnight.minusDays(purgeAttachmentDay-1);
		return todayMidnight.toInstant();
	}

	private Map<String, Long> purgeAttachment(AttachmentEntity attachment) {
		final Map<String, Long> result = BatchResult.defaultRes();
		deletePieceNas(attachment, result);
		return result;
	}

	private void deletePieceNas(AttachmentEntity attachment, Map<String, Long> result) {
		try {
			Optional.ofNullable(attachment.getId()).ifPresent(idAttachment -> nasAttachmentService.delete(UUID.fromString(idAttachment)));
			BatchResult.resOk(result);
		} catch (final TechnicalException e) {
			BatchResult.resKo(result);
			LOG.error(CollectErrorConstants.ERR_NAS_WRITE, e);
		}
	}

	@Scheduled(cron = "${purge.attachment.cron}")
	@Override
	public void scheduledStart() {
		MDC.put("UserID", getBatchName());
		MDC.put("AppName", appName);
		startBatch();

	}

}
