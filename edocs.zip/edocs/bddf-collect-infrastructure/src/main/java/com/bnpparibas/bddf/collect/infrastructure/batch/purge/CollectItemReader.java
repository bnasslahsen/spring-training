package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Iterator;

import org.springframework.batch.item.ItemReader;

import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.CollectJpaRepository;

public class CollectItemReader implements ItemReader<String> {

	private Instant instantCollect;
	private String status;
	private Iterator<String> collectIdsIt;
	private CollectJpaRepository collectJpaRepository;

	@Override
	public String read() {
		synchronized (this) {
			if (collectIdsIt == null) {
				collectIdsIt = collectJpaRepository.findCollectIdsBeforeAndByStatus(Timestamp.from(instantCollect), status).iterator();
			}
		}
		if (collectIdsIt.hasNext()) {
			return collectIdsIt.next();
		} else {
			return null;
		}
	}

	public Instant getInstantCollect() {
		return instantCollect;
	}

	public void setInstantCollect(Instant instantCollect) {
		this.instantCollect = instantCollect;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public CollectJpaRepository getCollectJpaRepository() {
		return collectJpaRepository;
	}

	public void setCollectJpaRepository(CollectJpaRepository collectJpaRepository) {
		this.collectJpaRepository = collectJpaRepository;
	}
}
