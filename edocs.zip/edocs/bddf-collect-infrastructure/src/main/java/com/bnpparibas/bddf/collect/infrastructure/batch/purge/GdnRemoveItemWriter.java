package com.bnpparibas.bddf.collect.infrastructure.batch.purge;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Tuple;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bnpp.jdf.connector.IJdfConnectorConstants;
import com.bnpp.jdf.connector.exception.ConnectorFunctionalException;
import com.bnpp.jdf.connector.exception.ConnectorTechnicalException;
import com.bnpp.jdf.deletedoc.query.DeleteDocI;
import com.bnpparibas.bddf.collect.infrastructure.gdn.service.GdnService;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.PieceJpaRepository;

@Component
public class GdnRemoveItemWriter implements ItemWriter<String> {
	
	private static final Logger LOG = LoggerFactory.getLogger(GdnRemoveItemWriter.class);

	
	@Value("${app.name}")
	private String appName;
	@Autowired
	private GdnService gdnService;
	@Autowired
	private PieceJpaRepository pieceJpaRepository;

	@Override
	public void write(List<? extends String> collectIds) throws Exception {
		List<Tuple> tuples = pieceJpaRepository.findAllPieceIdAndIdDocGdnFromCollectId((List<String>) collectIds);
		tuples.forEach(pieceTuples -> {
			String idDocGdn = (String) pieceTuples.get(1);
			String ownerId = (String) pieceTuples.get(2);
			String employeeId = (String) pieceTuples.get(3);
			try {
				if (idDocGdn != null) {
					deleteDocGdn(idDocGdn, ownerId, employeeId);
				}
			} catch (final ConnectorTechnicalException | ConnectorFunctionalException e) {
				LOG.error(e.getMessage(), e);
			}
		});

	}

	private void deleteDocGdn(String idDocGdn, String ownerId, String employeeId) throws ConnectorTechnicalException, ConnectorFunctionalException {
		final DeleteDocI deleteDocI = new DeleteDocI();
		deleteDocI.setDocumentId(idDocGdn);
		deleteDocI.setOwningApplication(appName);

		String pUser = "999999";
		if (StringUtils.isNotBlank(ownerId)) {
			pUser = ownerId;
		} else if (StringUtils.isNotBlank(employeeId)) {
			pUser = employeeId;
		}

		final Map<String, String> params = new HashMap();

		params.put(IJdfConnectorConstants.CALLING_USER, pUser);

		gdnService.deleteDoc(deleteDocI, params);
	}

}
