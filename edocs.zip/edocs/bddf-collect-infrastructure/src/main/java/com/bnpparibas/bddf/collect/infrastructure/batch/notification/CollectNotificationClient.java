package com.bnpparibas.bddf.collect.infrastructure.batch.notification;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditEvent;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.event.ClientNotificationSender;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.notification.NotificationDIGICOMMessage;
import com.bnpparibas.bddf.collect.domain.notification.NotificationMessage;
import com.bnpparibas.bddf.collect.domain.notification.NotificationUtils;
import com.bnpparibas.bddf.collect.domain.notification.enums.RecipientChannelNotification;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.infrastructure.batch.distributed.AbstractBatch;
import com.bnpparibas.bddf.collect.infrastructure.entity.CollectEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.OwnerEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.TypeEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.ClientNotificationJpaRepository;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.CollectJpaRepository;
import com.bnpparibas.bddf.rest.Context;

@Component
@Transactional(transactionManager = "transactionManager")
public class CollectNotificationClient extends AbstractBatch {

	private static final Logger LOG = LoggerFactory.getLogger(CollectNotificationClient.class);

	@Autowired
	private ClientNotificationJpaRepository clientNotificationJpaRepository;

	@Autowired
	private CollectJpaRepository collectJpaRepository;

	@Autowired
	private ClientNotificationSender clientNotificationSender;

	@Autowired
	private ClientNotificationJpaRepository clientNotificationRepository;

	@Autowired
	private AuditGenerator auditGenerator;

	@Autowired
	private CollectEventHandler collectEventHandler;

	@Value("${notification-bmm.relaunch.delay}")
	private Integer notificationBMMRelaunchDelay;

	@Value("${notification-bmm.relaunch.max-authorised}")
	private Integer notificationBMMRelaunchMaxAuthorized;

	@Value("${notification-bmm.startDiffusionHourDigicom}")
	private Integer startDiffusionHourDigicom;

	public CollectNotificationClient() {
		super("COLLECT_NOTIFICATION_CLIENT");
	}

	@Scheduled(cron = "${notification-bmm.cron}")
	@Override
	public void scheduledStart() {
		startBatch();
	}

	@Override
	@Transactional
	public void execute() {

		final ZonedDateTime todayMidnight = ZonedDateTime.now(ZoneId.systemDefault()).truncatedTo(ChronoUnit.DAYS);
		final Instant notificationRelaunchDate = todayMidnight.plusDays(notificationBMMRelaunchDelay).toInstant();
		final List<String> collectIds = clientNotificationJpaRepository.findByNotificationNumber(notificationBMMRelaunchMaxAuthorized, Timestamp.from(notificationRelaunchDate));
		collectIds.forEach(collectId -> {

			final CollectEntity collectEntity = collectJpaRepository.getOne(collectId);
			final Set<String> referenceList = collectEntity.getOwners().stream().map(OwnerEntity::getReference).collect(Collectors.toSet());
			final List<TypeEntity> typeEntities = clientNotificationJpaRepository.findTypesbyCollectId(collectId);
			final List<NotificationMessage> messages = new ArrayList<>();
			final List<NotificationDIGICOMMessage> messagesDigicom = new ArrayList<>();
			if (collectEntity.getNotifyOwners() && typeEntities.stream().anyMatch(
					typeEntity -> typeEntity.getPendingDocument() || typeEntity.getPieces().stream().anyMatch(pieceEntity -> PieceStatus.RF.getLabel().equals(pieceEntity.getStatus()) && PieceStates.ACTIF.getLabel().equals(pieceEntity.getState())))) {
				referenceList.forEach(reference -> {
					final String communicationTemplate = collectEntity.getOwners().stream().filter(collectOwner -> collectOwner.getReference().equals(reference)).findAny().get().getCommunicationTemplate();
					messages.add(NotificationUtils.generateMessageByOwner(UUID.randomUUID().toString(), communicationTemplate, reference, RecipientChannelNotification.MESSAGE_SECUR_BNP.getCode(), collectEntity.getProductLabel()));
					messages.add(NotificationUtils.generateMessageByOwner(UUID.randomUUID().toString(), communicationTemplate, reference, RecipientChannelNotification.EMAILS.getCode(), collectEntity.getProductLabel()));
					messagesDigicom.add(NotificationUtils.generateMessageDIGICOMByOwner(UUID.randomUUID().toString(), startTimeDigicom(), communicationTemplate, reference, collectEntity.getProductLabel()));
				});
				clientNotificationSender.sendNotification(messages, collectEntity.getId());
				clientNotificationSender.sendNotificationDIGICOM(messagesDigicom, collectEntity.getId());
				// Incrémentation du nombre de notification
				clientNotificationRepository.updateNotificationNumber(collectId, notificationBMMRelaunchMaxAuthorized, Timestamp.from(Instant.now()));
				// Audit event
				final AuditEvent auditEvent = auditGenerator.newAudit(new Context("", Channel.API.getValue(), ""), AuditValue.BATCH_CLIENT_NOTIFICATION).setIdCollect(UUID.fromString(collectId)).setJourneyCode(collectEntity.getJourneyCode());
				collectEventHandler.sendAuditEvent(auditEvent);
			}
			typeEntities.stream().filter(
					typeEntity -> !typeEntity.getPendingDocument() && typeEntity.getPieces().stream().noneMatch(pieceEntity -> PieceStatus.RF.getLabel().equals(pieceEntity.getStatus()) && PieceStates.ACTIF.getLabel().equals(pieceEntity.getState())))
					.forEach(typeEntity -> {
						clientNotificationJpaRepository.deleteById(typeEntity.getId());
					});

		});
		LOG.info("Batch de notification BMM et Digicom");
	}

	private String startTimeDigicom() {
		final Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, startDiffusionHourDigicom);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		final Date d = cal.getTime();
		final SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS");
		return f.format(d);
	}

}
