package com.bnpparibas.bddf.collect.infrastructure.repository;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Repository;

import com.bnp.schema.edoc_types_families.EdocFamiliesTypes;
import com.bnp.schema.edoc_types_families.EdocFamiliesTypes.EdocFamilyTypes;
import com.bnp.schema.edoc_types_families.ObjectFactory;
import com.bnpparibas.bddf.collect.domain.edoc.families.types.EdocFamiliesTypesRepository;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.errors.TechnicalException;

@DDD.RepositoryImpl
@Repository
public class EdocFamiliesTypesRepositoryImpl implements EdocFamiliesTypesRepository {
	private List<EdocFamilyTypes> edocFamiliesTypes;

	public EdocFamiliesTypesRepositoryImpl() {
		super();
	}

	@PostConstruct
	private void init() {
		try {
			final InputStream inputStream = new ClassPathResource("edoc-families-types.xml").getInputStream();
			final Unmarshaller unmarshaller = JAXBContext.newInstance(ObjectFactory.class).createUnmarshaller();
			final Object obj = unmarshaller.unmarshal(inputStream);
			edocFamiliesTypes = ((EdocFamiliesTypes) obj).getEdocFamilyTypes();
		} catch (final JAXBException | IOException e) {
			throw new TechnicalException(CollectErrorConstants.ERR_COL_TECH, e);
		}
	}

	@Override
	public List<EdocFamilyTypes> findAll() {
		return edocFamiliesTypes;
	}

}
