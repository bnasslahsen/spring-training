package com.bnpparibas.bddf.collect.infrastructure.jms.config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.jms.JMSException;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.connection.JmsTransactionManager;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.util.ErrorHandler;

import com.bnpparibas.bddf.config.SpringProfileConstants;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.mq.jms.MQTopicConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;



@Configuration
@EnableJms
@Profile(value = { SpringProfileConstants.SPRING_PROFILE_MQ })
public class JmsConfig {

	// GENERIC PARAMS
	@Value("${jms.mq.hosts}")
	private String hosts;
	@Value("${jms.mq.queue-manager}")
	private String queueManager;
	@Value("${jms.mq.channel}")
	private String channel;
	@Value("${jms.mq.receive-timeout}")
	private long receiveTimeout;
	@Value("${jms.mq.delivery-delay:60000}")
	private long deliveryDelay;
	@Value("${jms.mq.transactional:true}")
	private String transactionnal;
	@Value("${jms.mq.user:NOT_AVAILABLE}")
	private String user;
	@Value("${jms.mq.password:NOT_AVAILABLE}")
	private String password;

	// SSL PARAMS
	@Value("${jms.mq.ssl.enabled}")
	private boolean sslEnabled;
	@Value("${jms.mq.ssl.cipher:SSL_RSA_WITH_AES_128_CBC_SHA}")
	private String cipher;
	@Value("${jms.mq.ssl.keystore.fullPath:default}")
	private String keystoreFullPath;
	@Value("${jms.mq.ssl.keystore.password:default}")
	private String keystorePassword;
	@Value("${jms.mq.ssl.truststore.fullPath:default}")
	private String truststoreFullPath;
	@Value("${jms.mq.ssl.truststore.password:default}")
	private String truststorePassword;

	@Autowired
	private MessageConverter messageConverter;

	private SSLSocketFactory sslSocketFactory;

	@Bean
	public MQQueueConnectionFactory mqQueueConnectionFactory() throws JMSException, GeneralSecurityException, IOException {
		MQQueueConnectionFactory mqQueueConnectionFactory = new MQQueueConnectionFactory();
		mqQueueConnectionFactory.setConnectionNameList(hosts);
		mqQueueConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
		mqQueueConnectionFactory.setCCSID(1208);
		mqQueueConnectionFactory.setChannel(channel);
		mqQueueConnectionFactory.setQueueManager(queueManager);	
		mqQueueConnectionFactory.setBooleanProperty(WMQConstants.USER_AUTHENTICATION_MQCSP, true);
		

		// SSL parameters
		if (sslEnabled) {
			mqQueueConnectionFactory.setSSLCipherSuite(cipher);
			mqQueueConnectionFactory.setSSLSocketFactory(getSSLSocketFactory());
		}
		return mqQueueConnectionFactory;
	}
	
	@Bean
	public MQTopicConnectionFactory  mqTopicConnectionFactory() throws JMSException {
		MQTopicConnectionFactory mqTopicConnectionFactory = new MQTopicConnectionFactory();
		mqTopicConnectionFactory.setConnectionNameList(hosts);
		mqTopicConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
		mqTopicConnectionFactory.setCCSID(1208);
		mqTopicConnectionFactory.setChannel(channel);
		mqTopicConnectionFactory.setQueueManager(queueManager);	
		mqTopicConnectionFactory.setBooleanProperty(WMQConstants.USER_AUTHENTICATION_MQCSP, true);
		

		return mqTopicConnectionFactory;
	}
	
	@Bean(name="topicTemplate")
	public JmsTemplate topicTemplate() throws JMSException, GeneralSecurityException, IOException{
		JmsTemplate jmsTemplate = new JmsTemplate(cachingQueueConnectionFactory());
		jmsTemplate.setPubSubDomain(true);
		jmsTemplate.setReceiveTimeout(receiveTimeout);
		jmsTemplate.setMessageConverter(messageConverter);
		return jmsTemplate;
	}


	@Bean
	public UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter() throws JMSException, GeneralSecurityException, IOException {
		UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter = new UserCredentialsConnectionFactoryAdapter();
		if(!"NOT_AVAILABLE".equals(user)){
			userCredentialsConnectionFactoryAdapter.setUsername(user);
			userCredentialsConnectionFactoryAdapter.setPassword(password);
		}
		userCredentialsConnectionFactoryAdapter.setTargetConnectionFactory(mqTopicConnectionFactory());
		return userCredentialsConnectionFactoryAdapter;
	}

	@Bean
	@Primary
	public CachingConnectionFactory cachingQueueConnectionFactory() throws JMSException, GeneralSecurityException, IOException {
		CachingConnectionFactory cachingConnectionFactory = new CachingConnectionFactory();
		cachingConnectionFactory.setTargetConnectionFactory(userCredentialsConnectionFactoryAdapter());
		cachingConnectionFactory.setSessionCacheSize(500);
		cachingConnectionFactory.setReconnectOnException(true);
		return cachingConnectionFactory;
	}

	@Bean
	public PlatformTransactionManager jmsTransactionManager() throws JMSException, GeneralSecurityException, IOException {
		JmsTransactionManager jmsTransactionManager = new JmsTransactionManager();
		jmsTransactionManager.setConnectionFactory(cachingQueueConnectionFactory());
		return jmsTransactionManager;
	}

	@Bean
	public DefaultJmsListenerContainerFactory jmsListenerContainerFactory(ErrorHandler errorHandler) throws JMSException, GeneralSecurityException, IOException {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		factory.setConnectionFactory(cachingQueueConnectionFactory());
		factory.setMessageConverter(messageConverter);
		factory.setConcurrency("1-1");
		if ("true".equals(transactionnal)){
			factory.setTransactionManager(jmsTransactionManager());
		}
		factory.setErrorHandler(errorHandler);
		return factory;
	}

	@Bean(name = "jmsTemplate")
	public JmsTemplate jmsTemplate() throws JMSException, GeneralSecurityException, IOException {
		JmsTemplate jmsTemplate = new JmsTemplate(cachingQueueConnectionFactory());
		jmsTemplate.setReceiveTimeout(receiveTimeout);
		jmsTemplate.setMessageConverter(messageConverter);
		return jmsTemplate;
	}

	@Bean(name = "delayedJmsTemplate")
	public JmsTemplate delayedJmsTemplate() throws JMSException, GeneralSecurityException, IOException {
		JmsTemplate jmsTemplate = new JmsTemplate(cachingQueueConnectionFactory());
		jmsTemplate.setReceiveTimeout(receiveTimeout);
		jmsTemplate.setDeliveryDelay(deliveryDelay);
		return jmsTemplate;
	}

    /********************************************************/
	/*********** SSL MUTUAL AUTHENTICATION SETUP ************/
	/********************************************************/

	private SSLSocketFactory getSSLSocketFactory() throws GeneralSecurityException, IOException {
		if (sslSocketFactory == null) {
			initialiseSSLFactory();
		}
		return sslSocketFactory;
	}

	private void initialiseSSLFactory() throws GeneralSecurityException, IOException {

		KeyStore keyStore = getKeyStore("PKCS12", keystoreFullPath, keystorePassword);
		KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		kmf.init(keyStore, keystorePassword.toCharArray());

		KeyStore trustStore = getKeyStore("PKCS12", truststoreFullPath, truststorePassword);
		TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		tmf.init(trustStore);

		SSLContext sc = SSLContext.getInstance("TLS");
		sc.init(kmf.getKeyManagers(), tmf.getTrustManagers(), new java.security.SecureRandom());
		sslSocketFactory = sc.getSocketFactory();
	}

	private KeyStore getKeyStore(final String keyStoreType, final String keystorePath, final String password)
			throws KeyStoreException, FileNotFoundException, IOException, NoSuchAlgorithmException,
			CertificateException {
		final KeyStore keyStore = KeyStore.getInstance(keyStoreType);

		InputStream is = null;
		try {
			is = new FileInputStream(keystorePath);
			keyStore.load(is, password.toCharArray());
		} finally {
			if (is != null)
				is.close();
		}
		return keyStore;
	}

}
