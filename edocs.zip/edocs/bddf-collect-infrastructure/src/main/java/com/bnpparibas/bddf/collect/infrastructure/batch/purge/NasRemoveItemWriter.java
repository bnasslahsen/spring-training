package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.persistence.Tuple;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.PieceJpaRepository;
import com.bnpparibas.bddf.collect.infrastructure.nas.PieceNasService;

@Component
public class NasRemoveItemWriter implements ItemWriter<String> {
	
	private static final Logger LOG = LoggerFactory.getLogger(NasRemoveItemWriter.class);
	
	@Value("${app.name}")
	private String appName;
	@Autowired
	private PieceNasService pieceNasDao;
	@Autowired
	private PieceJpaRepository pieceJpaRepository;

	@Override
	public void write(List<? extends String> collectIds) throws Exception {
		List<Tuple> tuples = pieceJpaRepository.findAllPieceIdAndIdDocGdnFromCollectId((List<String>) collectIds);
		tuples.forEach(pieceTuples -> {
			String idPieceString = (String) pieceTuples.get(0);
			deletePiece(idPieceString);
		});

	}
	
	private void deletePiece(String idPieceString) {
		try {
			final UUID idPiece = UUID.fromString(idPieceString);
			pieceNasDao.deletePiece(idPiece);
			pieceNasDao.deleteThumbnail(idPiece);
		} catch (final IOException e) {
			LOG.error(e.getMessage(), e);
		}
	}


}
