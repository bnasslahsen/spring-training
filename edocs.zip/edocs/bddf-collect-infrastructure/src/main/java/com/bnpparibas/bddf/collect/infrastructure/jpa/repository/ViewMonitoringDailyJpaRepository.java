package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bnpparibas.bddf.collect.infrastructure.entity.ViewMonitoringDailyCtrlEntity;

@Repository
public interface ViewMonitoringDailyJpaRepository extends JpaRepository<ViewMonitoringDailyCtrlEntity, String> {

}
