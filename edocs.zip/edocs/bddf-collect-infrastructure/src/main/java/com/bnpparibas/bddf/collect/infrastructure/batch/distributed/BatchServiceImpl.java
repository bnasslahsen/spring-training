package com.bnpparibas.bddf.collect.infrastructure.batch.distributed;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Locale;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.infrastructure.entity.AuditEventEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.TimestampUtils;
import com.bnpparibas.bddf.collect.infrastructure.repository.EventRepository;


@Service
public class BatchServiceImpl implements BatchService {

	private static final Logger LOG = LoggerFactory.getLogger(BatchServiceImpl.class);
	@Value("${batch.releaseLockTime}")
	private long releaseLockTime;
	@Value("${app.name}")
	private String appName;
	@Autowired
	private BatchLockService batchLockService;
	@Autowired
	private EventRepository eventRepository;
	@Autowired
	private MessageSource messageSource;



	@Override
	public void startBatch(AbstractBatch batch) {
		try {
			initMDCForBatch(batch.getBatchName());
			if (batchLockService.lockTable(batch.getBatchName())) {
				LOG.info("[START] batch: " + batch.getBatchName());
				try {
					batch.execute();
				} finally {
					
					LOG.info("[END] batch: " + batch.getBatchName());
					try {
						Thread.sleep(releaseLockTime);
					} catch (InterruptedException e) {
						LOG.info("batch: " + batch.getBatchName() + " " + e.getMessage() );
					}
					sendMonitoring(AuditValue.BATCH_EXECUTION_OK, batch.getBatchName());
					batchLockService.unLockTable(batch.getBatchName());
					
				}
			} else if (LOG.isInfoEnabled()) {
				LOG.info(new StringBuilder().append("Une instance du batch ").append(batch.getBatchName()).append(" est déjà en cours d'execution").toString());
			}
		} finally {
			MDC.clear();
		}
	}

	/**
	 * Initialize MCD parameters for batch
	 * 
	 * @param batch
	 *            get the batch parameters
	 */
	private void initMDCForBatch(String batchName) {
		MDC.put("HostName", getHostName());
		MDC.put("UserID", batchName);
		MDC.put("Marker", "INFRASTRUCTURE");
	}
	
	private void sendMonitoring(AuditValue audit, String batchName) {
		final AuditEventEntity monitoring = new AuditEventEntity();
		monitoring.setDateCreation(TimestampUtils.getNow());
		monitoring.setCodeAP(appName);
		monitoring.setCodeAT(appName);
		monitoring.setIdTech(UUID.randomUUID().toString());
		monitoring.setCodeEvent(audit.getCode());
		monitoring.setMessage(messageSource.getMessage(audit.getLabel(), new String[] { batchName }, Locale.FRENCH));
		monitoring.setChannel(Channel.API.getValue());
		eventRepository.saveAuditEvent(monitoring);
	}

	private String getHostName() {
		try {
			InetAddress addr;
			addr = InetAddress.getLocalHost();
			return addr.getHostName();
		} catch (UnknownHostException ex) {
			LOG.error("Hostname can not be resolved", ex);
		}
		return "";
	}

}
