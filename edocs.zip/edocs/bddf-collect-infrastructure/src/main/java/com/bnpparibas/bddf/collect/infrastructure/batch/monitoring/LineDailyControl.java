package com.bnpparibas.bddf.collect.infrastructure.batch.monitoring;

public class LineDailyControl {
	
	private String edocType;
	private String parcours;
	private String typeTot;
	private String pieceAver;
	private String reco;
	private String extr;
	private String cohe;
	private String ladRad;
	private String vaAuto;
	private String rcAuto;
	private String err;
	
	
	public String getEdocType() {
		return edocType;
	}
	public void setEdocType(String edocType) {
		this.edocType = edocType;
	}
	public String getParcours() {
		return parcours;
	}
	public void setParcours(String parcours) {
		this.parcours = parcours;
	}
	public String getTypeTot() {
		return typeTot;
	}
	public void setTypeTot(String typeTot) {
		this.typeTot = typeTot;
	}
	public String getPieceAver() {
		return pieceAver;
	}
	public void setPieceAver(String pieceAver) {
		this.pieceAver = pieceAver;
	}
	public String getReco() {
		return reco;
	}
	public void setReco(String reco) {
		this.reco = reco;
	}
	public String getExtr() {
		return extr;
	}
	public void setExtr(String extr) {
		this.extr = extr;
	}
	public String getCohe() {
		return cohe;
	}
	public void setCohe(String cohe) {
		this.cohe = cohe;
	}
	public String getLadRad() {
		return ladRad;
	}
	public void setLadRad(String ladRad) {
		this.ladRad = ladRad;
	}
	public String getVaAuto() {
		return vaAuto;
	}
	public void setVaAuto(String vaAuto) {
		this.vaAuto = vaAuto;
	}
	public String getRcAuto() {
		return rcAuto;
	}
	public void setRcAuto(String rcAuto) {
		this.rcAuto = rcAuto;
	}
	public String getErr() {
		return err;
	}
	public void setErr(String err) {
		this.err = err;
	}
	

}
