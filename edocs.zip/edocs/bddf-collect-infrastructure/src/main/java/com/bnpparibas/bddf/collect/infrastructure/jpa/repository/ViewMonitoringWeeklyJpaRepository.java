package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bnpparibas.bddf.collect.infrastructure.entity.ViewMonitoringWeeklyEntity;

@Repository
public interface ViewMonitoringWeeklyJpaRepository extends JpaRepository<ViewMonitoringWeeklyEntity, String> {

}
