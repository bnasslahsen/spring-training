package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.infrastructure.entity.PieceEntity;
import com.bnpparibas.bddf.collect.infrastructure.gdn.service.GdnService;
import com.bnpparibas.bddf.collect.infrastructure.nas.PieceNasService;

@Component
public class PurgePieceItemWriter implements ItemWriter<PieceEntity> {
	private static final Logger LOG = LoggerFactory.getLogger(PurgePieceItemWriter.class);
	@Autowired
	protected PieceNasService pieceNasDao;
	@Value("${app.name}")
	protected String appName;
	@Autowired
	private GdnService gdnService;

	@Override
	public void write(List<? extends PieceEntity> allPiecesToDelete) throws Exception {
		allPiecesToDelete.stream().map(this::deletePieceNas).reduce(BatchResult.defaultRes(), BatchResult::groupMaps);
	}

	private Map<String, Long> deletePieceNas(PieceEntity piece) {
		final Map<String, Long> result = BatchResult.defaultRes();
		try {
			pieceNasDao.deletePiece(UUID.fromString(Optional.ofNullable(piece).map(PieceEntity::getId).orElse("")));
			pieceNasDao.deleteThumbnail(UUID.fromString(Optional.ofNullable(piece).map(PieceEntity::getId).orElse("")));
			BatchResult.resOk(result);
		} catch (final IOException e) {
			LOG.error(e.getMessage(), e);
			BatchResult.resKo(result);
		}
		return result;

	}

}
