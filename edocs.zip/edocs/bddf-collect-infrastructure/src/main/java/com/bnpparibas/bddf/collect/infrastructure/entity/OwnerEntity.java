package com.bnpparibas.bddf.collect.infrastructure.entity;

import java.sql.Timestamp;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.domain.Persistable;

@Entity
@Table(name = "owner")
public class OwnerEntity implements java.io.Serializable, Persistable<String> {

	private static final long serialVersionUID = 1L;
	private String id;
	private String reference;
	private String name;
	private String firstname;
	private Timestamp birthDate;
	private Integer nature;
	private boolean isNew;
	private String communicationTemplate;

	public OwnerEntity() {
	}

	public OwnerEntity(String id, String reference) {
		this.id = id;
		this.reference = reference;
	}

	@Override
	@Id
	@Column(name = "ID", unique = true, nullable = false, length = 45)
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Column(name = "REFERENCE", nullable = false, length = 17)
	public String getReference() {
		return this.reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	@Column(name = "NAME", length = 100)
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "FIRSTNAME", length = 100)
	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	@Column(name = "BIRTH_DATE", length = 7)
	public Timestamp getBirthDate() {
		return Optional.ofNullable(this.birthDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setBirthDate(Timestamp birthDate) {
		this.birthDate = Optional.ofNullable(birthDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Column(name = "NATURE", precision = 22, scale = 0)
	public Integer getNature() {
		return this.nature;
	}

	public void setNature(Integer nature) {
		this.nature = nature;
	}

	@Column(name = "COMMUNICATION_TEMPLATE", length = 20)
	public String getCommunicationTemplate() {
		return communicationTemplate;
	}

	public void setCommunicationTemplate(String communicationTemplate) {
		this.communicationTemplate = communicationTemplate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	@Transient
	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	@Override
	public boolean equals(Object obj) {
		boolean isEqual = true;
		if (this == obj) {
			isEqual = true;
		}
		if (obj == null) {
			isEqual = false;
		}
		if (!(obj instanceof OwnerEntity)) {
			isEqual = false;
		}
		final OwnerEntity other = (OwnerEntity) obj;
		if (id == null) {
			if (other != null && other.id != null) {
				isEqual = false;
			}
		} else if (other != null && !id.equals(other.id)) {
			isEqual = false;
		}
		return isEqual;
	}

}
