package com.bnpparibas.bddf.collect.infrastructure.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.domain.Persistable;

@Entity
@Table(name = "doc_reference")
public class DocReferenceEntity implements java.io.Serializable, Persistable<DocReferenceId> {

	private static final long serialVersionUID = 1L;
	private DocReferenceId id;
	private String referenceGdnId;
	private String label;
	private String channel;
	private String contentType;
	private Integer sizeDoc;
	private Integer position;
	private Set<DocReferenceJourneyCode> docReferenceJourneyCodes = new HashSet<>(0);
	private boolean isNew;

	public DocReferenceEntity() {
	}

	public DocReferenceEntity(String ownerID, String edocType, String referencePieceId) {
		this.id = new DocReferenceId(ownerID, edocType, referencePieceId);

	}

	public DocReferenceEntity(DocReferenceId id) {
		this.id = id;
	}

	@Override
	@EmbeddedId
	@AttributeOverrides({ @AttributeOverride(name = "ownerId", column = @Column(name = "OWNER_ID", nullable = false, length = 200)), @AttributeOverride(name = "edocType", column = @Column(name = "EDOC_TYPE", nullable = false, length = 17)),
			@AttributeOverride(name = "referencePieceId", column = @Column(name = "REFERENCE_PIECE_ID", nullable = false, length = 17)) })
	public DocReferenceId getId() {
		return this.id;
	}

	public void setId(DocReferenceId id) {
		this.id = id;
	}

	@Column(name = "REFERENCE_GDN_ID", length = 100)
	public String getReferenceGdnId() {
		return referenceGdnId;
	}

	public void setReferenceGdnId(String referenceGdnId) {
		this.referenceGdnId = referenceGdnId;
	}

	@Column(name = "LABEL", length = 200)
	public String getLabel() {
		return this.label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	@Column(name = "CHANNEL", length = 3)
	public String getChannel() {
		return this.channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	@Column(name = "CONTENT_TYPE", length = 200)
	public String getContentType() {
		return this.contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	@Column(name = "SIZE_DOC", precision = 22, scale = 0)
	public Integer getSizeDoc() {
		return this.sizeDoc;
	}

	public void setSizeDoc(Integer sizeDoc) {
		this.sizeDoc = sizeDoc;
	}

	@Column(name = "POSITION")
	public Integer getPosition() {
		return position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "docReference")
	public Set<DocReferenceJourneyCode> getDocReferenceJourneyCodes() {
		return this.docReferenceJourneyCodes;
	}

	public void setDocReferenceJourneyCodes(Set<DocReferenceJourneyCode> docReferenceJourneyCodes) {
		this.docReferenceJourneyCodes = docReferenceJourneyCodes;
	}

	@Override
	@Transient
	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

}
