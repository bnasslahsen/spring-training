package com.bnpparibas.bddf.collect.infrastructure.jpa.mapper;

import java.util.Optional;
import java.util.UUID;

import org.dozer.Mapper;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.type.AmiBatch;
import com.bnpparibas.bddf.collect.infrastructure.entity.AmiBatchEntity;

@Component
public class AmiBatchMapper {

	private final Mapper dozerMapper;

	public AmiBatchMapper(Mapper dozerMapper) {
		this.dozerMapper = dozerMapper;
	}

	public AmiBatch toAmiBatch(AmiBatchEntity amiBatchEntity) {
		final AmiBatch amiBatch = dozerMapper.map(amiBatchEntity, AmiBatch.class);
		amiBatch.setTypeId(UUID.fromString(Optional.ofNullable(amiBatchEntity).map(AmiBatchEntity::getId).orElse("")));
		return amiBatch;
	}

	public AmiBatchEntity toAmiBatchEntity(AmiBatch amiBatch, boolean isNew) {
		final AmiBatchEntity amiBatchEntity = dozerMapper.map(amiBatch, AmiBatchEntity.class);
		amiBatchEntity.setTypeId(amiBatch.getTypeId().toString());
		amiBatchEntity.setNew(isNew);
		return amiBatchEntity;
	}

}
