package com.bnpparibas.bddf.collect.infrastructure.event.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.ErrorHandler;

import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;

@Service
public class JmsCollectErrorHandler implements ErrorHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(JmsCollectErrorHandler.class);

	@Override
	public void handleError(Throwable t) {
		if (t.getCause() instanceof CollectBusinessException) {
			final CollectBusinessException e = (CollectBusinessException) t.getCause();
			LOGGER.error("Exception during unmarshalling message received : {}", e.getMessage());
		}
	}

}
