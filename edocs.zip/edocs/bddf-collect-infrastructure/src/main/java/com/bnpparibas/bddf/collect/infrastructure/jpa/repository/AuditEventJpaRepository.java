package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.entity.AuditEventEntity;

@Repository
public interface AuditEventJpaRepository extends JpaRepository<AuditEventEntity, String> {

	@Query("from AuditEventEntity b where b.dateCreation <= :dateEndCreation and b.dateCreation >= :dateBeginCreation")
	List<AuditEventEntity> findBetweenDateCreation(@Param("dateBeginCreation") Timestamp dateBeginCreation, @Param("dateEndCreation") Timestamp dateEndCreation);

	@Query("from AuditEventEntity b where b.dateCreation <= :dateEndCreation and b.dateCreation >= :dateBeginCreation and b.controlRequired=3")
	List<AuditEventEntity> findAutomatiControlsByDate(@Param("dateBeginCreation") Timestamp dateBeginCreation, @Param("dateEndCreation") Timestamp dateEndCreation);

	@Query("from AuditEventEntity a where a.eventId = :eventId")
	AuditEventEntity findByEventId(@Param("eventId") String eventId);

	@Modifying
	@Transactional
	@Query("delete from AuditEventEntity a where a.collectId in :collectIds")
	void deleteByCollectIds(@Param("collectIds") List<String> collectIds);

	@Modifying
	@Transactional
	@Query("delete from AuditEventEntity a where a.dateCreation  <= :expirationDate and (a.collectId is null or (select count(*) from CollectEntity c where c.id=a.collectId)=0)")
	void deleteExpiredValues(@Param("expirationDate") Timestamp expirationDate);

}
