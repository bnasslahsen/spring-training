package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.infrastructure.entity.PieceEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.PieceJpaRepository;

@Component
public class UpdateDeletedNasItemWriter implements ItemWriter<PieceEntity> {
	
	@Autowired
	private PieceJpaRepository pieceJpaRepository;

	@Override
	public void write(List<? extends PieceEntity> pieceList) throws Exception {
		pieceJpaRepository.updateDeletedNas(1, pieceList.stream().map(PieceEntity::getId).collect(Collectors.toList()));
		
	}

}
