package com.bnpparibas.bddf.collect.infrastructure.batch.distributed;

public interface BatchLockService {

	boolean lockTable(String batchName);

	void unLockTable(String batchName);
}
