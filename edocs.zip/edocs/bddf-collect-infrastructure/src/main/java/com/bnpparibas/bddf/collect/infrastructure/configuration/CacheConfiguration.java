package com.bnpparibas.bddf.collect.infrastructure.configuration;

import java.util.Arrays;

import javax.cache.configuration.MutableConfiguration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.cache.JCacheManagerCustomizer;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.bnpparibas.bddf.collect.infrastructure.cache.CacheName;
import com.hazelcast.config.Config;
import com.hazelcast.config.JoinConfig;

@Configuration
public class CacheConfiguration {
	
	@Value("${spring.cache.hosts}")
	private String hosts;
	@Value("${spring.cache.port}")
	private String port;
	@Value("${spring.cache.portCount}")
	private String portCount;

	@Bean
	public Config hazelcastConfig() {
		Config config = new Config().setInstanceName("hazelcast-instance");

		JoinConfig joinConfig = config.getNetworkConfig().getJoin();

		config.getNetworkConfig().setPort(Integer.parseInt(port));
		config.getNetworkConfig().setPortCount(Integer.parseInt(portCount));
		config.getNetworkConfig().setPortAutoIncrement(true);

		joinConfig.getMulticastConfig().setEnabled(false);
		joinConfig.getTcpIpConfig().setEnabled(true).setMembers(Arrays.asList(hosts.split(",")));
		joinConfig.getTcpIpConfig().setConnectionTimeoutSeconds(30);

		return config;
	}

	@Bean
    public JCacheManagerCustomizer cacheManagerCustomizer() {
		return cm -> {
			javax.cache.configuration.Configuration jcacheConfiguration = createConfiguration();
			cm.createCache(CacheName.NOMENCLATURES, jcacheConfiguration);

        };
	}

	private javax.cache.configuration.Configuration createConfiguration() {
		MutableConfiguration<Object, Object> config = new MutableConfiguration<Object, Object>();
		config.setStoreByValue(true).setTypes(Object.class, Object.class).setStatisticsEnabled(false);
		return config;
	}
	
	@Scheduled(cron = "${cache.nomenclatures.refresh}")
	@CacheEvict(allEntries = true, value = {CacheName.NOMENCLATURES})
	public void refresh() {
		
	}
}
