package com.bnpparibas.bddf.collect.infrastructure.converter;

import java.util.Optional;
import java.util.UUID;

import org.dozer.BeanFactory;

public class UuidBeanFactory implements BeanFactory {

	@Override
	public Object createBean(Object sourceBean, Class<?> destinationType, String mapId) {
		return Optional.ofNullable(sourceBean).map(o -> (UUID) o).map(uuid -> new UUID(uuid.getMostSignificantBits(), uuid.getLeastSignificantBits())).orElse(null);
	}
}