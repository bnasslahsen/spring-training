package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bnpparibas.bddf.collect.infrastructure.entity.OwnerEntity;

@Repository
public interface OwnerJpaRepository extends JpaRepository<OwnerEntity, String> {

	List<OwnerEntity> findByReference(String refernece);

}
