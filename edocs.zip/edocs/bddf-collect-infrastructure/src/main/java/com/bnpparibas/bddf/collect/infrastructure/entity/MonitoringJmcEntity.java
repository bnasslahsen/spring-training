package com.bnpparibas.bddf.collect.infrastructure.entity;

import java.sql.Timestamp;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "MONITORING_JMC")
public class MonitoringJmcEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private Timestamp creationDate;
	private String typeId;
	private String entityId;
	private String codeCallWs;
	private String labelCallWs;
	private String statusCallWs;
	private String responseBody;
	private String requestBody;
	private Integer duration;

	public MonitoringJmcEntity() {
	}

	public MonitoringJmcEntity(String id) {
		this.id = id;
	}

	public MonitoringJmcEntity(Timestamp creationDate, String typeId, String entityId, String codeCallWs, String labelCallWs, String statusCallWs, String responseBody, String requestBody, Integer duration) {
		this.creationDate = Optional.ofNullable(creationDate).map(d -> (Timestamp) d.clone()).orElse(null);
		this.typeId = typeId;
		this.entityId = entityId;
		this.codeCallWs = codeCallWs;
		this.labelCallWs = labelCallWs;
		this.statusCallWs = statusCallWs;
		this.responseBody = responseBody;
		this.requestBody = requestBody;
		this.duration = duration;
	}

	@Id
	@Column(name = "ID", unique = true, nullable = false, length = 100)
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Column(name = "CREATION_DATE")
	public Timestamp getCreationDate() {
		return Optional.ofNullable(this.creationDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = Optional.ofNullable(creationDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Column(name = "TYPE_ID", length = 100)
	public String getTypeId() {
		return this.typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	@Column(name = "ENTITY_ID", length = 100)
	public String getEntityId() {
		return this.entityId;
	}

	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}

	@Column(name = "CODE_CALL_WS", length = 50)
	public String getCodeCallWs() {
		return this.codeCallWs;
	}

	public void setCodeCallWs(String codeCallWs) {
		this.codeCallWs = codeCallWs;
	}

	@Column(name = "LABEL_CALL_WS", length = 50)
	public String getLabelCallWs() {
		return this.labelCallWs;
	}

	public void setLabelCallWs(String labelCallWs) {
		this.labelCallWs = labelCallWs;
	}

	@Column(name = "STATUS_CALL_WS", length = 50)
	public String getStatusCallWs() {
		return this.statusCallWs;
	}

	public void setStatusCallWs(String statusCallWs) {
		this.statusCallWs = statusCallWs;
	}

	@Lob
	@Column(name = "RESPONSE_BODY")
	public String getResponseBody() {
		return this.responseBody;
	}

	public void setResponseBody(String responseBody) {
		this.responseBody = responseBody;
	}

	@Lob
	@Column(name = "REQUEST_BODY")
	public String getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}

	@Column(name = "DURATION")
	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

}
