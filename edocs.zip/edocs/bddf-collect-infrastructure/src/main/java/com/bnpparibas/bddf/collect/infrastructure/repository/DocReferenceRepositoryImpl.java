package com.bnpparibas.bddf.collect.infrastructure.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.domain.helper.StringHelper;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReference;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceRepository;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.infrastructure.entity.DocReferenceEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.DocReferenceMapper;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.DocReferenceJpaRepository;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.RepositoryImpl
@Repository
public class DocReferenceRepositoryImpl implements DocReferenceRepository {

	@Autowired
	private DocReferenceMapper docReferenceMapper;

	@Autowired
	private DocReferenceJpaRepository docReferenceJpaRepository;

	@Override
	@Transactional(readOnly = true)
	public List<DocReference> getByOwnersAndType(String owners, String edocType) {
		return docReferenceMapper.toDocReferences(docReferenceJpaRepository.byOwnersAndType(owners, edocType));
	}

	@Override
	public List<DocReference> getByOwnersAndTypes(String owners, List<String> edocTypes) {
		return docReferenceMapper.toDocReferences(docReferenceJpaRepository.byOwnersAndTypes(owners, edocTypes));
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void saveDocReferences(List<DocReference> docReferences, String ownerId, String edocType) {
		final List<DocReferenceEntity> docRefEntities = docReferenceMapper.toDocRefEntities(docReferences);
		docReferenceJpaRepository.saveAll(docRefEntities);

	}
	
	@Override
	public void deleteById(List<DocReference> docReferences) {
		docReferenceJpaRepository.deleteAll(docReferenceMapper.toDocRefEntities(docReferences));

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void insertDocRef(Type type, final List<DocReference> repositoryRefs, final List<DocReference> referenceToRemove) {
		saveDocReferences(repositoryRefs, StringHelper.reduceSet(type.getFamilyOwners()), type.getEdocType());
		deleteById(referenceToRemove);
	}

}
