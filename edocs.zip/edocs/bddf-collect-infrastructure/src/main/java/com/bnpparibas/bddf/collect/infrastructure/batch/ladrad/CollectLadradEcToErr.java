package com.bnpparibas.bddf.collect.infrastructure.batch.ladrad;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditEventService;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.domain.ladrad.LadRadValidator;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.infrastructure.batch.distributed.AbstractBatch;
import com.bnpparibas.bddf.collect.infrastructure.batch.notification.CollectNotificationClient;
import com.bnpparibas.bddf.collect.infrastructure.entity.TypeEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.TypeMapper;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.PieceJpaRepository;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.TypeJpaRepository;
import com.bnpparibas.bddf.email.BddfMailMessage;
import com.bnpparibas.bddf.email.MailService;
import com.bnpparibas.bddf.rest.Context;

@Component
@Transactional(transactionManager = "transactionManagerDB")
public class CollectLadradEcToErr extends AbstractBatch {

	private static final DateTimeFormatter FORMATTER_DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	private static final String LIGNE = "------------------------------|----------------------------------------|-------------------------------------|\n";
	private static final String TITRE = "          Code parcours       |              Type Edoc                 |             Id type                 |\n";

	@Autowired
	PieceJpaRepository pieceJpaRepository;

	@Autowired
	private LadRadValidator ladRadValidator;

	@Autowired
	private TypeRepository typeRepository;

	@Autowired
	private TypeJpaRepository typeJpaRepository;

	@Autowired
	private TypeMapper typeMapper;
	@Autowired
	private CollectRepository collectRepository;

	@Autowired
	private CollectEventHandler collectEventHandler;

	@Autowired
	private MailService mailService;

	@Autowired
	private Environment environment;

	@Autowired
	private TypeAutomaticControlUtils typeAutomaticControlUtils;

	@Value("${batchectoerr.activated}")
	private boolean isActivated;

	@Value("${batchectoerr.maxAmiDelayed}")
	private Integer maxAmiDelayed;

	@Value("${batchectoerr.maxAmiImmediate}")
	private Integer maxAmiImmediate;

	public CollectLadradEcToErr() {
		super("COLLECT_LADRAD_EC_TO_ERR");
	}

	private static final Logger LOG = LoggerFactory.getLogger(CollectNotificationClient.class);

	@Autowired
	private AuditEventService auditEventService;

	@Scheduled(cron = "${batchectoerr.cron}")
	@Override
	public void scheduledStart() {
		startBatch();
	}

	@Override
	@Transactional
	public void execute() {
		LOG.info("Début Batch LADRAD EC TO ERR");
		final long startTimeBatchEcToErr = System.currentTimeMillis();

		if (isActivated) {
			final List<String> ecTypes = typeJpaRepository.findByStatusEc();
			final List<String> ecAmiTypes = typeJpaRepository.findByStatusEcAmi();
			final List<Type> ecTypeMail = new ArrayList<>();
			final List<Collect> ecCollectMail = new ArrayList<>();
			final List<String> listTypes = ecTypes.stream().collect(Collectors.toList());

			listTypes.addAll(ecAmiTypes);
			listTypes.forEach(typeEntityId -> {
				try {

					final TypeEntity typeEntity = typeJpaRepository.findById(typeEntityId).orElse(null);
					final Type type = typeMapper.typeEntityToType(typeEntity);
					final Collect collect = collectRepository.findOne(UUID.fromString(typeEntity.getCollectId()));
					ladRadValidator.updateTypeWhenError(type);
					typeAutomaticControlUtils.autoAcceptType(collect.getId(), type, new Context("", Channel.API.getValue(), ""), AuditValue.LAD_RAD_AUTOMATIC_ACCEPTATION);
					typeRepository.updateType(UUID.fromString(typeEntity.getCollectId()), type);
					collectEventHandler.sendAutomaticControlEvent(UUID.fromString(typeEntity.getCollectId()), new Context("", Channel.API.getValue(), ""), type);
					auditEventService.sendAuditEventLadRAD(UUID.fromString(typeEntity.getCollectId()), new Context("", Channel.API.getValue(), ""), collect.getJourneyCode(), type, AuditValue.LAD_RAD_AUTOMATIC_CONTROL_ERROR, "");
					ecTypeMail.add(type);
					ecCollectMail.add(collect);
				} catch (final Exception e) {
					LOG.error("exception type id" + typeEntityId, e);
				}

			});
			if (!ecTypeMail.isEmpty()) {
				sendEmail(ecTypeMail, ecCollectMail);
			}

		}
		LOG.info("FIN Batch LADRAD EC TO ERR");
		final long endTimeBatchEcToErr = System.currentTimeMillis();
		final long secondsActionsGetCollect = endTimeBatchEcToErr - startTimeBatchEcToErr;
		LoggerHelper.logForPerfTest(LOG, "Batch LADRAD EC TO ERR Temps pour actions : " + secondsActionsGetCollect + " ms");

	}

	public void sendEmail(List<Type> typeList, List<Collect> collectList) {

		final StringBuilder emailBody = new StringBuilder();
		emailBody.append("Batch EC2ERR - " + typeList.size() + " types passés en erreur:\n\n");
		emailBody.append(TITRE);
		collectList.forEach(collect -> {
			emailBody.append(LIGNE);
			addToEmailBody(emailBody, findType(typeList, collect), collect.getJourneyCode(), collect);
		});
		final BddfMailMessage mailMessage = new BddfMailMessage(environment.getProperty("ladrad.mail.sender"), new String[] { environment.getProperty("ladrad.mail.recipient") }, getEmailSubject(), emailBody.toString(), false);
		mailService.sendMail(mailMessage);
	}

	public Type findType(List<Type> typeList, Collect collect) {
		for (final Type type : typeList) {
			if (collect.getTypes().contains(type)) {
				return type;
			}
		}
		return null;
	}

	private void addToEmailBody(StringBuilder email, Type type, String journeyCode, Collect collect) {
		email.append(journeyCode);
		email.append("                        |");
		email.append(type.getEdocType());
		email.append("                       | ");
		email.append(type.getId());
		email.append("|\n");
		// email.append(LIGNE);
	}

	private String getEmailSubject() {
		final StringBuilder subject = new StringBuilder(256);
		subject.append("- Erreur de traitement des types EC-LadRadEcToErrBatch-  ");
		subject.append(FORMATTER_DATE.format(LocalDateTime.ofInstant(new Date().toInstant(), ZoneId.systemDefault())));
		final String host = environment.getProperty("spring.cloud.client.hostname");
		final String hostParse = Optional.ofNullable(host).map(v -> v.contains(".") ? v.substring(0, v.indexOf('.')) : v).orElse("");
		subject.append(hostParse);
		return subject.toString();
	}

}
