package com.bnpparibas.bddf.collect.infrastructure.event.converter;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnp.schema.edoc.collectevent.Collecte;
import com.bnp.schema.edoc.collectevent.CollecteRoot;
import com.bnp.schema.edoc.collectevent.Families;
import com.bnp.schema.edoc.collectevent.Families.Family;
import com.bnp.schema.edoc.collectevent.Families.Family.Owners;
import com.bnp.schema.edoc.collectevent.Indexes;
import com.bnp.schema.edoc.collectevent.Indexes.Index;
import com.bnp.schema.edoc.collectevent.Pieces;
import com.bnp.schema.edoc.collectevent.Pieces.Piece;
import com.bnp.schema.edoc.collectevent.SubTypes;
import com.bnp.schema.edoc.collectevent.SubTypes.SubType;
import com.bnp.schema.edoc.collectevent.Types;
import com.bnp.schema.edoc.pieceevent.PieceRoot;
import com.bnp.schema.edoc.typeevent.TypeRoot;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.event.AbstractCollectEvent;
import com.bnpparibas.bddf.collect.domain.event.collect.UpdatedCollect;
import com.bnpparibas.bddf.collect.domain.event.piece.PieceSent2Gdn;
import com.bnpparibas.bddf.collect.domain.event.type.EventSendAMI;
import com.bnpparibas.bddf.collect.domain.event.type.TypeReceived;
import com.bnpparibas.bddf.collect.domain.helper.DateUtil;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.infrastructure.repository.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.jms.converter.ConverterBody.ConversionBodyFormat;
import com.bnpparibas.bddf.jms.sender.domain.BodyData;
import com.bnpparibas.bddf.jms.sender.domain.BusinessContextEvent;
import com.bnpparibas.bddf.jms.sender.domain.CRESender;
import com.bnpparibas.bddf.jms.sender.domain.Channel;
import com.bnpparibas.bddf.jms.sender.domain.ConceptEnum;
import com.bnpparibas.bddf.jms.sender.domain.ConceptEvent;
import com.bnpparibas.bddf.jms.sender.domain.EventData;
import com.bnpparibas.bddf.jms.sender.domain.HeaderData;
import com.bnpparibas.bddf.jms.sender.domain.Media;
import com.bnpparibas.bddf.jms.sender.domain.Type;

public final class EventDataHelper {

	private static final Logger LOG = LoggerFactory.getLogger(EventDataHelper.class);
	private static final String EVENT_VERSION = "2.0";

	private EventDataHelper() {
		super();
	}

	public static EventData fromTypeReceived(TypeReceived typeReceived) throws DatatypeConfigurationException {
		final EventData eventData = base(typeReceived);

		final CollecteRoot collecte = new CollecteRoot();
		eventData.getBodyData().setContent(collecte);

		final ConceptEvent cUser = new ConceptEvent();
		cUser.setIdentifiantConcept(typeReceived.getUserId());
		if (com.bnpparibas.bddf.collect.domain.piece.Channel.isCollab(eventData.getHeaderData().getChannel().getCode())) {
			cUser.setConcept(ConceptEnum.ID_COLLAB);
		} else {
			cUser.setConcept(ConceptEnum.ID_CLIENT);
		}
		eventData.getHeaderData().getOptionalContextEvent().add(cUser);

		// Content
		final Collecte content = basicCollecte(typeReceived.getCollect());
		collecte.setCollect(content);

		content.getFamilies().getFamily().add(buildFamily(typeReceived));

		return eventData;
	}

	public static EventData fromUpdatedCollect(UpdatedCollect updatedCollect) throws DatatypeConfigurationException {
		final EventData eventData = base(updatedCollect);

		final CollecteRoot collecte = new CollecteRoot();
		eventData.getBodyData().setContent(collecte);

		final ConceptEvent cUser = new ConceptEvent();
		cUser.setConcept(ConceptEnum.ID_COLLAB);
		cUser.setIdentifiantConcept(updatedCollect.getEmployeeId());
		eventData.getHeaderData().getOptionalContextEvent().add(cUser);

		// Content
		final Collecte content = basicCollecte(updatedCollect.getCollect());
		collecte.setCollect(content);

		buildFamillies(updatedCollect.getCollect().getTypes(), content.getFamilies().getFamily());

		return eventData;
	}

	public static EventData fromUpdatedPiece(PieceSent2Gdn pieceSent2Gdn) throws DatatypeConfigurationException {
		final EventData eventData = base(pieceSent2Gdn);

		final PieceRoot pieceRoot = new PieceRoot();
		final com.bnp.schema.edoc.pieceevent.Piece piece = basicPiece(pieceSent2Gdn);
		pieceRoot.setPiece(piece);
		eventData.getBodyData().setContent(pieceRoot);
		return eventData;
	}

	public static EventData constructEventAmi(EventSendAMI eventSendAMI) throws DatatypeConfigurationException {
		final EventData eventData = base(eventSendAMI);
		final TypeRoot typeRoot = new TypeRoot();
		final com.bnp.schema.edoc.typeevent.Type type = basicType(eventSendAMI);
		typeRoot.setType(type);
		eventData.getBodyData().setContent(typeRoot);
		return eventData;
	}

	static void buildFamillies(Set<com.bnpparibas.bddf.collect.domain.type.Type> types, List<Family> families) {
		final Map<UUID, Map<UUID, List<com.bnpparibas.bddf.collect.domain.type.Type>>> typeByFamille = types.stream()
				.collect(Collectors.groupingBy(com.bnpparibas.bddf.collect.domain.type.Type::getFamilyId, groupingByWithNullKeys(com.bnpparibas.bddf.collect.domain.type.Type::getParentId)));
		typeByFamille.forEach((familyId, typesMap) -> {
			final Types typesFamily = new Types();
			final Family family = buildFamily(typesMap, typesFamily);
			final Map<UUID, List<SubType>> mapSubTypes = new HashMap<>();
			// --------------------------------------------------------
			typesMap.forEach((idParent, list) -> {
				if (idParent == null) {
					// On parcours une liste de type
					list.forEach(a -> typesFamily.getType().add(buildType(a)));
				} else {
					// On parcours une liste de sous type
					mapSubTypes.put(idParent, list.stream().map(EventDataHelper::buildSubType).collect(Collectors.toList()));
				}
			});
			family.getTypes().getType().forEach(t -> Optional.ofNullable(mapSubTypes.get(UUID.fromString(t.getId()))).ifPresent(subTypesList -> t.setSubTypes(buildSubTypes(subTypesList))));
			families.add(family);
		});
	}

	private static SubTypes buildSubTypes(List<SubType> subTypesList) {
		final SubTypes subtypes = new SubTypes();
		subtypes.getSubType().addAll(subTypesList);
		return subtypes;
	}

	private static SubType buildSubType(com.bnpparibas.bddf.collect.domain.type.Type a) {
		final SubType st = new SubType();
		Optional.ofNullable(a.getControlDate()).ifPresent(d -> st.setControlDate(DateUtil.instantToString(a.getControlDate())));
		st.setId(a.getId().toString());
		st.setLabel(a.getLabel());
		st.setPendingDocument(String.valueOf(a.isPendingDocument()));
		st.setPendingDocumentLabel(a.getPendingDocumentLabel());
		Optional.ofNullable(a.getPieces()).ifPresent(l -> buildPieces(st, l));
		Optional.ofNullable(a.getIndexes()).ifPresent(l -> buildIndexes(st, l));
		return st;
	}

	private static void buildPieces(SubType st, Set<com.bnpparibas.bddf.collect.domain.piece.Piece> l) {
		final Pieces piecesType = new Pieces();
		st.setPieces(piecesType);
		l.stream().filter(EventDataHelper::filterPieceToSend).forEach(piece -> piecesType.getPiece().add(buildPiece(piece)));
	}

	private static void buildIndexes(SubType st, Set<Indexe> listIndexes) {
		if (CollectionUtils.isNotEmpty(listIndexes)) {
			final Indexes indexesEvent = new Indexes();
			st.setIndexes(indexesEvent);
			listIndexes.stream().forEach(indexe -> indexesEvent.getIndex().add(buildIndexEvent(indexe)));
		}
	}

	private static void buildIndexes(com.bnp.schema.edoc.collectevent.Types.Type t, Set<Indexe> listIndexes) {
		if (CollectionUtils.isNotEmpty(listIndexes)) {
			final Indexes indexesEvent = new Indexes();
			t.setIndexes(indexesEvent);
			listIndexes.stream().forEach(indexe -> indexesEvent.getIndex().add(buildIndexEvent(indexe)));
		}

	}

	private static String getTypeGdn(String edocType) {
		if ((new EdocTypesRepositoryImpl()).byValue(edocType) != null) {
			return (new EdocTypesRepositoryImpl()).byValue(edocType).getGdnType();
		}
		return "";
	}

	private static com.bnp.schema.edoc.collectevent.Types.Type buildType(com.bnpparibas.bddf.collect.domain.type.Type a) {
		final com.bnp.schema.edoc.collectevent.Types.Type t = new com.bnp.schema.edoc.collectevent.Types.Type();
		Optional.ofNullable(a.getControlDate()).ifPresent(d -> t.setControlDate(DateUtil.instantToString(d)));
		t.setControlRequired(String.valueOf(a.getControlRequired()));
		t.setDigitalAllowed(String.valueOf(a.isDigitalAllowed()));
		t.setDocumentType(a.getControlDocumentType());
		t.setId(a.getId().toString());
		t.setLabel(a.getLabel());
		t.setPendingDocument(String.valueOf(a.isPendingDocument()));
		t.setPendingDocumentLabel(a.getPendingDocumentLabel());
		t.setEdocType(a.getEdocType());
		t.setTypeGdn(getTypeGdn(a.getEdocType()));
		t.setStatus(a.getStatus());
		Optional.ofNullable(a.getPieces()).ifPresent(l -> buildPieces(t, l));
		Optional.ofNullable(a.getIndexes()).ifPresent(l -> buildIndexes(t, l));
		return t;
	}

	static void buildPieces(com.bnp.schema.edoc.collectevent.Types.Type t, Set<com.bnpparibas.bddf.collect.domain.piece.Piece> l) {
		final Pieces piecesType = new Pieces();
		t.setPieces(piecesType);
		l.stream().filter(EventDataHelper::filterPieceToSend).forEach(piece -> piecesType.getPiece().add(buildPiece(piece)));
	}

	private static boolean filterPieceToSend(com.bnpparibas.bddf.collect.domain.piece.Piece p) {
		return !Arrays.asList(PieceStatus.DP_EC.getLabel(), PieceStatus.DP_ERR.getLabel(), PieceStatus.TP.getLabel()).contains(p.getStatus());
	}

	private static com.bnp.schema.edoc.collectevent.Families.Family buildFamily(Map<UUID, List<com.bnpparibas.bddf.collect.domain.type.Type>> typesMap, Types typesFamily) {
		final UUID idFirstType = typesMap.keySet().iterator().next();
		final com.bnpparibas.bddf.collect.domain.type.Type type = typesMap.get(idFirstType).get(0);
		final Owners owners = new Owners();
		owners.getOwner().addAll(type.getFamilyOwners());
		final com.bnp.schema.edoc.collectevent.Families.Family family = new com.bnp.schema.edoc.collectevent.Families.Family();
		family.setCategory(type.getFamilyCategory());
		family.setCategoryComment(type.getFamilyCategoryComment());
		family.setId(type.getFamilyId().toString());
		family.setLabel(type.getFamilyLabel());
		family.setPropertyType(type.getFamilyPropertyType());
		family.setOwners(owners);
		family.setTypes(typesFamily);
		return family;
	}

	/* Like Collectors.groupingBy, but accepts null keys. */
	static <T, A> Collector<T, ?, Map<A, List<T>>> groupingByWithNullKeys(Function<? super T, ? extends A> classifier) {
		return Collectors.toMap(classifier, Collections::singletonList, (List<T> oldList, List<T> newEl) -> {
			final List<T> newList = new ArrayList<>(oldList.size() + 1);
			newList.addAll(oldList);
			newList.addAll(newEl);
			return newList;
		});
	}

	private static Collecte basicCollecte(Collect c) {
		final Collecte collecte = new Collecte();
		collecte.setCallingApplicationCode(c.getSendingApplicationCode());
		collecte.setCreationDate(DateUtil.instantToString(c.getCreationDate()));
		collecte.setId(c.getId().toString());
		collecte.setJourneyCode(c.getJourneyCode());
		collecte.setControlIterationAllowed(String.valueOf(c.getControlIterationAllowed()));
		collecte.setStatus(c.getStatus());
		collecte.setAutoValidation(String.valueOf(c.isAutoValidation()));
		collecte.setAutoAcceptation(String.valueOf(c.isAutoAcceptationAllowed()));
		collecte.setEntityLabel(c.getEntityLabel());
		collecte.setProject(c.getProject());
		collecte.setStepLabel(c.getStepLabel());
		collecte.setProductLabel(c.getProductLabel());
		collecte.setFamilies(new Families());
		return collecte;
	}

	private static com.bnp.schema.edoc.pieceevent.Piece basicPiece(PieceSent2Gdn pieceSent2Gdn) {
		final com.bnp.schema.edoc.pieceevent.Piece piece = new com.bnp.schema.edoc.pieceevent.Piece();
		final com.bnpparibas.bddf.collect.domain.piece.Piece pieceDomain = pieceSent2Gdn.getPiece();
		final String typeId = pieceSent2Gdn.getTypeId();
		piece.setCollectId(pieceSent2Gdn.getCollect().getId().toString());
		piece.setIdDocGdn(pieceDomain.getIdDocGdn());
		piece.setLabel(pieceDomain.getLabel());
		piece.setPieceId(pieceSent2Gdn.getPiece().getId().toString());
		piece.setTypeId(typeId);

		return piece;
	}

	private static com.bnp.schema.edoc.typeevent.Type basicType(EventSendAMI event) {
		final com.bnp.schema.edoc.typeevent.Type type = new com.bnp.schema.edoc.typeevent.Type();
		type.setCollectId(event.getColledId());
		type.setTypeId(event.getTypeId());
		return type;

	}

	private static Family buildFamily(TypeReceived typeReceived) {
		final com.bnp.schema.edoc.collectevent.Families.Family family = new Family();
		final Owners owners = new Owners();
		family.setCategory(typeReceived.getType().getFamilyCategory());
		family.setCategoryComment(typeReceived.getType().getFamilyCategoryComment());
		family.setId(typeReceived.getType().getFamilyId().toString());
		family.setLabel(typeReceived.getType().getFamilyLabel());
		family.setPropertyType(typeReceived.getType().getFamilyPropertyType());
		owners.getOwner().addAll(typeReceived.getType().getFamilyOwners());
		family.setOwners(owners);
		family.setTypes(buildTypes(typeReceived));

		return family;
	}

	private static Types buildTypes(TypeReceived typeReceived) {
		final Types types = new Types();
		final com.bnp.schema.edoc.collectevent.Types.Type type = new com.bnp.schema.edoc.collectevent.Types.Type();
		types.getType().add(type);
		Optional.ofNullable(typeReceived.getType().getControlDate()).ifPresent(d -> type.setControlDate(DateUtil.instantToString(d)));
		type.setPendingDocument(String.valueOf(typeReceived.getType().isPendingDocument()));
		type.setId(typeReceived.getType().getId().toString());
		type.setLabel(typeReceived.getType().getLabel());
		type.setPendingDocumentLabel(typeReceived.getType().getPendingDocumentLabel());
		type.setDigitalAllowed(String.valueOf(typeReceived.getType().isDigitalAllowed()));
		type.setEdocType(typeReceived.getType().getEdocType());
		type.setTypeGdn(getTypeGdn(typeReceived.getType().getEdocType()));
		type.setDocumentType(typeReceived.getType().getControlDocumentType());
		type.setControlRequired(String.valueOf(typeReceived.getType().getControlRequired()));
		type.setStatus(typeReceived.getType().getStatus());
		Optional.ofNullable(typeReceived.getType().getCompleteness()).ifPresent(d -> type.setCompleteness(StringUtils.join(typeReceived.getType().getCompleteness(), ',')));
		type.setCompletenessControl(typeReceived.getType().getCompletenessControlLabel());
		type.setStatusControl(typeReceived.getType().getStatusControl());
		type.setAdditionalInformation(typeReceived.getType().getAdditionalInformation());
		type.setMaxSizeDoc(String.valueOf(typeReceived.getType().getMaxSizeDoc()));
		type.setPosition(String.valueOf(typeReceived.getType().getPosition()));
		type.setEnableReuse(String.valueOf(typeReceived.getType().isEnableReuse()));

		if (Optional.ofNullable(typeReceived.getSubType()).isPresent()) {
			final SubTypes subTypes = new SubTypes();
			type.setSubTypes(subTypes);
			final SubType subType = buildSubType(typeReceived);
			subTypes.getSubType().add(subType);
		} else {
			final Pieces pieces = new Pieces();
			typeReceived.getPieces().forEach(p -> pieces.getPiece().add(buildPiece(p)));
			type.setPieces(pieces);
			final Indexes indexes = new Indexes();
			typeReceived.getType().getIndexes().forEach(indexe -> indexes.getIndex().add(buildIndexEvent(indexe)));
			if (CollectionUtils.isNotEmpty(typeReceived.getType().getIndexes())) {
				type.setIndexes(indexes);
			}

		}
		return types;
	}

	private static SubType buildSubType(TypeReceived typeReceived) {
		final SubType subType = new SubType();
		Optional.ofNullable(typeReceived.getSubType().getControlDate()).ifPresent(d -> subType.setControlDate(DateUtil.instantToString(d)));
		subType.setPendingDocument(String.valueOf(typeReceived.getSubType().isPendingDocument()));
		subType.setId(typeReceived.getSubType().getId().toString());
		subType.setLabel(typeReceived.getSubType().getLabel());
		subType.setPendingDocumentLabel(typeReceived.getSubType().getPendingDocumentLabel());
		Optional.ofNullable(typeReceived.getSubType().getCompleteness()).ifPresent(d -> subType.setCompleteness(StringUtils.join(typeReceived.getSubType().getCompleteness(), ',')));
		subType.setCompletenessControl(typeReceived.getSubType().getCompletenessControlLabel());
		subType.setStatusControl(typeReceived.getSubType().getStatusControl());
		subType.setStatus(typeReceived.getSubType().getStatus());
		final Pieces pieces = new Pieces();
		typeReceived.getPieces().forEach(p -> pieces.getPiece().add(buildPiece(p)));
		subType.setPieces(pieces);
		if (Optional.ofNullable(typeReceived.getSubType().getIndexes()).isPresent()) {
			final Indexes indexes = new Indexes();
			typeReceived.getSubType().getIndexes().forEach(indexe -> indexes.getIndex().add(buildIndexEvent(indexe)));
			if (CollectionUtils.isNotEmpty(typeReceived.getSubType().getIndexes())) {
				subType.setIndexes(indexes);
			}
		}
		return subType;
	}

	private static Piece buildPiece(com.bnpparibas.bddf.collect.domain.piece.Piece p) {
		final Piece piece = new Piece();
		piece.setRejectionComment(p.getRejectionComment());
		piece.setAcquisitionDate(DateUtil.instantToString(p.getAcquisitionDate()));
		if (Optional.ofNullable(p.getUpdateDate()).isPresent()) {
			piece.setUpdateDate(DateUtil.instantToString(p.getUpdateDate()));
		}
		piece.setReceivedFormat(p.getReceivedFormat());
		piece.setId(p.getId().toString());
		piece.setIdDocGdn(p.getIdDocGdn());
		piece.setLabel(p.getLabel());
		piece.setRejectionReason(p.getRejectionReason());
		if (PieceStates.INACTIF.getLabel().equals(p.getState())) {
			piece.setStatus("SU");
		} else {
			piece.setStatus(p.getStatus());
		}
		piece.setSize(String.valueOf(p.getSize()));
		piece.setContentType(p.getContentType());
		piece.setChannel(p.getChannel());
		piece.setEmployeeId(p.getEmployeeId());
		piece.setOwnerId(p.getOwnerId());
		piece.setStatusControl(p.getStatusControl());
		piece.setTypeControl(p.getTypeControl());
		piece.setExtractionControl(p.getExtractionControl());
		piece.setCoherenceControl(p.getCoherenceControl());
		piece.setControlIterationAchieved(String.valueOf(p.getControlIterationAchieved()));
		return piece;
	}

	private static Index buildIndexEvent(Indexe indexe) {
		final Index indexEvent = new Index();
		try {
			BeanUtils.copyProperties(indexEvent, indexe);

		} catch (IllegalAccessException | InvocationTargetException e) {
			LOG.info(e.getMessage(), e);
		}
		return indexEvent;
	}

	private static EventData base(AbstractCollectEvent bodyContent) throws DatatypeConfigurationException {
		// Event
		final EventData eventData = new EventData();

		// Body
		final BodyData bodyData = new BodyData();
		eventData.setBodyData(bodyData);
		bodyData.setConversionBodyFormat(ConversionBodyFormat.XML);

		// Header
		final HeaderData headerData = new HeaderData();
		eventData.setHeaderData(headerData);

		// Fill header
		final GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(new Date());
		headerData.setDateTimeRef(DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar));
		headerData.setCommon("004");
		headerData.setEstablishmentId("00000000000000001");
		headerData.setEventId(bodyContent.getEventId().toString());
		headerData.setChannel(Channel.findByCode(bodyContent.getChannel()));
		headerData.setMedia(StringUtils.isEmpty(bodyContent.getMedia()) ? Media.SERVEUR_VOCAL : Media.findByCode(bodyContent.getMedia()));
		final BusinessContextEvent businessContextEvent = new BusinessContextEvent();
		headerData.setBusinessContextEvent(businessContextEvent);
		businessContextEvent.setConsumers(bodyContent.getCollect().getOwners().stream().map(Owner::getReference).collect(Collectors.toList()));
		businessContextEvent.setType(Type.PERSON);
		headerData.setNomenclatureRef(bodyContent.getNomenclatureRef());
		final CRESender creSender = new CRESender();
		creSender.setVersion(EVENT_VERSION);
		headerData.setCreSender(creSender);
		final ConceptEvent conceptEvent = new ConceptEvent();
		conceptEvent.setConcept(ConceptEnum.ID_DOSSIER);
		conceptEvent.setIdentifiantConcept(bodyContent.getCollect().getId().toString());
		headerData.setConceptEvent(conceptEvent);
		headerData.setOptionalContextEvent(new ArrayList<>());
		final ConceptEvent idApp = new ConceptEvent();
		idApp.setConcept(ConceptEnum.ID_APPLICATION);
		idApp.setIdentifiantConcept("AP12247");
		headerData.getOptionalContextEvent().add(idApp);
		final ConceptEvent journeyCode = new ConceptEvent();
		journeyCode.setConcept(ConceptEnum.JOURNEY_CODE);
		journeyCode.setIdentifiantConcept(bodyContent.getCollect().getJourneyCode());
		headerData.getOptionalContextEvent().add(journeyCode);

		return eventData;
	}

}
