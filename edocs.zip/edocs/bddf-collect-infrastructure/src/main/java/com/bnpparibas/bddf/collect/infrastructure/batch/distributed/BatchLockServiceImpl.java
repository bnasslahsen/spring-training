package com.bnpparibas.bddf.collect.infrastructure.batch.distributed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.BatchLockJpaRepository;

@Service
public class BatchLockServiceImpl implements BatchLockService {

	private static final String UNLOCK = "UNLOCK";
	private static final String LOCK = "LOCK";

	@Autowired
	private BatchLockJpaRepository batchLockJpaRepository;

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public boolean lockTable(String batchName) {
		// si le nombre de lignes modifiées sont supérieures à 0 (au moins une)
		// alors on est executé en premier par la BDD et donc on a le lock
		return batchLockJpaRepository.updateSwitch(batchName, UNLOCK, LOCK) > 0;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void unLockTable(String batchName) {
		batchLockJpaRepository.reinitSwitch(batchName, UNLOCK);
	}

}
