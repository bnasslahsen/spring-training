package com.bnpparibas.bddf.collect.infrastructure.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class IndexePieceId implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private String indexeId;
	private String pieceId;
	private String idPieceJmc;
	private String controlCode;

	public IndexePieceId() {
	}

	public IndexePieceId(String indexeId, String pieceId, String idPieceJmc, String controlCode) {
		this.indexeId = indexeId;
		this.pieceId = pieceId;
		this.idPieceJmc = idPieceJmc;
		this.controlCode = controlCode;
	}

	@Column(name = "INDEXE_ID", nullable = false, length = 100)
	public String getIndexeId() {
		return this.indexeId;
	}

	public void setIndexeId(String indexeId) {
		this.indexeId = indexeId;
	}

	@Column(name = "PIECE_ID", nullable = false, length = 100)
	public String getPieceId() {
		return this.pieceId;
	}

	public void setPieceId(String pieceId) {
		this.pieceId = pieceId;
	}

	@Column(name = "ID_PIECE_JMC", nullable = false, length = 50)
	public String getIdPieceJmc() {
		return idPieceJmc;
	}

	public void setIdPieceJmc(String idPieceJmc) {
		this.idPieceJmc = idPieceJmc;
	}

	@Column(name = "CONTROL_CODE", length = 200)
	public String getControlCode() {
		return this.controlCode;
	}

	public void setControlCode(String controlCode) {
		this.controlCode = controlCode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((controlCode == null) ? 0 : controlCode.hashCode());
		result = prime * result + ((idPieceJmc == null) ? 0 : idPieceJmc.hashCode());
		result = prime * result + ((indexeId == null) ? 0 : indexeId.hashCode());
		result = prime * result + ((pieceId == null) ? 0 : pieceId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		boolean isEqual = true;
		if (this == obj) {
			isEqual = true;
		}
		if (obj == null) {
			isEqual = false;
		}
		if (!(obj instanceof IndexePieceId)) {
			isEqual = false;
		}
		final IndexePieceId other = (IndexePieceId) obj;
		if (controlCode == null) {
			if (other != null && other.controlCode != null) {
				isEqual = false;
			}
		} else if (other != null && !controlCode.equals(other.controlCode)) {
			isEqual = false;
		}
		if (idPieceJmc == null) {
			if (other != null && other.idPieceJmc != null) {
				isEqual = false;
			}
		} else if (other != null && !idPieceJmc.equals(other.idPieceJmc)) {
			isEqual = false;
		}
		if (indexeId == null) {
			if (other != null && other.indexeId != null) {
				isEqual = false;
			}
		} else if (other != null && !indexeId.equals(other.indexeId)) {
			isEqual = false;
		}
		if (pieceId == null) {
			if (other != null && other.pieceId != null) {
				isEqual = false;
			}
		} else if (other != null && !pieceId.equals(other.pieceId)) {
			isEqual = false;
		}
		return isEqual;
	}

}
