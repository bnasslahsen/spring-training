package com.bnpparibas.bddf.collect.infrastructure.repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.infrastructure.entity.CollectEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.CollectMapper;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.CollectJpaRepository;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.OwnerJpaRepository;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.RepositoryImpl
@Repository
public class CollectRepositoryImpl implements CollectRepository {

	@Autowired
	CollectJpaRepository collectJpaRepository;

	@Autowired
	OwnerJpaRepository ownerJpaRepository;

	@Autowired
	CollectMapper collectMapper;

	@Override
	@Transactional(readOnly = true)
	public Collect findOne(UUID id) {
		return collectMapper.toCollect(collectJpaRepository.findById(id.toString()).orElse(null), true);
	}

	@Override
	public Collect findOnlyCollect(UUID id) {
		final Optional<CollectEntity> collectOptionnel = collectJpaRepository.findById(id.toString());
		return collectMapper.mapOnlyCollect(collectOptionnel.isPresent() ? collectOptionnel.get() : null);
	}

	@Override
	public Set<UUID> findAll() {
		return collectJpaRepository.findAllIds().stream().map(UUID::fromString).collect(Collectors.toSet());
	}

	@Override
	public Set<Collect> findByOwners(Set<String> references, List<String> journeyCodes) {
		if (CollectionUtils.isNotEmpty(journeyCodes)) {
			return collectMapper.toCollects(collectJpaRepository.findByRefsAndJourneyCode(references, journeyCodes));
		}
		return collectMapper.toCollects(collectJpaRepository.findByRefs(references));
	}

	@Override
	public Integer countByOwners(Set<String> references, String journeyCode) {
		return collectJpaRepository.countByRefsAndJourneyCode(references, journeyCode);
	}

	@Override
	public void add(Collect collect) {
		collectJpaRepository.save(collectMapper.toCollectEntity(collect, true));
	}

	@Override
	public void endCollect(Collect c) {
		updateCollect(c);
	}

	@Override
	public Set<Owner> getOwnerByCollect(UUID collectId) {
		return findOne(collectId).getOwners();
	}

	@Override
	public String getJourneyCode(UUID collectId) {
		return collectJpaRepository.findById(collectId.toString()).orElse(null).getJourneyCode();
	}

	@Override
	public void delete(UUID collectId) {
		collectJpaRepository.deleteById(collectId.toString());
	}

	@Override
	public void updateCollect(Collect collect) {
		final CollectEntity cE = collectMapper.toCollectEntity(collect, false);
		collectJpaRepository.save(cE);
	}

}
