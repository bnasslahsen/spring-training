package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.sql.Timestamp;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.infrastructure.entity.DocReferenceEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.DocReferenceJpaRepository;

@Component
public class PurgeDocReferenceItemReader implements ItemReader<DocReferenceEntity> {

	private Iterator<DocReferenceEntity> docRefIdsIt;
	private List<DocReferenceEntity> listDocRefs;

	@Autowired
	private DocReferenceJpaRepository docReferenceJpaRepository;
	@Autowired
	private EdocTypeRepository edocTypeRepository;

	@Override
	public DocReferenceEntity read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		synchronized (this) {
			if (docRefIdsIt == null) {
				listDocRefs = new ArrayList<DocReferenceEntity>();
				final Map<Integer, List<EdocType>> edocTypesByRetentionMonths = edocTypeRepository.findAll().stream().collect(Collectors.groupingBy(this::getMonthExpirationTime));
				edocTypesByRetentionMonths.forEach((monthsRetentionTime, edocTypes) -> {
					listDocRefs.addAll(docReferenceJpaRepository.getByRetentionTime(getExpirationDateFromMonthsRetention(monthsRetentionTime), edocTypes.stream().map(EdocType::getValue).collect(Collectors.toList())));

				});
				docRefIdsIt = listDocRefs.iterator();
			}
		}
		if (docRefIdsIt.hasNext()) {
			return docRefIdsIt.next();
		} else {
			return null;
		}
	}

	private Integer getMonthExpirationTime(EdocType edocType) {
		return edocType.getMonthRentetionTime() + 12 * edocType.getYearRentetionTime();
	}

	public static Timestamp getExpirationDateFromMonthsRetention(Integer months) {
		final ZonedDateTime todayMidnight = ZonedDateTime.now(ZoneId.systemDefault()).truncatedTo(ChronoUnit.DAYS);
		return Timestamp.from(todayMidnight.plusMonths(-months).toInstant());
	}

	public DocReferenceJpaRepository getDocReferenceJpaRepository() {
		return docReferenceJpaRepository;
	}

	public void setDocReferenceJpaRepository(DocReferenceJpaRepository docReferenceJpaRepository) {
		this.docReferenceJpaRepository = docReferenceJpaRepository;
	}

	public EdocTypeRepository getEdocTypeRepository() {
		return edocTypeRepository;
	}

	public void setEdocTypeRepository(EdocTypeRepository edocTypeRepository) {
		this.edocTypeRepository = edocTypeRepository;
	}

	public Iterator<DocReferenceEntity> getDocRefIdsIt() {
		return docRefIdsIt;
	}

	public void setDocRefIdsIt(Iterator<DocReferenceEntity> docRefIdsIt) {
		this.docRefIdsIt = docRefIdsIt;
	}

}
