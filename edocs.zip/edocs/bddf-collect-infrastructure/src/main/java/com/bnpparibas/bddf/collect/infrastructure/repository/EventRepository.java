package com.bnpparibas.bddf.collect.infrastructure.repository;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bnpparibas.bddf.collect.infrastructure.entity.AuditEventEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.EventEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.AuditEventJpaRepository;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.EventJpaRepository;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.RepositoryImpl
@Repository
public class EventRepository {

	@Autowired
	private EventJpaRepository eventJpaRepository;

	@Autowired
	private AuditEventJpaRepository auditEventJpaRepository;

	public void saveEvent(EventEntity event) {
		eventJpaRepository.save(event);
	}

	public EventEntity findEvent(UUID id) {
		return eventJpaRepository.findById(id.toString()).orElse(null);
	}

	public void saveAuditEvent(AuditEventEntity event) {
		auditEventJpaRepository.save(event);
	}

	public AuditEventEntity findAuditEvent(UUID id) {
		return auditEventJpaRepository.findById(id.toString()).orElse(null);
	}

	public void updateStatusEvent(String eventId, String status) {
		eventJpaRepository.updateStatus(eventId, status);
	}
	
}
