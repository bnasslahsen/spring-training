package com.bnpparibas.bddf.collect.infrastructure.jpa.mapper;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.infrastructure.entity.CollectEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.FamilyEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.OwnerEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.TypeEntity;

@Component
public class FamilyMapper {

	@Autowired
	OwnerMapper ownerMapper;

	@Autowired
	TypeMapper typeMapper;

	public Set<FamilyEntity> toFamilyEntities(Set<Type> types, CollectEntity collectEntity, boolean isNew) {
		final HashSet<FamilyEntity> families = new HashSet<>();
		final Map<UUID, List<Type>> mapFamilies = types.stream().collect(Collectors.groupingBy(Type::getFamilyId));

		mapFamilies.keySet().forEach(uuid -> {
			final List<Type> familiesType = mapFamilies.get(uuid);
			final FamilyEntity entity = toFamilyEntity(familiesType, collectEntity, isNew);
			families.add(entity);

		});

		return families;
	}

	public FamilyEntity toFamilyEntity(List<Type> familyTypes, CollectEntity collectEntity, boolean isNew) {
		final Type firstType = familyTypes.get(0);
		final FamilyEntity familyEntity = new FamilyEntity();
		familyEntity.setAdditionalInformation(firstType.getFamilyAdditionalInformation());
		familyEntity.setAdditionalInformationCollab(firstType.getFamilyAdditionalInformationCollab());
		familyEntity.setCategory(firstType.getFamilyCategory());
		familyEntity.setCategoryComment(firstType.getFamilyCategoryComment());
		familyEntity.setCollect(collectEntity);
		if (CollectionUtils.isNotEmpty(firstType.getFamiliesManagementActFamily())) {
			familyEntity.setFamiliesManagementAct(String.join(",", firstType.getFamiliesManagementActFamily()));
		}

		familyEntity.setIconeCode(firstType.getFamilyIconCode());
		familyEntity.setId(firstType.getFamilyId().toString());
		familyEntity.setLabel(firstType.getFamilyLabel());
		if (CollectionUtils.isNotEmpty(firstType.getPiecesManagementActFamily())) {
			familyEntity.setPiecesManagementAct(String.join(",", firstType.getPiecesManagementActFamily()));
		}

		familyEntity.setPosition(Integer.valueOf(firstType.getFamilyPosition()));
		familyEntity.setPropertyType(firstType.getFamilyPropertyType());
		familyEntity.setBlocked(firstType.isFamilyBlocked());
		familyEntity.setNew(isNew);

		familyEntity.setOwners(ownerMapper.toOwnersEntitiesForFamily(collectEntity.getOwners(), firstType.getFamilyOwners(), isNew));
		familyEntity.setTypes(new HashSet<TypeEntity>());
		familyTypes.forEach(typeToCopy -> {
			final TypeEntity typeEntity = new TypeEntity();
			typeMapper.copyTypeData(typeEntity, typeToCopy, familyEntity, isNew, collectEntity.getId());
			familyEntity.getTypes().add(typeEntity);
		});

		return familyEntity;
	}

	public Set<Type> toFamilies(Set<FamilyEntity> familyEntities, boolean withInactivePieces) {
		final HashSet<Type> types = new HashSet<>();
		familyEntities.forEach(familyEntity -> {
			final Set<Type> typesOfFamily = toFamily(familyEntity, withInactivePieces);
			types.addAll(typesOfFamily);
		});
		return types;

	}

	public Set<Type> toFamily(FamilyEntity familyEntity, boolean withInactivePieces) {
		final Set<Type> types = new HashSet<>();
		familyEntity.getTypes().forEach(typeEntity -> {
			final Type type = typeMapper.typeEntityToType(typeEntity, withInactivePieces);
			types.add(type);
		});

		types.forEach(type -> {
			type.setFamilyAdditionalInformation(familyEntity.getAdditionalInformation());
			type.setFamilyAdditionalInformationCollab(familyEntity.getAdditionalInformationCollab());
			type.setFamilyCategory(familyEntity.getCategory());
			type.setFamilyCategoryComment(familyEntity.getCategoryComment());
			type.setFamilyIconCode(familyEntity.getIconeCode());
			type.setFamilyId(UUID.fromString(familyEntity.getId()));
			type.setFamilyLabel(familyEntity.getLabel());
			type.setFamilyBlocked(familyEntity.isBlocked());

			if (StringUtils.isNotEmpty(familyEntity.getFamiliesManagementAct())) {
				type.setFamiliesManagementActFamily(new HashSet(Arrays.asList(familyEntity.getFamiliesManagementAct().split(","))));
			}

			if (StringUtils.isNotEmpty(familyEntity.getPiecesManagementAct())) {
				type.setPiecesManagementActFamily(new HashSet(Arrays.asList(familyEntity.getPiecesManagementAct().split(","))));
			}

			type.setFamilyPropertyType(familyEntity.getPropertyType());
			type.setFamilyPosition(familyEntity.getPosition());
			type.setFamilyOwners(familyEntity.getOwners().stream().map(OwnerEntity::getReference).collect(Collectors.toSet()));
		});

		return types;
	}

}
