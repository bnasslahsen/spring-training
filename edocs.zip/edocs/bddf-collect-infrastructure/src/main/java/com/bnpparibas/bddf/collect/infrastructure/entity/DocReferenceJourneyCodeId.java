package com.bnpparibas.bddf.collect.infrastructure.entity;

import java.sql.Timestamp;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class DocReferenceJourneyCodeId implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private String edocType;
	private String referencePieceId;
	private String ownerId;
	private Timestamp updateDate;
	private String journeyCode;

	public DocReferenceJourneyCodeId() {
	}

	public DocReferenceJourneyCodeId(String edocType, String referencePieceId, String ownerId, Timestamp updateDate, String journeyCode) {
		super();
		this.edocType = edocType;
		this.referencePieceId = referencePieceId;
		this.ownerId = ownerId;
		this.updateDate = Optional.ofNullable(updateDate).map(d -> (Timestamp) d.clone()).orElse(null);
		this.journeyCode = journeyCode;
	}

	public DocReferenceJourneyCodeId(Timestamp updateDate, String journeyCode) {
		this.updateDate = Optional.ofNullable(updateDate).map(d -> (Timestamp) d.clone()).orElse(null);
		this.journeyCode = journeyCode;
	}

	@Column(name = "UPDATE_DATE", nullable = false)
	public Timestamp getUpdateDate() {
		return Optional.ofNullable(this.updateDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setUpdateDate(Timestamp updateDate) {
		this.updateDate = Optional.ofNullable(updateDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Column(name = "JOURNEY_CODE", nullable = false, length = 6)
	public String getJourneyCode() {
		return this.journeyCode;
	}

	public void setJourneyCode(String journeyCode) {
		this.journeyCode = journeyCode;
	}

	@Column(name = "OWNER_ID", nullable = false, length = 17)
	public String getOwnerId() {
		return this.ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	@Column(name = "EDOC_TYPE", nullable = false, length = 17)
	public String getEdocType() {
		return this.edocType;
	}

	@Column(name = "REFERENCE_PIECE_ID", length = 100)
	public String getReferencePieceId() {
		return this.referencePieceId;
	}

	public void setReferencePieceId(String referencePieceId) {
		this.referencePieceId = referencePieceId;
	}

	public void setEdocType(String edocType) {
		this.edocType = edocType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((journeyCode == null) ? 0 : journeyCode.hashCode());
		result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof DocReferenceJourneyCodeId)) {
			return false;
		}
		final DocReferenceJourneyCodeId other = (DocReferenceJourneyCodeId) obj;
		if (journeyCode == null) {
			if (other.journeyCode != null) {
				return false;
			}
		} else if (!journeyCode.equals(other.journeyCode)) {
			return false;
		}
		if (updateDate == null) {
			if (other.updateDate != null) {
				return false;
			}
		} else if (!updateDate.equals(other.updateDate)) {
			return false;
		}
		return true;
	}

}
