package com.bnpparibas.bddf.collect.infrastructure.converter;

import java.util.UUID;

import org.dozer.CustomConverter;
import org.dozer.MappingException;

public class UUIDToStringConverter implements CustomConverter {

	@Override
	public Object convert(Object destination, Object source, Class destClass, Class sourceClass) {
		if (source == null) {
			return null;
		}

		if (source instanceof UUID) {
			return ((UUID)source).toString();
		} else if (source instanceof String) {
			return UUID.fromString((String)source);
		} else {
			throw new MappingException("Converter UUIDToString "
					+ "used incorrectly. Arguments passed in were:" + destination + " and " + source);
		}
	}
}
