package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bnpp.jdf.connector.IJdfConnectorConstants;
import com.bnpp.jdf.connector.exception.ConnectorFunctionalException;
import com.bnpp.jdf.connector.exception.ConnectorTechnicalException;
import com.bnpp.jdf.deletedoc.query.DeleteDocI;
import com.bnpparibas.bddf.collect.infrastructure.entity.PieceEntity;
import com.bnpparibas.bddf.collect.infrastructure.gdn.service.GdnService;

@Component
public class PurgePieceGdnItemWriter implements ItemWriter<PieceEntity> {
	private static final Logger LOG = LoggerFactory.getLogger(PurgePieceGdnItemWriter.class);
	@Value("${app.name}")
	protected String appName;
	@Autowired
	private GdnService gdnService;

	@Override
	public void write(List<? extends PieceEntity> allPiecesToDelete) throws Exception {
		allPiecesToDelete.stream().map(this::deletePieceNas).reduce(BatchResult.defaultRes(), BatchResult::groupMaps);
	}

	private Map<String, Long> deletePieceNas(PieceEntity piece) {
		final Map<String, Long> result = BatchResult.defaultRes();
		try {
			if (piece.getIdDocGdn() != null) {
				deleteDocGdn(piece);

			}
			BatchResult.resOk(result);
		} catch (ConnectorTechnicalException | ConnectorFunctionalException e) {
			LOG.error(e.getMessage(), e);
			BatchResult.resKo(result);
		}
		return result;

	}

	private void deleteDocGdn(PieceEntity piece) throws ConnectorTechnicalException, ConnectorFunctionalException {
		final DeleteDocI deleteDocI = new DeleteDocI();
		deleteDocI.setDocumentId(piece.getIdDocGdn());
		deleteDocI.setOwningApplication(appName);

		String pUser = "999999";
		if (StringUtils.isNotBlank(piece.getOwnerId())) {
			pUser = piece.getOwnerId();
		} else if (StringUtils.isNotBlank(piece.getEmployeeId())) {
			pUser = piece.getEmployeeId();
		}

		final Map<String, String> params = new HashMap<String, String>();

		params.put(IJdfConnectorConstants.CALLING_USER, pUser);

		gdnService.deleteDoc(deleteDocI, params);
	}

}
