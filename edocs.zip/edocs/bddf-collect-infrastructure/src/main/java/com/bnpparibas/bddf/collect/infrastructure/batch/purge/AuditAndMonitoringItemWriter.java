package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.AuditEventJpaRepository;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.EventJpaRepository;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.MonitoringJmcJpaRepository;

@Component
public class AuditAndMonitoringItemWriter implements ItemWriter<String> {

	private static final Logger LOG = LoggerFactory.getLogger(AuditAndMonitoringItemWriter.class);
	
	@Autowired
	private EventJpaRepository eventJpaRepository;
	@Autowired
	private AuditEventJpaRepository auditEventJpaRepository;
	@Autowired
	private MonitoringJmcJpaRepository monitoringJmcJpaRepository;
	
	@Override
	public void write(List<? extends String> collectIds) throws Exception {
		try {
			auditEventJpaRepository.deleteByCollectIds((List<String>) collectIds);
			eventJpaRepository.deleteByCollectIds((List<String>) collectIds);
			monitoringJmcJpaRepository.deleteByCollectIds((List<String>) collectIds);
		} catch (final Exception e) {
			LOG.error(e.getMessage(), e);
		}

	}

}
