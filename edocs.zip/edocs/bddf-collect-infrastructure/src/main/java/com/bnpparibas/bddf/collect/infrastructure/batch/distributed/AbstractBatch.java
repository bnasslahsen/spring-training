package com.bnpparibas.bddf.collect.infrastructure.batch.distributed;

import org.springframework.beans.factory.annotation.Autowired;

public abstract class AbstractBatch {

	@Autowired
	private BatchService batchService;

	private final String batchName;

	public AbstractBatch(String batchName) {
		this.batchName = batchName;
	}

	public String getBatchName() {
		return batchName;
	}

	protected void startBatch() {
		batchService.startBatch(this);
	}

	/**
	 * This method should call startBatch with a scheduled annotation
	 */
	public abstract void scheduledStart();

	/**
	 * This method should contain batch process
	 */
	public abstract void execute();

	// public abstract void sendMonitoring();

}
