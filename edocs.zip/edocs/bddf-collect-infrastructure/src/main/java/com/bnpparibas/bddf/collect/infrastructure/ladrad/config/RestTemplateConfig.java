package com.bnpparibas.bddf.collect.infrastructure.ladrad.config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.ProxyAuthenticationStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.support.BasicAuthorizationInterceptor;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {

	private static final Logger LOG = LoggerFactory.getLogger(RequestResponseLoggingInterceptor.class);
	
	@Value("${jouve.hookaccount.username}")
	private String jouveHookAccountUsername;
	@Value("${jouve.hookaccount.password}")
	private String jouveHookAccountPassword;
	@Value("${proxy.host}")
	private String proxyHost;
	@Value("${proxy.port}")
	private Integer proxyPort;
	@Value("${proxy.login}")
	private String proxyLogin;
	@Value("${proxy.password}")
	private String proxyPassword;
	@Value("${proxy.requiredAuth}")
	private Boolean proxyRequiredAuth;
	@Value("${proxy.useCertifSSL}")
	private Boolean enableProxyCertifSSL;
	@Value("${proxy.useProxy}")
	private Boolean enabledProxy;
	@Value("${jouve.poolhttp.maxconnection}")
	private Integer jouvePoolhttpMaxconnection;
	@Value("${restTemplateJMC.readTimeout}")
	private Integer restTemplateJMCReadTimeout;
	@Value("${restTemplateJMC.connectTimeout}")
	private Integer restTemplateJMCConnectTimeout;
	

	// SSL PARAMS
	@Value("${jouve.ssl.enabled}")
	private boolean sslEnabled;
	@Value("${jouve.ssl.keystore.fullPath:default}")
	private String keystoreFullPath;
	@Value("${jouve.ssl.keystore.password:default}")
	private String keystorePassword;
	@Value("${jouve.ssl.truststore.fullPath:default}")
	private String truststoreFullPath;
	@Value("${jouve.ssl.truststore.password:default}")
	private String truststorePassword;
	
	private SSLConnectionSocketFactory sslSocketFactory;

	public RestTemplateConfig() {
		super();
	}

	@Bean(name = "restTemplateJMC")
	public RestTemplate restTemplate(RestTemplateBuilder builder) throws GeneralSecurityException, IOException {
		final RestTemplate restTemplate = builder.build();
		final HttpClientBuilder clientBuilder = HttpClientBuilder.create().setMaxConnPerRoute(jouvePoolhttpMaxconnection).setMaxConnTotal(jouvePoolhttpMaxconnection);
		if(sslEnabled){
			if (LOG.isInfoEnabled()) {
				LOG.info("keystorePassword         : {}", keystorePassword);
			}
			clientBuilder.setSSLSocketFactory(getSSLSocketFactory());
		}
		if (enabledProxy) {
			clientBuilder.setProxy(new HttpHost(proxyHost, proxyPort));
			clientBuilder.setProxyAuthenticationStrategy(new ProxyAuthenticationStrategy());
		}
		if (proxyRequiredAuth) {
			final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
			credentialsProvider.setCredentials(new AuthScope(proxyHost, proxyPort, AuthScope.ANY_REALM), new UsernamePasswordCredentials(proxyLogin, proxyPassword));
			clientBuilder.setDefaultCredentialsProvider(credentialsProvider);
		}
		CloseableHttpClient client = null;
		if (enableProxyCertifSSL) {
			client = clientBuilder.useSystemProperties().build();
		} else {
			client = clientBuilder.build();
		}
		final HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(client);
		clientHttpRequestFactory.setConnectTimeout(restTemplateJMCConnectTimeout);
		clientHttpRequestFactory.setReadTimeout(restTemplateJMCReadTimeout);		
		restTemplate.setRequestFactory(clientHttpRequestFactory);
		restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor(jouveHookAccountUsername, jouveHookAccountPassword));
		return restTemplate;
	}
	
	private SSLConnectionSocketFactory getSSLSocketFactory() throws GeneralSecurityException, IOException {
		if (sslSocketFactory == null) {
			initialiseSSLFactory();
		}
		return sslSocketFactory;
	}
	
	private void initialiseSSLFactory() throws GeneralSecurityException, IOException {

		KeyStore keyStore = getKeyStore("PKCS12", keystoreFullPath, keystorePassword);
		KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		kmf.init(keyStore, keystorePassword.toCharArray());

		KeyStore trustStore = getKeyStore("PKCS12", truststoreFullPath, truststorePassword);
		TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		tmf.init(trustStore);

		SSLContext sc = SSLContext.getInstance("TLS");
		sc.init(kmf.getKeyManagers(), tmf.getTrustManagers(), new java.security.SecureRandom());
		sslSocketFactory = new SSLConnectionSocketFactory(sc, new String[]{"TLSv1"}, null,    
				   SSLConnectionSocketFactory.getDefaultHostnameVerifier());
	}

	private KeyStore getKeyStore(final String keyStoreType, final String keystorePath, final String password)
			throws KeyStoreException, FileNotFoundException, IOException, NoSuchAlgorithmException,
			CertificateException {
		final KeyStore keyStore = KeyStore.getInstance(keyStoreType);

		InputStream is = null;
		try {
			is = new FileInputStream(keystorePath);
			keyStore.load(is, password.toCharArray());
		} finally {
			if (is != null)
				is.close();
		}
		return keyStore;
	}
}
