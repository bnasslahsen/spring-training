package com.bnpparibas.bddf.collect.infrastructure.event.converter;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.stereotype.Component;

@Component
public class SmMessageConverter implements MessageConverter {

	private static final Logger LOGGER = LoggerFactory.getLogger(SmMessageConverter.class);

	public SmMessageConverter() {
		super();
	}

	@Override
	public Message toMessage(Object object, Session session) throws JMSException {
		final String xml = object.toString();
		LOGGER.debug("Marshalled message {}", xml);
		return session.createTextMessage(xml);
	}

	@Override
	public Object fromMessage(Message message) throws JMSException {
		return null;
	}

}
