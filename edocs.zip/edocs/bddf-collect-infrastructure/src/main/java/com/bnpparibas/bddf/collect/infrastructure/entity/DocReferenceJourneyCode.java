package com.bnpparibas.bddf.collect.infrastructure.entity;

import java.sql.Timestamp;
import java.util.Optional;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

@Entity
@Table(name = "DOC_REFERENCE_JOURNEY_CODE")
public class DocReferenceJourneyCode implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private DocReferenceJourneyCodeId id;
	private DocReferenceEntity docReference;

	public DocReferenceJourneyCode() {
	}

	public DocReferenceJourneyCode(Timestamp updateDate, String journeyCode, DocReferenceEntity docReference) {
		this.id = new DocReferenceJourneyCodeId(updateDate, journeyCode);
		this.docReference = docReference;
		this.getId().setEdocType(Optional.ofNullable(docReference).map(v -> v.getId().getEdocType()).orElse(""));
		this.getId().setOwnerId(Optional.ofNullable(docReference).map(v -> v.getId().getOwnerId()).orElse(""));
		this.getId().setReferencePieceId(Optional.ofNullable(docReference).map(v -> v.getId().getReferencePieceId()).orElse(""));
	}

	public DocReferenceJourneyCode(DocReferenceJourneyCodeId id, DocReferenceEntity docReference) {
		this.id = id;
		this.docReference = docReference;
	}

	public DocReferenceJourneyCode(String edocType, String referencePieceId, String ownerId, Timestamp updateDate, String journeyCode, DocReferenceEntity docReference) {
		this.id = new DocReferenceJourneyCodeId(edocType, referencePieceId, ownerId, updateDate, journeyCode);
		this.docReference = docReference;
	}

	@EmbeddedId
	@AttributeOverrides({ @AttributeOverride(name = "updateDate", column = @Column(name = "UPDATE_DATE", nullable = false)), @AttributeOverride(name = "journeyCode", column = @Column(name = "JOURNEY_CODE", nullable = false)),
			@AttributeOverride(name = "REFERENCE_PIECE_ID", column = @Column(name = "REFERENCE_PIECE_ID", nullable = false)), })
	public DocReferenceJourneyCodeId getId() {
		return this.id;
	}

	public void setId(DocReferenceJourneyCodeId id) {
		this.id = id;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@MapsId("edocType, referencePieceId, ownerId")
	@JoinColumns({ @JoinColumn(name = "OWNER_ID", referencedColumnName = "OWNER_ID"), @JoinColumn(name = "EDOC_TYPE", referencedColumnName = "EDOC_TYPE"), @JoinColumn(name = "REFERENCE_PIECE_ID", referencedColumnName = "REFERENCE_PIECE_ID") })
	public DocReferenceEntity getDocReference() {
		return this.docReference;
	}

	public void setDocReference(DocReferenceEntity docReference) {
		this.docReference = docReference;
	}

}
