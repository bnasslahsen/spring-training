package com.bnpparibas.bddf.collect.infrastructure.repository;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Arrays;
import java.util.Optional;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusFolderDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusPieceDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.UploadDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.RequestWSJMCType;
import com.bnpparibas.bddf.collect.domain.type.LadRadRepository;
import com.bnpparibas.bddf.collect.infrastructure.entity.MonitoringJmcEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.TimestampUtils;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.errors.TechnicalException;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.exception.HystrixRuntimeException;

@DDD.InfrastructureServiceImpl
@Service
public class LadRadRepositoryImpl implements LadRadRepository {

	private static final Logger LOG = LoggerFactory.getLogger(LadRadRepositoryImpl.class);

	@Value("${jouve.scheme}")
	private String ladradSheme;
	@Value("${jouve.port}")
	private Integer ladradPort;
	@Value("${jouve.host}")
	private String ladradHost;
	@Value("${jouve.individualaccount.username}")
	private String ladradIndividualAccountUserName;
	@Value("${jouve.individualaccount.password}")
	private String ladradIndividualAccountPsswd;

	@Value("${ladrad.path.base}")
	private String ladradUrlBase;
	@Value("${ladrad.path.deleteFolderBase}")
	private String urlDeleteFolderBase;
	@Value("${ladrad.path.deleteFolderEnd}")
	private String urlDeleteFolderEnd;
	@Value("${ladrad.path.createFolder}")
	private String ladradUrlCreateFolder;
	@Value("${ladrad.path.statusFolder}")
	private String ladradUrlStatusFolder;
	@Value("${ladrad.path.analyzeFolder}")
	private String ladradUrlAnalyseFolder;
	@Value("${ladrad.path.injectRefData}")
	private String ladradUrlInjectRefData;
	@Value("${ladrad.path.uploadDocument}")
	private String ladradUrlUploadDocument;
	@Value("${ladrad.path.baseDocument}")
	private String ladradUrlBaseDocument;
	@Value("${ladrad.path.basePiece}")
	private String ladradUrlBasePiece;
	@Value("${ladrad.path.basePage}")
	private String ladradUrlBasePage;
	@Value("${ladrad.path.updatePiece}")
	private String ladradUrlUpdatePiece;
	@Value("${ladrad.path.createPiece}")
	private String ladradUrlCreatePiece;
	@Value("${ladrad.path.forcePiece}")
	private String ladradUrlForcePiece;
	@Value("${ladrad.path.deleteDocumentBase}")
	private String ladradUrlDeleteDocuementBase;
	@Value("${ladrad.path.deleteDocumentEnd}")
	private String ladradUrlDeleteDocuementEnd;
	@Value("${ladrad.path.postAmiBase}")
	private String ladradUrlPostAMiBase;
	@Value("${ladrad.path.postAmiEnd}")
	private String ladradUrlPostAmiEnd;

	@Autowired
	@Qualifier(value = "restTemplateJMC")
	private RestTemplate restTemplateJMC;

	@Autowired
	private MonitoringJmcRepositoryImpl monitoringJMCCassandraRepository;

	private HttpHeaders headers;

	@PostConstruct
	private void addHeaders() {
		final StringBuilder plainCreds = new StringBuilder(ladradIndividualAccountUserName);
		plainCreds.append(":").append(ladradIndividualAccountPsswd);
		final byte[] plainCredsBytes = plainCreds.toString().getBytes();
		final byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
		final String base64Creds = new String(base64CredsBytes);
		headers = new HttpHeaders();
		headers.add("AUTH-USER", base64Creds);
	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public URI createFolder(String externalRef, String createFolderJson, UUID idType) {
		long startTime = 0;
		try {
			headers.setContentType(MediaType.APPLICATION_JSON);
			final HttpEntity<String> request = new HttpEntity<>(createFolderJson, headers);
			final URL urlCreateFolder = new URL(ladradSheme, ladradHost, ladradPort, ladradUrlCreateFolder);
			startTime = System.currentTimeMillis();
			final URI uri = restTemplateJMC.postForLocation(urlCreateFolder.toURI(), request);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.CREATE_FOLDER, HttpStatus.CREATED, Optional.ofNullable(uri).map(URI::toString).orElse(""), createFolderJson, duration);
			return uri;
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.CREATE_FOLDER, ex.getStatusCode(), ex.getResponseBodyAsString(), createFolderJson, duration);
			// LOG.error(CollectErrorConstants.ERR_CREATE_FOLDER_JMC + " : " + ex.getMessage(), ex);
			// Si le dosssier existe déja côté JMC , on ne génère pas d'exception ("This external reference is already in use")
			if (!HttpStatus.BAD_REQUEST.equals(ex.getStatusCode())) {
				throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_CREATE_FOLDER_JMC, externalRef);
			} else {
				return null;
			}

		} catch (final MalformedURLException | RestClientException | URISyntaxException | HystrixRuntimeException ex) {// NOSONAR
			// LOG.error(CollectErrorConstants.ERR_ACCES_LADRAD_TECH + " : " + ex.getMessage(), ex);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.CREATE_FOLDER, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), createFolderJson, duration);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_CREATE_FOLDER_JMC, externalRef);
		}

	}

	private Integer claculateDuration(long startTime) {
		final long endTime = System.currentTimeMillis();
		return (int) (endTime - startTime);
	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public StatusFolderDTO getStatusFolder(String externalRef, UUID idType) {
		long startTime = 0;
		try {
			final HttpEntity<String> request = new HttpEntity<>(externalRef, headers);
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			final StringBuilder urlStatusFolder = new StringBuilder(ladradUrlBase);
			urlStatusFolder.append(externalRef).append(ladradUrlStatusFolder);
			final URL urlGetStatusFolder = new URL(ladradSheme, ladradHost, ladradPort, urlStatusFolder.toString());
			final ResponseEntity<StatusFolderDTO> out = restTemplateJMC.exchange(urlGetStatusFolder.toURI(), HttpMethod.GET, request, StatusFolderDTO.class);
			startTime = System.currentTimeMillis();
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.GET_STATUS_FOLDER, HttpStatus.NO_CONTENT, null, null, duration);
			return out.getBody();
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.GET_STATUS_FOLDER, ex.getStatusCode(), ex.getResponseBodyAsString(), null, duration);
			// LOG.error(CollectErrorConstants.ERR_ACCES_LADRAD_TECH + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_ACCES_LADRAD_TECH, externalRef);
		} catch (final MalformedURLException | RestClientException | HttpMessageNotReadableException | URISyntaxException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.GET_STATUS_FOLDER, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), null, duration);
			// LOG.error(CollectErrorConstants.ERR_ACCES_LADRAD_TECH + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_ACCES_LADRAD_TECH, externalRef);
		}
	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public void analyseFolder(String externalRef, UUID idType) {
		long startTime = 0;
		try {
			final HttpEntity<Void> request = new HttpEntity<>(headers);
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			final StringBuilder urlAnalyseFolder = new StringBuilder(ladradUrlBase);
			urlAnalyseFolder.append(externalRef).append(ladradUrlAnalyseFolder);
			final URL urlAnaylseFolder = new URL(ladradSheme, ladradHost, ladradPort, urlAnalyseFolder.toString());
			startTime = System.currentTimeMillis();
			restTemplateJMC.postForLocation(urlAnaylseFolder.toURI(), request);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.ANAYLYSE_FOLDER, HttpStatus.NO_CONTENT, null, null, duration);
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.ANAYLYSE_FOLDER, ex.getStatusCode(), ex.getResponseBodyAsString(), null, duration);
			// LOG.error(CollectErrorConstants.ERR_ANALYSE_FOLDER_JMC + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_ANALYSE_FOLDER_JMC, externalRef);
		} catch (final MalformedURLException | RestClientException | URISyntaxException ex) {// NOSONAR
			// LOG.error(CollectErrorConstants.ERR_ACCES_LADRAD_TECH + " : " + ex.getMessage(), ex);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.ANAYLYSE_FOLDER, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), null, duration);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_ANALYSE_FOLDER_JMC, externalRef);
		}
	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public void injectRefDataFolder(String externalRef, String fieldsFolderJson, UUID idType) {
		long startTime = 0;
		try {
			headers.setContentType(MediaType.APPLICATION_JSON);
			final HttpEntity<String> request = new HttpEntity<>(fieldsFolderJson, headers);
			final StringBuilder urlInjectRefDataFolder = new StringBuilder(ladradUrlBase);
			urlInjectRefDataFolder.append(externalRef).append(ladradUrlInjectRefData);
			final URL injectRefDataFolderURL = new URL(ladradSheme, ladradHost, ladradPort, urlInjectRefDataFolder.toString());
			startTime = System.currentTimeMillis();
			restTemplateJMC.postForEntity(injectRefDataFolderURL.toURI(), request, String.class);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.INJECT_REF_DATA, HttpStatus.NO_CONTENT, null, fieldsFolderJson, duration);
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.INJECT_REF_DATA, ex.getStatusCode(), ex.getResponseBodyAsString(), fieldsFolderJson, duration);
			// LOG.error(CollectErrorConstants.ERR_INJECT_REF_DATA + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_INJECT_REF_DATA, externalRef);
		} catch (final MalformedURLException | RestClientException | URISyntaxException ex) {// NOSONAR
			// LOG.error(CollectErrorConstants.ERR_INJECT_REF_DATA + " : " + ex.getMessage(), ex);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.INJECT_REF_DATA, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), null, duration);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_INJECT_REF_DATA, externalRef);
		}

	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public String getFolder(String externalRef, UUID idType) {
		long startTime = 0;
		try {
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			final HttpEntity<String> request = new HttpEntity<>(externalRef, headers);
			final StringBuilder urlGetFolder = new StringBuilder(ladradUrlBase);
			urlGetFolder.append(externalRef);
			final URL getFolderURL = new URL(ladradSheme, ladradHost, ladradPort, urlGetFolder.toString());
			startTime = System.currentTimeMillis();
			final ResponseEntity<String> out = restTemplateJMC.exchange(getFolderURL.toURI(), HttpMethod.GET, request, String.class);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.GET_FOLDER, HttpStatus.OK, null, null, duration);
			return out.getBody();
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.GET_FOLDER, ex.getStatusCode(), ex.getResponseBodyAsString(), null, duration);
			if (ex.getStatusCode().equals(HttpStatus.NOT_FOUND)) {
				return null;
			}
			// LOG.error(CollectErrorConstants.ERR_ACCES_LADRAD_TECH + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_ACCES_LADRAD_TECH, externalRef);
		} catch (final MalformedURLException | RestClientException | HttpMessageNotReadableException | URISyntaxException ex) {// NOSONAR
			// LOG.error(CollectErrorConstants.ERR_ACCES_LADRAD_TECH + " : " + ex.getMessage(), ex);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.GET_FOLDER, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), null, duration);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_ACCES_LADRAD_TECH, externalRef);
		}
	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public URI uploadDocument(String externalRef, UploadDocumentDTO uploadDocumentDTO, InputStream inputStreamDocument, UUID idType) {
		long startTime = 0;
		try {
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			final HttpEntity<byte[]> entity = new HttpEntity<>(IOUtils.toByteArray(inputStreamDocument), headers);
			final StringBuilder urlUploadDocument = new StringBuilder(ladradUrlBase);
			urlUploadDocument.append(externalRef).append(ladradUrlUploadDocument).append("?documentExternalRef=").append(uploadDocumentDTO.getDocumentExternalRef()).append("&toAnalyze=").append(uploadDocumentDTO.getToAnalyze());
			final URL uploadDocumentURL = new URL(ladradSheme, ladradHost, ladradPort, urlUploadDocument.toString());
			startTime = System.currentTimeMillis();
			final URI uri = restTemplateJMC.postForLocation(uploadDocumentURL.toURI(), entity);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.UPLOAD_DOCUMENT, HttpStatus.NO_CONTENT, null, null, duration);
			return uri;
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.UPLOAD_DOCUMENT, ex.getStatusCode(), ex.getResponseBodyAsString(), null, duration);
			// LOG.error(CollectErrorConstants.ERR_UPLOAD_DOCUMENT_JMC + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_UPLOAD_DOCUMENT_JMC, uploadDocumentDTO.getDocumentExternalRef());
		} catch (final IOException | RestClientException | URISyntaxException ex) {// NOSONAR
			// LOG.error(CollectErrorConstants.ERR_ACCES_LADRAD_TECH + " : " + ex.getMessage(), ex);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.UPLOAD_DOCUMENT, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), null, duration);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_UPLOAD_DOCUMENT_JMC, externalRef);
		}

	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public StatusDocumentDTO getStatusDocument(String externalRef, UUID idType) {
		long startTime = 0;
		Integer duration;
		try {
			final HttpEntity<String> request = new HttpEntity<>(externalRef, headers);
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			final StringBuilder urlStatusFolder = new StringBuilder(ladradUrlBaseDocument);
			urlStatusFolder.append(externalRef).append(ladradUrlStatusFolder);
			final URL urlGetStatus = new URL(ladradSheme, ladradHost, ladradPort, urlStatusFolder.toString());
			startTime = System.currentTimeMillis();
			final ResponseEntity<StatusDocumentDTO> out = restTemplateJMC.exchange(urlGetStatus.toURI(), HttpMethod.GET, request, StatusDocumentDTO.class);
			duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.GET_STATUS_DOCUMENT, HttpStatus.NO_CONTENT, Optional.ofNullable(out).map(v -> v.getBody().toString()).orElse(""), null, duration);
			return out.getBody();
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			duration = claculateDuration(startTime);
			traceCallWS(externalRef, idType, RequestWSJMCType.GET_STATUS_DOCUMENT, ex.getStatusCode(), ex.getResponseBodyAsString(), null, duration);
			// LOG.error(CollectErrorConstants.ERR_GET_STATUS_DOCULENT_JMC + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_GET_STATUS_DOCULENT_JMC, externalRef);
		} catch (final MalformedURLException | RestClientException | HttpMessageNotReadableException | URISyntaxException ex) {// NOSONAR
			duration = claculateDuration(startTime);
			// LOG.error(CollectErrorConstants.ERR_ACCES_LADRAD_TECH + " : " + ex.getMessage(), ex);
			traceCallWS(externalRef, idType, RequestWSJMCType.GET_STATUS_DOCUMENT, HttpStatus.REQUEST_TIMEOUT, ex.getMessage(), null, duration);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_GET_STATUS_DOCULENT_JMC, externalRef);
		}
	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public String getPiece(String idPieceJMC, UUID idType) {
		long startTime = 0;
		try {
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			final HttpEntity<String> request = new HttpEntity<>(idPieceJMC, headers);
			final StringBuilder urlGetFolder = new StringBuilder(ladradUrlBasePiece);
			urlGetFolder.append(idPieceJMC);
			final URL getFolderURL = new URL(ladradSheme, ladradHost, ladradPort, urlGetFolder.toString());
			startTime = System.currentTimeMillis();
			final ResponseEntity<String> out = restTemplateJMC.exchange(getFolderURL.toURI(), HttpMethod.GET, request, String.class);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(idPieceJMC, idType, RequestWSJMCType.GET_PIECE, HttpStatus.NO_CONTENT, out.getBody(), null, duration);
			return out.getBody();
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(idPieceJMC, idType, RequestWSJMCType.GET_PIECE, ex.getStatusCode(), ex.getResponseBodyAsString(), null, duration);
			// LOG.error(CollectErrorConstants.ERR_GET_PIECE_JMC + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_GET_PIECE_JMC, idPieceJMC);

		} catch (final MalformedURLException | RestClientException | HttpMessageNotReadableException | URISyntaxException ex) {// NOSONAR
			// LOG.error(CollectErrorConstants.ERR_ACCES_LADRAD_TECH + " : " + ex.getMessage(), ex);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(idPieceJMC, idType, RequestWSJMCType.GET_PIECE, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), null, duration);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_GET_PIECE_JMC, idPieceJMC);
		}
	}

	@Override
	public void traceCallWS(String idEntity, UUID idType, RequestWSJMCType requestWSJMCType, HttpStatus httpStatus, String responseBody, String requestBody, Integer duration) {
		final MonitoringJmcEntity monitoringJMCEntity = new MonitoringJmcEntity(TimestampUtils.getNow(), idType.toString(), idEntity, requestWSJMCType.getLabel(), requestWSJMCType.name(), String.valueOf(httpStatus.value()), responseBody, requestBody,
				duration);
		monitoringJMCCassandraRepository.saveMonitoringJMC(monitoringJMCEntity);
	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public StatusPieceDTO getStatusPiece(String idPieceJMC, UUID idType) {
		long startTime = 0;
		try {
			final HttpEntity<String> request = new HttpEntity<>(idPieceJMC, headers);
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			final StringBuilder urlStatusFolder = new StringBuilder(ladradUrlBasePiece);
			urlStatusFolder.append(idPieceJMC).append(ladradUrlStatusFolder);
			final URL urlGetStatus = new URL(ladradSheme, ladradHost, ladradPort, urlStatusFolder.toString());
			startTime = System.currentTimeMillis();
			final ResponseEntity<StatusPieceDTO> out = restTemplateJMC.exchange(urlGetStatus.toURI(), HttpMethod.GET, request, StatusPieceDTO.class);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(idPieceJMC, idType, RequestWSJMCType.GET_STATUS_PIECE, HttpStatus.NO_CONTENT, null, null, duration);
			return out.getBody();
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(idPieceJMC, idType, RequestWSJMCType.GET_PIECE, ex.getStatusCode(), ex.getResponseBodyAsString(), null, duration);
			// LOG.error(CollectErrorConstants.ERR_GET_STATUS_PIECE_JMC + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_GET_STATUS_PIECE_JMC, idPieceJMC);
		} catch (final MalformedURLException | RestClientException | HttpMessageNotReadableException | URISyntaxException ex) {// NOSONAR
			// LOG.error(CollectErrorConstants.ERR_ACCES_LADRAD_TECH + " : " + ex.getMessage(), ex);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(idPieceJMC, idType, RequestWSJMCType.GET_PIECE, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), null, duration);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_GET_STATUS_PIECE_JMC, idPieceJMC);
		}
	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public URI createPiece(String typeJmcJason, String pageId, UUID idType) {
		long startTime = 0;
		try {
			headers.setContentType(MediaType.APPLICATION_JSON);
			final HttpEntity<String> request = new HttpEntity<>(typeJmcJason, headers);
			final StringBuilder urlCreatePiece = new StringBuilder(ladradUrlBasePage);
			urlCreatePiece.append(pageId).append(ladradUrlCreatePiece);
			final URL createPieceURL = new URL(ladradSheme, ladradHost, ladradPort, urlCreatePiece.toString());
			startTime = System.currentTimeMillis();
			final URI out = restTemplateJMC.postForLocation(createPieceURL.toURI(), request);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(pageId, idType, RequestWSJMCType.CREATE_PIECE, HttpStatus.NO_CONTENT, null, typeJmcJason, duration);
			return out;
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(pageId, idType, RequestWSJMCType.CREATE_PIECE, ex.getStatusCode(), ex.getResponseBodyAsString(), typeJmcJason, duration);
			// LOG.error(CollectErrorConstants.ERR_CREATE_PIECE_JMC + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_CREATE_PIECE_JMC, pageId);
		} catch (final MalformedURLException | RestClientException | URISyntaxException ex) {// NOSONAR
			// LOG.error(CollectErrorConstants.ERR_ACCES_LADRAD_TECH + " : " + ex.getMessage(), ex);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(pageId, idType, RequestWSJMCType.CREATE_PIECE, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), null, duration);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_CREATE_PIECE_JMC, pageId);
		}
	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public void forcePieceType(String typeJmcJason, String idEmptyPieceJmc, UUID idType) {
		long startTime = 0;
		try {
			headers.setContentType(MediaType.APPLICATION_JSON);
			final HttpEntity<String> request = new HttpEntity<>(typeJmcJason, headers);
			final StringBuilder urlCreatePiece = new StringBuilder(ladradUrlBasePiece);
			urlCreatePiece.append(idEmptyPieceJmc).append(ladradUrlForcePiece);
			final URL createPieceURL = new URL(ladradSheme, ladradHost, ladradPort, urlCreatePiece.toString());
			startTime = System.currentTimeMillis();
			restTemplateJMC.postForLocation(createPieceURL.toURI(), request);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(idEmptyPieceJmc, idType, RequestWSJMCType.FORCE_TYPE_PIECE, HttpStatus.NO_CONTENT, null, typeJmcJason, duration);
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(idEmptyPieceJmc, idType, RequestWSJMCType.FORCE_TYPE_PIECE, ex.getStatusCode(), ex.getResponseBodyAsString(), typeJmcJason, duration);
			// LOG.error(CollectErrorConstants.ERR_FORCE_PIECE_JMC + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_FORCE_PIECE_JMC, idEmptyPieceJmc);
		} catch (final MalformedURLException | RestClientException | URISyntaxException ex) {// NOSONAR
			// LOG.error(CollectErrorConstants.ERR_ACCES_LADRAD_TECH + " : " + ex.getMessage(), ex);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(idEmptyPieceJmc, idType, RequestWSJMCType.FORCE_TYPE_PIECE, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), null, duration);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_FORCE_PIECE_JMC, idEmptyPieceJmc);
		}
	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public void updatePiece(String correctedIndexes, String pieceId, UUID idType) {
		long startTime = 0;
		try {
			headers.setContentType(MediaType.APPLICATION_JSON);
			final HttpEntity<String> request = new HttpEntity<>(correctedIndexes, headers);
			final StringBuilder urlUpdatePiece = new StringBuilder(ladradUrlBasePiece);
			urlUpdatePiece.append(pieceId).append(ladradUrlUpdatePiece);
			final URL updatePieceURL = new URL(ladradSheme, ladradHost, ladradPort, urlUpdatePiece.toString());
			startTime = System.currentTimeMillis();
			restTemplateJMC.postForLocation(updatePieceURL.toURI(), request);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(pieceId, idType, RequestWSJMCType.UPDATE_PIECE, HttpStatus.NO_CONTENT, null, correctedIndexes, duration);
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(pieceId, idType, RequestWSJMCType.UPDATE_PIECE, ex.getStatusCode(), ex.getResponseBodyAsString(), correctedIndexes, duration);
			// LOG.error(CollectErrorConstants.ERR_UPDATE_PIECE_JMC + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_UPDATE_PIECE_JMC, correctedIndexes);
		} catch (final MalformedURLException | RestClientException | URISyntaxException ex) {// NOSONAR
			// LOG.error(CollectErrorConstants.ERR_ACCES_LADRAD_TECH + " : " + ex.getMessage(), ex);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(pieceId, idType, RequestWSJMCType.UPDATE_PIECE, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), null, duration);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_UPDATE_PIECE_JMC, correctedIndexes);
		}
	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public void deleteFolder(String folderExternalReference, UUID idType) {
		long startTime = 0;
		String referenceFolder = "";
		try {

			final StatusFolderDTO statusFolderDTO = getStatusFolder(folderExternalReference, idType);
			referenceFolder = statusFolderDTO.getReference();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			final HttpEntity<String> request = new HttpEntity<>(headers);
			final StringBuilder urlDeleteFolder = new StringBuilder(urlDeleteFolderBase);
			urlDeleteFolder.append(referenceFolder);
			urlDeleteFolder.append(urlDeleteFolderEnd);
			final URL deleteFolderURL = new URL(ladradSheme, ladradHost, ladradPort, urlDeleteFolder.toString());
			startTime = System.currentTimeMillis();
			restTemplateJMC.exchange(deleteFolderURL.toURI(), HttpMethod.POST, request, Object.class);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(referenceFolder, idType, RequestWSJMCType.DELETE_FOLDER, HttpStatus.OK, null, null, duration);
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(referenceFolder, idType, RequestWSJMCType.DELETE_FOLDER, ex.getStatusCode(), ex.getResponseBodyAsString(), null, duration);
			// LOG.error(CollectErrorConstants.ERR_JMC_DELETE_FOLDER + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_JMC_DELETE_FOLDER, referenceFolder);
		} catch (final MalformedURLException | RestClientException | URISyntaxException ex) {// NOSONAR
			// LOG.error(CollectErrorConstants.ERR_JMC_DELETE_FOLDER + " : " + ex.getMessage(), ex);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(referenceFolder, idType, RequestWSJMCType.DELETE_FOLDER, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), null, duration);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_JMC_DELETE_FOLDER, referenceFolder);
		}

	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public void deleteDocument(String documentExternalReference, UUID idType) {
		long startTime = 0;
		String referenceDocument = "";
		try {
			final StatusDocumentDTO statusDocument = getStatusDocument(documentExternalReference, idType);
			referenceDocument = statusDocument.getReference();

			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			final HttpEntity<String> request = new HttpEntity<>(headers);
			final StringBuilder urlDeleteFolder = new StringBuilder(ladradUrlDeleteDocuementBase);
			urlDeleteFolder.append(referenceDocument);
			urlDeleteFolder.append(ladradUrlDeleteDocuementEnd);
			final URL deleteFolderURL = new URL(ladradSheme, ladradHost, ladradPort, urlDeleteFolder.toString());
			startTime = System.currentTimeMillis();
			restTemplateJMC.exchange(deleteFolderURL.toURI(), HttpMethod.POST, request, Object.class);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(referenceDocument, idType, RequestWSJMCType.DELETE_DOCUMENT, HttpStatus.OK, null, null, duration);
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(referenceDocument, idType, RequestWSJMCType.DELETE_DOCUMENT, ex.getStatusCode(), ex.getResponseBodyAsString(), null, duration);
			// LOG.error(CollectErrorConstants.ERR_JMC_DELETE_DOCUMENT + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_JMC_DELETE_DOCUMENT, referenceDocument);
		} catch (final MalformedURLException | RestClientException | URISyntaxException ex) {// NOSONAR
			// LOG.error(CollectErrorConstants.ERR_JMC_DELETE_DOCUMENT + " : " + ex.getMessage(), ex);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(referenceDocument, idType, RequestWSJMCType.DELETE_DOCUMENT, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), null, duration);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_JMC_DELETE_DOCUMENT, referenceDocument);
		}

	}

	@Override
	@HystrixCommand(commandKey = "exchangeWSJmc")
	public void sendDocumentToAmi(String documentRef, UUID typeId, String amiJason) {
		long startTime = 0;
		try {
			headers.setContentType(MediaType.APPLICATION_JSON);
			final HttpEntity<String> request = new HttpEntity<>(amiJason, headers);
			final StringBuilder urlSendAmi = new StringBuilder(ladradUrlPostAMiBase);
			urlSendAmi.append(documentRef).append(ladradUrlPostAmiEnd);
			final URL postAmiURL = new URL(ladradSheme, ladradHost, ladradPort, urlSendAmi.toString());
			startTime = System.currentTimeMillis();
			restTemplateJMC.postForLocation(postAmiURL.toURI(), request);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(documentRef, typeId, RequestWSJMCType.POST_AMI, HttpStatus.NO_CONTENT, null, amiJason, duration);
		} catch (final HttpStatusCodeException ex) {// NOSONAR
			final Integer duration = claculateDuration(startTime);
			traceCallWS(documentRef, typeId, RequestWSJMCType.POST_AMI, ex.getStatusCode(), ex.getResponseBodyAsString(), amiJason, duration);
			// LOG.error(CollectErrorConstants.ERR_POST_AMI + " : " + ex.getMessage(), ex);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_POST_AMI, documentRef);
		} catch (final MalformedURLException | RestClientException | URISyntaxException ex) {// NOSONAR
			// LOG.error(CollectErrorConstants.ERR_POST_AMI + " : " + ex.getMessage(), ex);
			final Integer duration = claculateDuration(startTime);
			traceCallWS(documentRef, typeId, RequestWSJMCType.POST_AMI, HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), null, duration);
			throw new TechnicalException(HttpStatus.SERVICE_UNAVAILABLE, CollectErrorConstants.ERR_POST_AMI, documentRef);
		}

	}

}
