package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Step;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.support.CompositeItemWriter;
import org.springframework.batch.item.support.PassThroughItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.CollectJpaRepository;

public abstract class AbstractBatchPurgeCollect extends AbstractBatchPurge {

	private static final Logger LOG = LoggerFactory.getLogger(AbstractBatchPurgeCollect.class);

	@Autowired
	private CollectJpaRepository collectJpaRepository;
	@Autowired
	private NasRemoveItemWriter nasRemoveItemWriter;
	@Autowired
	private GdnRemoveItemWriter gdnRemoveItemWriter;
	@Autowired
	private CollectDeleteItemWriter collectDeleteItemWriter;
	private final PurgeType purgeType;

	public AbstractBatchPurgeCollect(String batchName, String batchType, PurgeType purgeType) {
		super(batchName, batchType);
		this.purgeType = purgeType;
	}

	@Override
	protected Step step(Map<String, Long> res) {
		return stepBuilderFactory.get("step1_" + getBatchName()).<String, String> chunk(getBatchSize()).reader(reader()).processor(new PassThroughItemProcessor<String>()).writer(writer(res)).build();
	}

	protected ItemWriter<String> writer(Map<String, Long> res) {

		final ItemWriter<String> countCollectsItemWriter = new CountCollectsItemWriter(res);
		final CompositeItemWriter<String> compositeItemWriter = new CompositeItemWriter<>();
		final List<ItemWriter<? super String>> delegates = new ArrayList<>();
		delegates.add(nasRemoveItemWriter);
		if (isDeletedOnGdn()) {
			delegates.add(gdnRemoveItemWriter);
		}
		delegates.add(collectDeleteItemWriter);
		delegates.add(countCollectsItemWriter);
		compositeItemWriter.setDelegates(delegates);
		return compositeItemWriter;
	}

	protected ItemReader<String> reader() {
		final Instant instantTimeOutCollect = buildPurgeDate(purgeType);
		final CollectItemReader itemReader = new CollectItemReader();
		itemReader.setCollectJpaRepository(collectJpaRepository);
		itemReader.setInstantCollect(instantTimeOutCollect);
		itemReader.setStatus(purgeTypeToCollectStatus());

		return itemReader;
	}

	private String purgeTypeToCollectStatus() {
		if (PurgeType.COL_AB_SU.equals(purgeType)) {
			return "AB";
		} else if (PurgeType.COL_CL_SU.equals(purgeType)) {
			return "CL";
		} else {
			throw new IllegalArgumentException();
		}
	}

	protected abstract boolean isDeletedOnGdn();

}
