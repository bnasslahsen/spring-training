package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.entity.TypeEntity;

@Repository
public interface TypeJpaRepository extends JpaRepository<TypeEntity, String> {

	List<TypeEntity> findByCollectId(String collectId);

	@Modifying
	@Transactional
	@Query("UPDATE TypeEntity SET status_control = :statusControl WHERE id = :id")
	void updateStatusControl(@Param("id") String id, @Param("statusControl") String status);

	@Query("select cT from TypeEntity cT where statusControl in :statusControl")
	List<TypeEntity> findByStatusControl(@Param("statusControl") List<String> statusControl);

	@Query("select cT from TypeEntity cT where statusControl=:statusControl")
	List<TypeEntity> findByStatusControl(@Param("statusControl") String statusControl);

	@Modifying
	@Transactional
	@Query("UPDATE TypeEntity SET status = :status, pendingDocument = :pendingDocument, pendingDocumentLabel = :pendingDocumentLabel  WHERE id = :id")
	void updateForAddPiece(@Param("id") String id, @Param("status") String status, @Param("pendingDocument") boolean pendingDocument, @Param("pendingDocumentLabel") String pendingDocumentLabel);

	@Transactional
	@Query(nativeQuery = true, value = "SELECT  type_id FROM ( SELECT  t.id as type_id,CASE WHEN (acquisition_date >= t.control_date OR t.control_date is NULL) THEN acquisition_date ELSE t.control_date END AS MostRecentDate FROM  type t , piece p where t.id=p.type_id and ( t.status_control='EC' or ( t.status_control='EC_AMI' and t.videocoding_delays='Immediate')))group by type_id having (max(MostRecentDate) ) + interval '60' minute <= sysdate")
	List<String> findByStatusEc();

	@Transactional
	@Query(nativeQuery = true, value = "SELECT  type_id FROM ( SELECT  t.id as type_id,  CASE WHEN (acquisition_date >= t.control_date OR t.control_date is NULL) THEN acquisition_date ELSE control_date END AS MostRecentDate FROM  type t , piece p where t.id=p.type_id and t.status_control='EC_AMI' and t.videocoding_delays='Delayed' ) group by type_id having max(MostRecentDate) + interval '3' day  <= sysdate")
	List<String> findByStatusEcAmi();

}
