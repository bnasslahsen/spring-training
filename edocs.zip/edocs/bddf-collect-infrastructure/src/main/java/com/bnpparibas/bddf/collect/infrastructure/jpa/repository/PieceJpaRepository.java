package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Tuple;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.entity.PieceEntity;

@Repository
public interface PieceJpaRepository extends JpaRepository<PieceEntity, String> {

	@Modifying
	@Transactional
	@Query("UPDATE PieceEntity SET status = :status, idDocGdn= :idDocGdn WHERE id = :id")
	public void updateStatusAndIdGdn(@Param("status") String status, @Param("idDocGdn") String idDocGdn, @Param("id") String id);

	@Modifying
	@Transactional
	@Query("UPDATE PieceEntity SET status = :status WHERE id = :id")
	public void updateStatus(@Param("status") String status, @Param("id") String id);

	@Query("SELECT pE from PieceEntity pE where status=:status and state=:state and updateDate<=:timeout")
	public Page<PieceEntity> findPiecesOlderThanAndByType(@Param("timeout") Timestamp timeOutPiece, @Param("state") String pieceState, @Param("status") String pieceStatus, Pageable pageable);

	@Query("SELECT pE from 	PieceEntity pE where state=:state and status in :statusList and acquisitionDate<=:timeout and deletedNas=0")
	public Page<PieceEntity> findOutdatedPiecesInNasByType(@Param("timeout") Timestamp timeOutPiece, @Param("state") String pieceState, @Param("statusList") List<String> statusList, Pageable pageable);

	@Query("SELECT pE from PieceEntity pE where deletedNas=0  and acquisitionDate >=:timeout  and referenceGdnId is not NULL  ")
	public List<PieceEntity> findOutdatedPiecesRFInNasByType(@Param("timeout") Timestamp timeOutPiece);

	@Modifying
	@Transactional
	@Query("UPDATE PieceEntity SET deletedNas = :deletedNas WHERE id in :idList")
	public void updateDeletedNas(@Param("deletedNas") Integer deletedNas, @Param("idList") List<String> idList);

	@Query(value = "select * from piece where acquisition_date<=:acquisitionDate and status=:status", nativeQuery = true)
	public List<PieceEntity> findByDateAndStatus(@Param("acquisitionDate") Timestamp acquisitionDate, @Param("status") String status);

	@Modifying
	@Transactional
	@Query("UPDATE PieceEntity SET statusControl = :status WHERE id = :id")
	public void updateStatusControl(@Param("status") String status, @Param("id") String id);

	@Query("SELECT p.id, p.idDocGdn, p.ownerId, p.employeeId from PieceEntity p, TypeEntity t where t.id=p.type.id and t.collectId in :idCollectList")
	public List<Tuple> findAllPieceIdAndIdDocGdnFromCollectId(@Param("idCollectList") List<String> idCollectList);

	@Query("SELECT p.id from PieceEntity p, TypeEntity t where t.id=p.type.id and t.collectId in :idCollectList")
	public List<Tuple> findAllPieceIdFromCollectId(@Param("idCollectList") List<String> idCollectList);

	@Modifying
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	@Query("UPDATE PieceEntity SET statusSentToGdn = :status WHERE id = :id")
	public void updateStatusSentToGdn(@Param("id") String id, @Param("status") String status);

	@Query("select p from PieceEntity p, TypeEntity t, FamilyEntity f where p.type.id=t.id and t.family.id=f.id and f.id=:familyId")
	List<PieceEntity> findAllPieces(@Param("familyId") String familyId);

}
