package com.bnpparibas.bddf.collect.infrastructure.repository;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Repository;

import com.bnp.schema.edoc.type.ObjectFactory;
import com.bnp.schema.edoc.type.Types;
import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.errors.TechnicalException;

@DDD.RepositoryImpl
@Repository
public class EdocTypesRepositoryImpl implements EdocTypeRepository {
	private List<EdocType> edocTypes;

	public EdocTypesRepositoryImpl() {
		super();
		init();
	}

	private void init() {
		try {
			final InputStream inputStream = new ClassPathResource("edocType.xml").getInputStream();
			final Unmarshaller unmarshaller = JAXBContext.newInstance(ObjectFactory.class).createUnmarshaller();
			edocTypes = ((Types) unmarshaller.unmarshal(inputStream)).getEdocType();
		} catch (final JAXBException | IOException e) {
			throw new TechnicalException(CollectErrorConstants.ERR_COL_TECH, e);
		}
	}

	@Override
	public List<EdocType> findAll() {
		return edocTypes;
	}

	@Override
	public EdocType byValue(String value) {
		return edocTypes.stream().filter(t -> t.getValue().equals(value)).findAny().orElse(null);
	}

}
