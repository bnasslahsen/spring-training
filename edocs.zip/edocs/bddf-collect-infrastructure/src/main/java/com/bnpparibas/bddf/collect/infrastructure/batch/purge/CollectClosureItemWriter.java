package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.domain.audit.event.NomenclatureRefEvent;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.domain.collect.FamiliesManagmentAct;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.event.collect.UpdatedCollect;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.type.PropertyType;
import com.bnpparibas.bddf.collect.infrastructure.entity.CollectEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.FamilyEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.PieceEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.TypeEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.CollectMapper;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.CollectJpaRepository;
import com.bnpparibas.bddf.jms.sender.domain.Media;

@Component
@Transactional(transactionManager = "transactionManagerDB")
@EnableTransactionManagement
public class CollectClosureItemWriter implements ItemWriter<CollectEntity> {
	private static final String OK_CL = "OK_CL";
	@Autowired
	private CollectJpaRepository collectJpaRepository;
	@Autowired
	private CollectEventHandler collectEventHandler;
	@Autowired
	private CollectMapper collectMapper;

	@Override
	@Transactional
	public void write(List<? extends CollectEntity> collects) throws Exception {
		collects.stream().map(this::purgeCollect).reduce(defaultResBatchCollect(), this::groupMapsBatchCollect);
	}

	@Transactional
	protected Map<String, Long> purgeCollect(CollectEntity collectEntity) {
		final Map<String, Long> result = defaultResBatchCollect();
		final Timestamp instantTimeOutCollectEc = Timestamp.from(ZonedDateTime.now(ZoneId.systemDefault()).minusDays(collectEntity.getAutoClosingDelay()).toInstant());
		final Set<FamilyEntity> families = collectEntity.getFamilies().stream().collect(Collectors.toSet());
		final List<Timestamp> acquisitionDates = families.stream().flatMap(family -> family.getTypes().stream()).flatMap(type -> type.getPieces().stream()).map(PieceEntity::getAcquisitionDate).filter(Objects::nonNull).collect(Collectors.toList());
		final List<Timestamp> updateDates = families.stream().flatMap(family -> family.getTypes().stream()).flatMap(type -> type.getPieces().stream()).map(PieceEntity::getUpdateDate).filter(Objects::nonNull).collect(Collectors.toList());

		acquisitionDates.addAll(updateDates);
		final Timestamp max = acquisitionDates.stream().max((t1, t2) -> t1.compareTo(t2)).orElse(instantTimeOutCollectEc);
		if (max.compareTo(instantTimeOutCollectEc) <= 0) {
			final AtomicBoolean isCL = new AtomicBoolean(true);
			final Set<FamilyEntity> familyEntitesToCheck = (families.stream().anyMatch(family -> FamiliesManagmentAct.FA.name().equals(family.getCategory()))
					&& families.stream().anyMatch(family -> FamiliesManagmentAct.OB.name().equals(family.getCategory()))) ? families.stream().filter(family -> !FamiliesManagmentAct.FA.name().equals(family.getCategory())).collect(Collectors.toSet())
							: families;

			// Si collecte avec au moins une famille obligatoire
			familyEntitesToCheck.stream().forEach(familyEntity -> {
				final Set<TypeEntity> typeEntities = familyEntity.getTypes();
				isCL.set(isCL.get() && isCL(typeEntities, familyEntity.getPropertyType()));
			});

			if (isCL.get()) {
				collectEntity.setStatus(CollectStatus.CL.name());
				saveAndCount(collectEntity, result, OK_CL);
				sendEvent(collectEntity, Channel.API.getValue(), Media.SERVEUR_VOCAL.getCode(), "");
			}
		}

		return result;
	}

	private Map<String, Long> defaultResBatchCollect() {
		final Map<String, Long> map = new HashMap<>();
		map.put(OK_CL, 0l);
		return map;
	}

	private boolean isCL(Set<TypeEntity> typeEntities, String propertyType) {
		boolean isCL = false;
		if (PropertyType.FIXE.getLabel().equals(propertyType)) {
			isCL = typeEntities.stream().allMatch(t -> validateTypeFixe(typeEntities, t));
		} else if (PropertyType.LISTE.getLabel().equals(propertyType)) {
			isCL = typeEntities.stream().allMatch(typeEntity -> validateTypeListe(typeEntities));

		}
		return isCL;
	}

	private void saveAndCount(CollectEntity collectEntity, Map<String, Long> result, String key) {
		collectEntity.setEndDate(Timestamp.from(Instant.now()));
		collectJpaRepository.save(collectEntity);

		result.put(key, result.get(key) + 1);
	}

	private void sendEvent(CollectEntity collectEntity, String channel, String media, String employeeId) {
		final UpdatedCollect updatedCollect = new UpdatedCollect();
		final Collect collect = collectMapper.toCollect(collectEntity, false);
		updatedCollect.setCollect(collect);
		updatedCollect.setChannel(channel);
		updatedCollect.setMedia(media);
		updatedCollect.setEmployeeId(employeeId);
		if (CollectStatus.CL.name().equals(collect.getStatus())) {
			updatedCollect.setNomenclatureRef(NomenclatureRefEvent.EVENT_CLOTURE_COLLECT.getCode());
		}
		collectEventHandler.sendUpdatedCollectEvent(updatedCollect);
	}

	private Map<String, Long> groupMapsBatchCollect(Map<String, Long> m1, Map<String, Long> m2) {
		m1.put(OK_CL, m1.get(OK_CL) + m2.get(OK_CL));
		return m1;
	}

	private boolean validateTypeFixe(Set<TypeEntity> typeList, TypeEntity t) {
		boolean isEligibleClosure = true;
		if (typeList.stream().noneMatch(x -> t.getId().equals(x.getParentId())) && (t.getPendingDocument() || t.getPieces().stream().filter(piece -> PieceStates.ACTIF.name().equals(piece.getState())).count() == 0
				|| t.getPieces().stream().filter(p -> !PieceStatus.VA.getLabel().equals(p.getStatus()) && PieceStates.ACTIF.name().equals(p.getState())).count() > 0)) {
			isEligibleClosure = false;
		}
		return isEligibleClosure;
	}

	private boolean validateTypeListe(Set<TypeEntity> typeList) {
		boolean isEligibleClosure = true;
		// Liste des pièces de la famille en cours
		final List<PieceEntity> pieceList = typeList.stream().flatMap(type -> type.getPieces().stream().filter(piece -> PieceStates.ACTIF.name().equals(piece.getState()))).collect(Collectors.toList());
		// Pas de cloture si un type avec document manquant
		if (typeList.stream().anyMatch(TypeEntity::getPendingDocument) ||
		// Pas de cloture si pas de pièces validés dans la famille
				pieceList.isEmpty() || pieceList.stream().anyMatch(piece -> !PieceStatus.VA.getLabel().equals(piece.getStatus()))
				// Pas de cloture si pas au moins un type "validé"
				|| typeList.stream().filter(currentType -> StringUtils.isEmpty(currentType.getParentId()))
						//
						.allMatch(type -> !isTypeValid(typeList, type))) {
			isEligibleClosure = false;
		}
		return isEligibleClosure;
	}

	private boolean isTypeValid(Set<TypeEntity> typeList, TypeEntity type) {
		boolean isValid = false;
		// Si type sans sous-types
		if (typeList.stream().noneMatch(currentType -> type.getId().equals(currentType.getParentId()))) {
			final List<PieceEntity> pieces = type.getPieces().stream().filter(piece -> PieceStates.ACTIF.name().equals(piece.getState())).collect(Collectors.toList());
			if (!pieces.isEmpty() && pieces.stream().allMatch(piece -> PieceStatus.VA.getLabel().equals(piece.getStatus()))) {
				isValid = true;
			}
			// Si type contient des sous-types, tout les sous-types doivent etre validés
		} else {
			isValid = typeList.stream().filter(currentType -> type.getId().equals(currentType.getParentId())).allMatch(subtype -> subtype.getPieces().stream().filter(piece -> PieceStates.ACTIF.name().equals(piece.getState())).count() > 0
					&& subtype.getPieces().stream().filter(piece -> PieceStates.ACTIF.name().equals(piece.getState())).allMatch(piece -> PieceStatus.VA.getLabel().equals(piece.getStatus())));
		}
		return isValid;
	}

}
