package com.bnpparibas.bddf.attachment.infrastructure;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bnpp.jdf.connector.IJdfConnectorConstants;
import com.bnpp.jdf.connector.exception.ConnectorFunctionalException;
import com.bnpp.jdf.connector.exception.ConnectorTechnicalException;
import com.bnpp.jdf.savedoc.query.CompressMethod;
import com.bnpp.jdf.savedoc.query.DescriptiveContext;
import com.bnpp.jdf.savedoc.query.Document;
import com.bnpp.jdf.savedoc.query.DocumentObject;
import com.bnpp.jdf.savedoc.query.EncodingMethod;
import com.bnpp.jdf.savedoc.query.Index;
import com.bnpp.jdf.savedoc.query.IndexingData;
import com.bnpp.jdf.savedoc.query.SaveDoc2I;
import com.bnpp.jdf.savedoc.query.StorageLevelType;
import com.bnpp.jdf.savedoc.response.SaveDoc2O;
import com.bnpparibas.bddf.attachment.domain.Attachment;
import com.bnpparibas.bddf.attachment.domain.AttachmentRepository;
import com.bnpparibas.bddf.attachment.domain.AttachmentValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.helper.DateUtil;
import com.bnpparibas.bddf.collect.infrastructure.gdn.service.GdnService;
import com.bnpparibas.bddf.collect.infrastructure.repository.MimeTypeUtils;
import com.bnpparibas.bddf.errors.TechnicalException;

@Repository
public class AttachmentRepositoryImpl implements AttachmentRepository {

	private static final String INDEX_MIME_TYPE = "mime-type";
	private static final String INDEX_ORIGINAL_VALUE_ID = "original-value-id";
	private static final String INDEX_TITLE = "title";
	private static final String INDEX_CREATOR = "creator";
	private static final String INDEX_E_DOC_LOCATION = "e-doc-location";
	private static final String INDEX_CALLING_APP_DATE = "calling-application-date";
	private static final String INDEX_CREATE_DATE = "create-date";
	private static final String EAAS = "EaaS";

	private static final String NATURE_ID = "6032";
	private static final String DOCUMENT_TYPE_ID = "11111111";
	private static final String APPLICATION_CODE = "AP12247";
	private static final String CREATOR = "BNP PARIBAS";

	@Autowired
	private AttachmentMapper attachmentMapper;

	@Autowired
	private AttachmentJpaRepository attachmentJpaRepository;

	@Autowired
	private GdnService gdnService;
	
	@Autowired
	AttachmentValidator attachmentValidator;

	@Override
	public void add(Attachment attachment) {
		attachmentJpaRepository.save(attachmentMapper.toAttachmentEntity(attachment));

	}

	@Override
	public Attachment get(UUID idAttachment) {
		final AttachmentEntity attachmentEntity = attachmentJpaRepository.findById(idAttachment.toString()).orElse(null);
		return attachmentMapper.toAttachment(attachmentEntity);
	}

	@Override
	public String sendToArchive(Attachment attachment, ByteBuffer fileData) {
		return sendFileToGDN(attachment, fileData);
	}

	@Override
	public void delete(UUID idAttachment) {
		attachmentJpaRepository.deleteById(idAttachment.toString());
	}

	private String sendFileToGDN(Attachment attachment, ByteBuffer fileData) {

		final SaveDoc2I saveDoc2I = new SaveDoc2I();
		saveDoc2I.setClassificationNatureId(NATURE_ID);
		saveDoc2I.setStorageLevel(StorageLevelType.HD);
		saveDoc2I.setOwningApplication(StringUtils.substring(attachment.getSendingApplicationCode(), 0, 7));
		final DescriptiveContext descriptiveContext = new DescriptiveContext();
		saveDoc2I.setDescriptiveContext(descriptiveContext);
		descriptiveContext.setDocumentTypeId(DOCUMENT_TYPE_ID);
		descriptiveContext.setLotId(APPLICATION_CODE + DateUtil.toLotIdFormat(new Date()));
		// Indexing data
		final IndexingData indexingData = new IndexingData();
		descriptiveContext.setIndexingData(indexingData);
		// Index mime-type
		final Index mimeType = new Index();
		mimeType.setIndexName(INDEX_MIME_TYPE);
		mimeType.setIndexValue(attachment.getMimeType());
		indexingData.getIndex().add(mimeType);
		// Index calling-application-date
		final Index callingApplicationDate = new Index();
		callingApplicationDate.setIndexName(INDEX_CALLING_APP_DATE);
		callingApplicationDate.setIndexValue(DateUtil.instantToString(Instant.now()));
		indexingData.getIndex().add(callingApplicationDate);
		// Index create-date
		final Index createDate = new Index();
		createDate.setIndexName(INDEX_CREATE_DATE);
		createDate.setIndexValue(DateUtil.instantToString(attachment.getCreationDate()));
		indexingData.getIndex().add(createDate);
		// Index original-value-id
		final Index originalValueId = new Index();
		originalValueId.setIndexName(INDEX_ORIGINAL_VALUE_ID);
		originalValueId.setIndexValue(Boolean.TRUE.toString());
		indexingData.getIndex().add(originalValueId);
		// Index title
		final Index title = new Index();
		title.setIndexName(INDEX_TITLE);
		title.setIndexValue(StringUtils.substring(attachment.getFileName(), 0, 50));
		indexingData.getIndex().add(title);
		// Index e-doc-location
		final Index eDocLocation = new Index();
		eDocLocation.setIndexName(INDEX_E_DOC_LOCATION);
		eDocLocation.setIndexValue(EAAS);
		indexingData.getIndex().add(eDocLocation);
		// Index creator
		final Index creator = new Index();
		creator.setIndexName(INDEX_CREATOR);
		creator.setIndexValue(CREATOR);
		indexingData.getIndex().add(creator);
		// Document
		final Document document = new Document();
		saveDoc2I.setDocument(document);
		final DocumentObject documentObject = new DocumentObject();
		document.setObject(documentObject);
		documentObject.setValue(Base64.encodeBase64String(fileData.array()));
		documentObject.setEncoding(EncodingMethod.BASE_64);
		documentObject.setCompress(CompressMethod.NONE);
		document.setFileName(getFileName(attachment.getFileName()));
		document.setArchiveFormat(archivingFormatFromMimeType(attachment.getMimeType()));
		final Map<String, String> params = new HashMap<>();
		params.put(IJdfConnectorConstants.TRACE_ID, attachment.getId().toString());
		if(!attachmentValidator.isAPI(attachment.getChannel())) {
			params.put(IJdfConnectorConstants.CALLING_USER, attachment.getUserId());			
		}
		SaveDoc2O saveDoc2O = null;
		try {
			saveDoc2O = gdnService.saveAttachment(saveDoc2I, params);
		} catch (final ConnectorTechnicalException ex) {
			throw new TechnicalException(CollectErrorConstants.ERR_ATTACHMENT_GDN_TECH, ex);
		} catch (final ConnectorFunctionalException ex) {
			throw new TechnicalException(CollectErrorConstants.ERR_ATTACHMENT_GDN_FUNC, ex);
		}
		return saveDoc2O.getDocumentId();
	}

	private String getFileName(String fileName) {
		final String withoutExtension = StringUtils.substring(fileName, 0, fileName.lastIndexOf('.'));
		final String extension = StringUtils.substring(fileName, fileName.lastIndexOf('.'), fileName.length());
		final String s = StringUtils.substring(withoutExtension, 0, 50 - extension.length());
		return s + extension;
	}

	private String archivingFormatFromMimeType(String mimeType) {
		return MimeTypeUtils.mimeTypeToArchivingFormat().get(mimeType);
	}

}
