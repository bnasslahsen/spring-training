package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.entity.FamilyEntity;

@Repository
public interface FamilyJpaRepository extends JpaRepository<FamilyEntity, String> {
	@Modifying
	@Transactional
	@Query("UPDATE FamilyEntity SET blocked=true WHERE id = :id")
	public void updateBlocked(@Param("id") String id);

	@Modifying
	@Transactional
	@Query("UPDATE FamilyEntity SET blocked=false WHERE id in ( select family.id from TypeEntity where id= :typeid)")
	public void unblockByType(@Param("typeid") String typeid);
}
