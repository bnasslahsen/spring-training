package com.bnpparibas.bddf.collect.infrastructure.batch.monitoring;

public class LineDaily {
	private String parcours;
	private String libelle;
	private String collecte;
	private String depotNum;
	private String acceptNum;
	private String validNum;
	private String refusNum;
	private String validPap;
	private String refusPap;
	
	
	public String getParcours() {
		return parcours;
	}
	public void setParcours(String parcours) {
		this.parcours = parcours;
	}
	public String getLibelle() {
		return libelle;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	public String getCollecte() {
		return collecte;
	}
	public void setCollecte(String collecte) {
		this.collecte = collecte;
	}
	public String getDepotNum() {
		return depotNum;
	}
	public void setDepotNum(String depotNum) {
		this.depotNum = depotNum;
	}
	public String getValidNum() {
		return validNum;
	}
	public void setValidNum(String validNum) {
		this.validNum = validNum;
	}
	public String getRefusNum() {
		return refusNum;
	}
	public void setRefusNum(String refusNum) {
		this.refusNum = refusNum;
	}
	public String getValidPap() {
		return validPap;
	}
	public void setValidPap(String validPap) {
		this.validPap = validPap;
	}
	public String getRefusPap() {
		return refusPap;
	}
	public void setRefusPap(String refusPap) {
		this.refusPap = refusPap;
	}
	public String getAcceptNum() {
		return acceptNum;
	}
	public void setAcceptNum(String acceptNum) {
		this.acceptNum = acceptNum;
	}

}
