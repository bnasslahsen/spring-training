package com.bnpparibas.bddf.collect.infrastructure.converter;

import java.nio.ByteBuffer;

import org.dozer.CustomConverter;
import org.dozer.MappingException;

public class ByteBufferBeanFactory implements CustomConverter {

	public ByteBufferBeanFactory() {
		super();
	}

	@Override
	public Object convert(Object destinationBean, Object sourceBean, Class destClass, Class sourceClass) {
		if (sourceBean == null) {
			return null;
		}

		if (sourceBean instanceof ByteBuffer) {
			final ByteBuffer source = (ByteBuffer) sourceBean;
			final ByteBuffer destination = ByteBuffer.allocate(source.capacity());
			source.rewind();
			destination.put(source);
			source.rewind();
			destination.flip();
			return destination;
		} else {
			throw new MappingException("Converter LocalDateToDateConverter " + "used incorrectly. Arguments passed in were:" + destinationBean + " and " + sourceBean);
		}
	}

}