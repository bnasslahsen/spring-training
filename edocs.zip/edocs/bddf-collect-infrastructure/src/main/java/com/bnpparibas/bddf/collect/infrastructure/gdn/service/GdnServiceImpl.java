package com.bnpparibas.bddf.collect.infrastructure.gdn.service;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.ByteBuffer;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.HttpClientBuilder;
import org.dozer.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;

import com.bnpp.jdf.connector.exception.AbstractConnectorException;
import com.bnpp.jdf.connector.exception.ConnectorFunctionalException;
import com.bnpp.jdf.connector.exception.ConnectorTechnicalException;
import com.bnpp.jdf.deletedoc.query.DeleteDocI;
import com.bnpp.jdf.deletedoc.response.DeleteDocO;
import com.bnpp.jdf.savedoc.query.SaveDoc2I;
import com.bnpp.jdf.savedoc.response.SaveDoc2O;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.jdf.service.AbstractParamJdf;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.errors.TechnicalException;
import com.bnpparibas.bddf.retry.CustomRetryTemplate;

@DDD.InfrastructureServiceImpl
@Service
public class GdnServiceImpl extends AbstractParamJdf implements GdnService {

	private static final Logger LOG = LoggerFactory.getLogger(GdnServiceImpl.class);

	private static final String SAVEDOC2_FACADE = "GDN.SaveDoc2";
	private static final String DELETE_DOC_FACADE = "GDN.DeleteDoc";
	private static final String GDN_PROPERTY_SCHEME = "gdn.scheme";
	private static final String GDN_PROPERTY_BASE = "gdn.path.base";
	private static final String GDN_PROPERTY_GET_DOC_BY_ID_GDN = "gdn.path.getdocbyidgdn";
	private static final String GDN_PROPERTY_HOST_INJECTION = "gdn.host.injection";
	private static final String GDN_PROPERTY_HOST_CONSULTATION = "gdn.host.consultation";
	private static final String GDN_PROPERTY_PORT = "gdn.port";
	private static final String GDN_PROPERTY_JDF = "gdn.jdf";
	private static final String GDN_PARAMETER_USER = "user";
	private static final String GDN_PARAMETER_USER_TYPE = "user-type";
	private static final String GDN_PARAMETER_DOCUMENT = "document";
	private static final String GDN_KO = " : failed to call gdn";
	private static final long RETRY_1 = 30000l; // 30s
	private static final long RETRY_2 = 60000l; // 1mn
	private static final long RETRY_3 = 300000l; // 5mn
	private static final long[] GDN_GET_DELAYS = { RETRY_1, RETRY_2, RETRY_3 };
	private static final String DEFAULT_CALLING_USER = "999999";


	private String scheme;
	private int port;
	private String hostConsultation;
	String hostInjection;
	private String getDocPath;
	private String jrfUrl;

	@Autowired
	private Environment env;

	@Autowired
	private Mapper mapperDozer;

	private RetryTemplate retryTemplate;

	@PostConstruct
	public void init() throws URISyntaxException {
		retryTemplate = new CustomRetryTemplate(CollectBusinessException.class, GDN_GET_DELAYS, true);
		scheme = env.getProperty(GDN_PROPERTY_SCHEME);
		hostConsultation = env.getProperty(GDN_PROPERTY_HOST_CONSULTATION);
		hostInjection = env.getProperty(GDN_PROPERTY_HOST_INJECTION);
		port = Integer.parseInt(Optional.ofNullable(env).map(v -> v.getProperty(GDN_PROPERTY_PORT)).orElse(""));
		final String base = env.getProperty(GDN_PROPERTY_BASE);
		getDocPath = base + env.getProperty(GDN_PROPERTY_GET_DOC_BY_ID_GDN);
		final String jrfPath = base + env.getProperty(GDN_PROPERTY_JDF);
		final URIBuilder builder = new URIBuilder();
		builder.setScheme(scheme);
		builder.setHost(hostInjection);
		builder.setPort(port);
		builder.setPath(jrfPath);
		jrfUrl = builder.build().toString();
	}

	@Override
	public SaveDoc2O saveDoc2(SaveDoc2I saveDoc2I, Map<String, String> params) throws AbstractConnectorException {
		return retryTemplate.execute(context -> saveDoc(saveDoc2I, params));
	}

	@Override
	public ByteBuffer getDocByIdGDN(UUID idPiece, String callingUser, String userType, String idGdn) {
		try {
			final long startTime = System.currentTimeMillis();
			final HttpClient client = HttpClientBuilder.create().build();
			final HttpGet request = new HttpGet(buildUrlGetDocByIdGdn(callingUser, userType, idGdn));
			final HttpResponse response = client.execute(request);
			final HttpEntity responseEntity = response.getEntity();
			if (HttpStatus.OK.value() == response.getStatusLine().getStatusCode()) {
				LoggerHelper.logForPerfTest(LOG, "PieceId : " + idPiece + " Temps pour getPiece GDN : " + (System.currentTimeMillis() - startTime) + " ms");
				return ByteBuffer.wrap(IOUtils.toByteArray(responseEntity.getContent()));
			}
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_ACCES_GDN_TECH, idPiece.toString(), ""));
		} catch (IOException | URISyntaxException ex) {
			throw new TechnicalException(CollectErrorConstants.ERR_ACCES_GDN_TECH, ex);
		}
	}

	@Override
	protected String initJrfUrl() {
		return jrfUrl;
	}

	@Override
	public DeleteDocO deleteDoc(DeleteDocI in, Map<String, String> params) throws ConnectorTechnicalException, ConnectorFunctionalException {
		try {
			final Object out = callJdfService(in, DELETE_DOC_FACADE, DeleteDocO.class, params);
			return mapperDozer.map(out, DeleteDocO.class);
		} catch (final ConnectorTechnicalException ex) {
			LOG.error(CollectErrorConstants.ERR_SUPP_GDN_TECH + GDN_KO, ex);
			throw ex;
		} catch (final ConnectorFunctionalException ex) {
			LOG.error(CollectErrorConstants.ERR_SUPP_GDN_FUNC + GDN_KO, ex);
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_SUPP_GDN_FUNC + GDN_KO));
		}
	}

	@Override
	public DeleteDocO deleteDocWithRetry(DeleteDocI in, Map<String, String> params) throws AbstractConnectorException {
		return retryTemplate.execute(context -> deleteDoc(in, params));
	}

	@Override
	public SaveDoc2O saveDoc(SaveDoc2I saveDoc2I, Map<String, String> params) throws ConnectorTechnicalException, ConnectorFunctionalException {
		try {
			return mapperDozer.map(callJdfService(saveDoc2I, SAVEDOC2_FACADE, SaveDoc2O.class, params), SaveDoc2O.class);
		} catch (final ConnectorTechnicalException ex) {
			LOG.error(CollectErrorConstants.ERR_UPD_GDN_TECH + GDN_KO, ex);
			throw ex;
		} catch (final ConnectorFunctionalException ex) {
			LOG.error(CollectErrorConstants.ERR_UPD_GDN_FUNC + GDN_KO, ex);
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_UPD_GDN_FUNC + GDN_KO));
		}
	}

	@Override
	public SaveDoc2O saveAttachment(SaveDoc2I saveDoc2I, Map<String, String> params) throws ConnectorTechnicalException, ConnectorFunctionalException {

		return mapperDozer.map(callJdfService(saveDoc2I, SAVEDOC2_FACADE, SaveDoc2O.class, params), SaveDoc2O.class);

	}

	private URI buildUrlGetDocByIdGdn(String callingUser, String userType, String idGdn) throws URISyntaxException {
		final URIBuilder builder = new URIBuilder();
		builder.setScheme(scheme);
		builder.setHost(hostConsultation);
		builder.setPort(port);
		builder.setPath(getDocPath);
		builder.addParameter(GDN_PARAMETER_USER, StringUtils.isNotEmpty(callingUser) ? callingUser : DEFAULT_CALLING_USER);
		builder.addParameter(GDN_PARAMETER_USER_TYPE, userType);
		builder.addParameter(GDN_PARAMETER_DOCUMENT, idGdn);
		return builder.build();
	}

}
