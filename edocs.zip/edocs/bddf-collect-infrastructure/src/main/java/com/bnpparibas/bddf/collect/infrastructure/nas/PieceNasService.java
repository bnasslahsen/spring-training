package com.bnpparibas.bddf.collect.infrastructure.nas;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.UUID;

public interface PieceNasService {

	void deletePiece(UUID id) throws IOException;

	void deleteThumbnail(UUID id) throws IOException;

	void addPiece(UUID id, ByteBuffer data, String contentType, String label) throws IOException;

	ByteBuffer getPiece(UUID id) throws IOException;

	ByteBuffer getThumbnail(UUID id) throws IOException;

}
