package com.bnpparibas.bddf.collect.infrastructure.entity;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.domain.Persistable;

@Entity
@Table(name = "collect")
public class CollectEntity implements java.io.Serializable, Persistable<String> {

	private static final long serialVersionUID = 1L;
	private String id;
	private String status;
	private Timestamp creationDate;
	private Timestamp endDate;
	private String entityLabel;
	private String productLabel;
	private String stepLabel;
	private String journeyCode;
	private String allowedFile;
	private String familiesManagementAct;
	private String piecesManagementAct;
	private String collectManagementAct;
	private String sendingApplicationCode;
	private String project;
	private Boolean autoValidation;
	private Boolean autoAcceptationAllowed;
	private Integer controlIterationAllowed;
	private Integer autoClosingDelay;
	private Boolean notifyOwners;
	private Set<OwnerEntity> owners = new HashSet<OwnerEntity>(0);
	private Set<FamilyEntity> families = new HashSet<FamilyEntity>(0);
	private boolean isNew;

	public CollectEntity() {
	}

	public CollectEntity(String id) {
		this.id = id;
	}

	@Override
	@Id
	@Column(name = "ID", unique = true, nullable = false, length = 100)
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Column(name = "STATUS", length = 3)
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "CREATION_DATE")
	public Timestamp getCreationDate() {
		return Optional.ofNullable(this.creationDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = Optional.ofNullable(creationDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Column(name = "END_DATE")
	public Timestamp getEndDate() {
		return Optional.ofNullable(this.endDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setEndDate(Timestamp endDate) {
		this.endDate = Optional.ofNullable(endDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Column(name = "ENTITY_LABEL", length = 100)
	public String getEntityLabel() {
		return this.entityLabel;
	}

	public void setEntityLabel(String entityLabel) {
		this.entityLabel = entityLabel;
	}

	@Column(name = "PRODUCT_LABEL", length = 100)
	public String getProductLabel() {
		return this.productLabel;
	}

	public void setProductLabel(String productLabel) {
		this.productLabel = productLabel;
	}

	@Column(name = "STEP_LABEL", length = 100)
	public String getStepLabel() {
		return this.stepLabel;
	}

	public void setStepLabel(String stepLabel) {
		this.stepLabel = stepLabel;
	}

	@Column(name = "JOURNEY_CODE", length = 6)
	public String getJourneyCode() {
		return this.journeyCode;
	}

	public void setJourneyCode(String journeyCode) {
		this.journeyCode = journeyCode;
	}

	@Column(name = "ALLOWED_FILE", length = 200)
	public String getAllowedFile() {
		return this.allowedFile;
	}

	public void setAllowedFile(String allowedFile) {
		this.allowedFile = allowedFile;
	}

	@Column(name = "FAMILIES_MANAGEMENT_ACT", length = 200)
	public String getFamiliesManagementAct() {
		return this.familiesManagementAct;
	}

	public void setFamiliesManagementAct(String familiesManagementAct) {
		this.familiesManagementAct = familiesManagementAct;
	}

	@Column(name = "PIECES_MANAGEMENT_ACT", length = 200)
	public String getPiecesManagementAct() {
		return this.piecesManagementAct;
	}

	public void setPiecesManagementAct(String piecesManagementAct) {
		this.piecesManagementAct = piecesManagementAct;
	}

	@Column(name = "SENDING_APPLICATION_CODE", length = 45)
	public String getSendingApplicationCode() {
		return this.sendingApplicationCode;
	}

	public void setSendingApplicationCode(String sendingApplicationCode) {
		this.sendingApplicationCode = sendingApplicationCode;
	}

	@Column(name = "PROJECT", length = 200)
	public String getProject() {
		return this.project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	@Column(name = "AUTO_VALIDATION", precision = 22, scale = 0)
	public Boolean getAutoValidation() {
		return this.autoValidation;
	}

	public void setAutoValidation(Boolean autoValidation) {
		this.autoValidation = autoValidation;
	}

	@Column(name = "AUTO_ACCEPTATION_ALLOWED", precision = 22, scale = 0)
	public Boolean getAutoAcceptationAllowed() {
		return this.autoAcceptationAllowed;
	}

	public void setAutoAcceptationAllowed(Boolean autoAcceptationAllowed) {
		this.autoAcceptationAllowed = autoAcceptationAllowed;
	}

	@Column(name = "CONTROL_ITERATION_ALLOWED", precision = 22, scale = 0)
	public Integer getControlIterationAllowed() {
		return this.controlIterationAllowed;
	}

	public void setControlIterationAllowed(Integer controlIterationAllowed) {
		this.controlIterationAllowed = controlIterationAllowed;
	}

	@Column(name = "AUTO_CLOSING_DELAY", precision = 22, scale = 0)
	public Integer getAutoClosingDelay() {
		return this.autoClosingDelay;
	}

	public void setAutoClosingDelay(Integer autoClosingDelay) {
		this.autoClosingDelay = autoClosingDelay;
	}

	@ManyToMany(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
	@JoinTable(name = "COLLECT_OWNER", joinColumns = { @JoinColumn(name = "COLLECT_ID", nullable = false, updatable = false) }, inverseJoinColumns = { @JoinColumn(name = "OWNER_ID", nullable = false, updatable = false) })
	public Set<OwnerEntity> getOwners() {
		return this.owners;
	}

	public void setOwners(Set<OwnerEntity> owners) {
		this.owners = owners;
	}

	@OneToMany(fetch = FetchType.EAGER, mappedBy = "collect", cascade = { CascadeType.ALL })
	public Set<FamilyEntity> getFamilies() {
		return this.families;
	}

	public void setFamilies(Set<FamilyEntity> families) {
		this.families = families;
	}

	@Column(name = "COLLECT_MANAGEMENT_ACT", length = 200)
	public String getCollectManagementAct() {
		return collectManagementAct;
	}

	public void setCollectManagementAct(String collectManagementAct) {
		this.collectManagementAct = collectManagementAct;
	}

	@Column(name = "NOTIFY_OWNERS")
	public Boolean getNotifyOwners() {
		return notifyOwners;
	}

	public void setNotifyOwners(Boolean notifyOwners) {
		this.notifyOwners = notifyOwners;
	}

	@Override
	@Transient
	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

}
