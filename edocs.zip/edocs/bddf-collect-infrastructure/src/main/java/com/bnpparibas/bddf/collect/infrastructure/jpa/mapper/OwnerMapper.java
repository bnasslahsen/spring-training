package com.bnpparibas.bddf.collect.infrastructure.jpa.mapper;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.owner.CommunicationTemplate;
import com.bnpparibas.bddf.collect.infrastructure.entity.OwnerEntity;

@Component
public class OwnerMapper {

	@Autowired
	TimestampUtils timestampUtils;

	public Set<OwnerEntity> toOwnersEntity(Set<Owner> owners, boolean isNew) {
		final Set<OwnerEntity> ownerEntities = new HashSet<>();
		owners.forEach(owner -> {
			final OwnerEntity ownerEntity = new OwnerEntity();
			ownerEntity.setFirstname(owner.getFirstname());
			ownerEntity.setId(StringUtils.isEmpty(owner.getId()) ? UUID.randomUUID().toString() : owner.getId());
			ownerEntity.setBirthDate(timestampUtils.localDateToTimestamp(owner.getBirthDate()));
			ownerEntity.setName(owner.getName());
			ownerEntity.setNature(owner.getNature());
			ownerEntity.setReference(owner.getReference());
			ownerEntity.setNew(isNew);
			ownerEntity.setCommunicationTemplate(owner.getCommunicationTemplate());
			ownerEntities.add(ownerEntity);
		});
		return ownerEntities;
	}

	public Set<OwnerEntity> toOwnersEntitiesForFamily(Set<OwnerEntity> owners, Set<String> ownersReference, boolean isNew) {
		final Set<OwnerEntity> ownerEntities = owners.stream().filter(ownerEntity -> ownersReference.contains(ownerEntity.getReference())).collect(Collectors.toSet());
		ownerEntities.forEach(ownerEntity -> ownerEntity.setNew(isNew));
		return ownerEntities;

	}

	public Set<Owner> toOwners(Set<OwnerEntity> ownerEntities) {
		final Set<Owner> owners = new HashSet<>();
		ownerEntities.forEach(ownerEntity -> {
			final Owner owner = new Owner();
			owner.setFirstname(ownerEntity.getFirstname());
			Optional.ofNullable(ownerEntity.getBirthDate()).map(timestamp -> timestamp.toLocalDateTime().toLocalDate()).ifPresent(owner::setBirthDate);
			owner.setName(ownerEntity.getName());
			owner.setNature(ownerEntity.getNature().intValue());
			owner.setReference(ownerEntity.getReference());
			owner.setId(ownerEntity.getId());
			if (StringUtils.isEmpty(ownerEntity.getCommunicationTemplate())) {
				owner.setCommunicationTemplate(CommunicationTemplate.BNP.getLabel());
			} else {
				owner.setCommunicationTemplate(ownerEntity.getCommunicationTemplate());
			}
			owners.add(owner);
		});
		return owners;
	}

}
