package com.bnpparibas.bddf.attachment.infrastructure;

import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.attachment.domain.Attachment;

@Component
public class AttachmentMapper {

	@Autowired
	private Mapper dozer;

	public AttachmentEntity toAttachmentEntity(Attachment attachment) {
		return dozer.map(attachment, AttachmentEntity.class);
	}

	public Attachment toAttachment(AttachmentEntity attachmentEntity) {
		if (attachmentEntity == null) {
			return null;
		}
		return dozer.map(attachmentEntity, Attachment.class);
	}

}
