package com.bnpparibas.bddf.collect.infrastructure.batch.event;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import javax.jms.JMSException;
import javax.jms.Message;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.audit.event.NomenclatureRefEvent;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.event.collect.UpdatedCollect;
import com.bnpparibas.bddf.collect.domain.event.piece.PieceSent2Gdn;
import com.bnpparibas.bddf.collect.domain.event.type.EventSendAMI;
import com.bnpparibas.bddf.collect.domain.event.type.TypeReceived;
import com.bnpparibas.bddf.collect.domain.event.type.TypeReceivedType;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.infrastructure.batch.distributed.AbstractBatch;
import com.bnpparibas.bddf.collect.infrastructure.entity.CollectEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.EventEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.EventJpaRepository;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.FamilyJpaRepository;
import com.bnpparibas.bddf.rest.Context;

@Component
public class SendingBlockedEventsBatch extends AbstractBatch {

	private static final Logger LOG = LoggerFactory.getLogger(SendingBlockedEventsBatch.class);
	private static final long TEN_MINUTES_IN_MILLIS = 600000;

	@Value("${jms.mq.outbound-default-queue}")
	private String destination;
	@Autowired
	private EventJpaRepository eventJpaRepository;
	@Autowired
	private FamilyJpaRepository familyJpaRepository;
	@Autowired
	private CollectEventHandler messageSender;
	@Autowired
	private CollectRepository collectRepositoryImpl;
	@Autowired
	private TypeRepository typeRepositoryImpl;
	@Autowired
	private PieceRepository pieceRepository;
	@Autowired
	private CollectEventHandler collectEventHandler;
	@Value("${event.batchSize}")
	private int batchSize;

	public SendingBlockedEventsBatch() {
		super("COLLECT_REPLAY_EVENTS");
	}

	@Scheduled(cron = "${event.cron}")
	@Override
	public void scheduledStart() {
		startBatch();
	}

	@Override
	public void execute() {
		try {
			final Timestamp tenMinutesAgo = new Timestamp((new Date()).getTime() - TEN_MINUTES_IN_MILLIS);
			// liste des types id pour lequel les evts sont bien envoyés
			final Set<String> listTypeId = new HashSet<>();

			for (int i = 0;; i++) {
				final Pageable pageable = PageRequest.of(i, batchSize, Sort.by(Direction.ASC, "dtSent"));
				final List<EventEntity> events = eventJpaRepository.findEventsOlderThanAndByStatus(tenMinutesAgo, "TO_SEND", pageable).getContent();
				if (CollectionUtils.isEmpty(events)) {
					break;
				}
				events.forEach(event -> {
					try {
						eventJpaRepository.updateReplays(event.getId(), event.getReplays() + 1);
						final Collect currentCollect = collectRepositoryImpl.findOne(UUID.fromString(event.getCollectId()));
						if (Optional.ofNullable(currentCollect).isPresent()) {
							if (isEventPostAmi(event)) {
								sendEventPostAMI(currentCollect, event.getTypeId(), new Context(event.getUserId(), event.getChannel(), event.getMedia()), event.getContent(), event.getId(), event.getReplays() + 1);
							} else if (isGdnPieceEvent(event)) {
								if (Optional.ofNullable(event.getTypeId()).isPresent()) {
									final Type currentType = typeRepositoryImpl.findCompleteType(currentCollect.getId(), UUID.fromString(event.getTypeId()));
									if (Optional.ofNullable(currentType).isPresent()) {
										if (Optional.ofNullable(event.getPieceId()).isPresent()) {
											final Piece piece = pieceRepository.getPiece(UUID.fromString(event.getCollectId()), UUID.fromString(event.getTypeId()), UUID.fromString(event.getPieceId()));
											if (Optional.ofNullable(piece).isPresent()) {
												sendDeposedPieceEvent(currentCollect, currentType, new Context(event.getUserId(), event.getChannel(), event.getMedia()), piece, event.getContent(), event.getId(), event.getReplays() + 1);
											} else {
												LOG.error("piece : " + event.getPieceId() + " n'existe pas");
											}
										}

									} else {
										LOG.error("type : " + event.getTypeId() + " n'existe pas");
									}
								}

							} else if (isTypeEvent(event)) {
								if (Optional.ofNullable(event.getTypeId()).isPresent()) {
									final Type currentType = typeRepositoryImpl.findCompleteType(currentCollect.getId(), UUID.fromString(event.getTypeId()));
									if (Optional.ofNullable(currentType).isPresent()) {
										sendTypeReceivedEvent(currentCollect, currentType, new Context(event.getUserId(), event.getChannel(), event.getMedia()), event.getNomenclatureRef(), event.getContent(), event.getId(), event.getReplays() + 1);
									} else {
										LOG.error("type : " + event.getTypeId() + " n'existe pas");
									}
								}
							} else if (isCollectEvent(event)) {
								sendUpdatedCollectEvent(currentCollect, new Context(event.getUserId(), event.getChannel(), event.getMedia()), event.getNomenclatureRef(), event.getContent(), event.getId(), event.getReplays() + 1);
							}
							listTypeId.add(event.getTypeId());
						} else {
							LOG.error("collect : " + event.getCollectId() + " n'existe pas");
						}

					} catch (final Exception e) {
						LOG.error(e.getMessage(), e);
					}
				});

			}

			unblockFamilies(listTypeId);

		} catch (final Exception e) {
			LOG.error(e.getMessage(), e);
		}
	}

	private void unblockFamilies(Set<String> listTypeId) {
		Optional.ofNullable(listTypeId).ifPresent(t -> t.forEach(typeId -> familyJpaRepository.unblockByType(typeId)));
	}

	private void sendDeposedPieceEvent(Collect collect, Type type, Context context, Piece piece, String content, String eventId, int replays) {
		final PieceSent2Gdn pieceSent2Gdn = new PieceSent2Gdn();

		pieceSent2Gdn.setChannel(context.getCanal());
		pieceSent2Gdn.setUserId(context.getCustomerId());
		pieceSent2Gdn.setCollect(collect);
		pieceSent2Gdn.setMedia(context.getMedia());
		pieceSent2Gdn.setNomenclatureRef(TypeReceivedType.SEND_GDN.getLabel()); // n° event
		pieceSent2Gdn.setPiece(piece);
		pieceSent2Gdn.setTypeId(type.getId().toString());

		collectEventHandler.sendGdnPieceEventForBatch(pieceSent2Gdn, content, type.getEdocType(), type.getLabel(), eventId, replays);
	}

	private void sendEventPostAMI(Collect collect, String typeId, Context context, String content, String eventId, int replays) {
		final EventSendAMI eventSendAMI = new EventSendAMI();
		eventSendAMI.setChannel(context.getCanal());
		eventSendAMI.setCollect(collect);
		eventSendAMI.setMedia(context.getMedia());
		eventSendAMI.setNomenclatureRef(TypeReceivedType.SEND_TO_AMI.getLabel()); // n° event
		eventSendAMI.setTypeId(typeId);
		eventSendAMI.setColledId(collect.getId().toString());
		eventSendAMI.setUserId(context.getCustomerId());
		collectEventHandler.sendEventAMIForBatch(eventSendAMI, content, eventId, replays);
	}

	private boolean isGdnPieceEvent(final EventEntity event) {
		return TypeReceivedType.SEND_GDN.getLabel().equals(event.getNomenclatureRef());
	}

	private boolean isEventPostAmi(final EventEntity event) {
		return TypeReceivedType.SEND_TO_AMI.getLabel().equals(event.getNomenclatureRef());
	}

	private boolean isTypeEvent(final EventEntity event) {
		return Arrays.asList(TypeReceivedType.DEPOSED.getLabel(), TypeReceivedType.CONTROLLED.getLabel(), TypeReceivedType.AUTOMATTC_CONTROL.getLabel()).contains(event.getNomenclatureRef());
	}

	private boolean isCollectEvent(final EventEntity event) {
		return Arrays.asList(NomenclatureRefEvent.EVENT_CLOTURE_COLLECT.getCode(), NomenclatureRefEvent.EVENT_ABANDON_COLLECT.getCode(), NomenclatureRefEvent.EVENT_UPDATE_COLLECT.getCode()).contains(event.getNomenclatureRef());
	}

	private void sendTypeReceivedEvent(Collect collect, final Type type, Context context, String nomenclatureRef, String content, String eventId, int replays) {
		final TypeReceived typeReceived = new TypeReceived();
		typeReceived.setPieces(type.getPieces());
		typeReceived.setChannel(context.getCanal());
		typeReceived.setUserId(context.getCustomerId());
		if (Optional.ofNullable(type.getParentId()).isPresent()) {
			typeReceived.setSubType(type);
			typeReceived.setType(collect.getTypes().stream().filter(t -> type.getParentId().equals(t.getId())).findAny().orElse(null));
		} else {
			typeReceived.setType(type);
		}
		typeReceived.setCollect(collect);
		typeReceived.setTypeReceivedType(TypeReceivedType.fromLabel(nomenclatureRef));
		messageSender.sendTypeReceivedEventForBatch(typeReceived, content, eventId, replays);
	}

	private void sendUpdatedCollectEvent(Collect collect, Context context, String nomenclatureRef, String content, String eventId, int replays) {
		final UpdatedCollect updatedCollect = new UpdatedCollect();
		updatedCollect.setCollect(collect);
		updatedCollect.setMedia(context.getMedia());
		updatedCollect.setChannel(context.getCanal());
		updatedCollect.setEmployeeId(context.getCustomerId());
		updatedCollect.setNomenclatureRef(nomenclatureRef);
		messageSender.sendUpdatedCollectEventForBatch(updatedCollect, content, eventId, replays);
	}

	Message setMessageProperties(CollectEntity collect, String nomenclatureRef, Message message) throws JMSException {
		message.setStringProperty("journeyCode", collect.getJourneyCode());
		message.setStringProperty("sendingApplicationCode", collect.getSendingApplicationCode());
		message.setStringProperty("nomenclatureRef", nomenclatureRef);
		return message;
	}

}
