package com.bnpparibas.bddf.collect.infrastructure.jpa.mapper;

import java.util.ArrayList;
import java.util.List;

import org.dozer.Mapper;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.piece.reference.DocReference;
import com.bnpparibas.bddf.collect.infrastructure.entity.DocReferenceEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.DocReferenceJourneyCode;

@Component
public class DocReferenceMapper {

	private final Mapper dozerMapper;

	public DocReferenceMapper(Mapper dozerMapper) {
		this.dozerMapper = dozerMapper;

	}

	public List<DocReference> toDocReferences(List<DocReferenceEntity> docRefEntities) {
		final List<DocReference> docRefs = new ArrayList<>();
		docRefEntities.forEach(docRefEntity -> docRefs.add(toDocReference(docRefEntity)));
		return docRefs;
	}

	public DocReference toDocReference(DocReferenceEntity docRefEntity) {
		final DocReference docRef = dozerMapper.map(docRefEntity, DocReference.class);
		docRefEntity.getDocReferenceJourneyCodes().stream().forEach(dcJC -> docRef.getJourneyCodes().put(TimestampUtils.timestampToDate(dcJC.getId().getUpdateDate()), dcJC.getId().getJourneyCode()));

		return docRef;
	}

	public List<DocReferenceEntity> toDocRefEntities(List<DocReference> docRefs) {
		final List<DocReferenceEntity> docRefEntities = new ArrayList<>();
		docRefs.forEach(docRef -> docRefEntities.add(toDocReferenceEntity(docRef)));
		return docRefEntities;
	}

	public DocReferenceEntity toDocReferenceEntity(DocReference docRef) {
		final DocReferenceEntity docRefEntity = dozerMapper.map(docRef, DocReferenceEntity.class);
		docRef.getJourneyCodes().entrySet().stream().forEach(dcJC -> docRefEntity.getDocReferenceJourneyCodes().add(new DocReferenceJourneyCode(TimestampUtils.dateToTimestamp(dcJC.getKey()), dcJC.getValue(), docRefEntity)));
		return docRefEntity;
	}

}
