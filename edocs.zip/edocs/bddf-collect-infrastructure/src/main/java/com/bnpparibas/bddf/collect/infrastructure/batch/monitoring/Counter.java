package com.bnpparibas.bddf.collect.infrastructure.batch.monitoring;

public class Counter {

	private long count;

	public Counter() {
		count = 0;
	}

	public long getCount() {
		return count;
	}

	public void increase(long l) {
		count += l;
	}
}
