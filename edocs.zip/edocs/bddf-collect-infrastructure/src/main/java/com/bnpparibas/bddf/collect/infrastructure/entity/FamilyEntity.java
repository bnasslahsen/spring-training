package com.bnpparibas.bddf.collect.infrastructure.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.domain.Persistable;

@Entity
@Table(name = "family")
public class FamilyEntity implements java.io.Serializable, Persistable<String> {

	private static final long serialVersionUID = 1L;
	private String id;
	private CollectEntity collect;
	private String label;
	private String category;
	private String categoryComment;
	private String propertyType;
	private String iconeCode;
	private String additionalInformation;
	private String familiesManagementAct;
	private String piecesManagementAct;
	private Integer position;
	private Set<OwnerEntity> owners = new HashSet<>(0);
	private Set<TypeEntity> types = new HashSet<>(0);
	private boolean isNew;
	private String additionalInformationCollab;
	private Boolean blocked;

	public FamilyEntity() {
	}

	public FamilyEntity(String id, CollectEntity collect) {
		this.id = id;
		this.collect = collect;
	}

	@Override
	@Id
	@Column(name = "ID", unique = true, nullable = false, length = 100)
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "COLLECT_ID", nullable = false)
	public CollectEntity getCollect() {
		return this.collect;
	}

	public void setCollect(CollectEntity collect) {
		this.collect = collect;
	}

	@Column(name = "LABEL", length = 200)
	public String getLabel() {
		return this.label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	@Column(name = "CATEGORY", length = 3)
	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Column(name = "CATEGORY_COMMENT", length = 100)
	public String getCategoryComment() {
		return this.categoryComment;
	}

	public void setCategoryComment(String categoryComment) {
		this.categoryComment = categoryComment;
	}

	@Column(name = "PROPERTY_TYPE", length = 20)
	public String getPropertyType() {
		return this.propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	@Column(name = "ICONE_CODE", length = 45)
	public String getIconeCode() {
		return this.iconeCode;
	}

	public void setIconeCode(String iconeCode) {
		this.iconeCode = iconeCode;
	}

	@Column(name = "ADDITIONAL_INFORMATION", length = 200)
	public String getAdditionalInformation() {
		return this.additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	@Column(name = "ADDITIONAL_INFORMATION_COLLAB", length = 200)
	public String getAdditionalInformationCollab() {
		return additionalInformationCollab;
	}

	public void setAdditionalInformationCollab(String additionalInformationCollab) {
		this.additionalInformationCollab = additionalInformationCollab;
	}

	@Column(name = "FAMILIES_MANAGEMENT_ACT", length = 200)
	public String getFamiliesManagementAct() {
		return this.familiesManagementAct;
	}

	public void setFamiliesManagementAct(String familiesManagementAct) {
		this.familiesManagementAct = familiesManagementAct;
	}

	@Column(name = "PIECES_MANAGEMENT_ACT", length = 200)
	public String getPiecesManagementAct() {
		return this.piecesManagementAct;
	}

	public void setPiecesManagementAct(String piecesManagementAct) {
		this.piecesManagementAct = piecesManagementAct;
	}

	@Column(name = "POSITION", precision = 22, scale = 0)
	public Integer getPosition() {
		return this.position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	@ManyToMany(fetch = FetchType.EAGER, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	@JoinTable(name = "FAMILY_OWNER", joinColumns = { @JoinColumn(name = "FAMILY_ID", nullable = false, updatable = false) }, inverseJoinColumns = { @JoinColumn(name = "OWNER_ID", nullable = false, updatable = false) })
	public Set<OwnerEntity> getOwners() {
		return this.owners;
	}

	public void setOwners(Set<OwnerEntity> owners) {
		this.owners = owners;
	}

	@OneToMany(fetch = FetchType.EAGER, cascade = { CascadeType.ALL }, orphanRemoval = true, mappedBy = "family")
	public Set<TypeEntity> getTypes() {
		return this.types;
	}

	public void setTypes(Set<TypeEntity> types) {
		this.types = types;
	}

	@Column(name = "BLOCKED")
	public Boolean isBlocked() {
		return blocked;
	}

	public void setBlocked(Boolean blocked) {
		this.blocked = blocked;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		boolean isEqual = true;
		boolean exit = false;
		if (this == obj) {
			isEqual = true;
			exit = true;
		}
		if (!exit && (obj == null || !(obj instanceof FamilyEntity))) {
			isEqual = false;
			exit = true;
		}

		final FamilyEntity other = (FamilyEntity) obj;
		if (!exit) {
			if (id == null) {
				if (other.id != null) {
					isEqual = false;
				}
			} else if (!id.equals(other.id)) {
				isEqual = false;
			}
		}
		return isEqual;
	}

	@Override
	@Transient
	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

}
