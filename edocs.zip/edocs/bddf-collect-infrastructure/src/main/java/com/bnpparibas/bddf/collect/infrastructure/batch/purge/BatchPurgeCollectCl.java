package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import org.apache.log4j.MDC;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class BatchPurgeCollectCl extends AbstractBatchPurgeCollect {

	public BatchPurgeCollectCl() {
		super("COLLECT_PURGE_COLLECT_CL", BATCH_COLLECT, PurgeType.COL_CL_SU);
	}

	@Override
	protected boolean isDeletedOnGdn() {
		return false;
	}

	@Override
	@Scheduled(cron = "${purge.collect-cl.cron}")
	public void scheduledStart() {
		MDC.put("UserID", getBatchName());
		MDC.put("AppName", appName);
		startBatch();
	}

}
