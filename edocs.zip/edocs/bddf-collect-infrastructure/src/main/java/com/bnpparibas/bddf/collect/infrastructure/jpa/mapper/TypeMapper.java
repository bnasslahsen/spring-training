package com.bnpparibas.bddf.collect.infrastructure.jpa.mapper;

import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.infrastructure.entity.FamilyEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.OwnerEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.TypeEntity;

@Component
public class TypeMapper {

	@Autowired
	private PieceMapper pieceMapper;

	@Autowired
	private IndexeMapper indexeMapper;

	@Autowired
	private EdocIndexRepository edocIndexRepository;

	public Type typeEntityToType(TypeEntity t) {
		return typeEntityToType(t, true);
	}

	public Type typeEntityToType(TypeEntity t, boolean withInactivePieces) {
		final Type type = new Type();
		type.setId(UUID.fromString(Optional.ofNullable(t).map(TypeEntity::getId).orElse("")));
		type.setDisplayToClient(BooleanUtils.toBoolean(t.getDisplayToClient()));
		type.setAdditionalInformation(t.getAdditionalInformation());
		type.setAdditionalInformationCollab(t.getAdditionalInformationCollab());
		type.setControlDate(Optional.ofNullable(t.getControlDate()).map(Date::toInstant).orElse(null));
		type.setControlRequired(t.getControlRequired());
		type.setDigitalAllowed(BooleanUtils.toBoolean(t.getDigitalAllowed()));
		type.setPaperAllowed(BooleanUtils.toBoolean(t.getPaperAllowed()));
		type.setLabel(t.getLabel());
		type.setMaxSizeDoc(Optional.ofNullable(t).map(TypeEntity::getMaxSizeDoc).orElse(0));
		Optional.ofNullable(t.getParentId()).map(UUID::fromString).ifPresent(type::setParentId);
		type.setPendingDocument(BooleanUtils.toBoolean(t.getPendingDocument()));
		type.setPendingDocumentLabel(t.getPendingDocumentLabel());
		type.setPendingDocumentProfile(t.getPendingDocumentProfile());
		if (withInactivePieces) {
			type.setPieces(t.getPieces().stream().map(p -> pieceMapper.pieceEntityToPieceAndIsInactive(p)).collect(Collectors.toSet()));
		} else {
			type.setPieces(t.getPieces().stream().filter(p -> PieceStates.ACTIF.getLabel().equals(p.getState())).map(p -> pieceMapper.pieceEntityToPiece(p)).collect(Collectors.toSet()));
		}
		type.setEdocType(t.getEdocType());
		type.setStatus(t.getStatus());
		Optional.ofNullable(t.getEnableReuse()).map(BooleanUtils::toBoolean).ifPresent(type::setEnableReuse);
		type.setCompleteness(t.getCompleteness() == null ? null : new HashSet<String>(Arrays.asList(t.getCompleteness().split(","))));
		type.setCompletenessControl(t.getCompletenessControl());
		type.setCompletenessControlLabel(t.getCompletenessControlLabel());
		type.setStatusControl(t.getStatusControl());
		type.setVideoCodingDelay(t.getVideoCodingDelays());
		type.setPosition(t.getPosition());
		type.getIndexes().addAll(indexeMapper.toIndexes(t.getIndexes(), edocIndexRepository.findAll()));
		type.setFamilyId(UUID.fromString(Optional.ofNullable(t).map(s -> s.getFamily().getId()).orElse("")));
		type.setFamilyOwners(t.getFamily().getOwners().stream().map(OwnerEntity::getReference).collect(Collectors.toSet()));
		type.setDisplayCommentToClient(Optional.ofNullable(t.getDisplayCommentToClient()).orElse(Boolean.FALSE));
		return type;
	}

	public void copyTypeData(TypeEntity type, Type typeToCopy, FamilyEntity familyEntity, boolean isNew, String collectId) {
		type.setAdditionalInformation(typeToCopy.getAdditionalInformation());
		type.setDisplayToClient(typeToCopy.isDisplayToClient());
		type.setAdditionalInformationCollab(typeToCopy.getAdditionalInformationCollab());
		type.setControlDate(Optional.ofNullable(typeToCopy.getControlDate()).map(Date::from).orElse(null));
		type.setControlRequired(typeToCopy.getControlRequired());
		type.setDigitalAllowed(typeToCopy.isDigitalAllowed());
		type.setPaperAllowed(typeToCopy.isPaperAllowed());
		type.setId(typeToCopy.getId().toString());
		type.setLabel(typeToCopy.getLabel());
		type.setMaxSizeDoc((int) (typeToCopy.getMaxSizeDoc()));
		if (Optional.ofNullable(typeToCopy.getParentId()).isPresent()) {
			type.setParentId(typeToCopy.getParentId().toString());
		}

		type.setPendingDocument(typeToCopy.isPendingDocument());
		type.setPendingDocumentLabel(typeToCopy.getPendingDocumentLabel());
		type.setPendingDocumentProfile(typeToCopy.getPendingDocumentProfile());

		type.setFamily(familyEntity);
		if (type.getPieces() == null) {
			type.setPieces(new HashSet<>());
		}
		if (type.getIndexes() == null) {
			type.setIndexes(new HashSet<>());
		}
		type.getPieces().addAll(typeToCopy.getPieces().stream().map(p -> pieceMapper.pieceToPieceEntity(p, type, isNew)).collect(Collectors.toSet()));
		if (Optional.ofNullable(typeToCopy.getCompleteness()).isPresent()) {
			type.setCompleteness(String.join(",", typeToCopy.getCompleteness()));
		}
		type.setEdocType(typeToCopy.getEdocType());
		Optional.ofNullable(typeToCopy.getStatus()).ifPresent(type::setStatus);
		type.setStatusControl(typeToCopy.getStatusControl());
		type.setCompletenessControl(typeToCopy.getCompletenessControl());
		type.setCompletenessControlLabel(typeToCopy.getCompletenessControlLabel());
		type.setPosition(typeToCopy.getPosition());
		type.setVideoCodingDelays(typeToCopy.getVideoCodingDelay());
		type.setNew(isNew);
		type.getIndexes().addAll(indexeMapper.toIndexeEntities(typeToCopy.getIndexes(), isNew));
		type.getIndexes().forEach(indexeEntity -> indexeEntity.setType(type));
		type.setCollectId(collectId);
		type.setDisplayCommentToClient(typeToCopy.isDisplayCommentToClient());
	}

}
