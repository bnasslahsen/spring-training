package com.bnpparibas.bddf.collect.infrastructure.converter;

import java.time.Instant;
import java.util.Date;

import org.dozer.CustomConverter;
import org.dozer.MappingException;

public class InstantToDateConverter implements CustomConverter {

	public InstantToDateConverter() {
		super();
	}

	@Override
	public Object convert(Object destination, Object source, Class destClass, Class sourceClass) {
		if (source == null) {
			return null;
		}

		if (source instanceof Instant) {
			return Date.from((Instant) source);
		} else if (source instanceof Date) {
			return ((Date) source).toInstant();
		} else {
			throw new MappingException("Converter InstantToDateConverter " + "used incorrectly. Arguments passed in were:" + destination + " and " + source);
		}
	}
}
