package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.audit.event.NomenclatureRefEvent;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.event.collect.UpdatedCollect;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.infrastructure.entity.CollectEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.FamilyEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.PieceEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.TypeEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.CollectMapper;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.CollectJpaRepository;
import com.bnpparibas.bddf.jms.sender.domain.Media;

@Component
public class CollectAbandonItemWriter implements ItemWriter<CollectEntity> {

	@Autowired
	private PurgeUtils purgeUtils;
	@Autowired
	private CollectJpaRepository collectJpaRepository;
	@Autowired
	private CollectEventHandler collectEventHandler;
	@Autowired
	private CollectMapper collectMapper;
	private static final String OK_AB = "OK_AB";

	@Override
	public void write(List<? extends CollectEntity> collectAb) throws Exception {
		final Instant instantTimeOutCollectEc = purgeUtils.buildPurgeDate(PurgeType.COL_EC_AB);
		collectAb.stream().map(collectEntity -> purgeCollect(collectEntity, Timestamp.from(instantTimeOutCollectEc))).reduce(defaultResBatchCollect(), this::groupMapsBatchCollect);
	}

	private Map<String, Long> purgeCollect(CollectEntity collectEntity, Timestamp instantTimeOutCollectEc) {
		final Map<String, Long> result = defaultResBatchCollect();
		final Set<FamilyEntity> families = collectEntity.getFamilies().stream().collect(Collectors.toSet());
		final List<Timestamp> acquisitionDates = families.stream().flatMap(family -> family.getTypes().stream()).flatMap(type -> type.getPieces().stream()).map(PieceEntity::getAcquisitionDate).filter(date -> date != null).collect(Collectors.toList());
		final List<Timestamp> updateDates = families.stream().flatMap(family -> family.getTypes().stream()).flatMap(type -> type.getPieces().stream()).map(PieceEntity::getUpdateDate).filter(date -> date != null).collect(Collectors.toList());

		acquisitionDates.addAll(updateDates);
		final Timestamp max = acquisitionDates.stream().max((t1, t2) -> t1.compareTo(t2)).orElse(instantTimeOutCollectEc);
		if (max.compareTo(instantTimeOutCollectEc) <= 0) {
			final AtomicBoolean isAB = new AtomicBoolean(true);

			families.stream().forEach(familyEntity -> {
				final Set<TypeEntity> typeEntities = familyEntity.getTypes();
				isAB.set(isAB.get() && isAB(typeEntities));
			});

			if (isAB.get()) {
				collectEntity.setStatus(CollectStatus.AB.name());
				saveAndCount(collectEntity, result, OK_AB);
				sendEvent(collectEntity, Channel.API.getValue(), Media.SERVEUR_VOCAL.getLibelle(), "");
			}
		}

		return result;
	}

	private void sendEvent(CollectEntity collectEntity, String channel, String media, String employeeId) {
		final UpdatedCollect updatedCollect = new UpdatedCollect();
		final Collect collect = collectMapper.toCollect(collectEntity, false);
		updatedCollect.setCollect(collect);
		updatedCollect.setChannel(channel);
		updatedCollect.setMedia(media);
		updatedCollect.setEmployeeId(employeeId);
		if (CollectStatus.AB.name().equals(collect.getStatus())) {
			updatedCollect.setNomenclatureRef(NomenclatureRefEvent.EVENT_ABANDON_COLLECT.getCode());
		}
		collectEventHandler.sendUpdatedCollectEvent(updatedCollect);
	}

	private Map<String, Long> defaultResBatchCollect() {
		final Map<String, Long> map = new HashMap<>();
		map.put(OK_AB, 0l);
		return map;
	}

	private void saveAndCount(CollectEntity collectEntity, Map<String, Long> result, String key) {
		collectEntity.setEndDate(Timestamp.from(Instant.now()));
		collectJpaRepository.save(collectEntity);

		result.put(key, result.get(key) + 1);
	}

	private boolean isAB(Set<TypeEntity> typeEntities) {
		return typeEntities.stream().allMatch(t -> validateTypeFixeAB(typeEntities, t));
	}

	private boolean validateTypeFixeAB(Set<TypeEntity> typeList, TypeEntity t) {
		boolean isTypeFixe = true;
		if (typeList.stream().noneMatch(x -> t.getId().equals(x.getParentId()))
				&& (!t.getPendingDocument() && !t.getPieces().isEmpty() && t.getPieces().stream().allMatch(piece -> Arrays.asList(PieceStatus.RC.getLabel(), PieceStatus.VA.getLabel()).contains(piece.getStatus())))) {
			isTypeFixe = false;
		}
		return isTypeFixe;
	}

	private Map<String, Long> groupMapsBatchCollect(Map<String, Long> m1, Map<String, Long> m2) {
		m1.put(OK_AB, m1.get(OK_AB) + m2.get(OK_AB));
		return m1;
	}

}
