package com.bnpparibas.bddf.collect.infrastructure.event.process;

import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.xml.datatype.DatatypeConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditEvent;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.audit.event.NomenclatureRefEvent;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.event.collect.UpdatedCollect;
import com.bnpparibas.bddf.collect.domain.event.piece.PieceSent2Gdn;
import com.bnpparibas.bddf.collect.domain.event.type.EventSendAMI;
import com.bnpparibas.bddf.collect.domain.event.type.TypeReceived;
import com.bnpparibas.bddf.collect.domain.event.type.TypeReceivedType;
import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.DocumentSet;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.TypeControls;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.type.FamilyRepository;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.infrastructure.entity.AuditEventEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.EventEntity;
import com.bnpparibas.bddf.collect.infrastructure.event.converter.EventDataHelper;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.TimestampUtils;
import com.bnpparibas.bddf.collect.infrastructure.repository.EventRepository;
import com.bnpparibas.bddf.jms.sender.domain.EventData;
import com.bnpparibas.bddf.jms.sender.process.EventManagementMessageToSendMarshaller;
import com.bnpparibas.bddf.rest.Context;

@Service
public class MessageSender implements CollectEventHandler {
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageSender.class);

	@Value("${jms.mq.outbound-default-queue}")
	private String destination;

	@Autowired
	@Qualifier(value = "topicTemplate")
	private final JmsTemplate jmsTemplate;
	private final EventRepository eventRepository;
	private final EventManagementMessageToSendMarshaller marshaller;
	private final AuditGenerator auditGenerator;
	@Autowired
	private EdocTypeRepository edocTypeRepository;
	@Autowired
	private CollectRepository collectRepository;
	@Autowired
	private FamilyRepository familyRepository;

	public MessageSender(JmsTemplate jmsTemplate, EventRepository eventCassandraRepository, EventManagementMessageToSendMarshaller marshaller, AuditGenerator auditGenerator) {
		this.jmsTemplate = jmsTemplate;
		this.eventRepository = eventCassandraRepository;
		this.marshaller = marshaller;
		this.auditGenerator = auditGenerator;
	}

	@Override
	public void sendTypeReceivedEventForBatch(TypeReceived typeReceived, String content, String eventId, int replays) {
		final EventEntity eventToSend = new EventEntity(content, typeReceived.getTypeReceivedType().getLabel(), TimestampUtils.getNow(), "TO_SEND", typeReceived.getCollect().getId().toString(), typeReceived.getType().getId().toString(),
				typeReceived.getMedia(), typeReceived.getChannel(), typeReceived.getUserId(), null);
		try {
			eventToSend.setId(eventId);
			eventToSend.setReplays(replays);
			jmsTemplate.convertAndSend(destination, content, m -> setMessageProperties(typeReceived, m));

			eventToSend.setStatus("SENT");
			eventRepository.saveEvent(eventToSend);

			final AuditEvent auditEvent = initAuditEvent(typeReceived, eventToSend);
			sendAuditEvent(auditEvent);
		} catch (final JmsException e) {
			if (replays == 3) {
				eventRepository.updateStatusEvent(eventToSend.getId(), "ERR");
				LOGGER.error("Batch Rejoue Event : " + e.getMessage(), e);
			}
		}

	}

	@Async("sendEventMQTaskExecutor")
	@Override
	public void sendTypeReceivedEvent(TypeReceived typeReceived) {
		LoggerHelper.logForPerfTest(LOGGER, "Début sendTypeReceivedEvent" + " pour le type " + typeReceived.getType().getId().toString() + " (thread id " + Thread.currentThread().getId() + ")");
		synchronized (typeReceived.getType().getId()) {
			try {
				final EventData eventData = EventDataHelper.fromTypeReceived(typeReceived);

				final String xml = marshaller.toXml(eventData);
				final EventEntity eventToSend = new EventEntity(xml, typeReceived.getTypeReceivedType().getLabel(), TimestampUtils.getNow(), "TO_SEND", typeReceived.getCollect().getId().toString(), typeReceived.getType().getId().toString(),
						typeReceived.getMedia(), typeReceived.getChannel(), typeReceived.getUserId(), null);
				eventToSend.setId(typeReceived.getEventId().toString());
				eventRepository.saveEvent(eventToSend);

				if (!typeReceived.getType().isFamilyBlocked()) {
					final long start = System.currentTimeMillis();
					jmsTemplate.convertAndSend(destination, xml, m -> setMessageProperties(typeReceived, m));
					final long elapsedTime = System.currentTimeMillis() - start;
					LoggerHelper.logForPerfTest(LOGGER, "Temps JMS pour sendTypeReceivedEvent : " + elapsedTime + " ms");

					eventToSend.setStatus("SENT");
					eventRepository.saveEvent(eventToSend);

					final AuditEvent auditEvent = initAuditEvent(typeReceived, eventToSend);
					sendAuditEvent(auditEvent);
				}

			} catch (final JmsException | DatatypeConfigurationException e) {
				final AuditEvent auditEvent = initErrorAuditEvent(typeReceived);
				sendAuditEvent(auditEvent);
				familyRepository.updateBlocked(typeReceived.getType().getFamilyId());
				LOGGER.error(e.getMessage(), e);
			}
			LoggerHelper.logForPerfTest(LOGGER, "Fin sendTypeReceivedEvent" + " pour le type " + typeReceived.getType().getId().toString() + " (thread id " + Thread.currentThread().getId() + ")");
		}
	}

	@Async("sendEventMQTaskExecutor")
	@Override
	public void sendGdnPieceEvent(PieceSent2Gdn pieceSent2Gdn, String edocType, String typeLabel) {
		LoggerHelper.logForPerfTest(LOGGER, "Début sendGdnPieceEvent" + " pour la piece " + pieceSent2Gdn.getPiece().getId().toString() + " (thread id " + Thread.currentThread().getId() + ")");
		final Type type = pieceSent2Gdn.getCollect().getTypes().stream().filter(typeL -> typeL.getId().toString().equals(pieceSent2Gdn.getTypeId())).findFirst().orElse(null);
		try {
			final EventData eventData = EventDataHelper.fromUpdatedPiece(pieceSent2Gdn);
			final String xml = marshaller.toXml(eventData);

			final EventEntity eventToSend = new EventEntity(xml, pieceSent2Gdn.getNomenclatureRef(), TimestampUtils.getNow(), "TO_SEND", pieceSent2Gdn.getCollect().getId().toString(), pieceSent2Gdn.getTypeId(), pieceSent2Gdn.getMedia(),
					pieceSent2Gdn.getChannel(), pieceSent2Gdn.getUserId(), pieceSent2Gdn.getPiece().getId().toString());
			eventToSend.setId(pieceSent2Gdn.getEventId().toString());
			eventRepository.saveEvent(eventToSend);

			if (type != null && !type.isFamilyBlocked()) {
				final long start = System.currentTimeMillis();
				jmsTemplate.convertAndSend(destination, xml, m -> setMessageProperties(pieceSent2Gdn, m));
				final long elapsedTime = System.currentTimeMillis() - start;
				LoggerHelper.logForPerfTest(LOGGER, "Temps JMS pour sendGdnPieceEvent : " + elapsedTime + " ms");

				eventToSend.setStatus("SENT");
				eventRepository.saveEvent(eventToSend);

				final AuditEvent auditEvent = auditGenerator.newAudit(new Context(pieceSent2Gdn.getUserId(), pieceSent2Gdn.getChannel(), pieceSent2Gdn.getMedia()), AuditValue.EVENT_GDN_INJECTION, pieceSent2Gdn.getPiece().getId().toString())
						// Event
						.setIdEvent(eventToSend.getId())
						// Collect
						.setIdCollect(pieceSent2Gdn.getCollect().getId())
						// journeyCode
						.setJourneyCode(pieceSent2Gdn.getCollect().getJourneyCode())
						// Type
						.setIdType(UUID.fromString(pieceSent2Gdn.getTypeId()))
						// edoctype
						.setEdocType(edocType)
						// edoctype label
						.setTypeLabel(Optional.ofNullable(edocType).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(typeLabel))
						// Piece
						.setIdPiece(UUID.fromString(pieceSent2Gdn.getPiece().getId().toString()));
				sendAuditEvent(auditEvent);
			}

		} catch (final JmsException | DatatypeConfigurationException e) {
			final AuditEvent auditEvent = auditGenerator.newAudit(new Context(pieceSent2Gdn.getUserId(), pieceSent2Gdn.getChannel(), pieceSent2Gdn.getMedia()), AuditValue.EVENT_ERROR_GDN_INJECTION, pieceSent2Gdn.getPiece().getId().toString())
					// Event
					.setIdEvent(pieceSent2Gdn.getEventId().toString())
					// Collect
					.setIdCollect(pieceSent2Gdn.getCollect().getId())
					// journeyCode
					.setJourneyCode(pieceSent2Gdn.getCollect().getJourneyCode())
					// Type
					.setIdType(UUID.fromString(pieceSent2Gdn.getTypeId()))
					// edoctype
					.setEdocType(edocType)
					// edoctype label
					.setTypeLabel(Optional.ofNullable(edocType).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(typeLabel))
					// Piece
					.setIdPiece(UUID.fromString(pieceSent2Gdn.getPiece().getId().toString()));
			sendAuditEvent(auditEvent);
			familyRepository.updateBlocked(type.getFamilyId());
			LOGGER.error(e.getMessage(), e);
		}
		LoggerHelper.logForPerfTest(LOGGER, "Fin sendGdnPieceEvent" + " pour la piece " + pieceSent2Gdn.getPiece().getId().toString() + " (thread id " + Thread.currentThread().getId() + ")");
	}

	@Override
	public void sendGdnPieceEventForBatch(PieceSent2Gdn pieceSent2Gdn, String content, String edocType, String typeLabel, String eventId, int replays) {
		final EventEntity eventToSend = new EventEntity(content, pieceSent2Gdn.getNomenclatureRef(), TimestampUtils.getNow(), "TO_SEND", pieceSent2Gdn.getCollect().getId().toString(), pieceSent2Gdn.getTypeId(), pieceSent2Gdn.getMedia(),
				pieceSent2Gdn.getChannel(), pieceSent2Gdn.getUserId(), pieceSent2Gdn.getPiece().getId().toString());
		try {
			eventToSend.setId(eventId);
			eventToSend.setReplays(replays);
			jmsTemplate.convertAndSend(destination, content, m -> setMessageProperties(pieceSent2Gdn, m));

			eventToSend.setStatus("SENT");
			eventRepository.saveEvent(eventToSend);

			final AuditEvent auditEvent = auditGenerator.newAudit(new Context(pieceSent2Gdn.getUserId(), pieceSent2Gdn.getChannel(), pieceSent2Gdn.getMedia()), AuditValue.EVENT_GDN_INJECTION, pieceSent2Gdn.getPiece().getId().toString())
					// Event
					.setIdEvent(eventToSend.getId())
					// Collect
					.setIdCollect(pieceSent2Gdn.getCollect().getId())
					// journeyCode
					.setJourneyCode(pieceSent2Gdn.getCollect().getJourneyCode())
					// Type
					.setIdType(UUID.fromString(pieceSent2Gdn.getTypeId()))
					// edoctype
					.setEdocType(edocType)
					// edoctype label
					.setTypeLabel(Optional.ofNullable(edocType).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(typeLabel))
					// Piece
					.setIdPiece(UUID.fromString(pieceSent2Gdn.getPiece().getId().toString()));
			sendAuditEvent(auditEvent);
		} catch (final JmsException e) {
			if (replays == 3) {
				eventRepository.updateStatusEvent(eventToSend.getId(), "ERR");
				LOGGER.error("Batch Rejoue Event : " + e.getMessage(), e);
			}
		}
	}

	@Async("sendEventMQTaskExecutor")
	@Override
	public void sendEventAMI(EventSendAMI eventSendAMI) {
		final Type type = eventSendAMI.getCollect().getTypes().stream().filter(t -> t.getId().toString().equals(eventSendAMI.getTypeId())).findFirst().orElse(null);
		final Integer nbPiecesToBeSentToAMI = TypeControls.OK.name().equals(type.getCompletenessControl()) ? 0 : type.getActivePieces().stream().filter(piece -> !PieceStatus.RF.getLabel().equals(piece.getStatus())).collect(Collectors.toList()).size();
		try {
			final EventData eventData = EventDataHelper.constructEventAmi(eventSendAMI);
			final String xml = marshaller.toXml(eventData);

			final EventEntity eventToSend = new EventEntity(xml, eventSendAMI.getNomenclatureRef(), TimestampUtils.getNow(), "TO_SEND", eventSendAMI.getCollect().getId().toString(), eventSendAMI.getTypeId(), eventSendAMI.getMedia(),
					eventSendAMI.getChannel(), null, null);
			eventToSend.setId(eventSendAMI.getEventId().toString());
			eventRepository.saveEvent(eventToSend);

			if (!type.isFamilyBlocked()) {

				final long start = System.currentTimeMillis();
				jmsTemplate.convertAndSend(destination, xml, m -> setMessageProperties(eventSendAMI, m));
				final long elapsedTime = System.currentTimeMillis() - start;
				LoggerHelper.logForPerfTest(LOGGER, "Temps  pour sendEventAMI : " + elapsedTime + " ms");

				eventToSend.setStatus("SENT");
				eventRepository.saveEvent(eventToSend);

				final AuditEvent auditEvent = auditGenerator.newAudit(new Context(eventSendAMI.getUserId(), eventSendAMI.getChannel(), eventSendAMI.getMedia()), AuditValue.EVENT_SEND_TO_AMI, eventSendAMI.getTypeId())
						// Event
						.setIdEvent(eventToSend.getId())
						// Collect
						.setIdCollect(eventSendAMI.getCollect().getId())
						// journeyCode
						.setJourneyCode(eventSendAMI.getCollect().getJourneyCode())
						// Type
						.setIdType(UUID.fromString(eventSendAMI.getTypeId()))
						// edoctype
						.setEdocType(type.getEdocType())
						// edoctype label
						.setTypeLabel(Optional.ofNullable(type.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(type.getLabel()))
						// iterationLadRad
						.setIterationLadRad(type.getActivePieces().stream().mapToInt(Piece::getControlIterationAchieved).max().orElse(0))
						// documentSet
						.setDocumentSet(findDocumentSetFromType(Optional.ofNullable(type.getEdocType()).orElse(type.getEdocType())))
						// totalPieces
						.setTotalPieces(nbPiecesToBeSentToAMI)
						// Piece
						.setIdPiece(UUID.fromString(eventSendAMI.getColledId()));
				sendAuditEvent(auditEvent);
			}

		} catch (final JmsException | DatatypeConfigurationException e) {
			final AuditEvent auditEvent = auditGenerator.newAudit(new Context(eventSendAMI.getColledId(), eventSendAMI.getChannel(), eventSendAMI.getMedia()), AuditValue.EVENT_SEND_TO_AMI, eventSendAMI.getTypeId())
					// Event
					.setIdEvent(eventSendAMI.getEventId().toString())
					// Collect
					.setIdCollect(eventSendAMI.getCollect().getId())
					// journeyCode
					.setJourneyCode(eventSendAMI.getCollect().getJourneyCode())
					// Type
					.setIdType(UUID.fromString(eventSendAMI.getTypeId()))
					// edoctype
					.setEdocType(type.getEdocType())
					// edoctype label
					.setTypeLabel(Optional.ofNullable(type.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(type.getLabel()))
					// iterationLadRad
					.setIterationLadRad(type.getActivePieces().stream().mapToInt(Piece::getControlIterationAchieved).max().orElse(0))
					// documentSet
					.setDocumentSet(findDocumentSetFromType(Optional.ofNullable(type.getEdocType()).orElse(type.getEdocType())))
					// totalPieces
					.setTotalPieces(nbPiecesToBeSentToAMI)
					// Piece
					.setIdPiece(UUID.fromString(eventSendAMI.getColledId()));
			sendAuditEvent(auditEvent);
			familyRepository.updateBlocked(type.getFamilyId());
			LOGGER.error(e.getMessage(), e);
		}
		LoggerHelper.logForPerfTest(LOGGER, "Fin eventSendAMI" + " pour la piece " + eventSendAMI.getColledId() + " (thread id " + Thread.currentThread().getId() + ")");
	}

	@Override
	public void sendEventAMIForBatch(EventSendAMI eventSendAMI, String content, String eventId, int replays) {
		final EventEntity eventToSend = new EventEntity(content, eventSendAMI.getNomenclatureRef(), TimestampUtils.getNow(), "TO_SEND", eventSendAMI.getCollect().getId().toString(), eventSendAMI.getTypeId(), eventSendAMI.getMedia(),
				eventSendAMI.getChannel(), null, null);
		final Type type = eventSendAMI.getCollect().getTypes().stream().filter(t -> t.getId().toString().equals(eventSendAMI.getTypeId())).findFirst().get();
		final Integer nbPiecesToBeSentToAMI = TypeControls.OK.name().equals(type.getCompletenessControl()) ? 0 : type.getActivePieces().stream().filter(piece -> !PieceStatus.RF.getLabel().equals(piece.getStatus())).collect(Collectors.toList()).size();
		try {
			eventToSend.setId(eventId);
			eventToSend.setReplays(replays);
			final long start = System.currentTimeMillis();
			jmsTemplate.convertAndSend(destination, content, m -> setMessageProperties(eventSendAMI, m));
			final long elapsedTime = System.currentTimeMillis() - start;
			LoggerHelper.logForPerfTest(LOGGER, "Temps  pour sendEventAMI : " + elapsedTime + " ms");

			eventToSend.setStatus("SENT");
			eventRepository.saveEvent(eventToSend);

			final AuditEvent auditEvent = auditGenerator.newAudit(new Context(eventSendAMI.getUserId(), eventSendAMI.getChannel(), eventSendAMI.getMedia()), AuditValue.EVENT_SEND_TO_AMI, eventSendAMI.getTypeId())
					// Event
					.setIdEvent(eventToSend.getId())
					// Collect
					.setIdCollect(eventSendAMI.getCollect().getId())
					// journeyCode
					.setJourneyCode(eventSendAMI.getCollect().getJourneyCode())
					// Type
					.setIdType(UUID.fromString(eventSendAMI.getTypeId()))
					// edoctype
					.setEdocType(type.getEdocType())
					// edoctype label
					.setTypeLabel(Optional.ofNullable(type.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(type.getLabel()))
					// iterationLadRad
					.setIterationLadRad(type.getActivePieces().stream().mapToInt(Piece::getControlIterationAchieved).max().orElse(0))
					// documentSet
					.setDocumentSet(findDocumentSetFromType(Optional.ofNullable(type.getEdocType()).orElse(type.getEdocType())))
					// totalPieces
					.setTotalPieces(nbPiecesToBeSentToAMI)
					// Piece
					.setIdPiece(UUID.fromString(eventSendAMI.getColledId()));
			sendAuditEvent(auditEvent);
		} catch (final JmsException e) {
			if (replays == 3) {
				eventRepository.updateStatusEvent(eventToSend.getId(), "ERR");
				LOGGER.error("Batch Rejoue Event : " + e.getMessage(), e);
			}
		}

	}

	private AuditEvent initErrorAuditEvent(TypeReceived typeReceived) {
		AuditValue auditValue;
		if (TypeReceivedType.DEPOSED.equals(typeReceived.getTypeReceivedType())) {
			auditValue = AuditValue.ERROR_EVENT_84;
		} else if (TypeReceivedType.CONTROLLED.equals(typeReceived.getTypeReceivedType())) {
			auditValue = AuditValue.ERROR_EVENT_85;
		} else if (TypeReceivedType.AUTOMATTC_CONTROL.equals(typeReceived.getTypeReceivedType())) {
			auditValue = AuditValue.LAD_RAD_SENDING_AUTO_CONTROL_EVENT_ERROR;
		} else {
			LOGGER.error("ERROR - Invalid typeReceivedType: " + typeReceived.getTypeReceivedType());
			auditValue = null;
		}
		return auditGenerator.newAudit(new Context(typeReceived.getUserId(), typeReceived.getChannel(), typeReceived.getMedia()), auditValue, typeReceived.getType().getLabel())
				// Collecte
				.setIdCollect(typeReceived.getCollect().getId()).setJourneyCode(typeReceived.getCollect().getJourneyCode())
				// Type
				.setIdType(typeReceived.getType().getId());

	}

	private AuditEvent initAuditEvent(TypeReceived typeReceived, final EventEntity eventToSend) {
		Integer maxIeration = 0;
		AuditValue auditValue;
		if (TypeReceivedType.DEPOSED.equals(typeReceived.getTypeReceivedType())) {
			auditValue = AuditValue.EVENT_SAVE_TYPE;
		} else if (TypeReceivedType.CONTROLLED.equals(typeReceived.getTypeReceivedType())) {
			auditValue = AuditValue.EVENT_UPDATE_TYPE;
		} else if (TypeReceivedType.AUTOMATTC_CONTROL.equals(typeReceived.getTypeReceivedType())) {
			maxIeration = typeReceived.getType().getActivePieces().stream().mapToInt(Piece::getControlIterationAchieved).max().orElse(0);
			auditValue = AuditValue.LAD_RAD_SENDING_AUTO_CONTROL_EVENT;
		} else {
			LOGGER.error("ERROR - Invalid typeReceivedType: " + typeReceived.getTypeReceivedType());
			auditValue = null;
		}
		return auditGenerator.newAudit(new Context(typeReceived.getUserId(), typeReceived.getChannel(), typeReceived.getMedia()), auditValue, typeReceived.getType().getLabel())
				// Collecte
				.setIdCollect(typeReceived.getCollect().getId()).setJourneyCode(typeReceived.getCollect().getJourneyCode())
				//
				.setIterationLadRad(maxIeration)
				//
				.setDocumentSet(findDocumentSetFromType(Optional.ofNullable(typeReceived.getType().getEdocType()).orElse(typeReceived.getType().getEdocType())))
				// Type
				.setIdType(typeReceived.getType().getId()).setEdocType(typeReceived.getType().getEdocType())
				.setTypeLabel(Optional.ofNullable(typeReceived.getType().getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(typeReceived.getType().getLabel()))
				// Event
				.setIdEvent(eventToSend.getId());

	}

	private String findDocumentSetFromType(String edocType) {
		return edocTypeRepository.findAll().stream().filter(edocTypeL -> edocTypeL.getValue().equals(edocType)).findAny().map(EdocType::getDocumentSet).orElse(DocumentSet.JMC_SET.getLabel());
	}

	private Message setMessageProperties(TypeReceived typeReceived, Message message) throws JMSException {
		message.setStringProperty("journeyCode", typeReceived.getCollect().getJourneyCode());
		message.setStringProperty("sendingApplicationCode", typeReceived.getCollect().getSendingApplicationCode());
		message.setStringProperty("nomenclatureRef", typeReceived.getTypeReceivedType().getLabel());
		return message;
	}

	private Message setMessageProperties(UpdatedCollect updatedCollect, Message message) throws JMSException {
		message.setStringProperty("journeyCode", updatedCollect.getCollect().getJourneyCode());
		message.setStringProperty("sendingApplicationCode", updatedCollect.getCollect().getSendingApplicationCode());
		message.setStringProperty("nomenclatureRef", updatedCollect.getNomenclatureRef());
		return message;
	}

	private Message setMessageProperties(PieceSent2Gdn pieceSent2Gdn, Message message) throws JMSException {
		message.setStringProperty("journeyCode", pieceSent2Gdn.getCollect().getJourneyCode());
		message.setStringProperty("sendingApplicationCode", pieceSent2Gdn.getCollect().getSendingApplicationCode());
		message.setStringProperty("nomenclatureRef", pieceSent2Gdn.getNomenclatureRef());
		return message;
	}

	private Message setMessageProperties(EventSendAMI pieceSent2Gdn, Message message) throws JMSException {
		message.setStringProperty("journeyCode", pieceSent2Gdn.getCollect().getJourneyCode());
		message.setStringProperty("sendingApplicationCode", pieceSent2Gdn.getCollect().getSendingApplicationCode());
		message.setStringProperty("nomenclatureRef", pieceSent2Gdn.getNomenclatureRef());
		return message;
	}

	@Override
	public void sendUpdatedCollectEventForBatch(UpdatedCollect updatedCollect, String content, String eventId, int replays) {
		final EventEntity eventToSend = new EventEntity(content, updatedCollect.getNomenclatureRef(), TimestampUtils.getNow(), "TO_SEND", updatedCollect.getCollect().getId().toString(), "", updatedCollect.getMedia(), updatedCollect.getChannel(),
				updatedCollect.getEmployeeId(), null);
		try {
			eventToSend.setId(eventId);
			eventToSend.setNew(false);
			eventToSend.setReplays(replays);

			jmsTemplate.convertAndSend(destination, content, m -> setMessageProperties(updatedCollect, m));

			eventToSend.setStatus("SENT");
			eventRepository.saveEvent(eventToSend);

			AuditValue auditValue;
			if (CollectStatus.CL.name().equals(updatedCollect.getCollect().getStatus())) {
				auditValue = AuditValue.EVENT_CLOTURE;
			} else if (CollectStatus.AB.name().equals(updatedCollect.getCollect().getStatus())) {
				auditValue = AuditValue.EVENT_ABANDON;
			} else if (NomenclatureRefEvent.EVENT_UPDATE_COLLECT.getCode().equals(updatedCollect.getNomenclatureRef())) {
				auditValue = AuditValue.EVENT_UPDATE_FAMILY;
			} else {
				LOGGER.error("ERREUR - Invalid event code " + updatedCollect.getNomenclatureRef());
				auditValue = null;
			}
			final AuditEvent auditEvent = auditGenerator.newAudit(new Context(updatedCollect.getEmployeeId(), updatedCollect.getChannel(), updatedCollect.getMedia()), auditValue)
					// Event
					.setIdEvent(eventToSend.getId())
					// Collecte
					.setIdCollect(updatedCollect.getCollect().getId()).setJourneyCode(updatedCollect.getCollect().getJourneyCode());
			if (NomenclatureRefEvent.EVENT_UPDATE_COLLECT.getCode().equals(updatedCollect.getNomenclatureRef())) {
				updatedCollect.getFamiliesIds().stream().forEach(familyId -> {
					auditEvent.setIdFamily(familyId);
					sendAuditEvent(auditEvent);
				});
			} else {
				sendAuditEvent(auditEvent);
			}

		} catch (final JmsException e) {
			if (replays == 3) {
				eventRepository.updateStatusEvent(eventToSend.getId(), "ERR");
				LOGGER.error("Batch Rejoue Event : " + e.getMessage(), e);
			}
		}
	}

	@Override
	@Async("sendEventMQTaskExecutor")
	public void sendUpdatedCollectEvent(UpdatedCollect updatedCollect) {
		try {
			// TODO: continuer check plus initialisation erreur
			LOGGER.debug("Invoking Send message consentConvention = {}", updatedCollect);

			final EventData eventData = EventDataHelper.fromUpdatedCollect(updatedCollect);

			final String xml = marshaller.toXml(eventData);
			final EventEntity eventToSend = new EventEntity(xml, updatedCollect.getNomenclatureRef(), TimestampUtils.getNow(), "TO_SEND", updatedCollect.getCollect().getId().toString(), "", updatedCollect.getMedia(), updatedCollect.getChannel(),
					updatedCollect.getEmployeeId(), null);
			eventToSend.setId(updatedCollect.getEventId().toString());
			eventRepository.saveEvent(eventToSend);

			if (updatedCollect.getCollect().getTypes().stream().noneMatch(type -> type.isFamilyBlocked())) {

				jmsTemplate.convertAndSend(destination, xml, m -> setMessageProperties(updatedCollect, m));

				eventToSend.setStatus("SENT");
				eventRepository.saveEvent(eventToSend);

				AuditValue auditValue;

				if (CollectStatus.CL.name().equals(updatedCollect.getCollect().getStatus())) {
					auditValue = AuditValue.EVENT_CLOTURE;
				} else if (CollectStatus.AB.name().equals(updatedCollect.getCollect().getStatus())) {
					auditValue = AuditValue.EVENT_ABANDON;
				} else if (NomenclatureRefEvent.EVENT_UPDATE_COLLECT.getCode().equals(updatedCollect.getNomenclatureRef())) {
					auditValue = AuditValue.EVENT_UPDATE_FAMILY;
				} else {
					LOGGER.error("ERREUR - Invalid event code " + updatedCollect.getNomenclatureRef());
					auditValue = null;
				}
				final AuditEvent auditEvent = auditGenerator.newAudit(new Context(updatedCollect.getEmployeeId(), updatedCollect.getChannel(), updatedCollect.getMedia()), auditValue)
						// Event
						.setIdEvent(eventToSend.getId())
						// Collecte
						.setIdCollect(updatedCollect.getCollect().getId()).setJourneyCode(updatedCollect.getCollect().getJourneyCode());
				if (NomenclatureRefEvent.EVENT_UPDATE_COLLECT.getCode().equals(updatedCollect.getNomenclatureRef())) {
					updatedCollect.getFamiliesIds().stream().forEach(familyId -> {
						auditEvent.setIdFamily(familyId);
						sendAuditEvent(auditEvent);
					});
				} else {
					sendAuditEvent(auditEvent);
				}
			}

		} catch (final JmsException | DatatypeConfigurationException e) {

			// Audit
			AuditValue auditValue;

			if (CollectStatus.CL.name().equals(updatedCollect.getCollect().getStatus())) {
				auditValue = AuditValue.ERROR_EVENT_86;
			} else if (CollectStatus.AB.name().equals(updatedCollect.getCollect().getStatus())) {
				auditValue = AuditValue.ERROR_EVENT_87;
			} else if (NomenclatureRefEvent.EVENT_UPDATE_COLLECT.getCode().equals(updatedCollect.getNomenclatureRef())) {
				auditValue = AuditValue.ERROR_EVENT_83;
			} else {
				LOGGER.error("ERREUR - Invalid event code " + updatedCollect.getNomenclatureRef());
				auditValue = null;
			}
			final AuditEvent auditEvent = auditGenerator.newAudit(new Context(updatedCollect.getEmployeeId(), updatedCollect.getChannel(), updatedCollect.getMedia()), auditValue)
					// Collecte
					.setIdCollect(updatedCollect.getCollect().getId()).setJourneyCode(updatedCollect.getCollect().getJourneyCode());
			sendAuditEvent(auditEvent);
			updatedCollect.getCollect().getTypes().forEach(type -> familyRepository.updateBlocked(type.getFamilyId()));
			LOGGER.error(e.getMessage(), e);
		}

	}

	@Override
	@Async("auditTaskExecutor")
	public void sendAuditEvent(AuditEvent auditEvent) {
		final long start = System.currentTimeMillis();
		LoggerHelper.logForPerfTest(LOGGER,
				"Début de l'insertion dans audit_event " + auditEvent.getCodeEvent() + " pour le type " + auditEvent.getIdType() + " de la collect " + auditEvent.getIdCollect() + " (thread id " + Thread.currentThread().getId() + ")");

		// Audit
		final AuditEventEntity eventAuditEntity = new AuditEventEntity();

		eventAuditEntity.setCodeEvent(auditEvent.getCodeEvent());
		eventAuditEntity.setCollectId(Optional.ofNullable(auditEvent.getIdCollect()).orElse(UUID.fromString("00000000-0000-0000-0000-000000000000")).toString());
		eventAuditEntity.setEventId(Optional.ofNullable(auditEvent.getIdEvent()).map(o -> auditEvent.getIdEvent()).orElse(""));
		eventAuditEntity.setFamilyId(Optional.ofNullable(auditEvent.getIdFamily()).map(o -> auditEvent.getIdFamily().toString()).orElse(""));
		eventAuditEntity.setTypeId(Optional.ofNullable(auditEvent.getIdType()).map(o -> auditEvent.getIdType().toString()).orElse(""));
		eventAuditEntity.setCorrelationId(auditEvent.getCorrelationId());
		eventAuditEntity.setCodeAP(AuditEvent.CODE_AP);
		eventAuditEntity.setCodeAT(AuditEvent.CODE_AT);
		eventAuditEntity.setDateCreation(TimestampUtils.instantToTimestamp(auditEvent.getDateCreation()));
		eventAuditEntity.setMessage(auditEvent.getMessage());
		eventAuditEntity.setJourneyCode(auditEvent.getJourneyCode());
		eventAuditEntity.setChannel(auditEvent.getChannel());
		eventAuditEntity.setMedia(auditEvent.getMedia());
		eventAuditEntity.setCodeError(auditEvent.getCodeError());
		eventAuditEntity.setPieceId(Optional.ofNullable(auditEvent.getIdPiece()).map(o -> auditEvent.getIdPiece().toString()).orElse(""));
		eventAuditEntity.setUserId(auditEvent.getUserId());
		eventAuditEntity.setEdocType(auditEvent.getEdocType());
		eventAuditEntity.setTypeLabel(auditEvent.getTypeLabel());

		eventAuditEntity.setTotalCollect(auditEvent.getTotalCollect());
		eventAuditEntity.setTotalPieces(auditEvent.getTotalPieces());
		eventAuditEntity.setTotalIndex(auditEvent.getTotalIndex());
		eventAuditEntity.setTotalIndexCohe(auditEvent.getTotalIndexCohe());
		eventAuditEntity.setTotalIndexExtr(auditEvent.getTotalIndexExtr());
		eventAuditEntity.setTotalIndexCorr(auditEvent.getTotalIndexCorr());
		eventAuditEntity.setDurationLadRad(auditEvent.getDurationLadRad());
		eventAuditEntity.setDurationAMI(auditEvent.getDurationAmi());
		eventAuditEntity.setIterationLadRad(auditEvent.getIterationLadRad());
		eventAuditEntity.setControlRequired(auditEvent.getControlRequired());
		eventAuditEntity.setDocumentSet(auditEvent.getDocumentSet());
		eventAuditEntity.setVideoCodingDelay(auditEvent.getVideoCodingDelay());
		eventRepository.saveAuditEvent(eventAuditEntity);
		LoggerHelper.logForPerfTest(LOGGER, "Fin de l'insertion dans audit_event " + auditEvent.getCodeEvent() + " pour le type " + auditEvent.getIdType() + " de la collect " + auditEvent.getIdCollect() + " Temps " + (System.currentTimeMillis() - start)
				+ " ms" + " (thread id " + Thread.currentThread().getId() + ")");
	}

	@Override
	@Async("auditTaskExecutor")
	public void sendAuditEventAttachment(AuditEvent auditEvent) {
		// Audit
		final AuditEventEntity eventAuditEntity = new AuditEventEntity();

		eventAuditEntity.setCodeEvent(auditEvent.getCodeEvent());
		eventAuditEntity.setCorrelationId(auditEvent.getCorrelationId());
		eventAuditEntity.setCodeAP(auditEvent.getCodeAP());
		eventAuditEntity.setCodeAT(AuditEvent.CODE_AT);
		eventAuditEntity.setDateCreation(TimestampUtils.instantToTimestamp(auditEvent.getDateCreation()));
		eventAuditEntity.setMessage(auditEvent.getMessage());
		eventAuditEntity.setJourneyCode(auditEvent.getJourneyCode());
		eventAuditEntity.setChannel(auditEvent.getChannel());
		eventAuditEntity.setMedia(auditEvent.getMedia());
		eventAuditEntity.setCodeError(auditEvent.getCodeError());
		eventAuditEntity.setPieceId(Optional.ofNullable(auditEvent.getIdPiece()).map(o -> auditEvent.getIdPiece().toString()).orElse(""));
		eventAuditEntity.setUserId(auditEvent.getUserId());
		eventAuditEntity.setEdocType(auditEvent.getEdocType());
		eventAuditEntity.setTypeLabel(auditEvent.getTypeLabel());

		eventAuditEntity.setTotalCollect(auditEvent.getTotalCollect());
		eventAuditEntity.setTotalPieces(auditEvent.getTotalPieces());
		eventAuditEntity.setTotalIndex(auditEvent.getTotalIndex());
		eventAuditEntity.setTotalIndexCohe(auditEvent.getTotalIndexCohe());
		eventAuditEntity.setTotalIndexExtr(auditEvent.getTotalIndexExtr());
		eventAuditEntity.setTotalIndexCorr(auditEvent.getTotalIndexCorr());
		eventAuditEntity.setDurationLadRad(auditEvent.getDurationLadRad());
		eventAuditEntity.setDurationAMI(auditEvent.getDurationAmi());
		eventAuditEntity.setIterationLadRad(auditEvent.getIterationLadRad());
		eventAuditEntity.setControlRequired(auditEvent.getControlRequired());
		eventAuditEntity.setDocumentSet(auditEvent.getDocumentSet());
		eventAuditEntity.setVideoCodingDelay(auditEvent.getVideoCodingDelay());
		eventRepository.saveAuditEvent(eventAuditEntity);
	}

	@Override
	@Async("sendEventMQTaskExecutor")
	public void sendAutomaticControlEvent(UUID collectId, Context context, final Type type) {
		final long start = System.currentTimeMillis();
		LoggerHelper.logForPerfTest(LOGGER, "Début de l'envoi de l'event " + TypeReceivedType.AUTOMATTC_CONTROL.getLabel() + " " + type.getId() + " pour la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
		final Collect collect = collectRepository.findOne(collectId);
		final TypeReceived typeReceived = new TypeReceived();
		typeReceived.setPieces(type.getActivePieces());
		typeReceived.setChannel(context.getCanal());
		typeReceived.setMedia(context.getMedia());
		typeReceived.setUserId(context.getCustomerId());
		if (Optional.ofNullable(type.getParentId()).isPresent()) {
			typeReceived.setSubType(type);
			typeReceived.setType(collect.getTypes().stream().filter(t -> type.getParentId().equals(t.getId())).findAny().orElse(null));
		} else {
			typeReceived.setType(type);
		}
		typeReceived.setCollect(collect);
		typeReceived.setTypeReceivedType(TypeReceivedType.AUTOMATTC_CONTROL);
		sendTypeReceivedEvent(typeReceived);
		LoggerHelper.logForPerfTest(LOGGER, "Fin de l'envoi de l'event " + TypeReceivedType.AUTOMATTC_CONTROL.getLabel() + type.getId() + " " + " pour la collecte " + collectId + " Temps " + (System.currentTimeMillis() - start) + " ms" + " (thread id "
				+ Thread.currentThread().getId() + ")");
	}

	public void sendedAutomaticStatusEvent(UUID collectId, Context context, final Type type) {
		final long start = System.currentTimeMillis();
		LoggerHelper.logForPerfTest(LOGGER, "Début de l'envoi de l'event 00005000000000189 " + type.getId() + " pour la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
		final Collect collect = collectRepository.findOne(collectId);
		final TypeReceived typeReceived = new TypeReceived();
		typeReceived.setPieces(type.getActivePieces());
		typeReceived.setChannel(context.getCanal());
		typeReceived.setMedia(context.getMedia());
		typeReceived.setUserId(context.getCustomerId());
		if (Optional.ofNullable(type.getParentId()).isPresent()) {
			typeReceived.setSubType(type);
			typeReceived.setType(collect.getTypes().stream().filter(t -> type.getParentId().equals(t.getId())).findAny().orElse(null));
		} else {
			typeReceived.setType(type);
		}
		typeReceived.setCollect(collect);
		typeReceived.setTypeReceivedType(TypeReceivedType.SEND_TO_AMI);
		sendTypeReceivedEvent(typeReceived);
		LoggerHelper.logForPerfTest(LOGGER,
				"Fin de l'envoi de l'event 00005000000000189 " + type.getId() + " pour la collecte " + collectId + " Temps " + (System.currentTimeMillis() - start) + " ms" + " (thread id " + Thread.currentThread().getId() + ")");
	}

	public EdocTypeRepository getEdocTypeRepository() {
		return edocTypeRepository;
	}

	public void setEdocTypeRepository(EdocTypeRepository edocTypeRepository) {
		this.edocTypeRepository = edocTypeRepository;
	}

}