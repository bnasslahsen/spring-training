package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.entity.DocReferenceEntity;

@Repository
public interface DocReferenceJpaRepository extends JpaRepository<DocReferenceEntity, String> {

	@Query("select docRef from DocReferenceEntity docRef where id.ownerId = :owner and id.edocType in :edocTypes and docRef.referenceGdnId IS NOT NULL")
	List<DocReferenceEntity> byOwnersAndTypes(@Param("owner") String owner, @Param("edocTypes") List<String> edocTypes);

	@Query("select docRef from DocReferenceEntity docRef where id.ownerId = :owner and id.edocType = :edocType")
	List<DocReferenceEntity> byOwnersAndType(@Param("owner") String owner, @Param("edocType") String edocType);

	@Modifying
	@Query("delete from DocReferenceEntity where id.ownerId = :owner and id.edocType = :edocType")
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	void deleteByOwnerAndEdocType(@Param("owner") String owner, @Param("edocType") String edocType);

	@Query("select docRef from DocReferenceEntity docRef where id.edocType = :edocType")
	Set<DocReferenceEntity> getByEdocType(@Param("edocType") String edocType);

	@Query("select distinct(docRef) from DocReferenceEntity docRef, DocReferenceJourneyCode journeyCode where journeyCode.id.edocType = docRef.id.edocType and journeyCode.id.ownerId = docRef.id.ownerId and journeyCode.id.updateDate < :expirationDate and docRef.id.edocType in :edocTypes")
	List<DocReferenceEntity> getByRetentionTime(@Param("expirationDate") Timestamp expirationDate, @Param("edocTypes") List<String> edocTypes);

}
