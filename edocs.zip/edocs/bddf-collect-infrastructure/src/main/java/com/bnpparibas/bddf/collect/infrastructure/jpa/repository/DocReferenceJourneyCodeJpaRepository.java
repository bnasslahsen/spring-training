package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.entity.DocReferenceJourneyCode;

@Repository
public interface DocReferenceJourneyCodeJpaRepository extends JpaRepository<DocReferenceJourneyCode, String> {

	@Modifying
	@Transactional
	@Query("delete from DocReferenceJourneyCode where docReference.id.ownerId = :owner and docReference.id.edocType = :edocType")
	void deleteByOwnerAndEdocType(@Param("owner") String owner, @Param("edocType") String edocType);

}
