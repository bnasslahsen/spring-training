package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.util.HashMap;
import java.util.Map;

public enum BatchResult {
	OK("OK"), KO("KO");
	
	private String value;
	
	private BatchResult(String value) {
		this.value = value;
	}

	
	public String getValue() {
		return value;
	}
	
	public static Map<String, Long> defaultRes() {
		final Map<String, Long> map = new HashMap<>();
		map.put(OK.getValue(), 0l);
		map.put(KO.getValue(), 0l);
		return map;
	}

	public static Map<String, Long> groupMaps(Map<String, Long> m1, Map<String, Long> m2) {
		m1.put(OK.getValue(), m1.get(OK.getValue()) + m2.get(OK.getValue()));
		m1.put(KO.getValue(), m1.get(KO.getValue()) + m2.get(KO.getValue()));
		return m1;
	}
	
	public static void resOk(Map<String, Long> result) {
		result.put(OK.getValue(), result.get(OK.getValue()) + 1l);
	}

	public static void resKo(Map<String, Long> result) {
		result.put(KO.getValue(), result.get(KO.getValue()) + 1l);
	}
}
