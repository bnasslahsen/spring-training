package com.bnpparibas.bddf.collect.infrastructure.enums;

import java.util.Arrays;

public enum StatusSentToGdn {
	NOT_SENT("NOT_SENT"), IN_PROGRESS("IN_PROGRESS"), DONE("DONE"), TECH_ERROR("TECH_ERROR"), FUNC_ERROR("FUNC_ERROR");

	private final String code;

	private StatusSentToGdn(String code) {
		this.code = code;

	}

	public String getCode() {
		return this.code;
	}

	public static StatusSentToGdn fromValue(String code) {
		return Arrays.asList(values()).stream().filter(c -> c.getCode().equals(code)).findAny().orElse(null);
	}

}
