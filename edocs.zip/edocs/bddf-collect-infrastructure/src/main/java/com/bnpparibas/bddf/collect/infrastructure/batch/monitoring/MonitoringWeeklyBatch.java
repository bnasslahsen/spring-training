package com.bnpparibas.bddf.collect.infrastructure.batch.monitoring;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.entity.ViewMonitoringWeeklyEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.ViewMonitoringWeeklyJpaRepository;
import com.bnpparibas.bddf.email.BddfMailMessage;
import com.bnpparibas.bddf.email.MailService;

@Component
@Transactional(transactionManager = "transactionManagerDB")
public class MonitoringWeeklyBatch extends AbstractBatchMonitoring {

	private static final int INITIAL_BUILDER_SIZE = 64;
	private static final String TITRE = "DATE_EXTRACTION;CODE_PARCOURS;LIBELLE_PRODUIT;TYPE_EDOC;LIBELLE;NIVEAU_DE_CONTROLE;NB_TYPES_DEPOSES;NB_FICHIERS_DEPOSES;NB_FICHIERS_RECONNUS;RADLAD PREMIERE;VIDEOCODING;NB_INDEX_ATTENDUS;NB_INDEX_EXTR;NB_INDEX_OK;VA_AUTO_1;VA_AUTO_1_AMI;NB_INDEX_CORRIGE;NB_RECO_FORCE;VA_AUTO_2_AMI;RC_AUTO;NB_TYPES_REFUS;NB_TYPES_ACCEPTE;NB_TYPES_VALIDE;TYPE_ERR_LADRAD;TYPE_ERR_VIDEOCODING\n";
	private static final DateTimeFormatter FORMATTER_DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	private static final Logger LOG = LoggerFactory.getLogger(MonitoringWeeklyBatch.class);

	@Autowired
	private MailService mailService;
	@Autowired
	private Environment environment;
	@Autowired
	private ViewMonitoringWeeklyJpaRepository viewMonitoringWeeklyJpaRepository;

	public MonitoringWeeklyBatch() {
		super("COLLECT_MONITORING_WEEKLY");
	}

	@Scheduled(cron = "${monitoring.cron.weekly}")
	@Override
	public void scheduledStart() {
		startBatch();

	}

	@Override
	public void execute() {
		try {
			final List<ViewMonitoringWeeklyEntity> monitorings = viewMonitoringWeeklyJpaRepository.findAll();

			final StringBuilder sb = new StringBuilder(TITRE);
			monitorings.stream().forEach(l -> sb.append(l).append('\n'));
			final StringBuilder object = new StringBuilder(INITIAL_BUILDER_SIZE);
			object.append("E-DOC WEEKLY MONITORING ");
			object.append(FORMATTER_DATE.format(LocalDateTime.ofInstant(new Date().toInstant(), ZoneId.systemDefault())));
			object.append(" > EXTRACT - ");
			final String host = environment.getProperty("spring.cloud.client.hostname");
			final String hostParse = extractHost(host);
			object.append(hostParse);
			final BddfMailMessage mailMessage = new BddfMailMessage(environment.getProperty("monitoring.mail.sender"), new String[] { environment.getProperty("monitoring.mail.recipient") }, object.toString(), sb.toString(), false);
			mailService.sendMail(mailMessage);
		} catch (final Exception e) {
			LOG.error(e.getMessage(), e);
		}
	}

	public MailService getMailService() {
		return mailService;
	}

	public void setMailService(MailService mailService) {
		this.mailService = mailService;
	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

}
