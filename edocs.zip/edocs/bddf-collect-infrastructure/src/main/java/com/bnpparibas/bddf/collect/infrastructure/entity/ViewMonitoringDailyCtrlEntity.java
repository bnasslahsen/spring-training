package com.bnpparibas.bddf.collect.infrastructure.entity;
// Generated 8 juin 2018 10:15:05 by Hibernate Tools 4.3.2-SNAPSHOT

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Immutable
@Table(name = "VIEW_MONITORING_DAILY_CTL")
public class ViewMonitoringDailyCtrlEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String idTech;
	private String edocType;
	private String typeLabel;
	private Integer nbTypes;
	private Double pieceAverage;
	private Double recognitionRate;
	private Double extractionRate;
	private Double coherenceRate;
	private Double durationLadRad;
	private Integer nbVaAuto;
	private Integer nbRcAuto;
	private Integer nbErr;

	@Id
	@Column(name = "ID_TECH")
	public String getIdTech() {
		return this.idTech;
	}

	public void setIdTech(String idTech) {
		this.idTech = idTech;
	}

	@Column(name = "EDOC_TYPE")
	public String getEdocType() {
		return this.edocType;
	}

	public void setEdocType(String edocType) {
		this.edocType = edocType;
	}

	@Column(name = "TYPE_LABEL")
	public String getTypeLabel() {
		return this.typeLabel;
	}

	public void setTypeLabel(String typeLabel) {
		this.typeLabel = typeLabel;
	}

	@Column(name = "NB_TYPES")
	public Integer getNbTypes() {
		return nbTypes;
	}

	public void setNbTypes(Integer nbTypes) {
		this.nbTypes = nbTypes;
	}

	@Column(name = "PIECE_AVERAGE")
	public Double getPieceAverage() {
		return pieceAverage;
	}

	public void setPieceAverage(Double pieceAverage) {
		this.pieceAverage = pieceAverage;
	}

	@Column(name = "RECOGNITION_RATE")
	public Double getRecognitionRate() {
		return recognitionRate;
	}

	public void setRecognitionRate(Double recognitionRate) {
		this.recognitionRate = recognitionRate;
	}

	@Column(name = "EXTRACTION_RATE")
	public Double getExtractionRate() {
		return extractionRate;
	}

	public void setExtractionRate(Double extractionRate) {
		this.extractionRate = extractionRate;
	}

	@Column(name = "COHERENCE_RATE")
	public Double getCoherenceRate() {
		return coherenceRate;
	}

	public void setCoherenceRate(Double coherenceRate) {
		this.coherenceRate = coherenceRate;
	}

	@Column(name = "DURATION_LAD_RAD")
	public Double getDurationLadRad() {
		return durationLadRad;
	}

	public void setDurationLadRad(Double durationLadRad) {
		this.durationLadRad = durationLadRad;
	}

	@Column(name = "NB_VA_AUTO")
	public Integer getNbVaAuto() {
		return nbVaAuto;
	}

	public void setNbVaAuto(Integer nbVaAuto) {
		this.nbVaAuto = nbVaAuto;
	}

	@Column(name = "NB_RC_AUTO")
	public Integer getNbRcAuto() {
		return nbRcAuto;
	}

	public void setNbRcAuto(Integer nbRcAuto) {
		this.nbRcAuto = nbRcAuto;
	}

	@Column(name = "NB_ERR")
	public Integer getNbErr() {
		return nbErr;
	}

	public void setNbErr(Integer nbErr) {
		this.nbErr = nbErr;
	}

	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append(edocType);
		builder.append(";");
		builder.append(typeLabel);
		builder.append(";");
		builder.append(nbTypes);
		builder.append(";");
		builder.append(pieceAverage);
		builder.append(";");
		builder.append(recognitionRate);
		builder.append(";");
		builder.append(extractionRate);
		builder.append(";");
		builder.append(coherenceRate);
		builder.append(";");
		builder.append(durationLadRad);
		builder.append(";");
		builder.append(nbVaAuto);
		builder.append(";");
		builder.append(nbRcAuto);
		builder.append(";");
		builder.append(nbErr);
		return builder.toString();
	}

}
