package com.bnpparibas.bddf.collect.infrastructure.ami.mocking;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

import com.bnpparibas.bddf.collect.domain.type.LadRadRepository;

@Profile("amiMock")
@Configuration
public class AmiMockConfiguration {
	@Bean
	@Primary
	public LadRadRepository mockAmiLadRadRepository() {
		return new AmiTestImpl();
	}
}
