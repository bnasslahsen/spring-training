package com.bnpparibas.bddf.collect.infrastructure.entity;
// Generated 8 juin 2018 10:15:05 by Hibernate Tools 4.3.2-SNAPSHOT

import java.sql.Timestamp;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "audit_event")
public class AuditEventEntity implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String idTech;
	private Timestamp dateCreation;
	private String correlationId;
	private String codeEvent;
	private String message;
	private String media;
	private String channel;
	private String userId;
	private String journeyCode;
	private String collectId;
	private String familyId;
	private String typeId;
	private String pieceId;
	private String eventId;
	private String codeError;
	private String edocType;
	private String typeLabel;
	private String codeAP;
	private String codeAT;

	private Integer totalCollect;
	private Integer totalPieces;
	private Integer totalIndex;
	private Integer totalIndexCohe;
	private Integer totalIndexExtr;
	private Integer totalIndexCorr;
	private Integer controlRequired;
	private Integer durationLadRad;
	private Integer durationAMI;
	private Integer iterationLadRad;
	private String documentSet;
	private String videoCodingDelay;

	public AuditEventEntity() {
	}

	public AuditEventEntity(String idTech, Timestamp dateCreation) {
		this.idTech = idTech;
		this.dateCreation = Optional.ofNullable(dateCreation).map(d -> (Timestamp) d.clone()).orElse(null);

	}

	@Id
	@Column(name = "ID_TECH", unique = true, nullable = false, length = 100)
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	public String getIdTech() {
		return this.idTech;
	}

	public void setIdTech(String idTech) {
		this.idTech = idTech;
	}

	@Column(name = "DATE_CREATION", nullable = false)
	public Timestamp getDateCreation() {
		return Optional.ofNullable(this.dateCreation).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setDateCreation(Timestamp dateCreation) {
		this.dateCreation = Optional.ofNullable(dateCreation).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Column(name = "CORRELATION_ID", length = 100)
	public String getCorrelationId() {
		return this.correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	@Column(name = "CODE_EVENT", length = 50)
	public String getCodeEvent() {
		return this.codeEvent;
	}

	public void setCodeEvent(String codeEvent) {
		this.codeEvent = codeEvent;
	}

	@Column(name = "MESSAGE", length = 200)
	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Column(name = "CHANNEL", length = 3)
	public String getChannel() {
		return this.channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	@Column(name = "MEDIA", length = 3)
	public String getMedia() {
		return this.media;
	}

	public void setMedia(String media) {
		this.media = media;
	}

	@Column(name = "USER_ID", length = 17)
	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Column(name = "JOURNEY_CODE", length = 6)
	public String getJourneyCode() {
		return this.journeyCode;
	}

	public void setJourneyCode(String journeyCode) {
		this.journeyCode = journeyCode;
	}

	@Column(name = "COLLECT_ID", length = 200)
	public String getCollectId() {
		return this.collectId;
	}

	public void setCollectId(String collectId) {
		this.collectId = collectId;
	}

	@Column(name = "FAMILY_ID", length = 200)
	public String getFamilyId() {
		return this.familyId;
	}

	public void setFamilyId(String familyId) {
		this.familyId = familyId;
	}

	@Column(name = "TYPE_ID", length = 200)
	public String getTypeId() {
		return this.typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	@Column(name = "PIECE_ID", length = 200)
	public String getPieceId() {
		return this.pieceId;
	}

	public void setPieceId(String pieceId) {
		this.pieceId = pieceId;
	}

	@Column(name = "EVENT_ID", length = 200)
	public String getEventId() {
		return this.eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	@Column(name = "CODE_ERROR", length = 50)
	public String getCodeError() {
		return this.codeError;
	}

	public void setCodeError(String codeError) {
		this.codeError = codeError;
	}

	@Column(name = "EDOC_TYPE", length = 17)
	public String getEdocType() {
		return this.edocType;
	}

	public void setEdocType(String edocType) {
		this.edocType = edocType;
	}

	@Column(name = "TYPE_LABEL", length = 200)
	public String getTypeLabel() {
		return this.typeLabel;
	}

	public void setTypeLabel(String typeLabel) {
		this.typeLabel = typeLabel;
	}

	@Column(name = "CODE_AP", length = 200)
	public String getCodeAP() {
		return codeAP;
	}

	public void setCodeAP(String codeAP) {
		this.codeAP = codeAP;
	}

	@Column(name = "CODE_AT", length = 200)
	public String getCodeAT() {
		return codeAT;
	}

	public void setCodeAT(String codeAT) {
		this.codeAT = codeAT;
	}

	@Column(name = "TOTAL_COLLECT")
	public Integer getTotalCollect() {
		return totalCollect;
	}

	public void setTotalCollect(Integer totalCollect) {
		this.totalCollect = totalCollect;
	}

	@Column(name = "TOTAL_PIECES")
	public Integer getTotalPieces() {
		return totalPieces;
	}

	public void setTotalPieces(Integer totalPieces) {
		this.totalPieces = totalPieces;
	}

	@Column(name = "TOTAL_INDEX")
	public Integer getTotalIndex() {
		return totalIndex;
	}

	public void setTotalIndex(Integer totalIndex) {
		this.totalIndex = totalIndex;
	}

	@Column(name = "CONTROL_REQUIRED")
	public Integer getControlRequired() {
		return controlRequired;
	}

	public void setControlRequired(Integer controlRequired) {
		this.controlRequired = controlRequired;
	}

	@Column(name = "DURATION_LAD_RAD")
	public Integer getDurationLadRad() {
		return durationLadRad;
	}

	public void setDurationLadRad(Integer durationLadRad) {
		this.durationLadRad = durationLadRad;
	}

	@Column(name = "ITERATION_LAD_RAD")
	public Integer getIterationLadRad() {
		return iterationLadRad;
	}

	public void setIterationLadRad(Integer iterationLadRad) {
		this.iterationLadRad = iterationLadRad;
	}

	@Column(name = "DOCUMENT_SET_LAD_RAD")
	public String getDocumentSet() {
		return documentSet;
	}

	public void setDocumentSet(String documentSet) {
		this.documentSet = documentSet;
	}

	@Column(name = "TOTAL_INDEX_COHE")
	public Integer getTotalIndexCohe() {
		return totalIndexCohe;
	}

	public void setTotalIndexCohe(Integer totalIndexCohe) {
		this.totalIndexCohe = totalIndexCohe;
	}

	@Column(name = "TOTAL_INDEX_EXTR")
	public Integer getTotalIndexExtr() {
		return totalIndexExtr;
	}

	public void setTotalIndexExtr(Integer totalIndexExtr) {
		this.totalIndexExtr = totalIndexExtr;
	}

	@Column(name = "TOTAL_INDEX_CORR")
	public Integer getTotalIndexCorr() {
		return totalIndexCorr;
	}

	public void setTotalIndexCorr(Integer totalIndexCorr) {
		this.totalIndexCorr = totalIndexCorr;
	}

	@Column(name = "VIDEOCODING_DELAYS", length = 50)
	public String getVideoCodingDelay() {
		return videoCodingDelay;
	}

	public void setVideoCodingDelay(String videoCodingDelay) {
		this.videoCodingDelay = videoCodingDelay;
	}

	@Column(name = "DURATION_AMI")
	public Integer getDurationAMI() {
		return durationAMI;
	}

	public void setDurationAMI(Integer durationAMI) {
		this.durationAMI = durationAMI;
	}

}
