package com.bnpparibas.bddf.collect.infrastructure.jpa.mapper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.dozer.Mapper;
import org.springframework.stereotype.Component;

import com.bnp.schema.edoc.index.Indexes.EdocIndex;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.index.IndexeJmc;
import com.bnpparibas.bddf.collect.infrastructure.entity.IndexeEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.IndexePiece;
import com.bnpparibas.bddf.collect.infrastructure.entity.IndexePieceId;

@Component
public class IndexeMapper {

	private final Mapper dozerMapper;

	public IndexeMapper(Mapper dozerMapper) {
		this.dozerMapper = dozerMapper;
	}

	public Set<Indexe> toIndexes(Set<IndexeEntity> indexeEntities, List<EdocIndex> edocIndexes) {
		final HashSet<Indexe> indexes = new HashSet<>();
		indexeEntities.forEach(indexeEntity -> {
			final Indexe indexe = toIndexe(indexeEntity);
			indexe.setIndexesJmc(new ArrayList<IndexeJmc>());
			indexeEntity.getIndexePieces().forEach(indexePiece -> {
				if (StringUtils.isNotEmpty(indexePiece.getStatusControl())) {
					final IndexeJmc indexeJmc = new IndexeJmc();
					indexeJmc.setAcceptancePercentage(indexePiece.getAcceptancePercentage() != null ? indexePiece.getAcceptancePercentage() : 0);
					indexeJmc.setControlCode(indexePiece.getId().getControlCode());
					indexeJmc.setExtractedValue(indexePiece.getExtractedValue());
					indexeJmc.setIdPieceJmc(indexePiece.getId().getIdPieceJmc());
					indexeJmc.setStatusControl(indexePiece.getStatusControl());
					indexeJmc.setIdPiece(UUID.fromString(indexePiece.getId().getPieceId()));
					indexe.getIndexesJmc().add(indexeJmc);
				}
			});
			indexe.setMinSize(edocIndexes.stream().filter(edocI -> edocI.getCode().equals(indexeEntity.getCode())).findAny().get().getMinSize());
			indexe.setMaxSize(edocIndexes.stream().filter(edocI -> edocI.getCode().equals(indexeEntity.getCode())).findAny().get().getMaxSize());
			indexes.add(indexe);
		});
		return indexes;
	}

	public Indexe toIndexe(IndexeEntity indexeEntity) {
		return dozerMapper.map(indexeEntity, Indexe.class);
	}

	public Set<IndexeEntity> toIndexeEntities(Set<Indexe> indexes, boolean isNew) {
		final HashSet<IndexeEntity> indexeEntities = new HashSet<>();
		indexes.forEach(indexe -> {
			final IndexeEntity indexeEntity = toIndexeEntity(indexe, isNew);
			indexeEntity.setIndexePieces(new HashSet<IndexePiece>());
			indexe.getIndexesJmc().forEach(indexJmc -> {
				if (StringUtils.isNotEmpty(indexJmc.getStatusControl())) {
					final IndexePiece indexePiece = new IndexePiece();
					indexePiece.setAcceptancePercentage(indexJmc.getAcceptancePercentage());
					indexePiece.setExtractedValue(indexJmc.getExtractedValue());
					indexePiece.setId(new IndexePieceId(indexe.getId().toString(), indexJmc.getIdPiece().toString(), indexJmc.getIdPieceJmc(), indexJmc.getControlCode()));
					indexePiece.setIndexe(indexeEntity);
					indexePiece.setStatusControl(indexJmc.getStatusControl());
					indexePiece.setNew(isNew);
					indexeEntity.getIndexePieces().add(indexePiece);
				}
			});
			indexeEntities.add(indexeEntity);
		});
		return indexeEntities;

	}

	private IndexeEntity toIndexeEntity(Indexe indexe, boolean isNew) {
		final IndexeEntity indexeEntity = dozerMapper.map(indexe, IndexeEntity.class);
		indexeEntity.setNew(isNew);
		return indexeEntity;
	}

}
