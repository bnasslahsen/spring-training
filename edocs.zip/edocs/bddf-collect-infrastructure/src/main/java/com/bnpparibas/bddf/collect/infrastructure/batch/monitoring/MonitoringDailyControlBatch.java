package com.bnpparibas.bddf.collect.infrastructure.batch.monitoring;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.bnpparibas.bddf.collect.infrastructure.entity.ViewMonitoringDailyCtrlEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.ViewMonitoringDailyJpaRepository;
import com.bnpparibas.bddf.email.BddfMailMessage;
import com.bnpparibas.bddf.email.MailService;

@Component
@Transactional(transactionManager = "transactionManagerDB")
public class MonitoringDailyControlBatch extends AbstractBatchMonitoring {

	private static final int NB_ERR_SIZE = 3;
	private static final int DURATION_SIZE = 6;
	private static final int NB_STATUS_SIZE = 7;
	private static final int RATE_SIZE = 5;
	private static final int PIECE_AVERAGE_SIZE = 10;
	private static final int NB_TYPES_SIZE = 8;
	private static final int TYPE_LABEL_SIZE = 50;
	private static final int EDOC_TYPE_SIZE = 17;
	private static final int INIT_BUILDER_SIZE = 64;
	private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
	private static final Logger LOG = LoggerFactory.getLogger(MonitoringDailyControlBatch.class);

	@Autowired
	private MailService mailService;
	@Autowired
	private Environment environment;
	@Autowired
	private ViewMonitoringDailyJpaRepository viewMonitoringDailyJpaRepository;
	@Autowired
	private TemplateEngine emailTemplateEngine;

	public MonitoringDailyControlBatch() {
		super("COLLECT_DAILY_AUTOMATIC_CONTROL");
	}

	public ViewMonitoringDailyJpaRepository getViewMonitoringDailyJpaRepository() {
		return viewMonitoringDailyJpaRepository;
	}

	public void setViewMonitoringDailyJpaRepository(ViewMonitoringDailyJpaRepository viewMonitoringDailyJpaRepository) {
		this.viewMonitoringDailyJpaRepository = viewMonitoringDailyJpaRepository;
	}

	@Scheduled(cron = "${monitoring.cron.automaticcontrol.daily}")
	@Override
	public void scheduledStart() {
		startBatch();
	}

	@Override
	public void execute() {
		try {
			final List<ViewMonitoringDailyCtrlEntity> monitorings = viewMonitoringDailyJpaRepository.findAll();

			final String mailContent = toMailContent(monitorings);
			final StringBuilder mailObject = new StringBuilder(INIT_BUILDER_SIZE);
			mailObject.append("E-DOC DAILY CTRL MONITORING - ");
			mailObject.append(DATE_FORMATTER.format(LocalDateTime.ofInstant(new Date().toInstant(), ZoneId.systemDefault())));
			final String host = environment.getProperty("spring.cloud.client.hostname");
			final String hostParse = extractHost(host);
			mailObject.append(hostParse);
			final BddfMailMessage mailMessage = new BddfMailMessage(environment.getProperty("monitoring.mail.sender"), new String[] { environment.getProperty("monitoring.mail.recipient") }, mailObject.toString(), mailContent, true);
			mailService.sendMail(mailMessage);
		} catch (final Exception e) {
			LOG.error(e.getMessage(), e);
		}
	}

	private String toMailContent(List<ViewMonitoringDailyCtrlEntity> monitorings) {
		final List<LineDailyControl> lines = new ArrayList<>();
		final Context context = new Context();
		monitorings.stream().filter(view -> view.getNbTypes() > 0).forEach(currentMonitoring -> {
			lines.add(fillMailLine(currentMonitoring));
		});
		context.setVariable("lines", lines);
		return emailTemplateEngine.process("dailyControl.html", context);
	}

	private LineDailyControl fillMailLine(ViewMonitoringDailyCtrlEntity currentMonitoring) {
		final LineDailyControl currentLine = new LineDailyControl();
		currentLine.setEdocType(currentMonitoring.getEdocType());
		currentLine.setParcours(currentMonitoring.getTypeLabel());
		currentLine.setTypeTot(String.valueOf(currentMonitoring.getNbTypes()));
		currentLine.setPieceAver(String.valueOf(currentMonitoring.getPieceAverage()));
		currentLine.setReco(String.valueOf(currentMonitoring.getRecognitionRate()));
		currentLine.setExtr(String.valueOf(currentMonitoring.getExtractionRate()));
		currentLine.setCohe(String.valueOf(currentMonitoring.getCoherenceRate()));
		currentLine.setLadRad(String.valueOf(currentMonitoring.getDurationLadRad()));
		currentLine.setVaAuto(String.valueOf(currentMonitoring.getNbVaAuto()));
		currentLine.setRcAuto(String.valueOf(currentMonitoring.getNbRcAuto()));
		currentLine.setErr(String.valueOf(currentMonitoring.getNbErr()));

		return currentLine;
	}

	public MailService getMailService() {
		return mailService;
	}

	public void setMailService(MailService mailService) {
		this.mailService = mailService;
	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

}
