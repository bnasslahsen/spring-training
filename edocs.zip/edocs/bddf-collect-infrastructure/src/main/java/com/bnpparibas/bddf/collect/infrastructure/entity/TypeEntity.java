package com.bnpparibas.bddf.collect.infrastructure.entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.domain.Persistable;

@Entity
@Table(name = "type")
public class TypeEntity implements java.io.Serializable, Persistable<String> {

	private static final long serialVersionUID = 1L;
	private String id;
	private FamilyEntity family;
	private String parentId;
	private String label;
	private String additionalInformation;
	private Boolean displayToClient;
	private Boolean digitalAllowed;
	private Boolean paperAllowed;
	private Integer controlRequired;
	private Integer maxSizeDoc;
	private Date controlDate;
	private Boolean pendingDocument;
	private String pendingDocumentLabel;
	private String edocType;
	private String status;
	private Boolean enableReuse;
	private String completeness;
	private String statusControl;
	private String completenessControl;
	private String completenessControlLabel;
	private Integer position;
	private Set<IndexeEntity> indexes = new HashSet<IndexeEntity>(0);
	private Set<PieceEntity> pieces = new HashSet<PieceEntity>(0);
	private String collectId;
	private String videoCodingDelays;
	private String pendingDocumentProfile;
	private Boolean displayCommentToClient;
	private boolean isNew;
	private String additionalInformationCollab;

	public TypeEntity() {
	}

	public TypeEntity(String id) {
		this.id = id;
	}

	public TypeEntity(String id, FamilyEntity family) {
		this.id = id;
		this.family = family;
	}

	@Override
	@Id
	@Column(name = "ID", unique = true, nullable = false, length = 100)
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FAMILY_ID", nullable = false)
	public FamilyEntity getFamily() {
		return this.family;
	}

	public void setFamily(FamilyEntity family) {
		this.family = family;
	}

	@Column(name = "PARENT_ID", length = 100)
	public String getParentId() {
		return this.parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	@Column(name = "LABEL", length = 200)
	public String getLabel() {
		return this.label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	@Column(name = "ADDITIONAL_INFORMATION", length = 200)
	public String getAdditionalInformation() {
		return this.additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public Boolean getDigitalAllowed() {
		return this.digitalAllowed;
	}

	@Column(name = "ADDITIONAL_INFORMATION_COLLAB", length = 200)
	public String getAdditionalInformationCollab() {
		return additionalInformationCollab;
	}

	public void setAdditionalInformationCollab(String additionalInformationCollab) {
		this.additionalInformationCollab = additionalInformationCollab;
	}

	public void setDigitalAllowed(Boolean digitalAllowed) {
		this.digitalAllowed = digitalAllowed;
	}

	@Column(name = "CONTROL_REQUIRED", precision = 1, scale = 0)
	public Integer getControlRequired() {
		return this.controlRequired;
	}

	public void setControlRequired(Integer controlRequired) {
		this.controlRequired = controlRequired;
	}

	@Column(name = "MAX_SIZE_DOC", precision = 22, scale = 0)
	public Integer getMaxSizeDoc() {
		return this.maxSizeDoc;
	}

	public void setMaxSizeDoc(Integer maxSizeDoc) {
		this.maxSizeDoc = maxSizeDoc;
	}

	@Column(name = "CONTROL_DATE")
	public Date getControlDate() {
		return Optional.ofNullable(this.controlDate).map(d -> (Date) d.clone()).orElse(null);
	}

	public void setControlDate(Date controlDate) {
		this.controlDate = Optional.ofNullable(controlDate).map(d -> (Date) d.clone()).orElse(null);
	}

	@Column(name = "PENDING_DOCUMENT", precision = 1, scale = 0)
	public Boolean getPendingDocument() {
		return this.pendingDocument;
	}

	public void setPendingDocument(Boolean pendingDocument) {
		this.pendingDocument = pendingDocument;
	}

	@Column(name = "PENDING_DOCUMENT_LABEL", length = 200)
	public String getPendingDocumentLabel() {
		return this.pendingDocumentLabel;
	}

	public void setPendingDocumentLabel(String pendingDocumentLabel) {
		this.pendingDocumentLabel = pendingDocumentLabel;
	}

	@Column(name = "EDOC_TYPE", length = 45)
	public String getEdocType() {
		return this.edocType;
	}

	public void setEdocType(String edocType) {
		this.edocType = edocType;
	}

	@Column(name = "STATUS", length = 3)
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "ENABLE_REUSE", precision = 22, scale = 0)
	public Boolean getEnableReuse() {
		return this.enableReuse;
	}

	public void setEnableReuse(Boolean enableReuse) {
		this.enableReuse = enableReuse;
	}

	@Column(name = "COMPLETENESS", length = 200)
	public String getCompleteness() {
		return this.completeness;
	}

	public void setCompleteness(String completeness) {
		this.completeness = completeness;
	}

	@Column(name = "STATUS_CONTROL", length = 45)
	public String getStatusControl() {
		return this.statusControl;
	}

	public void setStatusControl(String statusControl) {
		this.statusControl = statusControl;
	}

	@Column(name = "COMPLETENESS_CONTROL", length = 200)
	public String getCompletenessControl() {
		return this.completenessControl;
	}

	public void setCompletenessControl(String completenessControl) {
		this.completenessControl = completenessControl;
	}

	@Column(name = "COMPLETENESS_CONTROL_LABEL", length = 200)
	public String getCompletenessControlLabel() {
		return this.completenessControlLabel;
	}

	public void setCompletenessControlLabel(String completenessControlLabel) {
		this.completenessControlLabel = completenessControlLabel;
	}

	@Column(name = "POSITION", precision = 22, scale = 0)
	public Integer getPosition() {
		return this.position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	@OneToMany(fetch = FetchType.EAGER, orphanRemoval = true, cascade = { CascadeType.ALL }, mappedBy = "type")
	public Set<IndexeEntity> getIndexes() {
		return this.indexes;
	}

	public void setIndexes(Set<IndexeEntity> indexes) {
		this.indexes = indexes;
	}

	@OneToMany(fetch = FetchType.EAGER, orphanRemoval = true, cascade = { CascadeType.ALL }, mappedBy = "type")
	public Set<PieceEntity> getPieces() {
		return this.pieces;
	}

	public void setPieces(Set<PieceEntity> pieces) {
		this.pieces = pieces;
	}

	@Column(name = "COLLECT_ID", length = 100)
	public String getCollectId() {
		return collectId;
	}

	public void setCollectId(String collectId) {
		this.collectId = collectId;
	}

	@Column(name = "VIDEOCODING_DELAYS", length = 50)
	public String getVideoCodingDelays() {
		return videoCodingDelays;
	}

	public void setVideoCodingDelays(String videoCodingDelays) {
		this.videoCodingDelays = videoCodingDelays;
	}

	public Boolean getPaperAllowed() {
		return paperAllowed;
	}

	public void setPaperAllowed(Boolean paperAllowed) {
		this.paperAllowed = paperAllowed;
	}

	public Boolean getDisplayToClient() {
		return displayToClient;
	}

	public void setDisplayToClient(Boolean displayToClient) {
		this.displayToClient = displayToClient;
	}

	@Override
	@Transient
	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	@Column(name = "PENDING_DOCUMENT_PROFILE", length = 2)
	public String getPendingDocumentProfile() {
		return pendingDocumentProfile;
	}

	public void setPendingDocumentProfile(String pendingDocumentProfile) {
		this.pendingDocumentProfile = pendingDocumentProfile;
	}

	@Column(name = "DISPLAY_COMMENT_CLIENT", precision = 1, scale = 0)
	public Boolean getDisplayCommentToClient() {
		return displayCommentToClient;
	}

	public void setDisplayCommentToClient(Boolean displayCommentToClient) {
		this.displayCommentToClient = displayCommentToClient;
	}

}
