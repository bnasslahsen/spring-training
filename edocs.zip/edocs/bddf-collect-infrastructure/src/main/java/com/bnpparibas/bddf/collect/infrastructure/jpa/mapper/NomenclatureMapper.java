package com.bnpparibas.bddf.collect.infrastructure.jpa.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.nomenclature.Nomenclature;
import com.bnpparibas.bddf.collect.infrastructure.entity.NomenclatureEntity;

@Component
public class NomenclatureMapper {

	public List<Nomenclature> toNomenclatureList(List<NomenclatureEntity> nomenclatureEntities) {
		List<Nomenclature> nomenclatures = new ArrayList<>();
		nomenclatureEntities.forEach(nomenclatureEntity -> {
			nomenclatures.add(toNomenclature(nomenclatureEntity));
		});
		return nomenclatures;
	}

	private Nomenclature toNomenclature(NomenclatureEntity nomenclatureEntity) {
		Nomenclature nomenclature = new Nomenclature();
		nomenclature.setCode(nomenclatureEntity.getId().getCode());
		nomenclature.setEdoc(nomenclatureEntity.getId().getId());
		nomenclature.setJmc(nomenclatureEntity.getJmc());
		nomenclature.setLabel(nomenclatureEntity.getLabel());
		return nomenclature;
	}

}
