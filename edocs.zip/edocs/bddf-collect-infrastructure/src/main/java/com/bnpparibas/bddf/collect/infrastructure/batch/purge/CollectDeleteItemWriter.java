package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.CollectJpaRepository;

@Component
public class CollectDeleteItemWriter implements ItemWriter<String> {
	
	@Autowired
	private CollectJpaRepository collectJpaRepository;

	@Override
	public void write(List<? extends String> collectIds) throws Exception {
		collectIds.stream().forEach(collectId -> collectJpaRepository.deleteById(collectId));
	}

}
