package com.bnpparibas.bddf.collect.infrastructure.entity;

import java.sql.Timestamp;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.domain.Persistable;

@Entity
@Table(name = "CLIENT_NOTIFICATION")
public class ClientNotificationEntity implements java.io.Serializable, Persistable<String> {

	private static final long serialVersionUID = 1L;
	private String typeId;
	private String collectId;
	private Timestamp creationDate;
	private Timestamp lastNotificationDate;
	private Integer notificationNumber;
	private boolean isNew;

	public ClientNotificationEntity() {
	}

	public ClientNotificationEntity(String typeId, Timestamp creationDate) {
		this.typeId = typeId;
		this.creationDate = Optional.ofNullable(creationDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Id
	@Column(name = "TYPE_ID", length = 20)
	public String getTypeId() {
		return this.typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	@Column(name = "CREATION_DATE")
	public Timestamp getCreationDate() {
		return Optional.ofNullable(this.creationDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = Optional.ofNullable(creationDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Column(name = "LAST_NOTIFICATION_DATE")
	public Timestamp getLastNotificationDate() {
		return Optional.ofNullable(this.lastNotificationDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setLastNotificationDate(Timestamp lastNotificationDate) {
		this.lastNotificationDate = Optional.ofNullable(lastNotificationDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Column(name = "NOTIFICATION_NUMBER", precision = 22, scale = 0)
	public Integer getNotificationNumber() {
		return this.notificationNumber;
	}

	public void setNotificationNumber(Integer notificationNumber) {
		this.notificationNumber = notificationNumber;
	}

	@Override
	@Transient
	public String getId() {
		return typeId;
	}

	@Override
	@Transient
	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	@Column(name = "COLLECT_ID", length = 20, nullable=false)
	public String getCollectId() {
		return collectId;
	}

	public void setCollectId(String collectId) {
		this.collectId = collectId;
	}

}
