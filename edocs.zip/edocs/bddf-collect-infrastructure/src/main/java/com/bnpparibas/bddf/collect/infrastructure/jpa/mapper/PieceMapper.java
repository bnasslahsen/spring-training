package com.bnpparibas.bddf.collect.infrastructure.jpa.mapper;

import java.util.Arrays;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.dozer.Mapper;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.infrastructure.entity.PieceEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.TypeEntity;

@Component
public class PieceMapper {

	private final Mapper dozerMapper;

	public PieceMapper(Mapper dozerMapper) {
		this.dozerMapper = dozerMapper;

	}

	public Piece pieceEntityToPiece(PieceEntity pieceEntity, boolean keepInactive) {
		if (pieceEntity == null) {
			return null;
		}
		final Piece piece = dozerMapper.map(pieceEntity, Piece.class);
		piece.setId(UUID.fromString(Optional.ofNullable(pieceEntity).map(PieceEntity::getId).orElse("")));
		Optional.of(pieceEntity.getDeletedNas()).ifPresent(deleteNas -> piece.setDeletedNas(deleteNas));
		if (StringUtils.isNotEmpty(pieceEntity.getListTypesJmc())) {
			piece.setTypesJmc(Arrays.asList(pieceEntity.getListTypesJmc().split(",")));
		}
		if (keepInactive || PieceStates.ACTIF.getLabel().equals(piece.getState())) {
			return piece;
		} else {
			return null;
		}

	}

	public Piece pieceEntityToPiece(PieceEntity pieceEntity) {
		return pieceEntityToPiece(pieceEntity, false);
	}

	public Piece pieceEntityToPieceAndIsInactive(PieceEntity pieceEntity) {
		return pieceEntityToPiece(pieceEntity, true);
	}

	public PieceEntity pieceToPieceEntity(Piece piece, TypeEntity typeEntity, boolean isNew) {
		final PieceEntity pieceEntity = dozerMapper.map(piece, PieceEntity.class);
		pieceEntity.setId(piece.getId().toString());
		pieceEntity.setType(typeEntity);
		pieceEntity.setDeletedNas(piece.isDeletedNas());
		pieceEntity.setNew(isNew);
		if (CollectionUtils.isNotEmpty(piece.getTypesJmc())) {
			pieceEntity.setListTypesJmc(String.join(",", piece.getTypesJmc()));
		}
		if (PieceStatus.DF.getLabel().equals(piece.getStatus())) {
			pieceEntity.setStatusSentToGdn("NOT_SENT");
		}
		return pieceEntity;
	}

}
