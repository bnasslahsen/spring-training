package com.bnpparibas.bddf.collect.infrastructure.batch.monitoring;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.batch.distributed.AbstractBatch;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.TimestampUtils;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.AuditEventJpaRepository;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.MonitoringJmcJpaRepository;

@Component
@Transactional(transactionManager = "transactionManagerDB")
public class CollectPurgeTrack extends AbstractBatch {

	@Autowired
	private AuditEventJpaRepository auditEventJpaRepository;

	@Autowired
	private MonitoringJmcJpaRepository monitoringJmcJpaRepository;

	@Autowired
	private Environment environment;

	private static final Logger LOG = LoggerFactory.getLogger(CollectPurgeTrack.class);

	public CollectPurgeTrack() {
		super("COLLECT_PURGE_TRACK");
	}

	@Scheduled(cron = "${purge.monitoring.cron}")
	@Override
	public void scheduledStart() {
		startBatch();
	}

	@Override
	@Transactional
	public void execute() {
		final long expirationDelay = Long.parseLong(environment.getProperty("purge.monitoring.expiration-delay"));
		final Timestamp expirationDate = TimestampUtils.getPastDay(expirationDelay);
		auditEventJpaRepository.deleteExpiredValues(expirationDate);
		monitoringJmcJpaRepository.deleteExpiredValues(expirationDate);
		LOG.info("Batch de purge des tables monitoring_jmc et audit_event");
	}

}
