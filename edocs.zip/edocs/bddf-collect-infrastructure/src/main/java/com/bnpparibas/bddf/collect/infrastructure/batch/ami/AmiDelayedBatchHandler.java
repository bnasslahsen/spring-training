package com.bnpparibas.bddf.collect.infrastructure.batch.ami;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditEventService;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.ladrad.LadRadValidator;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.RequestWSJMCType;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.type.AmiBatchService;
import com.bnpparibas.bddf.collect.domain.type.AmiBatchStatus;
import com.bnpparibas.bddf.collect.domain.type.AmiService;
import com.bnpparibas.bddf.collect.domain.type.LadRadRepository;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.collect.infrastructure.entity.AmiBatchEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.TypeEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.AmiBatchMapper;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.TypeMapper;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.TypeJpaRepository;
import com.bnpparibas.bddf.errors.TechnicalException;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.base.Optional;
import com.netflix.hystrix.exception.HystrixRuntimeException;

@Component
public class AmiDelayedBatchHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(AmiDelayedBatchHandler.class);

	@Autowired
	private TypeMapper typeMapper;

	@Autowired
	private LadRadRepository ladRadRepository;

	@Autowired
	private AmiService amiService;

	@Autowired
	private AmiBatchService amiBatchService;

	@Autowired
	private AmiBatchMapper amiBatchMapper;

	@Autowired
	private TypeAutomaticControlUtils typeAutomaticControlUtils;

	@Autowired
	private LadRadValidator ladRadValidator;

	@Autowired
	private AuditEventService auditEventService;

	@Autowired
	private TypeRepository typeRepository;

	@Autowired
	private TypeJpaRepository typeJpaRepository;

	@Autowired
	private CollectEventHandler collectEventHandler;
	
	@Autowired
	private TypeValidator typeValidator;

	@Transactional(transactionManager = "transactionManagerDB", propagation = Propagation.REQUIRES_NEW)
	@Async("sendAmiBatchTaskExecutor")
	public CompletableFuture<Void> handle(AmiBatchEntity amiBatch, String typeId) {
		LoggerHelper.logForPerfTest(LOGGER, "Début du batch amiDelayed pour le type " + typeId + " (thread id " + Thread.currentThread().getId() + ")");
		updateStatusAndLastSent(amiBatch);

		final TypeEntity typeEntity = typeJpaRepository.findById(typeId).orElse(null);
		final Type type = typeMapper.typeEntityToType(typeEntity);
		final String documentSet = "AMI" + "_" + typeEntity.getVideoCodingDelays();
		final String ownerIndex = "1";
		final UUID collectId = UUID.fromString(typeEntity.getCollectId());
		final Context context = new Context("", "012");
		final String journeyCode = Optional.fromNullable(amiBatch.getJourneyCode()).or("");
		final Map<UUID, StatusDocumentDTO> listStatusDocumentJmc = new HashMap<>();
		try {
			LoggerHelper.logForPerfTest(LOGGER, "AmiDelayed début getStatusDocument  " + typeId + " (thread id " + Thread.currentThread().getId() + ")");
			final List<Piece> piecesSentToAmi = type.getActivePieces().stream().filter(piece -> piece.getControlIterationAchieved() == 9).collect(Collectors.toList());
			Collections.sort(piecesSentToAmi);
			final Piece amiPorterPiece = piecesSentToAmi.get(0);
			final String externalRef = amiPorterPiece.getId() + "-" + ownerIndex;
			final StatusDocumentDTO statusDocument = ladRadRepository.getStatusDocument(externalRef, UUID.fromString(typeId));
			if (typeAutomaticControlUtils.getSuccess(typeAutomaticControlUtils.getDocumentStatusFromDocumentSet(amiPorterPiece, documentSet, statusDocument), documentSet)) {
				listStatusDocumentJmc.put(amiPorterPiece.getId(), statusDocument);
				type.getActivePieces().stream().filter(currentPiece -> !amiPorterPiece.getId().toString().equals(currentPiece.getId().toString())).forEach(currentPiece -> {
					final String externalRefPiece = computeExternalRef(currentPiece.getId(), ownerIndex);
					final StatusDocumentDTO currentStatusDocument = ladRadRepository.getStatusDocument(externalRefPiece, UUID.fromString(typeId));
					listStatusDocumentJmc.put(currentPiece.getId(), currentStatusDocument);
				});
				final long end = System.currentTimeMillis();
				final long startJmc = piecesSentToAmi.stream().map(piece -> piece.getAcquisitionDate()).mapToLong(Instant::toEpochMilli).max().getAsLong();
				final Integer durationSendsAMI = (int) ((end - amiBatch.getInitialSent().toInstant().toEpochMilli()) / 1000);
				final Integer durationSendsJMC = (int) ((amiBatch.getInitialSent().toInstant().toEpochMilli() - startJmc) / 1000);
				auditEventService.sendAuditEventLadRADFirstIteration(collectId, context, journeyCode, type, durationSendsJMC, durationSendsAMI, documentSet, piecesSentToAmi);
			} else {
				return CompletableFuture.completedFuture(null);
			}
			LoggerHelper.logForPerfTest(LOGGER, "AmiDelayed fin getStatusDocument  " + typeId + " (thread id " + Thread.currentThread().getId() + ")");
			amiService.extractIndexesPieceAndCalculateIndicatorsAMI(collectId, type, listStatusDocumentJmc, new ArrayList<Indexe>(type.getIndexes()), ownerIndex, documentSet);
			if (type.getActivePieces().stream().allMatch(p -> !Arrays.asList(PieceStatus.DP_EC.getLabel(), PieceStatus.DP_ERR.getLabel()).contains(p.getStatus()))) {				
				typeAutomaticControlUtils.autoValidateType(collectId, type, context, AuditValue.LAD_RAD_AUTOMATIC_VALIDATION_ITERATION_1);
				typeAutomaticControlUtils.autoAcceptType(collectId, type, context, AuditValue.LAD_RAD_AUTOMATIC_ACCEPTATION);
			}
			typeRepository.updateType(collectId, type);
			LoggerHelper.logForPerfTest(LOGGER, "Début mise à jour status à DONE pour le type " + typeId + " (thread id " + Thread.currentThread().getId() + ")");
			amiBatch.setLastSent(Timestamp.from(Instant.now()));
			amiBatch.setStatus(AmiBatchStatus.DONE.getCode());
			amiBatchService.update(amiBatchMapper.toAmiBatch(amiBatch));
			collectEventHandler.sendAutomaticControlEvent(collectId, context, type);
			LoggerHelper.logForPerfTest(LOGGER, "Fin mise à jour status à DONE pour le type " + typeId + " (thread id " + Thread.currentThread().getId() + ")");
			LoggerHelper.logForPerfTest(LOGGER, "Fin du batch amiDelayed pour le type " + typeId + " (thread id " + Thread.currentThread().getId() + ")");
			return CompletableFuture.completedFuture(null);

		} catch (final TechnicalException | CollectBusinessException | HystrixRuntimeException ex) {
			LoggerHelper.logForPerfTest(LOGGER, "Erreur du batch amiDelayed pour le type " + typeId + " (thread id " + Thread.currentThread().getId() + ")");
			ladRadValidator.updateTypeWhenError(type);
			typeAutomaticControlUtils.autoAcceptType(collectId, type, context, AuditValue.LAD_RAD_AUTOMATIC_ACCEPTATION);
			typeRepository.updateType(collectId, type);
			auditEventService.sendAuditEventLadRAD(collectId, context, journeyCode, type, AuditValue.LAD_RAD_AUTOMATIC_CONTROL_ERROR, ex.getMessage());
			amiBatch.setLastSent(Timestamp.from(Instant.now()));
			amiBatch.setStatus(AmiBatchStatus.ERR.getCode());
			amiBatchService.update(amiBatchMapper.toAmiBatch(amiBatch));
			collectEventHandler.sendAutomaticControlEvent(collectId, context, type);
			LOGGER.info(ex.getMessage(), ex);
			return CompletableFuture.completedFuture(null);
		}

	}

	@Transactional(transactionManager = "transactionManagerDB", propagation = Propagation.REQUIRES_NEW)
	@Async("sendAmiBatchTaskExecutor")
	public CompletableFuture<Void> handleTimeout(AmiBatchEntity amiBatch, String typeId) {
		LoggerHelper.logForPerfTest(LOGGER, "AmiDelayed début handleTimeout  " + typeId + " (thread id " + Thread.currentThread().getId() + ")");
		final TypeEntity typeEntity = typeJpaRepository.findById(typeId).orElse(null);
		final Type type = typeMapper.typeEntityToType(typeEntity);
		final UUID collectId = UUID.fromString(typeEntity.getCollectId());
		final Context context = new Context("", "012");
		final String journeyCode = Optional.fromNullable(amiBatch.getJourneyCode()).or("");
		ladRadRepository.traceCallWS("", UUID.fromString(amiBatch.getTypeId()), RequestWSJMCType.GET_STATUS_DOCUMENT, HttpStatus.NO_CONTENT, "TimeOut AMI Batch", null, null);
		ladRadValidator.updateTypeWhenError(type);
		typeAutomaticControlUtils.autoAcceptType(collectId, type, context, AuditValue.LAD_RAD_AUTOMATIC_ACCEPTATION);
		typeRepository.updateType(collectId, type);
		amiBatch.setLastSent(Timestamp.from(Instant.now()));
		amiBatch.setStatus(AmiBatchStatus.TIMEOUT.getCode());
		amiBatchService.update(amiBatchMapper.toAmiBatch(amiBatch));
		auditEventService.sendAuditEventLadRAD(collectId, context, journeyCode, type, AuditValue.LAD_RAD_AUTOMATIC_CONTROL_ERROR, "");
		collectEventHandler.sendAutomaticControlEvent(collectId, context, type);
		LoggerHelper.logForPerfTest(LOGGER, "AmiDelayed fin handleTimeout  " + typeId + " (thread id " + Thread.currentThread().getId() + ")");
		return CompletableFuture.completedFuture(null);
	}

	private void updateStatusAndLastSent(AmiBatchEntity amiBatchEntity) {
		LoggerHelper.logForPerfTest(LOGGER, "Début mise à jour status à IN_PR pour le type " + amiBatchEntity.getTypeId() + " (thread id " + Thread.currentThread().getId() + ")");
		amiBatchEntity.setStatus(AmiBatchStatus.IN_PROGRESS.getCode());
		amiBatchEntity.setLastSent(Timestamp.from(Instant.now()));
		amiBatchService.update(amiBatchMapper.toAmiBatch(amiBatchEntity));
		LoggerHelper.logForPerfTest(LOGGER, "Fin mise à jour status à IN_PR pour le type " + amiBatchEntity.getTypeId() + " (thread id " + Thread.currentThread().getId() + ")");
	}

	private String computeExternalRef(UUID id, String ownerIndex) {
		return id.toString() + "-" + ownerIndex;
	}

}
