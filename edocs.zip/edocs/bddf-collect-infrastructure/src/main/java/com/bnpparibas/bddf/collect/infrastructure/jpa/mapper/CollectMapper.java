package com.bnpparibas.bddf.collect.infrastructure.jpa.mapper;

import java.sql.Timestamp;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.infrastructure.entity.CollectEntity;

@Component
public class CollectMapper {

	@Autowired
	OwnerMapper ownerMapper;

	@Autowired
	FamilyMapper familyMapper;

	public CollectEntity toCollectEntity(Collect collect, boolean isNew) {
		final CollectEntity collectEntity = new CollectEntity();

		collectEntity.setAllowedFile(String.join(",", collect.getAllowedFile()));
		collectEntity.setAutoValidation(collect.isAutoValidation());
		collectEntity.setAutoAcceptationAllowed(collect.isAutoAcceptationAllowed());
		collectEntity.setControlIterationAllowed(collect.getControlIterationAllowed());
		collectEntity.setAutoClosingDelay(collect.getAutoClosingDelay());
		if (Optional.ofNullable(collect.getCreationDate()).isPresent()) {
			collectEntity.setCreationDate(Timestamp.from(collect.getCreationDate()));
		}
		if (Optional.ofNullable(collect.getEndDate()).isPresent()) {
			collectEntity.setEndDate(Timestamp.from(collect.getEndDate()));
		}

		collectEntity.setEntityLabel(collect.getEntityLabel());
		if (CollectionUtils.isNotEmpty(collect.getFamiliesManagementAct())) {
			collectEntity.setFamiliesManagementAct(String.join(",", collect.getFamiliesManagementAct()));
		}
		if (CollectionUtils.isNotEmpty(collect.getPiecesManagementAct())) {
			collectEntity.setPiecesManagementAct(String.join(",", collect.getPiecesManagementAct()));
		}
		if (CollectionUtils.isNotEmpty(collect.getCollectManagementAct())) {
			collectEntity.setCollectManagementAct(String.join(",", collect.getCollectManagementAct()));
		}

		collectEntity.setId(collect.getId().toString());
		collectEntity.setJourneyCode(collect.getJourneyCode());
		collectEntity.setProductLabel(collect.getProductLabel());
		collectEntity.setProject(collect.getProject());
		collectEntity.setSendingApplicationCode(collect.getSendingApplicationCode());
		collectEntity.setStatus(collect.getStatus());
		collectEntity.setStepLabel(collect.getStepLabel());
		collectEntity.setNotifyOwners(collect.isNotifyOwners());
		collectEntity.setNew(isNew);

		collectEntity.setOwners(ownerMapper.toOwnersEntity(collect.getOwners(), isNew));
		collectEntity.setFamilies(familyMapper.toFamilyEntities(collect.getTypes(), collectEntity, isNew));

		return collectEntity;
	}

	public Collect toCollect(CollectEntity collectEntity, boolean withInactivePieces) {

		if (collectEntity == null) {
			return null;
		}

		final Collect collect = new Collect();

		if (Optional.ofNullable(collectEntity.getAllowedFile()).isPresent()) {
			collect.setAllowedFile(Arrays.stream(collectEntity.getAllowedFile().split(",")).collect(Collectors.toSet()));
		}
		collect.setAutoValidation(collectEntity.getAutoValidation());
		collect.setAutoAcceptationAllowed(collectEntity.getAutoAcceptationAllowed());
		collect.setControlIterationAllowed(collectEntity.getControlIterationAllowed().intValue());
		collect.setAutoClosingDelay(collectEntity.getAutoClosingDelay());

		if (Optional.ofNullable(collectEntity.getCreationDate()).isPresent()) {
			collect.setCreationDate(collectEntity.getCreationDate().toInstant());
		}
		if (Optional.ofNullable(collectEntity.getEndDate()).isPresent()) {
			collect.setEndDate(collectEntity.getEndDate().toInstant());
		}

		collect.setEntityLabel(collectEntity.getEntityLabel());
		if (StringUtils.isNotEmpty(collectEntity.getFamiliesManagementAct())) {
			collect.setFamiliesManagementAct(Arrays.stream(collectEntity.getFamiliesManagementAct().split(",")).collect(Collectors.toSet()));
		}
		if (StringUtils.isNotEmpty(collectEntity.getPiecesManagementAct())) {
			collect.setPiecesManagementAct(Arrays.stream(collectEntity.getPiecesManagementAct().split(",")).collect(Collectors.toSet()));
		}

		if (StringUtils.isNotEmpty(collectEntity.getCollectManagementAct())) {
			collect.setCollectManagementAct(Arrays.stream(collectEntity.getCollectManagementAct().split(",")).collect(Collectors.toSet()));
		}

		collect.setId(UUID.fromString(Optional.ofNullable(collectEntity).map(CollectEntity::getId).orElse("")));
		collect.setJourneyCode(collectEntity.getJourneyCode());
		collect.setProductLabel(collectEntity.getProductLabel());
		collect.setProject(collectEntity.getProject());
		collect.setSendingApplicationCode(collectEntity.getSendingApplicationCode());
		collect.setStatus(collectEntity.getStatus());
		collect.setStepLabel(collectEntity.getStepLabel());
		collect.setNotifyOwners(BooleanUtils.toBoolean(collectEntity.getNotifyOwners()));
		collect.setOwners(ownerMapper.toOwners(collectEntity.getOwners()));
		collect.setTypes(familyMapper.toFamilies(collectEntity.getFamilies(), withInactivePieces));
		return collect;

	}

	public Collect mapOnlyCollect(CollectEntity collectEntity) {

		if (collectEntity == null) {
			return null;
		}

		final Collect collect = new Collect();

		collect.setAllowedFile(Arrays.stream(collectEntity.getAllowedFile().split(",")).collect(Collectors.toSet()));
		collect.setAutoValidation(collectEntity.getAutoValidation());
		collect.setAutoAcceptationAllowed(collectEntity.getAutoAcceptationAllowed());
		collect.setControlIterationAllowed(collectEntity.getControlIterationAllowed().intValue());
		collect.setAutoClosingDelay(collectEntity.getAutoClosingDelay());
		if (Optional.ofNullable(collectEntity.getCreationDate()).isPresent()) {
			collect.setCreationDate(collectEntity.getCreationDate().toLocalDateTime().toInstant(ZoneOffset.UTC));
		}
		if (Optional.ofNullable(collectEntity.getEndDate()).isPresent()) {
			collect.setEndDate(collectEntity.getEndDate().toLocalDateTime().toInstant(ZoneOffset.UTC));
		}

		collect.setEntityLabel(collectEntity.getEntityLabel());
		if (StringUtils.isNotEmpty(collectEntity.getFamiliesManagementAct())) {
			collect.setFamiliesManagementAct(Arrays.stream(collectEntity.getFamiliesManagementAct().split(",")).collect(Collectors.toSet()));
		}
		if (StringUtils.isNotEmpty(collectEntity.getPiecesManagementAct())) {
			collect.setPiecesManagementAct(Arrays.stream(collectEntity.getPiecesManagementAct().split(",")).collect(Collectors.toSet()));
		}

		if (StringUtils.isNotEmpty(collectEntity.getCollectManagementAct())) {
			collect.setCollectManagementAct(Arrays.stream(collectEntity.getCollectManagementAct().split(",")).collect(Collectors.toSet()));
		}

		collect.setId(UUID.fromString(Optional.ofNullable(collectEntity).map(CollectEntity::getId).orElse("")));
		collect.setJourneyCode(collectEntity.getJourneyCode());
		collect.setProductLabel(collectEntity.getProductLabel());
		collect.setProject(collectEntity.getProject());
		collect.setSendingApplicationCode(collectEntity.getSendingApplicationCode());
		collect.setStatus(collectEntity.getStatus());
		collect.setStepLabel(collectEntity.getStepLabel());
		collect.setNotifyOwners(BooleanUtils.toBoolean(collectEntity.getNotifyOwners()));
		collect.setOwners(ownerMapper.toOwners(collectEntity.getOwners()));
		return collect;
	}

	public Set<Collect> toCollects(Set<CollectEntity> collectEntities) {
		final HashSet<Collect> collects = new HashSet<>();

		if (collectEntities == null) {
			return collects;
		}

		collectEntities.forEach(collectEntity -> collects.add(toCollect(collectEntity, true)));
		return collects;
	}

}
