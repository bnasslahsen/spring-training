package com.bnpparibas.bddf.collect.infrastructure.converter;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import org.dozer.CustomConverter;
import org.dozer.MappingException;

public class LocalDateToDateConverter implements CustomConverter {

	@Override
	public Object convert(Object destination, Object source, Class destClass, Class sourceClass) {
		if (source == null) {
			return null;
		}

		if (source instanceof LocalDate) {
			return Date.from(((LocalDate) source).atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
		} else if (source instanceof Date) {
			return Instant.ofEpochMilli(((Date) source).getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
		} else {
			throw new MappingException("Converter LocalDateToDateConverter "
					+ "used incorrectly. Arguments passed in were:" + destination + " and " + source);
		}
	}
}
