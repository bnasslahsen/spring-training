package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.util.List;
import java.util.Map;

import org.springframework.batch.item.ItemWriter;

public class CountCollectsItemWriter implements ItemWriter<String> {

	private final Map<String, Long> res;

	public CountCollectsItemWriter(Map<String, Long> res) {
		this.res = res;
	}

	@Override
	public void write(List<? extends String> items) throws Exception {
		res.put(BatchResult.OK.getValue(), res.get(BatchResult.OK.getValue()) + Long.valueOf(items.size()));
	}

}
