package com.bnpparibas.bddf.collect.infrastructure.repository;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bnpparibas.bddf.collect.domain.owner.ClientNotification;
import com.bnpparibas.bddf.collect.domain.owner.ClientNotificationRepository;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.ClientNotificationMapper;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.ClientNotificationJpaRepository;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.RepositoryImpl
@Repository
public class ClientNotificationRepositoryImpl implements ClientNotificationRepository {

	@Autowired
	private ClientNotificationJpaRepository clientNotificationJpaRepository;
	@Autowired
	private ClientNotificationMapper clientNotificationMapper;

	@Override
	public void save(ClientNotification clientNotification) {
		clientNotificationJpaRepository.save(clientNotificationMapper.toClientNotificationEntity(clientNotification, true));
	}

	@Override
	public void update(ClientNotification clientNotification) {
		clientNotificationJpaRepository.save(clientNotificationMapper.toClientNotificationEntity(clientNotification, false));
	}

	@Override
	public void delete(ClientNotification clientNotification) {
		clientNotificationJpaRepository.delete(clientNotificationMapper.toClientNotificationEntity(clientNotification, false));
	}
	
	@Override
	public void delete(UUID typeId) {
		clientNotificationJpaRepository.deleteById(typeId.toString());
	}

	@Override
	public void updateNotificationNumber(String typeId, Integer notificationNumber) {
		clientNotificationJpaRepository.updateNotificationNumber(typeId, notificationNumber, Timestamp.from(Instant.now()));
	}

	@Override
	public int count(UUID typeId) {
		return clientNotificationJpaRepository.count(typeId.toString());
	}

}
