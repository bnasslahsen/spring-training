package com.bnpparibas.bddf.attachment.infrastructure;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AttachmentJpaRepository extends JpaRepository<AttachmentEntity, String> {
	
	@Query("select aE from AttachmentEntity aE where aE.creationDate <= :timeOut")
	List<AttachmentEntity> findAttachmentsOlderThan(@Param("timeOut") Timestamp timeOut);

}
