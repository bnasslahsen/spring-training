package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.util.List;
import java.util.Map;

import org.springframework.batch.item.ItemWriter;

import com.bnpparibas.bddf.collect.infrastructure.entity.DocReferenceEntity;

public class CountPiecesReferenceItemWriter implements ItemWriter<DocReferenceEntity> {

	private final Map<String, Long> res;

	public CountPiecesReferenceItemWriter(Map<String, Long> res) {
		this.res = res;
	}

	@Override
	public void write(List<? extends DocReferenceEntity> items) throws Exception {
		res.put(BatchResult.OK.getValue(), res.get(BatchResult.OK.getValue()) + Long.valueOf(items.size()));

	}

}
