package com.bnpparibas.bddf.collect.infrastructure.jpa.mapper;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Optional;

import org.springframework.stereotype.Component;

@Component
public class TimestampUtils {
	public Timestamp localDateToTimestamp(LocalDate date) {
		return Optional.ofNullable(date).map(d -> Timestamp.from((d).atStartOfDay().atZone(ZoneId.systemDefault()).toInstant())).orElse(null);
	}

	public static Timestamp instantToTimestamp(Instant date) {
		return Optional.ofNullable(date).map(d -> Timestamp.from(date)).orElse(null);
	}

	public static Timestamp getNow() {
		final java.util.Date date = new java.util.Date();
		return (new Timestamp(date.getTime()));
	}

	public static Timestamp getPastDay(long days) {
		ZonedDateTime pastDay = ZonedDateTime.now(ZoneId.systemDefault()).truncatedTo(ChronoUnit.DAYS);
		pastDay = pastDay.plusDays(-days);
		return Timestamp.from(pastDay.toInstant());
	}

	public static Timestamp dateToTimestamp(Date date) {
		return Optional.ofNullable(date).map(d -> new Timestamp(date.getTime())).orElse(null);
	}

	public static Date timestampToDate(Timestamp timestamp) {
		return Optional.ofNullable(timestamp).map(d -> new Date(timestamp.getTime())).orElse(null);
	}
}
