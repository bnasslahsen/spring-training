package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Iterator;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.infrastructure.entity.CollectEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.CollectJpaRepository;

@Component
public class CollectAbandonItemReader implements ItemReader<CollectEntity> {

	@Autowired
	private CollectJpaRepository collectJpaRepository;
	@Autowired
	private PurgeUtils purgeUtils;
	private Iterator<CollectEntity> collectAbIdsIt;

	@Override
	public CollectEntity read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		final Instant instantTimeOutCollectEc = purgeUtils.buildPurgeDate(PurgeType.COL_EC_AB);
		synchronized (this) {
			if (collectAbIdsIt == null) {
				collectAbIdsIt = collectJpaRepository.findCollectsBeforeAndByStatus(Timestamp.from(instantTimeOutCollectEc), CollectStatus.EC.name()).iterator();
			}
		}

		if (collectAbIdsIt.hasNext()) {
			return collectAbIdsIt.next();
		} else {
			return null;
		}
	}

}
