package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.entity.BatchLock;

@Repository
public interface BatchLockJpaRepository extends JpaRepository<BatchLock, String> {

	@Modifying
	@Transactional
	@Query("UPDATE BatchLock SET batchLock=:newLock WHERE id =:batchName and batchLock=:oldLock")
	int updateSwitch(@Param("batchName") String batchName, @Param("oldLock") String oldLock, @Param("newLock") String newLock);

	@Modifying
	@Transactional
	@Query("UPDATE BatchLock SET batchLock=:lock WHERE id =:batchName")
	void reinitSwitch(@Param("batchName") String batchName, @Param("lock") String lock);


}
