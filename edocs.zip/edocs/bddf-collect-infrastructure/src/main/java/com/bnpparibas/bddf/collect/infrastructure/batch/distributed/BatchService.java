package com.bnpparibas.bddf.collect.infrastructure.batch.distributed;


public interface BatchService {

	void startBatch(AbstractBatch batch);

}
