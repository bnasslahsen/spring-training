package com.bnpparibas.bddf.collect.infrastructure.batch.monitoring;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.entity.ViewMonitoringDailyEntity;
import com.bnpparibas.bddf.collect.infrastructure.repository.ViewAuditDailyRepository;
import com.bnpparibas.bddf.email.BddfMailMessage;
import com.bnpparibas.bddf.email.MailService;

@Component
@Transactional(transactionManager = "transactionManagerDB")
public class CollectMonitoringDaily extends AbstractBatchMonitoring {

	private static final int LAST_HOUR = 23;
	private static final int LAST_MINUTE = 59;
	private static final int LAST_SECOND = 59;
	private static final int LAST_MILLISECOND = 999;
	private static final int MAX_SIZE_9 = 9;
	private static final int MAX_SIZE_11 = 11;
	private static final int MAX_SIZE_50 = 50;
	private static final int INIT_SIZE = 256;
	private static final int COUNTER_0 = 0;
	private static final int COUNTER_1 = 1;
	private static final int COUNTER_2 = 2;
	private static final int COUNTER_3 = 3;
	private static final int COUNTER_4 = 4;
	private static final int COUNTER_5 = 5;
	private static final int COUNTER_6 = 6;

	private static final Logger LOG = LoggerFactory.getLogger(CollectMonitoringDaily.class);

	private static final String BOT = "-------------------------------------------------------------- ----------- | ---------  ---------  --------- | ---------  ---------\n                                                         TOTAL ";
	private static final String HEADERS = "                                                                                        NUMERIQUE                     PAPIER\n                                                                             -------------------------------   --------------------\nID_PARCOURS LIBELLE                                                COLLECT |     DEPOT     ACCEPT      VALID      REFUS |     VALID      REFUS\n----------- -------------------------------------------------- ----------- | ---------  ---------  ---------   ---------  ---------\n";
	private static final String SPACE2 = "  ";

	private static final DateTimeFormatter FORMATTER_DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	@Autowired
	private ViewAuditDailyRepository viewAuditDailyRepository;
	@Autowired
	private MailService mailService;
	@Autowired
	private Environment environment;

	public CollectMonitoringDaily() {
		super("COLLECT_MONITORING_DAILY");
	}

	@Scheduled(cron = "${monitoring.cron.daily}")
	@Override
	public void scheduledStart() {
		startBatch();
	}

	@Override
	public void execute() {
		try {
			final List<ViewMonitoringDailyEntity> monitorings = viewAuditDailyRepository.findAll();

			final BddfMailMessage mailMessage = buildMailMessage(monitorings);
			mailService.sendMail(mailMessage);
		} catch (final Exception e) {
			LOG.error(e.getMessage(), e);
		}
	}

	public static Date beginOfDay(Date date) {
		final Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);

		return cal.getTime();
	}

	public static Date endOfDay(Date date) {
		final Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		cal.set(Calendar.HOUR_OF_DAY, LAST_HOUR);
		cal.set(Calendar.MINUTE, LAST_MINUTE);
		cal.set(Calendar.SECOND, LAST_SECOND);
		cal.set(Calendar.MILLISECOND, LAST_MILLISECOND);

		return cal.getTime();
	}

	public BddfMailMessage buildMailMessage(final List<ViewMonitoringDailyEntity> monitorings) {
		final List<Counter> counters = new ArrayList<>();
		counters.add(new Counter());
		counters.add(new Counter());
		counters.add(new Counter());
		counters.add(new Counter());
		counters.add(new Counter());
		counters.add(new Counter());
		counters.add(new Counter());

		final StringBuilder bodyLines = new StringBuilder();
		bodyLines.append(HEADERS);
		monitorings.stream().filter(mon -> !"Total".equals(mon.getJourneyCode())).collect(Collectors.groupingBy(ViewMonitoringDailyEntity::getJourneyCode)).forEach((jouneyCode, list) -> bodyLines.append(toMailLine(jouneyCode, list, counters)));

		final StringBuilder object = new StringBuilder(INIT_SIZE);
		object.append("E-DOC DAILY MONITORING");
		object.append(FORMATTER_DATE.format(LocalDateTime.ofInstant(new Date().toInstant(), ZoneId.systemDefault())));
		object.append(" >  CO : ");
		object.append(counters.get(COUNTER_0).getCount());
		object.append(" - DP : ");
		object.append(counters.get(COUNTER_1).getCount());
		object.append(" - VA : ");
		object.append(counters.get(COUNTER_3).getCount());
		object.append(" - RF : ");
		object.append(counters.get(COUNTER_4).getCount());
		object.append(" - ");
		final String host = environment.getProperty("spring.cloud.client.hostname");
		final String hostParse = extractHost(host);
		object.append(hostParse);

		bodyLines.append('\n');
		bodyLines.append(BOT);
		bodyLines.append(alignRight(String.valueOf(counters.get(COUNTER_0).getCount()), MAX_SIZE_11));
		bodyLines.append(" | ");
		bodyLines.append(alignRight(String.valueOf(counters.get(COUNTER_1).getCount()), MAX_SIZE_9));
		bodyLines.append(SPACE2);
		bodyLines.append(alignRight(String.valueOf(counters.get(COUNTER_2).getCount()), MAX_SIZE_9));
		bodyLines.append(SPACE2);
		bodyLines.append(alignRight(String.valueOf(counters.get(COUNTER_3).getCount()), MAX_SIZE_9));
		bodyLines.append(SPACE2);
		bodyLines.append(alignRight(String.valueOf(counters.get(COUNTER_4).getCount()), MAX_SIZE_9));
		bodyLines.append(" | ");
		bodyLines.append(alignRight(String.valueOf(counters.get(COUNTER_5).getCount()), MAX_SIZE_9));
		bodyLines.append(SPACE2);
		bodyLines.append(alignRight(String.valueOf(counters.get(COUNTER_6).getCount()), MAX_SIZE_9));
		return new BddfMailMessage(environment.getProperty("monitoring.mail.sender"), new String[] { environment.getProperty("monitoring.mail.recipient") }, object.toString(), bodyLines.toString(), false);
	}

	private String toMailLine(String journeyCode, List<ViewMonitoringDailyEntity> list, List<Counter> counters) {
		final ViewMonitoringDailyEntity viewAuditDaily = list.get(0);
		final StringBuilder label = new StringBuilder();
		label.append(viewAuditDaily.getProductLabel());

		final StringBuilder line = new StringBuilder();
		line.append(alignRight(journeyCode, MAX_SIZE_11));
		line.append(' ');
		line.append(alignLeft(label.toString(), MAX_SIZE_50));
		line.append(' ');

		final long nbCollectCreate = viewAuditDaily.getCollectDay();
		counters.get(COUNTER_0).increase(nbCollectCreate);
		line.append(alignRight(String.valueOf(nbCollectCreate), MAX_SIZE_11));
		line.append(" | ");

		final long nbPieceNumAdd = viewAuditDaily.getDepotDayNum();
		counters.get(COUNTER_1).increase(nbPieceNumAdd);
		line.append(alignRight(String.valueOf(nbPieceNumAdd), MAX_SIZE_9));
		line.append(SPACE2);

		final long nbPieceNumAccepted = viewAuditDaily.getAcceptDayNum();
		counters.get(COUNTER_2).increase(nbPieceNumAccepted);
		line.append(alignRight(String.valueOf(nbPieceNumAccepted), MAX_SIZE_9));
		line.append(SPACE2);

		final long nbPieceNumValid = viewAuditDaily.getValidDayNum();
		counters.get(COUNTER_3).increase(nbPieceNumValid);
		line.append(alignRight(String.valueOf(nbPieceNumValid), MAX_SIZE_9));
		line.append(SPACE2);

		final long nbPieceNumRf = viewAuditDaily.getRefusDayNum();
		counters.get(COUNTER_4).increase(nbPieceNumRf);
		line.append(alignRight(String.valueOf(nbPieceNumRf), MAX_SIZE_9));
		line.append(" | ");

		final long nbPiecePapValid = viewAuditDaily.getValidDayPap();
		counters.get(COUNTER_5).increase(nbPiecePapValid);
		line.append(alignRight(String.valueOf(nbPiecePapValid), MAX_SIZE_9));
		line.append(SPACE2);

		final long nbPiecePapRf = viewAuditDaily.getRefusDayPap();
		counters.get(COUNTER_6).increase(nbPiecePapRf);
		line.append(alignRight(String.valueOf(nbPiecePapRf), MAX_SIZE_9));
		line.append('\n');

		return line.toString();
	}

	private String alignRight(String s, int length) {
		if (s.length() >= length) {
			return s.substring(0, length);
		}
		final char[] blank = new char[length - s.length()];
		Arrays.fill(blank, ' ');
		return new String(blank) + s;
	}

	private String alignLeft(String s, int length) {
		if (s.length() >= length) {
			return s.substring(0, length);
		}
		final char[] blank = new char[length - s.length()];
		Arrays.fill(blank, ' ');
		return s + new String(blank);
	}

	public MailService getMailService() {
		return mailService;
	}

	public void setMailService(MailService mailService) {
		this.mailService = mailService;
	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

}
