package com.bnpparibas.bddf.collect.infrastructure.entity;
// Generated 8 juin 2018 10:15:05 by Hibernate Tools 4.3.2-SNAPSHOT

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Immutable
@Table(name = "VIEW_MONITORING_WEEKLY")
public class ViewMonitoringWeeklyEntity implements java.io.Serializable {

	private static final int INITIAL_BUILDER_SIZE = 32;

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String idTech;
    private String extractionDate;
    private String journeyCode;
    private String productLabel;
    private String edocType;
    private String typeLabel;
    private Integer controlRequired;
    private Integer nbTypesDeposit;
    private Integer nbFilesUploaded;
    private Integer nbFilesRecognized;
    private Integer durationFirstIteration;
    private Integer durationAmi;
    private Integer nbIndexExpected;
    private Integer nbExtractIndex;
    private Integer nbIndexOk;
    private Integer nbIndexCorrected;
    private Integer nbVaAuto1;
    private Integer nbVaAutoVc1;
    private Integer nbVaAuto2;
    private Integer nbVaAutoVc2;
    private Integer nbRcAuto;
    private Integer nbForcedRecognition;
    private Integer nbRefusedType;
    private Integer nbAcceptedType;
    private Integer nbValidatedType;
    private Integer nbErrType;
    private Integer nbErrTypeVc;

   @Id
   @Column(name="ID_TECH")
   public String getIdTech() {
       return this.idTech;
   }
   
   public void setIdTech(String idTech) {
       this.idTech = idTech;
   }


   @Column(name="EXTRACTION_DATE")
   public String getExtractionDate() {
       return this.extractionDate;
   }
   
   public void setExtractionDate(String extractionDate) {
       this.extractionDate = extractionDate;
   }


   @Column(name="JOURNEY_CODE")
   public String getJourneyCode() {
       return this.journeyCode;
   }
   
   public void setJourneyCode(String journeyCode) {
       this.journeyCode = journeyCode;
   }


   @Column(name="PRODUCT_LABEL")
   public String getProductLabel() {
       return this.productLabel;
   }
   
   public void setProductLabel(String productLabel) {
       this.productLabel = productLabel;
   }


   @Column(name="EDOC_TYPE", length=17)
   public String getEdocType() {
       return this.edocType;
   }
   
   public void setEdocType(String edocType) {
       this.edocType = edocType;
   }


   @Column(name="TYPE_LABEL")
   public String getTypeLabel() {
       return this.typeLabel;
   }
   
   public void setTypeLabel(String typeLabel) {
       this.typeLabel = typeLabel;
   }


   @Column(name="CONTROL_REQUIRED")
   public Integer getControlRequired() {
       return this.controlRequired;
   }
   
   public void setControlRequired(Integer controlRequired) {
       this.controlRequired = controlRequired;
   }


   @Column(name="NB_TYPES_DEPOSIT")
   public Integer getNbTypesDeposit() {
       return this.nbTypesDeposit;
   }
   
   public void setNbTypesDeposit(Integer nbTypesDeposit) {
       this.nbTypesDeposit = nbTypesDeposit;
   }


   @Column(name="NB_FILES_UPLOADED")
   public Integer getNbFilesUploaded() {
       return this.nbFilesUploaded;
   }
   
   public void setNbFilesUploaded(Integer nbFilesUploaded) {
       this.nbFilesUploaded = nbFilesUploaded;
   }


   @Column(name="NB_FILES_RECOGNIZED")
   public Integer getNbFilesRecognized() {
       return this.nbFilesRecognized;
   }
   
   public void setNbFilesRecognized(Integer nbFilesRecognized) {
       this.nbFilesRecognized = nbFilesRecognized;
   }


   @Column(name="DURATION_FIRST_ITERATION")
   public Integer getDurationFirstIteration() {
       return this.durationFirstIteration;
   }
   
   public void setDurationFirstIteration(Integer durationFirstIteration) {
       this.durationFirstIteration = durationFirstIteration;
   }


   @Column(name="DURATION_AMI")
   public Integer getDurationAmi() {
       return this.durationAmi;
   }
   
   public void setDurationAmi(Integer durationAmi) {
       this.durationAmi = durationAmi;
   }


   @Column(name="NB_INDEX_EXPECTED")
   public Integer getNbIndexExpected() {
       return this.nbIndexExpected;
   }
   
   public void setNbIndexExpected(Integer nbIndexExpected) {
       this.nbIndexExpected = nbIndexExpected;
   }


   @Column(name="NB_EXTRACT_INDEX")
   public Integer getNbExtractIndex() {
       return this.nbExtractIndex;
   }
   
   public void setNbExtractIndex(Integer nbExtractIndex) {
       this.nbExtractIndex = nbExtractIndex;
   }


   @Column(name="NB_INDEX_OK")
   public Integer getNbIndexOk() {
       return this.nbIndexOk;
   }
   
   public void setNbIndexOk(Integer nbIndexOk) {
       this.nbIndexOk = nbIndexOk;
   }


   @Column(name="NB_INDEX_CORRECTED")
   public Integer getNbIndexCorrected() {
       return this.nbIndexCorrected;
   }
   
   public void setNbIndexCorrected(Integer nbIndexCorrected) {
       this.nbIndexCorrected = nbIndexCorrected;
   }


   @Column(name="NB_VA_AUTO_1")
   public Integer getNbVaAuto1() {
       return this.nbVaAuto1;
   }
   
   public void setNbVaAuto1(Integer nbVaAuto1) {
       this.nbVaAuto1 = nbVaAuto1;
   }


   @Column(name="NB_VA_AUTO_VC_1")
   public Integer getNbVaAutoVc1() {
       return this.nbVaAutoVc1;
   }
   
   public void setNbVaAutoVc1(Integer nbVaAutoVc1) {
       this.nbVaAutoVc1 = nbVaAutoVc1;
   }


   @Column(name="NB_VA_AUTO_2", precision=22)
   public Integer getNbVaAuto2() {
       return this.nbVaAuto2;
   }
   
   public void setNbVaAuto2(Integer nbVaAuto2) {
       this.nbVaAuto2 = nbVaAuto2;
   }


   @Column(name="NB_VA_AUTO_VC_2")
   public Integer getNbVaAutoVc2() {
       return this.nbVaAutoVc2;
   }
   
   public void setNbVaAutoVc2(Integer nbVaAutoVc2) {
       this.nbVaAutoVc2 = nbVaAutoVc2;
   }


   @Column(name="NB_RC_AUTO")
   public Integer getNbRcAuto() {
       return this.nbRcAuto;
   }
   
   public void setNbRcAuto(Integer nbRcAuto) {
       this.nbRcAuto = nbRcAuto;
   }


   @Column(name="NB_FORCED_RECOGNITION")
   public Integer getNbForcedRecognition() {
       return this.nbForcedRecognition;
   }
   
   public void setNbForcedRecognition(Integer nbForcedRecognition) {
       this.nbForcedRecognition = nbForcedRecognition;
   }


   @Column(name="NB_REFUSED_TYPE", length = 6)
   public Integer getNbRefusedType() {
       return this.nbRefusedType;
   }
   
   public void setNbRefusedType(Integer nbRefusedType) {
       this.nbRefusedType = nbRefusedType;
   }


   @Column(name="NB_ACCEPTED_TYPE")
   public Integer getNbAcceptedType() {
       return this.nbAcceptedType;
   }
   
   public void setNbAcceptedType(Integer nbAcceptedType) {
       this.nbAcceptedType = nbAcceptedType;
   }


   @Column(name="NB_VALIDATED_TYPE")
   public Integer getNbValidatedType() {
       return this.nbValidatedType;
   }
   
   public void setNbValidatedType(Integer nbValidatedType) {
       this.nbValidatedType = nbValidatedType;
   }


   @Column(name="NB_ERR_TYPE")
   public Integer getNbErrType() {
       return this.nbErrType;
   }
   
   public void setNbErrType(Integer nbErrType) {
       this.nbErrType = nbErrType;
   }


   @Column(name="NB_ERR_TYPE_VC")
   public Integer getNbErrTypeVc() {
       return this.nbErrTypeVc;
   }
   
   public void setNbErrTypeVc(Integer nbErrTypeVc) {
       this.nbErrTypeVc = nbErrTypeVc;
   }
   
   @Override
	public String toString() {
		final StringBuilder builder = new StringBuilder(INITIAL_BUILDER_SIZE);
		builder.append(extractionDate);
		builder.append(";");
		builder.append(journeyCode);
		builder.append(";");
		builder.append(productLabel);
		builder.append(";");
		builder.append(edocType);
		builder.append(";");
		builder.append(typeLabel);
		builder.append(";");
		builder.append(controlRequired);
		builder.append(";");
		builder.append(nbTypesDeposit);
		builder.append(";");
		builder.append(nbFilesUploaded);
		builder.append(";");
		builder.append(nbFilesRecognized);
		builder.append(";");
		builder.append(durationFirstIteration);
		builder.append(";");
		builder.append(durationAmi);
		builder.append(";");
		builder.append(nbIndexExpected);
		builder.append(";");
		builder.append(nbExtractIndex);
		builder.append(";");
		builder.append(nbIndexOk);
		builder.append(";");
		builder.append(nbVaAuto1);
		builder.append(";");
		builder.append(nbVaAutoVc1);
		builder.append(";");
		builder.append(nbRcAuto);
		builder.append(";");
		builder.append(nbIndexCorrected);
		builder.append(";");
		builder.append(nbForcedRecognition);
		builder.append(";");
		builder.append(nbVaAuto2);
		builder.append(";");
		builder.append(nbVaAutoVc2);
		builder.append(";");
		builder.append(nbRefusedType);
		builder.append(";");
		builder.append(nbAcceptedType);
		builder.append(";");
		builder.append(nbValidatedType);
		builder.append(";");
		builder.append(nbErrType);
		builder.append(";");
		builder.append(nbErrTypeVc);
		return builder.toString();
	}


}
