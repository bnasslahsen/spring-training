package com.bnpparibas.bddf.collect.infrastructure.repository;

import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.type.FamilyRepository;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.infrastructure.entity.FamilyEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.CollectMapper;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.FamilyMapper;
import com.bnpparibas.bddf.collect.infrastructure.jpa.mapper.PieceMapper;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.CollectJpaRepository;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.FamilyJpaRepository;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.PieceJpaRepository;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.RepositoryImpl
@Repository
public class FamilyRepositoryImpl implements FamilyRepository {

	@Autowired
	private CollectMapper collectMapper;
	@Autowired
	private FamilyMapper familyMapper;
	@Autowired
	private FamilyJpaRepository familyJpaRepository;
	@Autowired
	private CollectJpaRepository collectJpaRepository;
	@Autowired
	private PieceRepository pieceRepository;
	@Autowired
	private PieceJpaRepository pieceJpaRepository;
	@Autowired
	private PieceMapper pieceMapper;

	@Override
	public void add(Collect collect, List<Type> types) {
		final FamilyEntity familyEntity = familyMapper.toFamilyEntity(types, collectJpaRepository.findById(collect.getId().toString()).orElse(null), true);
		familyJpaRepository.save(familyEntity);
	}

	@Override
	public void delete(UUID familyId) {
		final FamilyEntity fE = familyJpaRepository.findById(familyId.toString()).orElse(null);
		final List<Piece> piecesFromFamily = pieceJpaRepository.findAllPieces(familyId.toString()).stream().map(pieceMapper::pieceEntityToPieceAndIsInactive).collect(Collectors.toList());
		fE.getCollect().getFamilies().removeIf(family -> family.getId().equals(familyId.toString()));
		pieceRepository.deleteAllPiecesOnGdnAndNas(piecesFromFamily);
		familyJpaRepository.delete(fE);

	}
	

	@Override
	public void update(Collect collect, Set<Type> types) {
		final Set<FamilyEntity> familyEntities = familyMapper.toFamilyEntities(types, collectMapper.toCollectEntity(collect, false), false);
		familyEntities.forEach(familyEntity -> familyJpaRepository.save(familyEntity));
	}

	@Override
	public void updateBlocked(UUID familyId) {
		familyJpaRepository.updateBlocked(familyId.toString());
	}

}
