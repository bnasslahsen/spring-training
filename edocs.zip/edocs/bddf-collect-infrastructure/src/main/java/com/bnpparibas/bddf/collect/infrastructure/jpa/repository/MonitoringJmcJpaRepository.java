package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.entity.MonitoringJmcEntity;

@Repository
public interface MonitoringJmcJpaRepository extends JpaRepository<MonitoringJmcEntity, String> {

	@Query("select mE from MonitoringJmcEntity mE where mE.codeCallWs=:codeWs and mE.typeId=:typeId and creationDate = (select max(creationDate) from MonitoringJmcEntity where codeCallWs=:codeWs and typeId=:typeId)")
	List<MonitoringJmcEntity> findMonitoringJmcByStatusAndType(@Param("typeId") String typeId, @Param("codeWs") String codeWs);

	@Modifying
	@Transactional
	@Query(value = "delete from MONITORING_JMC where TYPE_ID  in ( select ID FROM TYPE where collect_id  in :collectIds )", nativeQuery = true)
	void deleteByCollectIds(@Param("collectIds") List<String> collectIds);

	@Modifying
	@Transactional
	@Query("delete from MonitoringJmcEntity m where m.creationDate  <= :expirationDate and (m.typeId is null or (select count(*) from TypeEntity t where t.id=m.typeId)=0)")
	void deleteExpiredValues(@Param("expirationDate") Timestamp expirationDate);

}
