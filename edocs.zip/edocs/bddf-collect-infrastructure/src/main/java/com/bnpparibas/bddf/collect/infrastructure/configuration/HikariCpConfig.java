package com.bnpparibas.bddf.collect.infrastructure.configuration;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.util.StringUtils;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
@Profile("hikari")
public class HikariCpConfig {

	@Value("${db.datasource.driverClassName}")
	private String driverClassName;

	@Value("${db.datasource.url}")
	private String url;

	@Value("${db.datasource.username}")
	private String userName;

	@Value("${db.datasource.password}")
	private String password;

	@Value("${db.datasource.maximumPoolSize}")
	private Integer maximumPoolSize;

	@Value("${db.datasource.maxLifeTime:600000}")
	private Integer maxLifeTime;

	// @Value("${db.datasource.idleTimeout}")
	// private Long idleTimeout;
	//
	// @Value("${db.datasource.leakDetectionThresholdMs}")
	// private Long leakDetectionThresholdMs;
	//
	// @Value("${db.datasource.minimumIdle}")
	// private Integer minimumIdle;

	@Bean
	public DataSource dataSource() {
		final HikariConfig config = new HikariConfig();
		config.setPoolName("POOL-HIKARI-ORACLE");
		config.setDriverClassName(driverClassName);
		config.setJdbcUrl(url);
		if (!StringUtils.isEmpty(userName)) {
			config.setUsername(userName);
		}
		if (!StringUtils.isEmpty(password)) {
			config.setPassword(password);
		}
		if (!StringUtils.isEmpty(maximumPoolSize)) {
			config.setMaximumPoolSize(maximumPoolSize);
		}
		if (!StringUtils.isEmpty(maxLifeTime)) {
			config.setMaxLifetime(maxLifeTime);
		}
		// IF (!STRINGUTILS.ISEMPTY(MINIMUMIDLE)) {
		// CONFIG.SETMINIMUMIDLE(MINIMUMIDLE);
		// }
		// IF (!STRINGUTILS.ISEMPTY(IDLETIMEOUT)) {
		// CONFIG.SETIDLETIMEOUT(IDLETIMEOUT);
		// }
		// IF (!STRINGUTILS.ISEMPTY(LEAKDETECTIONTHRESHOLDMS)) {
		// CONFIG.SETLEAKDETECTIONTHRESHOLD(LEAKDETECTIONTHRESHOLDMS);
		// }
		return new HikariDataSource(config);

	}

}
