package com.bnpparibas.bddf.collect.infrastructure.batch.monitoring;

import java.util.Optional;

import com.bnpparibas.bddf.collect.infrastructure.batch.distributed.AbstractBatch;


public abstract class AbstractBatchMonitoring extends AbstractBatch {

	public AbstractBatchMonitoring(String batchName) {
		super(batchName);

	}

	public String extractHost(String host) {
		return Optional.ofNullable(host).map(v -> v.contains(".") ? v.substring(0, v.indexOf('.')) : v).orElse("");
	}

}
