package com.bnpparibas.bddf.collect.infrastructure.entity;

import java.sql.Timestamp;
import java.util.Optional;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.domain.Persistable;

@Entity
@Table(name = "VALIDATION_PIECE")
public class ValidationPieceEntity implements java.io.Serializable, Persistable<ValidationPieceId> {

	private static final long serialVersionUID = 1L;
	private ValidationPieceId id;
	private String typeId;
	private String collectId;
	private String userId;
	private String channel;
	private String newTypeStatus;
	private Integer triesNumber;
	private Timestamp aquisitionDate;
	private String status;
	private boolean isNew;

	public ValidationPieceEntity() {
	}

	public ValidationPieceEntity(ValidationPieceId id) {
		this.id = id;
	}

	@EmbeddedId
	@AttributeOverrides({ @AttributeOverride(name = "creationDate", column = @Column(name = "CREATION_DATE", nullable = false)), @AttributeOverride(name = "pieceId", column = @Column(name = "PIECE_ID", nullable = false, length = 200)) })
	public ValidationPieceId getId() {
		return this.id;
	}

	public void setId(ValidationPieceId id) {
		this.id = id;
	}

	@Column(name = "TYPE_ID", length = 200)
	public String getTypeId() {
		return this.typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	@Column(name = "COLLECT_ID", length = 200)
	public String getCollectId() {
		return this.collectId;
	}

	public void setCollectId(String collectId) {
		this.collectId = collectId;
	}

	@Column(name = "USER_ID", length = 200)
	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Column(name = "CHANNEL", length = 3)
	public String getChannel() {
		return this.channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	@Column(name = "NEW_TYPE_STATUS", length = 50)
	public String getNewTypeStatus() {
		return this.newTypeStatus;
	}

	public void setNewTypeStatus(String newTypeStatus) {
		this.newTypeStatus = newTypeStatus;
	}

	@Column(name = "TRIES_NUMBER", precision = 22, scale = 0)
	public Integer getTriesNumber() {
		return this.triesNumber;
	}

	public void setTriesNumber(Integer triesNumber) {
		this.triesNumber = triesNumber;
	}

	@Column(name = "AQUISITION_DATE")
	public Timestamp getAquisitionDate() {
		return Optional.ofNullable(this.aquisitionDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setAquisitionDate(Timestamp aquisitionDate) {
		this.aquisitionDate = Optional.ofNullable(aquisitionDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	@Column(name = "STATUS", length = 45)
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	@Transient
	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

}
