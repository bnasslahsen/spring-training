package com.bnpparibas.bddf.collect.infrastructure.jpa.mapper;

import java.util.Optional;
import java.util.UUID;

import org.dozer.Mapper;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.owner.ClientNotification;
import com.bnpparibas.bddf.collect.infrastructure.entity.ClientNotificationEntity;

@Component
public class ClientNotificationMapper {

	private final Mapper dozerMapper;

	public ClientNotificationMapper(Mapper dozerMapper) {
		this.dozerMapper = dozerMapper;
	}

	public ClientNotification toClientNotification(ClientNotificationEntity clientNotificationEntity) {
		final ClientNotification clientNotification = dozerMapper.map(clientNotificationEntity, ClientNotification.class);
		clientNotification.setTypeId(UUID.fromString(Optional.ofNullable(clientNotificationEntity).map(ClientNotificationEntity::getId).orElse("")));
		clientNotification.setCollectId(UUID.fromString(Optional.ofNullable(clientNotificationEntity).map(ClientNotificationEntity::getCollectId).orElse("")));
		return clientNotification;
	}

	public ClientNotificationEntity toClientNotificationEntity(ClientNotification clientNotification, boolean isNew) {
		final ClientNotificationEntity clientNotificationEntity = dozerMapper.map(clientNotification, ClientNotificationEntity.class);
		clientNotificationEntity.setTypeId(clientNotification.getTypeId().toString());
		clientNotificationEntity.setCollectId(clientNotification.getCollectId().toString());
		clientNotificationEntity.setNew(isNew);
		return clientNotificationEntity;
	}

}
