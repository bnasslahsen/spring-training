package com.bnpparibas.bddf.collect.infrastructure.configuration;

import javax.persistence.EntityManagerFactory;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EntityScan({ "com.bnpparibas.bddf.collect.infrastructure.entity", "com.bnpparibas.bddf.attachment.infrastructure" })
@EnableJpaRepositories({ "com.bnpparibas.bddf.collect.infrastructure.jpa.repository", "com.bnpparibas.bddf.attachment.infrastructure" })
@EnableTransactionManagement
public class PersistenceConfig {

	@Bean(name = "transactionManagerDB")
	@Primary
	public JpaTransactionManager transactionManager(EntityManagerFactory emf) {
		return new JpaTransactionManager(emf);
	}

}
