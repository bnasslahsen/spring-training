package com.bnpparibas.bddf.collect.infrastructure.nas;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.infrastructure.repository.PieceRepositoryImpl;

@Component
public class PieceNasServiceImpl implements PieceNasService {

	private static final Logger LOG = LoggerFactory.getLogger(PieceRepositoryImpl.class);

	private static final String GENERATE_THUMBNAIL_ENABLED = "generateThumbnail.enabled";

	private final String fileDirectory;
	private final Boolean generateThumbnailEnabled;

	@Autowired
	private ThumbnailService thumbnailService;

	private final List<String> listMimeTypeOffice = Arrays.asList("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel", "application/vnd.ms-excel.sheet.macroEnabled.12",
			"application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword");

	public PieceNasServiceImpl(Environment environment) {
		this.fileDirectory = environment.getProperty("files.path");
		this.generateThumbnailEnabled = Boolean.valueOf(environment.getProperty(GENERATE_THUMBNAIL_ENABLED));
	}

	@Override
	public void deletePiece(UUID id) throws IOException {
		Files.deleteIfExists(piecePath(id));
	}

	@Override
	public void deleteThumbnail(UUID id) throws IOException {
		Files.deleteIfExists(piecePathThumbnail(id));
	}

	@Override
	public void addPiece(UUID id, ByteBuffer data, String contentType, String label) throws IOException {
		// Ajout piece normale
		final long startTimeNas = System.currentTimeMillis();
		Files.write(piecePath(id), data.array());
		final long elapsedTimeNas = System.currentTimeMillis() - startTimeNas;
		LoggerHelper.logForPerfTest(LOG, "PieceId : " + id + " Temps pour save nas : " + elapsedTimeNas + " ms");

		if (generateThumbnailEnabled) {
			try {
				if ("application/pdf".equals(contentType)) {
					thumbnailService.writeThumbnailPdf(id, data);
				} else if (!listMimeTypeOffice.contains(contentType)) {
					thumbnailService.writeImageThumbnail(id, data);
				}
			} catch (final Exception e) {
				LOG.error(CollectErrorConstants.ERR_NAS_GENERATE_THUMBNAIL, e);
			}
		}
	}

	@Override
	public ByteBuffer getPiece(UUID pieceId) throws IOException {
		final long startTimeNas = System.currentTimeMillis();
		final ByteBuffer pieceData = ByteBuffer.wrap(Files.readAllBytes(piecePath(pieceId)));
		LoggerHelper.logForPerfTest(LOG, "PieceId : " + pieceId + " Temps pour getPiece NAS : " + (System.currentTimeMillis() - startTimeNas) + " ms");
		return pieceData;
	}

	@Override
	public ByteBuffer getThumbnail(UUID pieceId) throws IOException {
		return ByteBuffer.wrap(Files.readAllBytes(piecePathThumbnail(pieceId)));
	}

	private Path piecePath(UUID id) {
		return Paths.get(fileDirectory + id.toString());
	}

	private Path piecePathThumbnail(UUID id) {
		return Paths.get(new StringBuilder().append(fileDirectory).append(id.toString()).append("_thumbnail").toString());
	}

}
