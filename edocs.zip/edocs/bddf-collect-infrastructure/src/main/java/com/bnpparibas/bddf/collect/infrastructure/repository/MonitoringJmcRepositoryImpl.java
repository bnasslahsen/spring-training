package com.bnpparibas.bddf.collect.infrastructure.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.domain.piece.monitoring.jmc.MonitoringJmcRepository;
import com.bnpparibas.bddf.collect.infrastructure.entity.MonitoringJmcEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.MonitoringJmcJpaRepository;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.RepositoryImpl
@Repository
public class MonitoringJmcRepositoryImpl implements MonitoringJmcRepository {

	@Autowired
	private MonitoringJmcJpaRepository monitoringJmcJpaRepository;

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void saveMonitoringJMC(MonitoringJmcEntity monitoringJMC) {
		monitoringJmcJpaRepository.save(monitoringJMC);
	}

	@Transactional
	public List<MonitoringJmcEntity> findMonitoringJmcByStatusAndType(String typId, String codeWs) {
		return monitoringJmcJpaRepository.findMonitoringJmcByStatusAndType(typId, codeWs);
	}

	@Override
	public boolean isLastInjectDataError(String typId) {
		final List<MonitoringJmcEntity> monitorings = findMonitoringJmcByStatusAndType(typId, "D5");
		return monitorings != null && !monitorings.isEmpty() && !"204".equals(monitorings.get(0).getStatusCallWs());
	}

}
