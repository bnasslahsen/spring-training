package com.bnpparibas.bddf.collect.infrastructure.repository;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.MediaType;

public class MimeTypeUtils {
	
	private static HashMap<String, String> mimeTypeToArchivingFormat = new HashMap<>();
	
	private MimeTypeUtils() {
		throw new IllegalStateException();
	}
	
	static {
		mimeTypeToArchivingFormat.put(MediaType.APPLICATION_PDF_VALUE, "PDF");
		mimeTypeToArchivingFormat.put(MediaType.IMAGE_PNG_VALUE, "PNG");
		mimeTypeToArchivingFormat.put(MediaType.IMAGE_GIF_VALUE, "GIF");
		mimeTypeToArchivingFormat.put("image/tif", "TIF");
		mimeTypeToArchivingFormat.put("image/tiff", "TIFF");
		mimeTypeToArchivingFormat.put(MediaType.IMAGE_JPEG_VALUE, "JPEG");
		mimeTypeToArchivingFormat.put("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "DOC");
		mimeTypeToArchivingFormat.put("application/msword", "DOC");
		mimeTypeToArchivingFormat.put("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "XLS");
		mimeTypeToArchivingFormat.put("application/vnd.ms-excel", "XLS");
		mimeTypeToArchivingFormat.put("application/vnd.ms-excel.sheet.macroEnabled.12", "XLS");
		
	}
	
	public static Map<String,String> mimeTypeToArchivingFormat() {
		return mimeTypeToArchivingFormat;
	}
	
	
	
	 
}
