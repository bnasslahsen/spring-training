package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.entity.DocReferenceEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.DocReferenceJpaRepository;

@Component
public class PurgeUtils {
	@Value("${collect-abandon.ttl.month}")
	private Integer collectAbandonTTLMonth;
	@Value("${collect-abandon.ttl.day}")
	private Integer collectAbandonTTLDay;
	@Value("${purge.collect-ab.ttl.month}")
	private Integer purgeCollectAbTTLMonth;
	@Value("${purge.collect-ab.ttl.day}")
	private Integer purgeCollectAbTTLDay;
	@Value("${purge.collect-cl.ttl.month}")
	private Integer purgeCollectClTTLMonth;
	@Value("${purge.collect-cl.ttl.day}")
	private Integer purgeCollectClTTLDay;
	@Value("${purge.piece-tp-dp.ttl.month}")
	private Integer purgePieceTpDpTTLMonth;
	@Value("${purge.piece-tp-dp.ttl.day}")
	private Integer purgePieceTpDpTTLDay;
	@Value("${files.nas-retention-days}")
	private Integer filesNasRetentionDays;
	@Autowired
	private DocReferenceJpaRepository docReferenceJpaRepository;

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void delete(DocReferenceEntity docRef) {
		docReferenceJpaRepository.delete(docRef);

	}

	public Instant buildPurgeDate(PurgeType type) {

		ZonedDateTime todayMidnight = ZonedDateTime.now(ZoneId.systemDefault()).truncatedTo(ChronoUnit.DAYS);

		switch (type) {
		case COL_EC_AB:
			todayMidnight = todayMidnight.minusMonths(collectAbandonTTLMonth);
			todayMidnight = todayMidnight.minusDays(collectAbandonTTLDay);
			break;
		case COL_AB_SU:
			todayMidnight = todayMidnight.minusMonths(purgeCollectAbTTLMonth);
			todayMidnight = todayMidnight.minusDays(purgeCollectAbTTLDay);
			break;
		case COL_CL_SU:
			todayMidnight = todayMidnight.minusMonths(purgeCollectClTTLMonth);
			todayMidnight = todayMidnight.minusDays(purgeCollectClTTLDay);
			break;
		case PIECE_TP_DP:
			todayMidnight = todayMidnight.minusMonths(purgePieceTpDpTTLMonth);
			todayMidnight = todayMidnight.minusDays(purgePieceTpDpTTLDay);
			break;
		default:
			throw new IllegalArgumentException();
		}

		return todayMidnight.toInstant();

	}

	protected Instant calculateNasexpirationDate() {
		final ZonedDateTime todayMidnight = ZonedDateTime.now(ZoneId.systemDefault()).truncatedTo(ChronoUnit.DAYS);
		return todayMidnight.plusDays(-filesNasRetentionDays).toInstant();
	}

}
