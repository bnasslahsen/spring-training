package com.bnpparibas.bddf.collect.infrastructure.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.domain.Persistable;

@Entity
@Table(name = "INDEXE_PIECE")
public class IndexePiece implements java.io.Serializable, Persistable<IndexePieceId> {

	private static final long serialVersionUID = 1L;
	private IndexePieceId id;
	private PieceEntity piece;
	private IndexeEntity indexe;
	private String extractedValue;
	private String statusControl;
	private Integer acceptancePercentage;
	private boolean isNew;

	public IndexePiece() {
	}

	public IndexePiece(IndexePieceId id, PieceEntity piece, IndexeEntity indexe) {
		this.id = id;
		this.piece = piece;
		this.indexe = indexe;
	}

	@Override
	@EmbeddedId
	@AttributeOverrides({ @AttributeOverride(name = "indexeId", column = @Column(name = "INDEXE_ID", nullable = false, length = 100)), @AttributeOverride(name = "pieceId", column = @Column(name = "PIECE_ID", nullable = false, length = 100)) })
	public IndexePieceId getId() {
		return this.id;
	}

	public void setId(IndexePieceId id) {
		this.id = id;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PIECE_ID", nullable = false, insertable = false, updatable = false)
	public PieceEntity getPiece() {
		return this.piece;
	}

	public void setPiece(PieceEntity piece) {
		this.piece = piece;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "INDEXE_ID", nullable = false, insertable = false, updatable = false)
	public IndexeEntity getIndexe() {
		return this.indexe;
	}

	public void setIndexe(IndexeEntity indexe) {
		this.indexe = indexe;
	}

	@Column(name = "EXTRACTED_VALUE", length = 200)
	public String getExtractedValue() {
		return this.extractedValue;
	}

	public void setExtractedValue(String extractedValue) {
		this.extractedValue = extractedValue;
	}

	@Column(name = "STATUS_CONTROL", length = 5)
	public String getStatusControl() {
		return this.statusControl;
	}

	public void setStatusControl(String statusControl) {
		this.statusControl = statusControl;
	}

	@Column(name = "ACCEPTANCE_PERCENTAGE", precision = 22, scale = 0)
	public Integer getAcceptancePercentage() {
		return this.acceptancePercentage;
	}

	public void setAcceptancePercentage(Integer acceptancePercentage) {
		this.acceptancePercentage = acceptancePercentage;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		boolean equal = true;
		if (this == obj) {
			equal = true;
		}
		if (obj == null) {
			equal = false;
		}
		if (!(obj instanceof IndexePiece)) {
			equal = false;
		}
		final IndexePiece other = (IndexePiece) obj;
		if (id == null) {
			if (other.id != null) {
				equal = false;
			}
		} else if (other != null && !id.equals(other.id)) {
			equal = false;
		}
		return equal;
	}

	@Override
	@Transient
	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

}
