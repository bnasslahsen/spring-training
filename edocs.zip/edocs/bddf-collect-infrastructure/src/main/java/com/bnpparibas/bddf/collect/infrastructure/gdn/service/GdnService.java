package com.bnpparibas.bddf.collect.infrastructure.gdn.service;

import java.nio.ByteBuffer;
import java.util.Map;
import java.util.UUID;

import com.bnpp.jdf.connector.exception.AbstractConnectorException;
import com.bnpp.jdf.connector.exception.ConnectorFunctionalException;
import com.bnpp.jdf.connector.exception.ConnectorTechnicalException;
import com.bnpp.jdf.deletedoc.query.DeleteDocI;
import com.bnpp.jdf.deletedoc.response.DeleteDocO;
import com.bnpp.jdf.savedoc.query.SaveDoc2I;
import com.bnpp.jdf.savedoc.response.SaveDoc2O;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.InfrastructureService
public interface GdnService {

	SaveDoc2O saveDoc(SaveDoc2I saveDoc2I, Map<String, String> params) throws AbstractConnectorException;

	SaveDoc2O saveDoc2(SaveDoc2I saveDoc2I, Map<String, String> params) throws AbstractConnectorException;

	SaveDoc2O saveAttachment(SaveDoc2I saveDoc2I, Map<String, String> params) throws ConnectorTechnicalException, ConnectorFunctionalException;

	ByteBuffer getDocByIdGDN(UUID idPiece, String callingUser, String userType, String idGdn);

	DeleteDocO deleteDoc(DeleteDocI in, Map<String, String> params) throws ConnectorTechnicalException, ConnectorFunctionalException;

	DeleteDocO deleteDocWithRetry(DeleteDocI in, Map<String, String> params) throws AbstractConnectorException;

}
