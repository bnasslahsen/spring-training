package com.bnpparibas.bddf.collect.infrastructure.ami.mocking;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusFolderDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusPieceDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.UploadDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.RequestWSJMCType;
import com.bnpparibas.bddf.collect.domain.type.LadRadRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AmiTestImpl implements LadRadRepository {

	private static final Logger LOGGER = LoggerFactory.getLogger(AmiTestImpl.class);

	@Override
	public URI uploadDocument(String externalRef, UploadDocumentDTO uploadDocumentDTO, InputStream document, UUID idType) {
		try {
			return new URI("http://localhost");
		} catch (final URISyntaxException e) {
			LOGGER.error(e.getMessage(), e);
			return null;
		}
	}

	@Override
	public void updatePiece(String correctedIndexes, String pieceId, UUID idType) {
		return;
	}

	@Override
	public void traceCallWS(String idEntity, UUID idType, RequestWSJMCType requestWSJMCType, HttpStatus httpStatus, String responseBody, String requestBody, Integer duration) {
		return;
	}

	@Override
	public void sendDocumentToAmi(String documentRef, UUID typeId, String amiJason) {
		return;
	}

	@Override
	public void injectRefDataFolder(String externalRef, String fieldsFolderJson, UUID idType) {
		return;
	}

	@Override
	public StatusPieceDTO getStatusPiece(String idPieceJMC, UUID idType) {
		return null;
	}

	@Override
	public StatusFolderDTO getStatusFolder(String externalRef, UUID idType) {
		return null;
	}

	@Override
	public StatusDocumentDTO getStatusDocument(String externalRef, UUID idType) {
		final String json = "{\"status\":2,\"reference\":\"1Difpht5eS\",\"total_pages\":1,\"processed_pages\":1,\"creation_date\":\"2019-01-15 14:40:55\",\"external_ref\":\"b33f1a9a-db96-4845-991a-d94c1d3c01f2-1\",\"pages\":[{\"status\":2,\"reference\":\"1EdDY2snEA\",\"page_number\":1,\"creation_date\":\"2019-01-15 14:40:56\",\"processed_pieces\":1,\"pieces\":[{\"status\":3,\"reference\":\"08Duwjpiyz\",\"type\":\"identity_card_recto\",\"document_family\":\"identity\",\"document_type\":\"identity_card\",\"creation_date\":\"2019-01-15 15:24:53\",\"rejection_causes\":[{\"code\":\"CONTROL_IDX_AMI_NR\",\"value\":\"body_usual_name\"}],\"image_quality_alerts\":null,\"piece_order\":1,\"match_expected_doc_family\":0,\"match_expected_doc_type\":0,\"match_expected_type\":0,\"business_status\":null,\"ref_doc_family\":\"address_proof\",\"images\":{\"image_original\":{\"selected\":0,\"href\":\"\\/images\\/piece\\/fRnYPyffgj\"},\"image_warped\":{\"selected\":0,\"href\":\"\\/images\\/piece\\/00MCVIPXqw\"}},\"links\":{\"data\":{\"href\":\"\\/pieces\\/08Duwjpiyz\"},\"status\":{\"href\":\"\\/pieces\\/08Duwjpiyz\\/status\"},\"rawdata\":{\"href\":\"\\/pieces\\/08Duwjpiyz\\/rawdata\"},\"document\":{\"href\":\"\\/documents\\/1Difpht5eS\\/status\"},\"page\":{\"href\":\"\\/pages\\/1EdDY2snEA\\/status\"},\"update\":{\"href\":\"\\/pieces\\/08Duwjpiyz\\/update\"},\"differed_time_update\":{\"href\":\"\\/differed-time\\/pieces\\/08Duwjpiyz\\/update\"},\"deactivate\":{\"href\":\"\\/pieces\\/08Duwjpiyz\\/deactivate\"},\"force_piece_type\":{\"href\":\"\\/pieces\\/08Duwjpiyz\\/forcePieceType\"},\"force_piece_business_status\":{\"href\":\"\\/pieces\\/08Duwjpiyz\\/forcePieceBusinessStatus\"},\"update-document-family\":{\"href\":\"\\/pieces\\/08Duwjpiyz\\/updatePieceDocumentFamily\"}}}],\"rejection_causes\":null,\"image_quality_alerts\":null,\"business_status\":9,\"ref_doc_family\":\"address_proof\",\"images\":{\"image_original\":{\"href\":\"\\/images\\/page\\/iTpgJGOfbH\"},\"image_warped\":{\"href\":\"\\/images\\/page\\/K9qmqwD9RI\"}},\"links\":{\"status\":{\"href\":\"\\/pages\\/1EdDY2snEA\\/status\"},\"create_piece\":{\"href\":\"\\/pages\\/1EdDY2snEA\\/createPiece\"},\"update-document-family\":{\"href\":\"\\/pages\\/1EdDY2snEA\\/updateDocumentFamily\"},\"deactivate\":{\"href\":\"\\/pages\\/1EdDY2snEA\\/deactivate\"},\"document\":{\"href\":\"\\/documents\\/1Difpht5eS\\/status\"}}}],\"business_status\":null,\"rejection_causes\":null,\"expected_doc_family\":null,\"expected_doc_type\":null,\"expected_type\":null,\"technical_hash_checked\":0,\"ref_doc_family\":null,\"differed_time_status\":-2,\"differed_time_status_list\":{\"back_td_outsource_ho_manual\":[{\"reference\":\"1gq8XfTX5B\",\"mode\":\"manual\",\"status\":2,\"start_date\":\"2019-01-15 14:41:01\",\"end_date\":\"2019-01-15 15:25:03\"}]},\"links\":{\"delete\":{\"href\":\"\\/documents\\/1Difpht5eS\\/delete\"},\"outsource\":{\"href\":\"\\/documents\\/1Difpht5eS\\/outsource\"}}}";
		final ObjectMapper objectMapper = new ObjectMapper();
		try {
			return objectMapper.readValue(json, StatusDocumentDTO.class);
		} catch (final IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return null;
	}

	@Override
	public String getPiece(String idPieceJMC, UUID idType) {
		return "{\"fields\":{\"name\":{\"kind\":\"extracted\",\"value\":\"BERGERON\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"firstname\":{\"kind\":\"extracted\",\"value\":\"VINCENT\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"gender\":{\"kind\":\"extracted\",\"value\":\"M\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":[\"M\",\"F\"],\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"birth_date\":{\"kind\":\"extracted\",\"value\":\"1992-01-09\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"birth_date_key\":{\"kind\":\"extracted\",\"value\":\"5\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":null},\"nationality\":{\"kind\":\"extracted\",\"value\":\"FRA\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"piece_number\":{\"kind\":\"extracted\",\"value\":\"160369103287\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"piece_number_key\":{\"kind\":\"extracted\",\"value\":\"8\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":null},\"issue_date\":{\"kind\":\"extracted\",\"value\":\"2016-03-01\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"expiration_date\":{\"kind\":\"computed\",\"value\":\"2031-03-31\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"body_name\":{\"kind\":\"extracted\",\"value\":\"BERGERON\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"body_usual_name\":{\"kind\":\"extracted\",\"value\":\"\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":0,\"message\":\"missing_piece_data_value\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"body_firstname\":{\"kind\":\"extracted\",\"value\":\"VINCENT\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"body_gender\":{\"kind\":\"extracted\",\"value\":\"M\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":[\"M\",\"F\"],\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"body_birth_date\":{\"kind\":\"extracted\",\"value\":\"09 01 1992\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"body_piece_number\":{\"kind\":\"extracted\",\"value\":\"160369103287\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"body_birth_place\":{\"kind\":null,\"value\":\"\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":0,\"message\":\"missing_piece_data_value\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"body_other_firstnames\":{\"kind\":null,\"value\":null,\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":0,\"message\":\"missing_piece_data_value\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"photo_initials\":{\"kind\":\"extracted\",\"value\":\"BV\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"mrz_lines\":{\"kind\":\"corrected\",\"value\":\"IDFRABERGERON<<<<<<<<<<<<<<<<<6911501603691032878VINCENT<<<<<<<9201095M1\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"mrz_lines_key\":{\"kind\":\"extracted\",\"value\":\"1\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":null}},\"validity_controls\":{\"back\":{\"MRZ_OVERALL\":\"OK\",\"BIRTHDAY\":\"OK\",\"DOCUMENT_NUMBER\":\"OK\",\"MRZ_FORMAT\":\"OK\"},\"front\":{\"identity_is_adult\":\"OK\",\"identity_not_expired\":\"OK\"}},\"conformity_controls\":{\"dossier_gender\":\"OK\",\"identity_card_issue_date\":\"NOT_APPLICABLE_KO\",\"identity_card_expiration_date\":\"NOT_APPLICABLE_KO\",\"identity_diff_mrz_body_name\":\"OK\",\"identity_diff_mrz_body_gender\":\"OK\",\"identity_diff_mrz_body_birth_date\":\"OK\",\"identity_diff_mrz_body_piece_number\":\"OK\",\"identity_diff_mrz_body_firstname\":\"OK\",\"dossier_body_gender\":\"OK\",\"dossier_body_birth_date\":\"NOT_APPLICABLE_KO\"},\"controls\":{\"fraud_controls\":{\"fraud_initials_not_conform\":{\"status\":\"NOT_APPLICABLE_KO\",\"kind\":\"computed\"},\"fraud_initials_chars_count\":{\"status\":\"OK\",\"kind\":\"computed\"},\"fraud_blacklist\":{\"status\":\"OK\",\"kind\":\"computed\"},\"fraud_document_creator\":{\"status\":\"NOT_APPLICABLE_WARNING\",\"kind\":\"computed\"}},\"validity_controls\":{\"MRZ_OVERALL\":{\"status\":\"OK\",\"kind\":\"computed\"},\"BIRTHDAY\":{\"status\":\"OK\",\"kind\":\"computed\"},\"DOCUMENT_NUMBER\":{\"status\":\"OK\",\"kind\":\"computed\"},\"MRZ_FORMAT\":{\"status\":\"OK\",\"kind\":\"computed\"},\"identity_is_adult\":{\"status\":\"OK\",\"kind\":\"computed\"},\"identity_not_expired\":{\"status\":\"OK\",\"kind\":\"computed\"}},\"conformity_controls\":{\"dossier_gender\":{\"status\":\"OK\",\"kind\":\"computed\"},\"identity_card_issue_date\":{\"status\":\"NOT_APPLICABLE_KO\",\"kind\":\"computed\"},\"identity_card_expiration_date\":{\"status\":\"NOT_APPLICABLE_KO\",\"kind\":\"computed\"},\"identity_diff_mrz_body_name\":{\"status\":\"OK\",\"kind\":\"computed\"},\"identity_diff_mrz_body_gender\":{\"status\":\"OK\",\"kind\":\"computed\"},\"identity_diff_mrz_body_birth_date\":{\"status\":\"OK\",\"kind\":\"computed\"},\"identity_diff_mrz_body_piece_number\":{\"status\":\"OK\",\"kind\":\"computed\"},\"identity_diff_mrz_body_firstname\":{\"status\":\"OK\",\"kind\":\"computed\"},\"dossier_body_gender\":{\"status\":\"OK\",\"kind\":\"computed\"},\"dossier_body_birth_date\":{\"status\":\"NOT_APPLICABLE_KO\",\"kind\":\"computed\"}}},\"type\":\"identity_card_recto\",\"document_family\":\"identity\",\"document_type\":\"identity_card\",\"mandatory\":null,\"data_type\":null,\"business_status\":null,\"creation_date\":\"2019-01-15 15:24:53\",\"last_dossier_analyze_date\":\"19-01-23 17:25:02\",\"fraud_controls\":{\"fraud_initials_not_conform\":\"NOT_APPLICABLE_KO\",\"fraud_initials_chars_count\":\"OK\",\"fraud_blacklist\":\"OK\",\"fraud_document_creator\":\"NOT_APPLICABLE_WARNING\"},\"images\":{\"image_original\":{\"selected\":0,\"href\":\"\\/images\\/piece\\/fRnYPyffgj\"},\"image_warped\":{\"selected\":0,\"href\":\"\\/images\\/piece\\/00MCVIPXqw\"}},\"links\":{\"data\":{\"href\":\"\\/pieces\\/08Duwjpiyz\"},\"status\":{\"href\":\"\\/pieces\\/08Duwjpiyz\\/status\"},\"rawdata\":{\"href\":\"\\/pieces\\/08Duwjpiyz\\/rawdata\"},\"document\":{\"href\":\"\\/documents\\/1Difpht5eS\\/status\"},\"page\":{\"href\":\"\\/pages\\/1EdDY2snEA\\/status\"},\"update\":{\"href\":\"\\/pieces\\/08Duwjpiyz\\/update\"},\"differed_time_update\":{\"href\":\"\\/differed-time\\/pieces\\/08Duwjpiyz\\/update\"},\"deactivate\":{\"href\":\"\\/pieces\\/08Duwjpiyz\\/deactivate\"},\"force_piece_type\":{\"href\":\"\\/pieces\\/08Duwjpiyz\\/forcePieceType\"}}}";
	}

	@Override
	public String getFolder(String externalRef, UUID idType) {
		return "";
	}

	@Override
	public void forcePieceType(String typeJmcJason, String idEmptyPieceJmc, UUID idType) {
		return;
	}

	@Override
	public void deleteFolder(String folderExternalRef, UUID idType) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void deleteDocument(String externalRef, UUID idType) {
		throw new UnsupportedOperationException();
	}

	@Override
	public URI createPiece(String typeJmcJason, String pageId, UUID idType) {
		return null;
	}

	@Override
	public URI createFolder(String externalRef, String createFolderJson, UUID idType) {
		return null;
	}

	@Override
	public void analyseFolder(String externalRef, UUID idType) {
		return;
	}

}
