package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.entity.ValidationPieceEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.ValidationPieceId;

@Repository
public interface ValidationPieceJpaRepository extends JpaRepository<ValidationPieceEntity, ValidationPieceId> {

	@Query("select vPE from ValidationPieceEntity vPE where id.creationDate = :timestamp")
	List<ValidationPieceEntity> getByCreationDate(@Param("timestamp") Timestamp timestamp);
	
	@Modifying
	@Query("delete from ValidationPieceEntity vPE where id.pieceId = :pieceId")
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	void deleteByPieceId(@Param("pieceId") String pieceId);

}
