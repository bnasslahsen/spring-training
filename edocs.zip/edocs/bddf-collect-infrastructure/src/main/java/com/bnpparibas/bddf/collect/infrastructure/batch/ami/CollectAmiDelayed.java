package com.bnpparibas.bddf.collect.infrastructure.batch.ami;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.domain.type.AmiBatchStatus;
import com.bnpparibas.bddf.collect.infrastructure.batch.distributed.AbstractBatch;
import com.bnpparibas.bddf.collect.infrastructure.entity.AmiBatchEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.AmiBatchJpaRepository;
import com.google.common.base.Optional;

@Component
public class CollectAmiDelayed extends AbstractBatch {

	private static final Logger LOG = LoggerFactory.getLogger(CollectAmiDelayed.class);

	private static final String BATCH_AMI_INITIAL = "batchAmi.time.initial";
	private static final String BATCH_AMI_PROGRESS = "batchAmi.time.progress";
	private static final String BATCH_AMI_MAX = "batchAmi.time.max";
	private static final String BATCH_AMI_MAX_EXEC_TIME = "batchAmi.maxExecTime";

	@Autowired
	private AmiBatchJpaRepository amiBatchJpaRepository;

	@Autowired
	private AmiDelayedBatchHandler amiDelayedBatchUtils;

	@Autowired
	private Environment env;

	public CollectAmiDelayed() {
		super("COLLECT_AMI_DELAYED");
	}

	@Scheduled(cron = "${batchAmi.cron}")
	@Override
	public void scheduledStart() {
		startBatch();
	}

	@Override
	public void execute() {
		final List<CompletableFuture<Void>> tasks = new ArrayList<>();
		LoggerHelper.logForPerfTest(LOG, "batch amiDelayed before findByStatus" + " (thread id " + Thread.currentThread().getId() + ")");
		amiBatchJpaRepository.findByStatus(Arrays.asList(AmiBatchStatus.IN_PROGRESS.getCode(), AmiBatchStatus.IN.getCode())).forEach(amiBatchEntity -> {
			if (isTimeout(amiBatchEntity)) {
				final CompletableFuture<Void> task = amiDelayedBatchUtils.handleTimeout(amiBatchEntity, amiBatchEntity.getTypeId());
				tasks.add(task);
			} else if (isEligibleForBatchProgress(amiBatchEntity) || isEligibleForBatchInitial(amiBatchEntity)) {
				LoggerHelper.logForPerfTest(LOG, "batch amiDelayed création du future pour le type " + amiBatchEntity.getId() + " (thread id " + Thread.currentThread().getId() + ")");
				final CompletableFuture<Void> task = amiDelayedBatchUtils.handle(amiBatchEntity, amiBatchEntity.getTypeId());
				tasks.add(task);
				LoggerHelper.logForPerfTest(LOG, "batch amiDelayed fin création du future pour le type " + amiBatchEntity.getId() + " (thread id " + Thread.currentThread().getId() + ")");
			}
		});
		LoggerHelper.logForPerfTest(LOG, "batch amiDelayed after findByStatus" + " (thread id " + Thread.currentThread().getId() + ")");

		try {
			if(CollectionUtils.isNotEmpty(tasks)) {				
				CompletableFuture.allOf(tasks.toArray(new CompletableFuture[0])).get(Long.valueOf(env.getProperty(BATCH_AMI_MAX_EXEC_TIME)), TimeUnit.MILLISECONDS);
			}
		} catch (InterruptedException | ExecutionException | TimeoutException e) {
			LOG.error("COLLECT_AMI_DELAYED batch in error : ", e);

		}

	}

	private boolean isEligibleForBatchInitial(AmiBatchEntity amiBatch) {
		final Instant now = Instant.now();
		final Instant initialSent = amiBatch.getInitialSent().toInstant();
		return AmiBatchStatus.IN.getCode().equals(amiBatch.getStatus()) && now.isAfter(initialSent.plus(Long.valueOf(env.getProperty(BATCH_AMI_INITIAL)), ChronoUnit.MILLIS));
	}

	private boolean isEligibleForBatchProgress(AmiBatchEntity amiBatch) {
		final Instant now = Instant.now();
		final Instant lastSent = Optional.fromNullable(amiBatch.getLastSent()).or(Timestamp.from(now)).toInstant();
		return AmiBatchStatus.IN_PROGRESS.getCode().equals(amiBatch.getStatus()) && now.isAfter(lastSent.plus(Long.valueOf(env.getProperty(BATCH_AMI_PROGRESS)), ChronoUnit.MILLIS));
	}

	private boolean isTimeout(AmiBatchEntity amiBatch) {
		final Instant now = Instant.now();
		final Instant initialSent = amiBatch.getInitialSent().toInstant();
		return now.isAfter(initialSent.plus(Long.valueOf(env.getProperty(BATCH_AMI_MAX)), ChronoUnit.MILLIS));
	}

}
