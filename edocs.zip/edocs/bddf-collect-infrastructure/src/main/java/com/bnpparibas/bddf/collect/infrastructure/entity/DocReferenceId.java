package com.bnpparibas.bddf.collect.infrastructure.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class DocReferenceId implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private String ownerId;
	private String edocType;
	private String referencePieceId;

	public DocReferenceId() {
	}

	public DocReferenceId(String ownerId, String edocType, String referencePieceId) {
		this.ownerId = ownerId;
		this.edocType = edocType;
		this.referencePieceId = referencePieceId;
	}

	@Column(name = "OWNER_ID", nullable = false, length = 17)
	public String getOwnerId() {
		return this.ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	@Column(name = "EDOC_TYPE", nullable = false, length = 17)
	public String getEdocType() {
		return this.edocType;
	}

	@Column(name = "REFERENCE_PIECE_ID", length = 100)
	public String getReferencePieceId() {
		return this.referencePieceId;
	}

	public void setReferencePieceId(String referencePieceId) {
		this.referencePieceId = referencePieceId;
	}

	public void setEdocType(String edocType) {
		this.edocType = edocType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((edocType == null) ? 0 : edocType.hashCode());
		result = prime * result + ((ownerId == null) ? 0 : ownerId.hashCode());
		result = prime * result + ((referencePieceId == null) ? 0 : referencePieceId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof DocReferenceId)) {
			return false;
		}
		final DocReferenceId other = (DocReferenceId) obj;
		if (edocType == null) {
			if (other.edocType != null) {
				return false;
			}
		} else if (!edocType.equals(other.edocType)) {
			return false;
		}
		if (ownerId == null) {
			if (other.ownerId != null) {
				return false;
			}
		} else if (!ownerId.equals(other.ownerId)) {
			return false;
		}
		if (referencePieceId == null) {
			if (other.referencePieceId != null) {
				return false;
			}
		} else if (!referencePieceId.equals(other.referencePieceId)) {
			return false;
		}
		return true;
	}

}
