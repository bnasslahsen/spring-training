package com.bnpparibas.bddf.collect.infrastructure.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.domain.Persistable;

@Entity
@Table(name = "indexe")
public class IndexeEntity implements java.io.Serializable, Persistable<String> {

	private static final long serialVersionUID = 1L;
	private String id;
	private TypeEntity type;
	private String code;
	private String label;
	private String category;
	private Boolean indexable;
	private String referenceValue;
	private String extractedValue;
	private String correctedValue;
	private String format;
	private Integer position;
	private String statusControl;
	private String messageControl;
	private String ownerIndex;
	private String additionalInformation;
	private Boolean videoCoding;
	private String groupLabel;
	private Set<IndexePiece> indexePieces = new HashSet<IndexePiece>(0);
	private boolean isNew;

	public IndexeEntity() {
	}

	public IndexeEntity(String id, TypeEntity type) {
		this.id = id;
		this.type = type;
	}

	public IndexeEntity(String id, TypeEntity type, String code, String label, String category, Boolean indexable, String referenceValue, String correctedValue, String format, Integer postion, String statusControl, String messageControl, String ownerIndex,
			Set<IndexePiece> indexePieces) {
		this.id = id;
		this.type = type;
		this.code = code;
		this.label = label;
		this.category = category;
		this.indexable = indexable;
		this.referenceValue = referenceValue;
		this.correctedValue = correctedValue;
		this.format = format;
		this.position = postion;
		this.statusControl = statusControl;
		this.messageControl = messageControl;
		this.ownerIndex = ownerIndex;
		this.indexePieces = indexePieces;
	}

	@Override
	@Id

	@Column(name = "ID", unique = true, nullable = false, length = 100)
	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TYPE_ID", nullable = false)
	public TypeEntity getType() {
		return this.type;
	}

	public void setType(TypeEntity type) {
		this.type = type;
	}

	@Column(name = "CODE", length = 17)
	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Column(name = "LABEL", length = 200)
	public String getLabel() {
		return this.label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	@Column(name = "CATEGORY", length = 2)
	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Column(name = "INDEXABLE", precision = 22, scale = 0)
	public Boolean getIndexable() {
		return this.indexable;
	}

	public void setIndexable(Boolean indexable) {
		this.indexable = indexable;
	}

	@Column(name = "REFERENCE_VALUE", length = 200)
	public String getReferenceValue() {
		return this.referenceValue;
	}

	public void setReferenceValue(String referenceValue) {
		this.referenceValue = referenceValue;
	}

	@Column(name = "CORRECTED_VALUE", length = 200)
	public String getCorrectedValue() {
		return this.correctedValue;
	}

	public void setCorrectedValue(String correctedValue) {
		this.correctedValue = correctedValue;
	}

	@Column(name = "EXTRACTED_VALUE", length = 200)
	public String getExtractedValue() {
		return extractedValue;
	}

	public void setExtractedValue(String extractedValue) {
		this.extractedValue = extractedValue;
	}

	@Column(name = "FORMAT", length = 1)
	public String getFormat() {
		return this.format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	@Column(name = "POSTION", precision = 22, scale = 0)
	public Integer getPosition() {
		return this.position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	@Column(name = "STATUS_CONTROL", length = 12)
	public String getStatusControl() {
		return this.statusControl;
	}

	public void setStatusControl(String statusControl) {
		this.statusControl = statusControl;
	}

	@Column(name = "MESSAGE_CONTROL", length = 200)
	public String getMessageControl() {
		return this.messageControl;
	}

	public void setMessageControl(String messageControl) {
		this.messageControl = messageControl;
	}

	@Column(name = "OWNER_INDEX", length = 2)
	public String getOwnerIndex() {
		return this.ownerIndex;
	}

	public void setOwnerIndex(String ownerIndex) {
		this.ownerIndex = ownerIndex;
	}

	@Column(name = "ADDITIONAL_INFORMATION", length = 200)
	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	@OneToMany(fetch = FetchType.EAGER, cascade = { CascadeType.ALL }, mappedBy = "indexe", orphanRemoval = true)
	public Set<IndexePiece> getIndexePieces() {
		return this.indexePieces;
	}

	public void setIndexePieces(Set<IndexePiece> indexePieces) {
		this.indexePieces = indexePieces;
	}

	@Column(name = "VIDEOCODING", precision = 22, scale = 0)
	public Boolean getVideoCoding() {
		return videoCoding;
	}

	public void setVideoCoding(Boolean videoCoding) {
		this.videoCoding = videoCoding;
	}

	@Column(name = "GROUP_LABEL", length = 100)
	public String getGroupLabel() {
		return groupLabel;
	}

	public void setGroupLabel(String groupLabel) {
		this.groupLabel = groupLabel;
	}

	@Override
	@Transient
	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

}
