package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import org.apache.log4j.MDC;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class BatchPurgeCollectAb extends AbstractBatchPurgeCollect {

	public BatchPurgeCollectAb() {
		super("COLLECT_PURGE_COLLECT_AB", BATCH_COLLECT, PurgeType.COL_AB_SU);
	}

	@Override
	protected boolean isDeletedOnGdn() {
		return true;
	}

	@Override
	@Scheduled(cron = "${purge.collect-ab.cron}")
	public void scheduledStart() {
		MDC.put("UserID", getBatchName());
		MDC.put("AppName", appName);
		startBatch();

	}

}
