package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Iterator;

import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.support.AbstractItemStreamItemReader;

import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.infrastructure.entity.CollectEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.CollectJpaRepository;


public class CollectClosureItemReader extends AbstractItemStreamItemReader<CollectEntity> {

	private CollectJpaRepository collectJpaRepository;
	private Iterator<CollectEntity> collectIdsIt;
	private final int blockSize;
	private int counter;
	
	public CollectClosureItemReader(CollectJpaRepository collectJpaRepository, int blockSize) {
		this.blockSize = blockSize;
		this.counter = 0;
		this.collectJpaRepository = collectJpaRepository;
	}
	
	@Override
	public void open(ExecutionContext executionContext) throws ItemStreamException {
		initCollectPage();
	}

	@Override
	public CollectEntity read() {
		if (collectIdsIt.hasNext()) {
			return collectIdsIt.next();
		} else {
			nextCollectPage();
			if (collectIdsIt.hasNext()) {
				return collectIdsIt.next(); 
			} else {
				return null;
			}
		}
	}
	
	private synchronized void initCollectPage() {
		if (collectIdsIt == null) {
			nextCollectPage();
		}
	}
	
	private synchronized void nextCollectPage() {
		collectIdsIt = collectJpaRepository.findOutdatedCollects(Timestamp.from(Instant.now()), CollectStatus.EC.name(), counter*blockSize, blockSize).iterator();
		counter++;
	}

}
