package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.infrastructure.entity.EventEntity;

@Repository
public interface EventJpaRepository extends JpaRepository<EventEntity, String> {

	@Query(value = "select eE from EventEntity eE where dtSent<=:sendDate and status=:status and replays<3")
	Page<EventEntity> findEventsOlderThanAndByStatus(@Param("sendDate") Timestamp sendDate, @Param("status") String status, Pageable pageable);

	@Modifying
	@Transactional
	@Query(value = "UPDATE event SET replays =:replays WHERE id = :eventId", nativeQuery = true)
	void updateReplays(@Param("eventId") String eventId, @Param("replays") int replays);

	@Modifying
	@Transactional
	@Query(value = "UPDATE event SET status =:status WHERE id = :eventId", nativeQuery = true)
	void updateStatus(@Param("eventId") String eventId, @Param("status") String status);

	@Modifying
	@Transactional
	@Query(value = "delete from event where ID IN ( SELECT ID_TECH from audit_event where collect_id  in :collectIds )", nativeQuery = true)
	void deleteByCollectIds(@Param("collectIds") List<String> collectIds);

}
