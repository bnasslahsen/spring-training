package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.MDC;
import org.springframework.batch.core.Step;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.support.CompositeItemWriter;
import org.springframework.batch.item.support.PassThroughItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.infrastructure.entity.CollectEntity;

@Component
public class CollectAbandon extends AbstractBatchPurge {
	@Autowired
	private CollectAbandonItemWriter collectAbandonItemWriter;
	@Autowired
	private CollectAbandonItemReader collectAbandonItemReader;

	@Value("${app.name}")
	protected String appName;

	public CollectAbandon() {
		super("COLLECT_ABANDON", "");
	}

	@Override
	protected Step step(Map<String, Long> res) {
		return stepBuilderFactory.get("step_" + getBatchName()).<CollectEntity, CollectEntity> chunk(getBatchSize()).reader(reader()).processor(new PassThroughItemProcessor<CollectEntity>()).writer(writer(res)).build();
	}

	protected ItemWriter<CollectEntity> writer(Map<String, Long> res) {
		final ItemWriter<CollectEntity> countCollectsItemWriter = new CountCollectAbItemWriter(res);
		final CompositeItemWriter<CollectEntity> compositeItemWriter = new CompositeItemWriter<>();
		final List<ItemWriter<? super CollectEntity>> delegates = new ArrayList<>();
		delegates.add(collectAbandonItemWriter);
		delegates.add(countCollectsItemWriter);
		compositeItemWriter.setDelegates(delegates);
		return compositeItemWriter;
	}

	protected ItemReader<CollectEntity> reader() {
		return collectAbandonItemReader;
	}

	@Scheduled(cron = "${collect-abandon.cron}")
	@Override
	public void scheduledStart() {
		MDC.put("UserID", getBatchName());
		MDC.put("AppName", appName);
		startBatch();
	}
}
