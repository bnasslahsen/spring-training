package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.MDC;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.builder.RepositoryItemReaderBuilder;
import org.springframework.batch.item.data.builder.RepositoryItemWriterBuilder;
import org.springframework.batch.item.support.CompositeItemWriter;
import org.springframework.batch.item.support.PassThroughItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.infrastructure.entity.PieceEntity;
import com.bnpparibas.bddf.collect.infrastructure.jpa.repository.PieceJpaRepository;

@Component
public class CollectPurgePiece extends AbstractBatchPurge {
	
	private static final String FIND_PIECES_OLDER = "findPiecesOlderThanAndByType";
	private static final String DELETE = "delete";
	private static final String FIND_PIECES_OUTDATED_NAS = "findOutdatedPiecesInNasByType";

	
	@Autowired
	private PurgePieceItemWriter purgePieceItemWriter;
	@Autowired
	private PurgePieceGdnItemWriter purgePieceGdnItemWriter;
	@Autowired
	private UpdateDeletedNasItemWriter updateDeletedNasItemWriter;
	@Autowired
	private PieceJpaRepository pieceJpaRepository;
	@Autowired
	private PurgeUtils purgeUtils;
	@Value("${purge.piece.batchSize}")
	private int batchSize;

	public CollectPurgePiece() {
		super("COLLECT_PURGE_PIECE", "");
	}

	@Override
	protected Step step(Map<String, Long> res) {
		return null;
	}
	
	@Override
	protected Job job(Map<String, Long> res) {
		return jobBuilderFactory.get("job_" + getBatchName()).incrementer(new RunIdIncrementer()).flow(step1(res)).next(step2(res)).next(step3(res)).end().build();
	}

	private Step step1(Map<String, Long> res) {
		final Timestamp purgeDatePieceTpDp = Timestamp.from(purgeUtils.buildPurgeDate(PurgeType.PIECE_TP_DP));
		final String state = PieceStates.INACTIF.getLabel();
		final String status = PieceStatus.TP.getLabel();
		return stepBuilderFactory.get("step1_" + getBatchName()).<PieceEntity, PieceEntity> chunk(batchSize).reader(reader(purgeDatePieceTpDp, state, status)).processor(new PassThroughItemProcessor<PieceEntity>()).writer(writerStep1(res)).build();
	}
	
	private ItemWriter<? super PieceEntity> writerStep1(Map<String, Long> res) {
		final ItemWriter<PieceEntity> deleteAllItemWriter =  new RepositoryItemWriterBuilder<PieceEntity>().repository(pieceJpaRepository).methodName(DELETE).build();
		final ItemWriter<PieceEntity> countPiecesItemWriter = new CountPiecesItemWriter(res);
		final CompositeItemWriter<PieceEntity> compositeItemWriter = new CompositeItemWriter<>();
		final List<ItemWriter<? super PieceEntity>> delegates = new ArrayList<>();
		delegates.add(purgePieceItemWriter);
		delegates.add(countPiecesItemWriter);
		delegates.add(deleteAllItemWriter);
		compositeItemWriter.setDelegates(delegates);
		return compositeItemWriter;
	}

	private Step step2(Map<String, Long> res) {
		final Timestamp purgeDatePieceTpDp = Timestamp.from(purgeUtils.buildPurgeDate(PurgeType.PIECE_TP_DP));
		final String state = PieceStates.INACTIF.getLabel();
		final String status = PieceStatus.DP.getLabel();
		return stepBuilderFactory.get("step2_" + getBatchName()).<PieceEntity, PieceEntity> chunk(getBatchSize()).reader(reader(purgeDatePieceTpDp, state, status)).processor(new PassThroughItemProcessor<PieceEntity>()).writer(writerStep2(res)).build();
	}
	
	private ItemWriter<? super PieceEntity> writerStep2(Map<String, Long> res) {
		final ItemWriter<PieceEntity> deleteAllItemWriter =  new RepositoryItemWriterBuilder<PieceEntity>().repository(pieceJpaRepository).methodName(DELETE).build();
		final ItemWriter<PieceEntity> countPiecesItemWriter = new CountPiecesItemWriter(res);
		final CompositeItemWriter<PieceEntity> compositeItemWriter = new CompositeItemWriter<>();
		final List<ItemWriter<? super PieceEntity>> delegates = new ArrayList<>();
		delegates.add(countPiecesItemWriter);
		delegates.add(deleteAllItemWriter);
		delegates.add(purgePieceGdnItemWriter);
		compositeItemWriter.setDelegates(delegates);
		return compositeItemWriter;
	}

	private Step step3(Map<String, Long> res) {
		final Timestamp purgeDatePieceNas = Timestamp.from(purgeUtils.calculateNasexpirationDate());
		final String state = PieceStates.ACTIF.getLabel();
		final List<String> statusPieceToDelete = Arrays.asList(PieceStatus.RC.getLabel(), PieceStatus.VA.getLabel(), PieceStatus.DP.getLabel());
		return stepBuilderFactory.get("step3_" + getBatchName()).<PieceEntity, PieceEntity> chunk(getBatchSize()).reader(readerPieceNas(purgeDatePieceNas, state, statusPieceToDelete)).processor(new PassThroughItemProcessor<PieceEntity>()).writer(writerStep3(res)).build();
	}

	private ItemWriter<? super PieceEntity> writerStep3(Map<String, Long> res) {
		final ItemWriter<PieceEntity> countPiecesItemWriter = new CountPiecesItemWriter(res);
		final CompositeItemWriter<PieceEntity> compositeItemWriter = new CompositeItemWriter<>();
		final List<ItemWriter<? super PieceEntity>> delegates = new ArrayList<>();
		delegates.add(purgePieceItemWriter);
		delegates.add(countPiecesItemWriter);
		delegates.add(updateDeletedNasItemWriter);
		compositeItemWriter.setDelegates(delegates);
		return compositeItemWriter;
	}

	@Scheduled(cron = "${purge.piece.cron}")
	@Override
	public void scheduledStart() {
		MDC.put("UserID", getBatchName());
		MDC.put("AppName", appName);
		startBatch();
	}

	protected ItemReader<PieceEntity> reader(Timestamp purgeDate, String state, String status) {
		final List<Object> arguments = Arrays.asList(purgeDate, state, status);
		final Map<String, Direction> sorts = new HashMap<>();
	    sorts.put("id", Direction.DESC);
		return new RepositoryItemReaderBuilder<PieceEntity>().repository(pieceJpaRepository).methodName(FIND_PIECES_OLDER).arguments(arguments).pageSize(getBatchSize()).sorts(sorts).saveState(false).build();
	}
	
	private ItemReader<? extends PieceEntity> readerPieceNas(Timestamp purgeDatePieceNas, String state, List<String> statusPieceToDelete) {
		final List<Object> arguments = Arrays.asList(purgeDatePieceNas, state, statusPieceToDelete);
		final Map<String, Direction> sorts = new HashMap<>();
	    sorts.put("id", Direction.DESC);
		return new RepositoryItemReaderBuilder<PieceEntity>().repository(pieceJpaRepository).methodName(FIND_PIECES_OUTDATED_NAS).arguments(arguments).pageSize(getBatchSize()).sorts(sorts).saveState(false).build();
	}

}
