package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bnpparibas.bddf.collect.infrastructure.entity.CollectEntity;

@Repository
public interface CollectJpaRepository extends JpaRepository<CollectEntity, String> {

	@Query("select cE from CollectEntity cE join cE.owners oE where oE.reference in :references and  cE.journeyCode in :journeyCodes and rownum < 101 order by creation_date")
	Set<CollectEntity> findByRefsAndJourneyCode(@Param("references") Set<String> references, @Param("journeyCodes") List<String> journeyCodes);

	@Query("select cE from CollectEntity cE join cE.owners oE where oE.reference in :references and rownum < 101 order by creation_date ")
	Set<CollectEntity> findByRefs(@Param("references") Set<String> references);

	@Query("select cE.id from CollectEntity cE")
	Collection<String> findAllIds();

	@Query("select cE from CollectEntity cE where endDate<=:timeout and status=:status")
	List<CollectEntity> findCollectsOlderThanAndByStatus(@Param("timeout") Timestamp timeOutCollect, @Param("status") String collectStatus);

	@Query("select count(cE) from CollectEntity cE where endDate<=:timeout and status=:status")
	int countCollectsOlderThanAndByStatus(@Param("timeout") Timestamp timeOutCollect, @Param("status") String collectStatus);

	@Query("select cE from CollectEntity cE where creationDate<=:timeout and status=:status")
	List<CollectEntity> findCollectsBeforeAndByStatus(@Param("timeout") Timestamp timeOutCollect, @Param("status") String collectStatus);

	@Query("select cE.id from CollectEntity cE where endDate<=:timeout and status=:status")
	List<String> findCollectIdsBeforeAndByStatus(@Param("timeout") Timestamp timeOutCollect, @Param("status") String collectStatus);

	@Query("select count(cE) from CollectEntity cE join cE.owners oE where oE.reference in :references and cE.journeyCode = :journeyCode")
	Integer countByRefsAndJourneyCode(@Param("references") Set<String> references, @Param("journeyCode") String journeyCode);

	@Query(value = "select c.* from collect c, type t, piece p where trunc(c.creation_date) <= trunc(:currentDate - c.auto_closing_delay) and c.status=:status and t.collect_id=c.id and p.type_id=t.id and p.status='VA' order by c.creation_date offset :offset rows fetch next :blockSize rows only", nativeQuery = true)
	List<CollectEntity> findOutdatedCollects(@Param("currentDate") Timestamp currentDate, @Param("status") String status, @Param("offset") int offset, @Param("blockSize") int blockSize);
}
