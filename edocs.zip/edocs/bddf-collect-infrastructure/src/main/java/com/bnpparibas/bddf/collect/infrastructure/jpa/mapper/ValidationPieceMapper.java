package com.bnpparibas.bddf.collect.infrastructure.jpa.mapper;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Optional;

import org.dozer.Mapper;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.piece.validation.ValidationPiece;
import com.bnpparibas.bddf.collect.infrastructure.entity.ValidationPieceEntity;
import com.bnpparibas.bddf.collect.infrastructure.entity.ValidationPieceId;

@Component
public class ValidationPieceMapper {

	private final Mapper dozerMapper;

	public ValidationPieceMapper(Mapper dozerMapper) {
		this.dozerMapper = dozerMapper;
	}

	public ValidationPiece toValidationPiece(ValidationPieceEntity validationPieceEntity) {
		final ValidationPiece validationPiece = dozerMapper.map(validationPieceEntity, ValidationPiece.class);
		validationPiece.setPieceId(Optional.ofNullable(validationPieceEntity).map(v -> v.getId().getPieceId()).orElse(""));
		validationPiece.setCreationDate(Date.from(Optional.ofNullable(validationPieceEntity).map(v -> validationPieceEntity.getId().getCreationDate().toInstant()).orElse(null)));
		return validationPiece;
	}

	public ValidationPieceEntity toValidationPieceEntity(ValidationPiece validationPiece) {
		final ValidationPieceEntity validationPieceEntity = dozerMapper.map(validationPiece, ValidationPieceEntity.class);
		validationPieceEntity.setId(new ValidationPieceId(Timestamp.from(Optional.ofNullable(validationPieceEntity).map(v -> validationPiece.getCreationDate().toInstant()).orElse(null)), validationPiece.getPieceId()));
		return validationPieceEntity;

	}

}
