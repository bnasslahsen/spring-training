package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.util.List;
import java.util.Map;

import org.springframework.batch.item.ItemWriter;

import com.bnpparibas.bddf.collect.infrastructure.entity.PieceEntity;

public class CountPiecesItemWriter implements ItemWriter<PieceEntity> {

	private final Map<String, Long> res;

	public CountPiecesItemWriter(Map<String, Long> res) {
		this.res = res;
	}

	@Override
	public void write(List<? extends PieceEntity> items) throws Exception {
		res.put(BatchResult.OK.getValue(), res.get(BatchResult.OK.getValue()) + Long.valueOf(items.size()));

	}

}
