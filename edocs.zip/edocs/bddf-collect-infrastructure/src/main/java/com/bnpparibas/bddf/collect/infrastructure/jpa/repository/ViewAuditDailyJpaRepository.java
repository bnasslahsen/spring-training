package com.bnpparibas.bddf.collect.infrastructure.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bnpparibas.bddf.collect.infrastructure.entity.ViewMonitoringDailyEntity;

@Repository
public interface ViewAuditDailyJpaRepository extends JpaRepository<ViewMonitoringDailyEntity, String> {

}
