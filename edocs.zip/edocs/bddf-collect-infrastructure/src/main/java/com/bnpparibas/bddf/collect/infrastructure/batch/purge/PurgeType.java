package com.bnpparibas.bddf.collect.infrastructure.batch.purge;

import java.util.Arrays;
import java.util.Optional;

public enum PurgeType {

	COL_AB_SU(1), COL_CL_SU(2), PIECE_TP_DP(3), COL_EC_AB(4), COL_EC_CL(5);

	private final int value;

	private PurgeType(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	public Optional<PurgeType> fromValue(int value) {
		return Arrays.asList(PurgeType.values()).stream().filter(p -> p.getValue() == value).findAny();
	}

}
