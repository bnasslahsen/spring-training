package com.bnpparibas.bddf.collect.infrastructure.repository;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Repository;

import com.bnp.schema.edoc_families.EdocFamilies;
import com.bnp.schema.edoc_families.EdocFamilies.EdocFamily;
import com.bnp.schema.edoc_families.ObjectFactory;
import com.bnpparibas.bddf.collect.domain.edoc.families.EdocFamiliesRepository;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.errors.TechnicalException;

@DDD.RepositoryImpl
@Repository
public class EdocFamiliesRepositoryImpl implements EdocFamiliesRepository {
	private List<EdocFamily> edocFamilies;

	public EdocFamiliesRepositoryImpl() {
		super();
	}

	@PostConstruct
	private void init() {
		try {
			final InputStream inputStream = new ClassPathResource("edoc-families.xml").getInputStream();
			final Unmarshaller unmarshaller = JAXBContext.newInstance(ObjectFactory.class).createUnmarshaller();
			edocFamilies = ((EdocFamilies) unmarshaller.unmarshal(inputStream)).getEdocFamily();
		} catch (final JAXBException | IOException e) {
			throw new TechnicalException(CollectErrorConstants.ERR_COL_TECH, e);
		}
	}

	@Override
	public List<EdocFamily> findAll() {
		return edocFamilies;
	}

}
