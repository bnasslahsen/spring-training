package com.bnpparibas.bddf.collect.application.collect.params;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Repository;

import com.bnp.schema.edoc.gdnparam.GdnParameters;
import com.bnp.schema.edoc.gdnparam.GdnParameters.Param;
import com.bnp.schema.edoc.gdnparam.ObjectFactory;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.param.GdnParamRepository;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.errors.TechnicalException;

@DDD.RepositoryImpl
@Repository
public class GdnParamRepositoryImpl implements GdnParamRepository {

	private Map<String, Long> gdnParam;

	public GdnParamRepositoryImpl() {
		super();
		try {
			final InputStream inputStream = new ClassPathResource("gdnParam.xml").getInputStream();
			final Unmarshaller unmarshaller = JAXBContext.newInstance(ObjectFactory.class).createUnmarshaller();
			final JAXBElement<?> gdnParameters = (JAXBElement<?>) unmarshaller.unmarshal(inputStream);
			gdnParam = ((GdnParameters) gdnParameters.getValue()).getParam().stream().collect(Collectors.toMap(Param::getTypeGdn, Param::getTailleLimite));
		} catch (final JAXBException | IOException e) {
			throw new TechnicalException(CollectErrorConstants.ERR_COL_TECH, e);
		}
	}

	@Override
	public Map<String, Long> getGdnParam() {
		return gdnParam;
	}

}
