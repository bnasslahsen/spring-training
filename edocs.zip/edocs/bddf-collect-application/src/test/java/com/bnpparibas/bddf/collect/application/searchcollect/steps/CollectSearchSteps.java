package com.bnpparibas.bddf.collect.application.searchcollect.steps;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.CollectDetailsDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.collect.CollectActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.CollectServiceImpl;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableSet;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CollectSearchSteps {

	private CollectActionsImpl collectActions;
	private CollectRepository collects;
	private Set<CollectDetailsDTO> collectDTOSet;
	private Set<Collect> collectSet;
	private Map<String, Set<Collect>> ownersCollects;
	private Set<Set<String>> references;
	private Set<String> journeyCodes;
	private CollectEventHandler collectEventHandler;
	private AuditGenerator auditGenerator;

	public CollectSearchSteps() {
		collectEventHandler = mock(CollectEventHandler.class);
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		collects = mock(CollectRepository.class);
		final Environment environment = mock(Environment.class);
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(false);
		final TypeValidator typeValidator = new TypeValidator();
		final CollectServiceImpl collectService = new CollectServiceImpl(collects, null, null, null, collectEventHandler, auditGenerator, environment, typeValidator, new EdocTypesRepositoryImpl(), new EdocIndexRepositoryImpl());

		collectActions = new CollectActionsImpl(collectService, new CustomMapper());
		collectActions.setEnvironment(environment);
		collectService.setFeatureManager(featureManager);
	}

	/**
	 * Get all subsets of a set
	 *
	 * @param ref
	 *            TODO fill parameter description
	 */
	public static <T> Set<Set<String>> powerSet(Set<String> ref) {
		final String[] set = ref.toArray(new String[ref.size()]);
		return IntStream.range(0, (int) Math.pow(2, set.length)).parallel() // performance improvement
				.mapToObj(e -> IntStream.range(0, set.length).filter(i -> (e & (0b1 << i)) != 0).mapToObj(i -> set[i]).collect(Collectors.toSet())).map(Function.identity()).collect(Collectors.toSet());
	}

	/**
	 * Creation of owners
	 *
	 * @param idCollect
	 */
	private void createOwners(List<List<String>> data, Collect collect) {
		final List<Owner> ownersBis = new ArrayList<Owner>();

		data.stream().skip(1).forEach(row -> {
			if (row.get(0).equals(collect.getId().toString())) {
				final Owner owner = new Owner(row.get(9), row.get(10), row.get(11), null, Integer.parseInt(row.get(12)), "", null);
				ownersBis.add(owner);
			}
		});
		collect.setOwners(new HashSet<>(ownersBis));
		ownersBis.stream().forEach(o -> {
			if (ownersCollects.containsKey(o.getReference())) {
				ownersCollects.get(o.getReference()).add(collect);
			} else {
				ownersCollects.put(o.getReference(), new HashSet<>(Collections.singleton(collect)));
			}
		});
	}

	private void createCollects(List<List<String>> data) {
		collectSet = new HashSet<Collect>();
		journeyCodes = new HashSet<String>();
		final Set<String> ref = new HashSet<String>();
		data.stream().skip(1).forEach(row -> {
			final Collect collect = new Collect(UUID.fromString(row.get(0)), row.get(1), Instant.now(), null, row.get(3), row.get(4), row.get(5), row.get(6), ImmutableSet.<String> of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIF", "TIFF"),
					ImmutableSet.<String> of(row.get(7)), ImmutableSet.<String> of(), null, row.get(8), false, false, 0, false, 0);
			collectSet.add(collect);
			ref.add(row.get(9));
			journeyCodes.add(row.get(6));
		});
		references = powerSet(ref);
	}

	private void mockOwnersCollects(String journeyCode) {
		references.forEach(refs -> {
			final Set<Collect> c = new HashSet<Collect>();
			refs.stream().forEach(r -> {
				c.addAll(ownersCollects.get(r));
			});
			final Set<String> refsOrdredList = refs.stream().sorted().collect(Collectors.toSet());
			when(collects.findByOwners(refsOrdredList, Arrays.asList(journeyCode))).thenReturn(c);
		});

	}

	/* SCENARIO 1. ***********/

	@Given("^two individual HOME collect and one in common$")
	public void two_individual_home_collect_and_one_in_common(DataTable arg1) throws Throwable {
		final List<List<String>> data = arg1.raw();
		createCollects(data);
		ownersCollects = new HashMap<>();
		collectSet.forEach(collect -> createOwners(data, collect));
		journeyCodes.forEach(j -> mockOwnersCollects(j));
	}

	@When("^I search for home solva collects owned by Jean or Marie$")
	public void i_search_for_home_solva_collects_owned_by_Jean_or_Marie() throws Throwable {
		this.collectDTOSet = collectActions.getCollectsByOwners(Arrays.asList("01740005814400000", "01740005814200000"), Arrays.asList("100000"), new Context("123456", "001"));
	}

	@Then("^I get a list of three collects$")
	public void i_get_a_list_of_three_collects() throws Throwable {
		assertEquals(3, collectDTOSet.size());
	}

	/* SCENARIO 2. ***********/
	@Given("^an individual EERBPF collect owned by Jean$")
	public void an_individual_EERBPF_collect_owned_by_Jean(DataTable arg1) throws Throwable {
		final List<List<String>> data = arg1.raw();
		createCollects(data);
		ownersCollects = new HashMap<>();
		collectSet.forEach(collect -> createOwners(data, collect));
		journeyCodes.forEach(j -> mockOwnersCollects(j));
	}

	@When("^I search for Marie collects$")
	public void i_search_for_Marie_collects() throws Throwable {
		this.collectDTOSet = collectActions.getCollectsByOwners(Arrays.asList("01740005814200000"), Arrays.asList("100000"), new Context("123456", "001"));
	}

	@Then("^I get an empty list$")
	public void i_get_an_empty_list() throws Throwable {
		assertEquals(0, collectDTOSet.size());
	}

	/* SCENARIO 3. ***********/
	@Given("^an individual HOME collect owned by Jean$")
	public void an_individual_HOME_collect_owned_by_Jean(DataTable arg1) throws Throwable {
		final List<List<String>> data = arg1.raw();
		createCollects(data);
		ownersCollects = new HashMap<>();
		collectSet.forEach(collect -> createOwners(data, collect));
		journeyCodes.forEach(j -> mockOwnersCollects(j));
	}

	@When("^I search for EERBPF collects owned by Jean$")
	public void i_search_for_EERBPF_collects_owned_by_Jean() throws Throwable {
		this.collectDTOSet = collectActions.getCollectsByOwners(Arrays.asList("01740005814400000"), Arrays.asList("200000"), new Context("123456", "001"));
	}

}
