package com.bnpparibas.bddf.collect.application.index.sm02.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnp.schema.edoc.index.Indexes.EdocIndex;
import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.IndexDTO;
import com.bnpparibas.bddf.collect.application.dto.OwnerDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.collect.CollectActionsImpl;
import com.bnpparibas.bddf.collect.application.service.family.FamilyActionsImpl;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActionsImpl;
import com.bnpparibas.bddf.collect.application.service.type.TypeActionsImpl;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectService;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ReferenceValidationSteps {

	private PieceActionsImpl pieceAction;
	private TypeActionsImpl typeAction;
	private FamilyActionsImpl familyAction;
	private CollectActionsImpl collectAction;
	private Exception currentException;
	private Collect existingCollect;
	private Collect savedCollect;
	private PieceDTO pieceDTO;
	private SubTypeDTO typeDTO;
	private List<FamilyDTO> familiesDTO;
	private List<Piece> pieceToUpdateInDocReference = new ArrayList<>();
	private boolean eventFlag = false;
	private CollectAllDetailsDTO collectDTO;
	private List<Piece> piecesSentToGdn = new ArrayList<>();
	private TypeValidator typeValidator = new TypeValidator();

	public ReferenceValidationSteps() {

		final CollectService collectService = mock(CollectService.class);
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(true);
		doAnswer(invocation -> {
			final List<EdocIndex> edocIndexes = (new EdocIndexRepositoryImpl()).findAll();
			final List<EdocType> edocTypes = (new EdocTypesRepositoryImpl()).findAll();
			final Collect newCollect = invocation.getArgument(0);

			// RG129 - Vérifier existance des indexes envoyés
			newCollect.getTypes().forEach(t -> typeValidator.validateTypeIndexes(t, edocIndexes));
			// ERROR 97
			newCollect.getTypes().forEach(t -> typeValidator.validateSubTypeIndexes(t, edocIndexes, newCollect.getTypes()));

			// ERROR 98
			newCollect.getTypes().forEach(t -> typeValidator.validateSubTypeCompleteness(t, edocIndexes, newCollect.getTypes()));

			// RG131 - Vérifier control required and no index
			newCollect.getTypes().stream().filter(t -> t.getParentId() != null || newCollect.getTypes().stream().allMatch(subType -> !t.getId().equals(subType.getParentId())))
					.forEach(t -> typeValidator.validateTypeControlRequired(t, newCollect.getTypes()));
			// RG132 - Vérifier que la catégorie de l'index est OB/ND/FA
			newCollect.getTypes().forEach(t -> typeValidator.validateTypeIndexCategory(t));
			// RG133 - Init des libellés index vides
			newCollect.getTypes().forEach(t -> typeValidator.initTypeIndexLabel(t, edocIndexes));
			// RG134 - Vérifier existance des formats envoyés
			newCollect.getTypes().forEach(t -> typeValidator.validateTypeIndexReferenceFormat(t, edocIndexes));
			// RG190
			newCollect.getTypes().forEach(type -> typeValidator.initTypeCompleteness(type, edocTypes, newCollect.getTypes()));
			// RG192
			newCollect.getTypes().forEach(t -> typeValidator.initTypeIndexOwnerIndex(t));
			// RG191 - Vérifier existance des completeness envoyés
			newCollect.getTypes().forEach(t -> typeValidator.validateTypeCompleteness(t, edocTypes, newCollect.getTypes()));
			// RG192
			newCollect.getTypes().forEach(t -> typeValidator.validateTypeIndexOwnerIndex(t));
			// RG193
			newCollect.getTypes().forEach(t -> typeValidator.validateTypeIndexUniqueForEachOwner(t));
			// Error77
			newCollect.getTypes().forEach(t -> typeValidator.validateTypeIndexList(t, edocTypes));
			// Error78+79
			newCollect.getTypes().forEach(t -> typeValidator.validateTypeIndexInjection(t, edocIndexes));

			savedCollect = newCollect;
			return UUID.randomUUID();
		}).when(collectService).addCollect(any(), any());
		final Environment environment = mock(Environment.class);
		collectAction = new CollectActionsImpl(collectService, new CustomMapper());
		collectAction.setEnvironment(environment);

	}

	@Given("^An existing collect$")
	public void an_existing_collect(List<Collect> collects) throws Throwable {
		this.existingCollect = collects.get(0);
	}

	@Given("^An existing Owners$")
	public void an_existing_Owners(List<Owner> owners) throws Throwable {
		this.existingCollect.setOwners(new HashSet<>(owners));
	}

	@Given("^An existing types$")
	public void an_existing_types(List<Type> types) throws Throwable {
		this.existingCollect.getTypes().addAll(types);
	}

	@Given("^An existing sub-types$")
	public void an_existing_sub_types(List<Type> types) throws Throwable {
		this.existingCollect.getTypes().addAll(types);
	}

	@Given("^existing pieces in type <\"([^\"]*)\">$")
	public void existing_pieces_in_type(String idType, List<Piece> pieces) throws Throwable {
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(idType)).findAny().get().setPieces(pieces.stream().collect(Collectors.toSet()));
	}

	@Given("^new piece to add$")
	public void new_piece_to_add(List<PieceDTO> piecesDTO) throws Throwable {
		pieceDTO = piecesDTO.get(0);
	}

	@Given("^A type to modify$")
	public void a_type_to_modify(List<SubTypeDTO> typesDTO) throws Throwable {
		this.typeDTO = typesDTO.get(0);
	}

	@Given("^pieces in the type to modify$")
	public void pieces_in_the_type_to_modify(List<PieceDTO> piecesDTO) throws Throwable {
		this.typeDTO.setPieces(piecesDTO);
	}

	@When("^I update a type <\"([^\"]*)\">$")
	public void i_update_a_type(String idType) throws Throwable {
		try {
			typeAction.updateType(existingCollect.getId(), UUID.fromString(idType), typeDTO, new Context("123456", "001"));
		} catch (final Exception e) {
			currentException = e;
		}
	}

	@Given("^Families to update$")
	public void families_to_update(List<FamilyDTO> familiesDTO) throws Throwable {
		this.familiesDTO = familiesDTO;
	}

	@Then("^I expect the status of all types in the family <\"([^\"]*)\"> are initialized$")
	public void i_expect_the_status_of_all_types_in_the_family_are_initialized(String familyId) throws Throwable {
		assertTrue(existingCollect.getTypes().stream().filter(t -> familyId.equals(t.getFamilyId().toString())).allMatch(t -> TypeStatus.IN.getLabel().equals(t.getStatus())));
	}

	@Given("^pieces to add$")
	public void pieces_to_add(List<PieceDTO> piecesDTO) throws Throwable {
		typeDTO.setPieces(piecesDTO);
	}

	@Then("^The type is validated with status <\"([^\"]*)\">$")
	public void the_type_is_validated_with_status(String status) throws Throwable {
		assertThat(status).isEqualTo(existingCollect.getTypes().iterator().next().getStatus());
	}

	@Then("^I expect validation event not to be sent$")
	public void i_expect_validation_event_not_to_be_sent() throws Throwable {
		assertFalse(eventFlag);
	}

	@Given("^A subtype to modify$")
	public void a_subtype_to_modify(List<Type> subTypes) throws Throwable {
		existingCollect.getTypes().add(subTypes.get(0));
	}

	@When("^I update a family$")
	public void i_update_a_family() throws Throwable {
		try {
			familyAction.updateFamilies(existingCollect.getId(), familiesDTO, new Context("123456", "001"));
		} catch (final Exception e) {
			currentException = e;
		}
	}

	@Then("^I get (\\d+) pieces added in reference table$")
	public void i_get_pieces_added_in_reference_table(int nbPieces) throws Throwable {
		assertThat(currentException).isNull();
		assertThat(pieceToUpdateInDocReference.size()).isEqualTo(nbPieces);
	}

	@When("^I add a new piece in type <\"([^\"]*)\">$")
	public void i_add_a_new_piece_in_type(String idType) throws Throwable {
		try {
			pieceAction.addPiece(existingCollect.getId(), UUID.fromString(idType), pieceDTO, null, "", new Context("123456", "001"));
		} catch (final Exception e) {
			currentException = e;
		}

	}

	@Given("^A new collect$")
	public void a_new_collect(List<CollectAllDetailsDTO> collects) throws Throwable {
		collectDTO = collects.get(0);
	}

	@When("^I add a collect <\"([^\"]*)\">$")
	public void i_add_a_collect(String idCollect) throws Throwable {
		try {
			collectAction.saveCollect(collectDTO, new Context("123456", "001", "001"));
		} catch (final Exception e) {
			currentException = e;
		}
	}

	@Then("^The status of all types is initialized with <\"([^\"]*)\">$")
	public void the_status_of_all_types_is_initialized_with(String status) throws Throwable {
		assertTrue(savedCollect.getTypes().stream().allMatch(t -> TypeStatus.IN.getLabel().equals(t.getStatus())));
	}

	@Given("^A new family$")
	public void a_new_family(List<FamilyDTO> families) throws Throwable {
		collectDTO.setFamilies(families);
	}

	@Given("^New types to add$")
	public void new_types_to_add(List<TypeDTO> types) throws Throwable {
		collectDTO.getFamilies().get(0).setTypes(types);
	}

	@Given("^with pieces in type <\"([^\"]*)\">$")
	public void with_pieces_in_type(String idType, List<Piece> pieces) throws Throwable {
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(idType)).findAny().get().setPieces(pieces.stream().collect(Collectors.toSet()));
	}

	@Then("^pieces of other types are deleted$")
	public void pieces_of_other_types_are_deleted() throws Throwable {
		final Type existingType = existingCollect.getTypes().stream().filter(t -> typeDTO.getId().equals(t.getId())).findAny().get();
		assertThat(currentException).isNull();
		assertThat(existingCollect.getTypes().stream().filter(t -> !t.getId().equals(existingType.getId()) && t.getFamilyId().toString().equals(existingType.getFamilyId())).mapToInt(t -> t.getPieces().size()).sum()).isEqualTo(0);
	}

	@Then("^The status of the type <\"([^\"]*)\"> is set to <\"([^\"]*)\">$")
	public void the_status_of_the_type_is_set_to(String typeId, String status) throws Throwable {
		final Type existingType = existingCollect.getTypes().stream().filter(t -> typeId.equals(t.getId().toString())).findAny().get();
		assertThat(currentException).isNull();
		assertThat(existingType.getStatus()).isEqualTo(status);
	}

	@Given("^An new Owners$")
	public void an_new_Owners(List<OwnerDTO> owners) throws Throwable {
		collectDTO.setOwners(owners);
	}

	@Given("^types in family to update <\"([^\"]*)\">$")
	public void types_in_family_to_update(String familyId, List<TypeDTO> types) throws Throwable {
		familiesDTO.stream().filter(f -> familyId.equals(f.getId().toString())).findAny().ifPresent(f -> f.setTypes(types));
	}

	@Then("^Type <\"([^\"]*)\"> is updated with status <\"([^\"]*)\">$")
	public void type_is_updated_with_status(String typeId, String status) throws Throwable {
		final Optional<Type> type = existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny();
		assertTrue(type.isPresent());
		assertThat(type.get().getStatus()).isEqualTo(status);
	}

	@Then("^I expect type <\"([^\"]*)\"> containing (\\d+) pieces$")
	public void i_expect_type_containing_pieces(String typeId, int nbPieces) throws Throwable {
		final Optional<Type> type = existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny();
		assertTrue(type.isPresent());
		assertThat(nbPieces).isEqualTo(type.get().getPieces().size());
	}

	@Then("^Piece <\"([^\"]*)\"> is saved in gdn$")
	public void piece_is_saved_in_gdn(String pieceId) throws Throwable {
		assertThat(piecesSentToGdn).isNotEmpty();
		assertTrue(piecesSentToGdn.stream().filter(p -> p.getId().toString().equals(pieceId)).findAny().isPresent());
	}

	@Then("^No piece is saved in gdn$")
	public void no_piece_is_saved_in_gdn() throws Throwable {
		assertTrue(piecesSentToGdn == null || piecesSentToGdn.isEmpty());

	}

	@Then("^There is no exception$")
	public void there_is_no_exception() throws Throwable {
		assertThat(currentException).isNull();
	}

	@Given("^New indexes in type$")
	public void existing_indexes_in_type(List<IndexDTO> indexes) throws Throwable {
		collectDTO.getFamilies().get(0).getTypes().get(0).setIndexes(indexes);
	}

	@Given("^Existing completeness in type$")
	public void existing_completeness_in_type(List<String> completeness) throws Throwable {
		collectDTO.getFamilies().get(0).getTypes().get(0).setCompleteness(completeness);
	}

	@Given("^Existing completeness in subtype$")
	public void existing_completeness_in_subtype(List<String> completeness) throws Throwable {
		collectDTO.getFamilies().get(0).getTypes().get(0).getSubTypes().get(0).setCompleteness(completeness);
	}

	@Given("^null completeness$")
	public void null_completeness() throws Throwable {
		collectDTO.getFamilies().get(0).getTypes().get(0).setCompleteness(null);
	}

	@When("^I save the collect$")
	public void i_save_the_collect() throws Throwable {
		try {
			// collectDTO.getFamilies().forEach(f -> f.getTypes().forEach(t -> t.setEdocIndex(edocIndex)));
			collectAction.saveCollect(collectDTO, new Context("123456", "001", "001"));
		} catch (final Exception e) {
			currentException = e;
		}
	}

	@Then("^I expect error code <\"([^\"]*)\">$")
	public void i_expect_error_code(String codeError) throws Throwable {
		assertThat(currentException).isNotNull();
		assertThat(currentException.getMessage()).isEqualTo(codeError);
	}

	@Then("^I expect index label to be initialized$")
	public void i_expect_index_label_to_be_initialized() throws Throwable {
		final List<String> labels = new ArrayList<>();
		savedCollect.getTypes().forEach(t -> t.getIndexes().forEach(index -> labels.add(index.getLabel())));
		assertTrue(labels.isEmpty() || labels.stream().allMatch(label -> StringUtils.isNotEmpty(label)));
	}

	@Then("^I expect completeness to be initialized$")
	public void i_expect_completeness_to_be_initialized() throws Throwable {
		assertTrue(savedCollect.getTypes().stream().allMatch(type -> CollectionUtils.isNotEmpty(type.getCompleteness())));

	}

	@Then("^I expect indexOwner to be initialized$")
	public void i_expect_indexOwner_to_be_initialized() throws Throwable {
		assertTrue(savedCollect.getTypes().stream().filter(type -> type.getIndexes() != null).flatMap(type -> type.getIndexes().stream()).allMatch(index -> StringUtils.isNotEmpty(index.getOwnerIndex())));
	}

	@Given("^New subtypes to add$")
	public void new_subtypes_to_add(List<SubTypeDTO> subTypesDTO) throws Throwable {
		collectDTO.getFamilies().get(0).getTypes().get(0).setSubTypes(subTypesDTO);
	}

	@Given("^New indexes in subtype$")
	public void new_indexes_in_subtype(List<IndexDTO> indexes) throws Throwable {
		collectDTO.getFamilies().get(0).getTypes().get(0).getSubTypes().get(0).setIndexes(indexes);
	}
}
