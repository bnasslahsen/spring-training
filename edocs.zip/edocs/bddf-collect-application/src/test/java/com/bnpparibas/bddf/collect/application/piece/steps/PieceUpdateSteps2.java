package com.bnpparibas.bddf.collect.application.piece.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadService;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableSet;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PieceUpdateSteps2 {

	private PieceActionsImpl pieceActions;
	private CollectRepository collectRepository;
	private PieceRepository pieceRepository;
	private TypeRepository typeRepository;
	private PieceAutomaticControlUtils pieceAutomaticControlUtils;
	private CollectEventHandler collectEventHandler;

	private Collect collect;
	private AuditGenerator auditGenerator;

	private Piece piece;
	private Type type;

	private List<PieceDTO> pieceDTOList = new ArrayList<>();
	private Exception exception;
	private Collect collectClose;
	private UUID collectId;

	public PieceUpdateSteps2() {
		collectRepository = mock(CollectRepository.class);
		pieceRepository = mock(PieceRepository.class);
		final MessageSource messageSource = mock(MessageSource.class);
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(false);
		auditGenerator = new AuditGenerator(messageSource);
		typeRepository = mock(TypeRepository.class);
		collectEventHandler = mock(CollectEventHandler.class);
		final TypeLadRadService typeLadRadService = mock(TypeLadRadService.class);
		final TypeValidator typeValidator = new TypeValidator();
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		doNothing().when(collectEventHandler).sendTypeReceivedEvent(any());
		final Environment environment = mock(Environment.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		final CollectValidator customValidator = new CollectValidator();
		final PieceValidator pieceValidator = new PieceValidator();
		final PiecesStatusActionsRepository piecesStatusActionsRepository = mock(PiecesStatusActionsRepository.class);
		pieceValidator.setPieceStatusRepository(piecesStatusActionsRepository);

		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("TP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutPieces(eq("TP"), any())).thenReturn(true);
		final TypeAutomaticControlServiceImpl typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, typeValidator, null, new EdocIndexRepositoryImpl(), null, null, null, null, null, null,
				docReferenceService, new TypeAutomaticControlUtils());
		typeAutomaticControlService.setCollectRepository(collectRepository);
		pieceAutomaticControlUtils = new PieceAutomaticControlUtils(new PieceGdnServiceImpl(), typeAutomaticControlService);
		final PieceServiceImpl pieceService = new PieceServiceImpl(collectRepository, typeRepository, pieceRepository, customValidator, collectEventHandler, null, auditGenerator, environment, typeAutomaticControlService, featureManager,
				pieceAutomaticControlUtils);
		pieceActions = new PieceActionsImpl(pieceService, new CustomMapper());
		pieceActions.setEnvironment(environment);
		final EdocTypeRepository edocTypeRepository = mock(EdocTypeRepository.class);
		pieceService.setEdocTypeRepository(edocTypeRepository);
		pieceService.setPieceValidator(pieceValidator);
		collect = new Collect(UUID.randomUUID(), "EC", Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", ImmutableSet.<String> of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIFF"), ImmutableSet.<String> of("DP", "VA"),
				ImmutableSet.<String> of(), null, "AP001", false, false, 0, false, 0);
		collectClose = new Collect(UUID.randomUUID(), "CL", Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", ImmutableSet.<String> of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIFF"), ImmutableSet.<String> of("DP", "VA"),
				ImmutableSet.<String> of(), null, "AP001", false, false, 0, false, 0);
		type = new Type(UUID.randomUUID(), null, UUID.randomUUID(), new HashSet<String>(Arrays.asList("01740005814400000")), "Justificatif d'identité", "OB", null, "Liste", null, "info compl famille Justificatif d'identité", "Carte d'identité",
				"Veuiller fournir le recto et verso de votre carte d'identité", true, null, new Random().nextLong(), 0, null, false, null, false, null, false, false, null, null, true);

	}

	@When("^I Delete the piece <\"([^\"]*)\"> with channel <\"([^\"]*)\">$")
	public void i_Delete_the_piece_with_channel(String id, String channel) throws Throwable {
		try {
			pieceActions.updatePieces(collectId, type.getId(), new ArrayList<>(), new Context("", Channel.CLIENT_007.getValue()));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@Then("^the piece is deactivated$")
	public void the_piece_is_deactivated() throws Throwable {
		assertThat(pieceDTOList).isNotNull();

	}

	@Then("^I receive an error : <\"([^\"]*)\">$")
	public void i_receive_an_error(String arg1) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);
		assertThat(exception.getMessage()).isEqualTo(arg1);
	}

	@Given("^a piece loaded by a employee in the context database$")
	public void a_piece_loaded_by_a_employee_in_the_context_database(List<Piece> data) throws Throwable {
		piece = data.get(0);
		// piece.setIdType(type.getId());
		type.setPieces(new HashSet<>(Arrays.asList(piece)));
		piece.setAcquisitionDate(Instant.now());
		when(pieceRepository.getPiece(collect.getId(), type.getId(), piece.getId())).thenReturn(piece);
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
		when(typeRepository.findOneWithInactivePieces(collect.getId(), type.getId())).thenReturn(type);
		collect.setTypes(ImmutableSet.<Type> of(type));
		collectId = collect.getId();

	}

	@Given("^a piece loaded by a customer in the context database$")
	public void a_piece_loaded_by_a_customer_in_the_context_database(List<Piece> data) throws Throwable {
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
		piece = data.get(0);
		// piece.setIdType(type.getId());
		type.setPieces(new HashSet<>(Arrays.asList(piece)));
		piece.setAcquisitionDate(Instant.now());
		when(pieceRepository.getPiece(collect.getId(), type.getId(), piece.getId())).thenReturn(piece);
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
		collect.setTypes(ImmutableSet.<Type> of(type));
		collectId = collect.getId();
	}

	@Given("^a piece with status\\(VA\\) and delete piece by client$")
	public void a_piece_with_status_VA_and_delete_piece_by_client(List<Piece> data) throws Throwable {
		piece = data.get(0);
		// piece.setIdType(type.getId());
		type.setPieces(new HashSet<>(Arrays.asList(piece)));
		piece.setAcquisitionDate(Instant.now());
		when(pieceRepository.getPiece(collect.getId(), type.getId(), piece.getId())).thenReturn(piece);
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
		when(typeRepository.findOneWithInactivePieces(collect.getId(), type.getId())).thenReturn(type);
		collectId = collect.getId();
		collect.setTypes(ImmutableSet.<Type> of(type));
	}

	@Given("^an existing piece in collect closed$")
	public void an_existing_piece_in_collect_closed(DataTable data) throws Throwable {
		if (collectClose == null) {
			final List<String> col = data.raw().get(0);
			collectClose = new Collect(UUID.fromString(col.get(0)), col.get(1), ZonedDateTime.parse(col.get(2)).toInstant(), null, col.get(4), col.get(5), col.get(6), col.get(7), ImmutableSet.<String> of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIFF"),
					ImmutableSet.<String> of("DP", "VA"), ImmutableSet.<String> of(), null, col.get(8), false, false, 0, false, 0);

		}
		when(collectRepository.findOne(collectClose.getId())).thenReturn(collectClose);
		collectId = collectClose.getId();

	}

	@Given("^an existing piece in collect abandoned$")
	public void an_existing_piece_in_collect_abandoned(DataTable data) throws Throwable {
		final List<String> col = data.raw().get(0);
		collectClose = new Collect(UUID.fromString(col.get(0)), col.get(1), ZonedDateTime.parse(col.get(2)).toInstant(), null, col.get(4), col.get(5), col.get(6), col.get(7), ImmutableSet.<String> of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIFF"),
				ImmutableSet.<String> of("DP", "VA"), ImmutableSet.<String> of(), null, col.get(8), false, false, 0, false, 0);

		when(collectRepository.findOne(collectClose.getId())).thenReturn(collectClose);
		collectId = collectClose.getId();
	}

	@Given("^a non existant type$")
	public void a_non_existant_type(DataTable data) throws Throwable {
		if (collect == null) {
			final List<String> col = data.raw().get(0);
			collect = new Collect(UUID.fromString(col.get(0)), col.get(1), ZonedDateTime.parse(col.get(2)).toInstant(), null, col.get(4), col.get(5), col.get(6), col.get(7), ImmutableSet.<String> of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIFF"),
					ImmutableSet.<String> of("DP", "VA"), ImmutableSet.<String> of(), null, col.get(8), false, false, 0, false, 0);

		}
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
		this.collectId = collect.getId();
		when(typeRepository.findOne(collect.getId(), type.getId())).thenReturn(null);
	}

	@Given("^a non existant collect$")
	public void a_non_existant_collect(DataTable data) throws Throwable {
		if (collect == null) {
			final List<String> col = data.raw().get(0);
			collect = new Collect(UUID.fromString(col.get(0)), col.get(1), ZonedDateTime.parse(col.get(2)).toInstant(), null, col.get(4), col.get(5), col.get(6), col.get(7), ImmutableSet.<String> of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIFF"),
					ImmutableSet.<String> of("DP", "VA"), ImmutableSet.<String> of(), null, col.get(8), false, false, 0, false, 0);

		}
		when(collectRepository.findOne(collect.getId())).thenReturn(null);
		collectId = collect.getId();

	}
}