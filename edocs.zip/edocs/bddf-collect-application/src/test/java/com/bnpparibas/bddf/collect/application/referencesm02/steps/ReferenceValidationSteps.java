package com.bnpparibas.bddf.collect.application.referencesm02.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.OwnerDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.collect.CollectActionsImpl;
import com.bnpparibas.bddf.collect.application.service.family.FamilyActionsImpl;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActionsImpl;
import com.bnpparibas.bddf.collect.application.service.type.TypeActionsImpl;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectService;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceRecivedFormat;
import com.bnpparibas.bddf.collect.domain.piece.PieceService;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReference;
import com.bnpparibas.bddf.collect.domain.type.PropertyType;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeService;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ReferenceValidationSteps {

	private PieceActionsImpl pieceAction;
	private TypeActionsImpl typeAction;
	private FamilyActionsImpl familyAction;
	private CollectActionsImpl collectAction;
	private Exception currentException;
	private Collect existingCollect;
	private Collect savedCollect;
	private PieceDTO pieceDTO;
	private SubTypeDTO typeDTO;
	private List<FamilyDTO> familiesDTO;
	private List<DocReference> docReferences;
	private List<EdocType> edocTypes;
	private List<Piece> pieceToUpdateInDocReference = new ArrayList<>();
	private boolean gdnFlag = true;
	private boolean eventFlag = false;
	private CollectAllDetailsDTO collectDTO;
	private List<Piece> piecesSentToGdn = new ArrayList<>();

	public ReferenceValidationSteps() throws InterruptedException {
		final PieceService pieceService = mock(PieceService.class);
		doAnswer(invocation -> {
			final UUID idType = invocation.getArgument(1);
			final Piece piece = invocation.getArgument(2);
			final Type currentType = existingCollect.getTypes().stream().filter(t -> idType.equals(t.getId())).findAny().get();
			// Controler l'ajout d'une pièce pour un type validé (RG101 - Scénario1)
			if (TypeStatus.VA.getLabel().equals(currentType.getStatus())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UPDATE_UNAUTHORIZED));
			}
			// RG90 Pour une famille de type "Liste", si une pièce est déposée pour un type alors qu'un autre type de la famille contient des pièces avec un statut différent de DF
			if (PropertyType.LISTE.getLabel().equals(currentType.getFamilyPropertyType())
					&& existingCollect.getTypes().stream().filter(t -> !t.getId().equals(idType) && t.getFamilyId().equals(currentType.getFamilyId())).anyMatch(t -> t.getPieces().stream().anyMatch(p -> !PieceStatus.DF.getLabel().equals(p.getStatus())))) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_CATEGORY_TYPE_LISTE));
			}
			currentType.getPieces().add(piece);
			// RG 121 - Suite à l'ajout d'une pièce papier validé/recueilli, le statut du type passe respectivement à VA ou RC
			if (PieceRecivedFormat.PAP.name().equals(piece.getReceivedFormat()) && PieceStatus.VA.getLabel().equals(piece.getStatus())) {
				currentType.setStatus(TypeStatus.VA.getLabel());
			}
			// RG 121 - Scenario 2
			if (PieceRecivedFormat.PAP.name().equals(piece.getReceivedFormat()) && PieceStatus.RC.getLabel().equals(piece.getStatus())) {
				currentType.setStatus(TypeStatus.RC.getLabel());
			}
			// RG127 Ajout Pièce pour un type RC
			if (!Arrays.asList(PieceStatus.VA.getLabel(), PieceStatus.RC.getLabel()).contains(piece.getStatus()) && Arrays.asList(TypeStatus.RC.getLabel(), TypeStatus.RC_AUTO.getLabel()).contains(currentType.getStatus())) {
				currentType.setStatus(TypeStatus.IN.getLabel());
			}
			return UUID.randomUUID();
		}).when(pieceService).addPiece(any(), any(), any(), any(), any(), any());

		final TypeService typeService = mock(TypeService.class);

		doAnswer(invocation -> {
			// RG105 - La modification de catégorie d'une famille réinitialise le statut du/des types associés
			final Map<UUID, Type> families = invocation.getArgument(1);
			existingCollect.getTypes().stream().filter(t -> !t.getFamilyCategory().equals(families.get(t.getFamilyId()).getFamilyCategory())).forEach(t -> t.setStatus(TypeStatus.IN.getLabel()));
			return null;
		}).when(typeService).updateFamilies(any(), any(), any());

		doAnswer(invocation -> {
			final Type type = invocation.getArgument(2);
			final Optional<Type> existingTypeOpt = existingCollect.getTypes().stream().filter(t -> type.getId().equals(t.getId())).findAny();
			final Type existingType = existingTypeOpt.get();
			// RG98 : Un type ne peut être validé si l'une de ses pièces a un statut différent de VA ou si pendingDocument =true
			if (TypeStatus.VA.getLabel().equals(type.getStatus()) && type.getPieces() != null && (type.isPendingDocument() || !type.getPieces().stream().allMatch(p -> PieceStatus.VA.getLabel().equals(p.getStatus())))) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_STATUS_NOT_ALLOWED));
			}
			// RG120
			if ((Arrays.asList(TypeStatus.RC.getLabel(), TypeStatus.RC_AUTO.getLabel()).contains(type.getStatus())) && type.getPieces() != null
					&& (type.isPendingDocument() || !type.getPieces().stream().allMatch(p -> PieceStatus.RC.getLabel().equals(p.getStatus()) || PieceStatus.VA.getLabel().equals(p.getStatus())))) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_STATUS_NOT_ALLOWED));
			}
			if (Arrays.asList(TypeStatus.VA.getLabel(), TypeStatus.VA_AUTO.getLabel()).contains(existingType.getStatus())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UPDATE_UNAUTHORIZED));
			}

			final boolean enabledReuse = edocTypes.stream().filter(t -> t.getValue().equals(existingType.getEdocType())).findAny().map(EdocType::isReuseEligibility).orElse(false);
			// RG108 - Contrôler l'ajout d'une pièce pour un type edoc-non éligible
			// RG106 - La fonction de stockage des pièces de référence ne s'applique pas aux sous types
			if (enabledReuse && !type.isPendingDocument() && Arrays.asList(TypeStatus.VA.getLabel(), TypeStatus.VA_AUTO.getLabel(), TypeStatus.RC.getLabel(), TypeStatus.RC_AUTO.getLabel()).contains(type.getStatus()) && existingType.getParentId() == null) {
				pieceToUpdateInDocReference = existingType.getPieces().stream().filter(p -> type.getPieces().stream().anyMatch(pparam -> pparam.getId().equals(p.getId()))).collect(Collectors.toList());
			}
			// RG116 - A la validation d'un type appartenant à une famille de propert-type=Liste, supprimer les pièces des autres types
			if (TypeStatus.VA.getLabel().equals(type.getStatus()) && PropertyType.LISTE.getLabel().equals(existingType.getFamilyPropertyType())) {
				existingCollect.getTypes().stream().filter(t -> !t.getId().equals(existingType.getId()) && t.getFamilyId().equals(existingType.getFamilyId())).forEach(t -> t.getPieces().clear());
			}
			piecesSentToGdn = new ArrayList<>();
			final List<UUID> pieceIds = type.getPieces().stream().map(Piece::getId).collect(Collectors.toList());
			if (TypeStatus.VA.getLabel().equals(type.getStatus())) {
				piecesSentToGdn.addAll(existingType.getPieces().stream().filter(p -> pieceIds.contains(p.getId()) && p.getReferenceGdnId() == null).collect(Collectors.toList()));
			}
			piecesSentToGdn.addAll(existingType.getPieces().stream().filter(p -> pieceIds.contains(p.getId()) && PieceStatus.DF.getLabel().equals(p.getStatus())).collect(Collectors.toList()));

			existingType.setStatus(type.getStatus());

			eventFlag = Arrays.asList(TypeStatus.VA.getLabel(), TypeStatus.RC.getLabel()).contains(type.getStatus()) && !gdnFlag;
			return null;
		}).when(typeService).updateType(any(), any(), any(), any());

		final CollectService collectService = mock(CollectService.class);
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(true);
		doAnswer(invocation -> {
			// RG100 Init des statut des Types à IN lors du save collect
			final Collect newCollect = invocation.getArgument(0);
			newCollect.getTypes().forEach(t -> t.setStatus(TypeStatus.IN.getLabel()));
			savedCollect = newCollect;
			return UUID.randomUUID();
		}).when(collectService).addCollect(any(), any());
		final Environment environment = mock(Environment.class);
		pieceAction = new PieceActionsImpl(pieceService, new CustomMapper());
		pieceAction.setEnvironment(environment);
		typeAction = new TypeActionsImpl(typeService, new CustomMapper());
		familyAction = new FamilyActionsImpl(typeService, new CustomMapper());
		collectAction = new CollectActionsImpl(collectService, new CustomMapper());
		collectAction.setEnvironment(environment);
	}

	@Given("^An existing collect$")
	public void an_existing_collect(List<Collect> collects) throws Throwable {
		this.existingCollect = collects.get(0);
	}

	@Given("^An existing Owners$")
	public void an_existing_Owners(List<Owner> owners) throws Throwable {
		this.existingCollect.setOwners(new HashSet<>(owners));
	}

	@Given("^An existing types$")
	public void an_existing_types(List<Type> types) throws Throwable {
		this.existingCollect.getTypes().addAll(types);
	}

	@Given("^An existing sub-types$")
	public void an_existing_sub_types(List<Type> types) throws Throwable {
		this.existingCollect.getTypes().addAll(types);
	}

	@Given("^existing pieces in type <\"([^\"]*)\">$")
	public void existing_pieces_in_type(String idType, List<Piece> pieces) throws Throwable {
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(idType)).findAny().get().setPieces(pieces.stream().collect(Collectors.toSet()));
	}

	@Given("^An existing document reference$")
	public void an_existing_document_reference(List<DocReference> docReferences) throws Throwable {
		this.docReferences = docReferences;
	}

	@Given("^new piece to add$")
	public void new_piece_to_add(List<PieceDTO> piecesDTO) throws Throwable {
		pieceDTO = piecesDTO.get(0);
	}

	@Given("^A type to modify$")
	public void a_type_to_modify(List<SubTypeDTO> typesDTO) throws Throwable {
		this.typeDTO = typesDTO.get(0);
	}

	@Given("^pieces in the type to modify$")
	public void pieces_in_the_type_to_modify(List<PieceDTO> piecesDTO) throws Throwable {
		this.typeDTO.setPieces(piecesDTO);
	}

	@When("^I update a type <\"([^\"]*)\">$")
	public void i_update_a_type(String idType) throws Throwable {
		try {
			typeAction.updateType(existingCollect.getId(), UUID.fromString(idType), typeDTO, new Context("123456", "001"));
		} catch (final Exception e) {
			currentException = e;
		}
	}

	@Given("^A list of edoc-Type$")
	public void a_list_of_edoc_Type(List<EdocType> edocTypes) throws Throwable {
		this.edocTypes = edocTypes;
	}

	@Then("^I expect error code : <\"([^\"]*)\">$")
	public void i_expect_error_code(String codeError) throws Throwable {
		assertThat(currentException).isNotNull();
		assertThat(currentException.getMessage()).isEqualTo(codeError);
	}

	@Given("^Families to update$")
	public void families_to_update(List<FamilyDTO> familiesDTO) throws Throwable {
		this.familiesDTO = familiesDTO;
	}

	@Then("^I expect the status of all types in the family <\"([^\"]*)\"> are initialized$")
	public void i_expect_the_status_of_all_types_in_the_family_are_initialized(String familyId) throws Throwable {
		assertTrue(existingCollect.getTypes().stream().filter(t -> familyId.equals(t.getFamilyId().toString())).allMatch(t -> TypeStatus.IN.getLabel().equals(t.getStatus())));
	}

	@Given("^pieces to add$")
	public void pieces_to_add(List<PieceDTO> piecesDTO) throws Throwable {
		typeDTO.setPieces(piecesDTO);
	}

	@Then("^The type is validated with status <\"([^\"]*)\">$")
	public void the_type_is_validated_with_status(String status) throws Throwable {
		assertThat(status).isEqualTo(existingCollect.getTypes().iterator().next().getStatus());
	}

	@Then("^I expect validation event not to be sent$")
	public void i_expect_validation_event_not_to_be_sent() throws Throwable {
		assertFalse(eventFlag);
	}

	@Given("^A subtype to modify$")
	public void a_subtype_to_modify(List<Type> subTypes) throws Throwable {
		existingCollect.getTypes().add(subTypes.get(0));
	}

	@Given("^GDN is <\"([^\"]*)\">$")
	public void gdn_is(String gdnFlag) throws Throwable {
		this.gdnFlag = "true".equalsIgnoreCase(gdnFlag);
	}

	@When("^I update a family$")
	public void i_update_a_family() throws Throwable {
		try {
			familyAction.updateFamilies(existingCollect.getId(), familiesDTO, new Context("123456", "001"));
		} catch (final Exception e) {
			currentException = e;
		}
	}

	@Then("^I get (\\d+) pieces added in reference table$")
	public void i_get_pieces_added_in_reference_table(int nbPieces) throws Throwable {
		assertThat(currentException).isNull();
		assertThat(pieceToUpdateInDocReference.size()).isEqualTo(nbPieces);
	}

	@When("^I add a new piece in type <\"([^\"]*)\">$")
	public void i_add_a_new_piece_in_type(String idType) throws Throwable {
		try {
			pieceAction.addPiece(existingCollect.getId(), UUID.fromString(idType), pieceDTO, null, "", new Context("123456", "001"));
		} catch (final Exception e) {
			currentException = e;
		}

	}

	@Given("^A new collect$")
	public void a_new_collect(List<CollectAllDetailsDTO> collects) throws Throwable {
		collectDTO = collects.get(0);
	}

	@When("^I add a collect <\"([^\"]*)\">$")
	public void i_add_a_collect(String idCollect) throws Throwable {
		try {
			collectAction.saveCollect(collectDTO, new Context("123456", "001", "001"));
		} catch (final Exception e) {
			currentException = e;
		}
	}

	@Then("^The status of all types is initialized with <\"([^\"]*)\">$")
	public void the_status_of_all_types_is_initialized_with(String status) throws Throwable {
		assertTrue(savedCollect.getTypes().stream().allMatch(t -> TypeStatus.IN.getLabel().equals(t.getStatus())));
	}

	@Given("^A new family$")
	public void a_new_family(List<FamilyDTO> families) throws Throwable {
		collectDTO.setFamilies(families);
	}

	@Given("^new types to add$")
	public void new_types_to_add(List<TypeDTO> types) throws Throwable {
		collectDTO.getFamilies().get(0).setTypes(types);
	}

	@Given("^with pieces in type <\"([^\"]*)\">$")
	public void with_pieces_in_type(String idType, List<Piece> pieces) throws Throwable {
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(idType)).findAny().get().setPieces(pieces.stream().collect(Collectors.toSet()));
	}

	@Then("^pieces of other types are deleted$")
	public void pieces_of_other_types_are_deleted() throws Throwable {
		final Type existingType = existingCollect.getTypes().stream().filter(t -> typeDTO.getId().equals(t.getId())).findAny().get();
		assertThat(currentException).isNull();
		assertThat(existingCollect.getTypes().stream().filter(t -> !t.getId().equals(existingType.getId()) && t.getFamilyId().toString().equals(existingType.getFamilyId())).mapToInt(t -> t.getPieces().size()).sum()).isEqualTo(0);
	}

	@Then("^The status of the type <\"([^\"]*)\"> is set to <\"([^\"]*)\">$")
	public void the_status_of_the_type_is_set_to(String typeId, String status) throws Throwable {
		final Type existingType = existingCollect.getTypes().stream().filter(t -> typeId.equals(t.getId().toString())).findAny().get();
		assertThat(currentException).isNull();
		assertThat(existingType.getStatus()).isEqualTo(status);
	}

	@Given("^An new Owners$")
	public void an_new_Owners(List<OwnerDTO> owners) throws Throwable {
		collectDTO.setOwners(owners);
	}

	@Given("^types in family to update <\"([^\"]*)\">$")
	public void types_in_family_to_update(String familyId, List<TypeDTO> types) throws Throwable {
		familiesDTO.stream().filter(f -> familyId.equals(f.getId().toString())).findAny().ifPresent(f -> f.setTypes(types));
	}

	@Then("^Type <\"([^\"]*)\"> is updated with status <\"([^\"]*)\">$")
	public void type_is_updated_with_status(String typeId, String status) throws Throwable {
		final Optional<Type> type = existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny();
		assertTrue(type.isPresent());
		assertThat(type.get().getStatus()).isEqualTo(status);
	}

	@Then("^I expect type <\"([^\"]*)\"> containing (\\d+) pieces$")
	public void i_expect_type_containing_pieces(String typeId, int nbPieces) throws Throwable {
		final Optional<Type> type = existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny();
		assertTrue(type.isPresent());
		assertThat(nbPieces).isEqualTo(type.get().getPieces().size());
	}

	@Then("^Piece <\"([^\"]*)\"> is saved in gdn$")
	public void piece_is_saved_in_gdn(String pieceId) throws Throwable {
		assertThat(piecesSentToGdn).isNotEmpty();
		assertTrue(piecesSentToGdn.stream().filter(p -> p.getId().toString().equals(pieceId)).findAny().isPresent());
	}

	@Then("^No piece is saved in gdn$")
	public void no_piece_is_saved_in_gdn() throws Throwable {
		assertTrue(piecesSentToGdn == null || piecesSentToGdn.isEmpty());

	}

	@Then("^there is no exception$")
	public void there_is_no_exception() throws Throwable {
		assertThat(currentException).isNull();
	}
}
