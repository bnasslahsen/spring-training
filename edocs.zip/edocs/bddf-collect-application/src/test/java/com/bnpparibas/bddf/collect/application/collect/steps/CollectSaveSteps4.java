package com.bnpparibas.bddf.collect.application.collect.steps;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.IndexDTO;
import com.bnpparibas.bddf.collect.application.dto.OwnerDTO;
import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CollectSaveSteps4 extends AbstractCollectSaveSteps {

	public CollectSaveSteps4() {
		super();
	}

	@Given("^A new collect$")
	public void a_new_collect(List<CollectAllDetailsDTO> collects) throws Throwable {
		collectAllDetailsDTO = collects.get(0);
	}

	@Given("^A new family$")
	public void a_new_family(List<FamilyDTO> families) throws Throwable {
		collectAllDetailsDTO.setFamilies(families);
	}

	@Given("^Existing familiesManagmentActs$")
	public void existing_familiesManagmentActs_in_collect(List<String> familiesManagementAct) throws Throwable {
		collectAllDetailsDTO.setFamiliesManagementAct(familiesManagementAct);
	}

	@Given("^New types to add$")
	public void new_types_to_add(List<TypeDTO> types) throws Throwable {
		collectAllDetailsDTO.getFamilies().get(0).setTypes(types);
	}

	@Given("^An new Owners$")
	public void an_new_Owners(List<OwnerDTO> owners) throws Throwable {
		collectAllDetailsDTO.setOwners(owners);
	}

	@Then("^There is no exception$")
	public void there_is_no_exception() throws Throwable {
		assertThat(exception).isNull();
	}

	@Given("^New indexes in type$")
	public void existing_indexes_in_type(List<IndexDTO> indexes) throws Throwable {
		collectAllDetailsDTO.getFamilies().get(0).getTypes().get(0).setIndexes(indexes);
	}

	@Given("^New subTypes to add$")
	public void new_subTypes_to_add(List<SubTypeDTO> subTypes) throws Throwable {
		collectAllDetailsDTO.getFamilies().get(0).getTypes().get(0).setSubTypes(subTypes);
	}

	@Given("^New indexes in subtype$")
	public void new_indexes_in_subtype(List<IndexDTO> indexes) throws Throwable {
		collectAllDetailsDTO.getFamilies().get(0).getTypes().get(0).getSubTypes().get(0).setIndexes(indexes);
	}

	@When("^I add a collect$")
	public void i_add_a_collect() throws Throwable {
		try {
			collectAction.saveCollect(collectAllDetailsDTO, new Context("123456", "001", "001"));
		} catch (final Exception e) {
			exception = e;
		}
	}

	@Then("^I expect error <\"([^\"]*)\">$")
	public void i_expect_error(String errorMessage) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);
		assertThat(exception.getMessage()).isEqualTo(errorMessage);
	}

}
