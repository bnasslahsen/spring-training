package com.bnpparibas.bddf.collect.application.searchcollect;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;

import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@SpringBootTest(classes = { CollectValidator.class, CustomMapper.class })
@RunWith(Cucumber.class)
@CucumberOptions(strict = true, plugin = { "pretty", "html:target/cucumber", "json:target/cucumber/collect/cucumber.json" }, glue = { "com.bnpparibas.bddf.collect.application.searchcollect", "cucumber.api.spring", "cucumber.runtime.java.spring" })
public class CollectSearchCucumberSuiteRunnerTest {

}
