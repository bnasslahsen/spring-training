package com.bnpparibas.bddf.collect.application.piece.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.PieceDataDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnService;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadService;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PieceGetSteps {

	private PieceActionsImpl pieceActions;
	private CollectRepository collectRepository;
	private CollectEventHandler collectEventHandler;
	private TypeRepository typeRepository;
	private PieceRepository pieceRepository;
	private PieceGdnService pieceGdnService;
	private PieceAutomaticControlUtils pieceAutomaticControlUtils;
	private Collect collect;
	private Piece piece;
	private Type type;

	private PieceDataDTO pieceDataDTO;
	private Exception exception;
	private AuditGenerator auditGenerator;

	// UPL2024SM02

	// UPL3001SM01

	// UPL3001SM02

	public PieceGetSteps() {
		collectRepository = mock(CollectRepository.class);
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		typeRepository = mock(TypeRepository.class);
		pieceRepository = mock(PieceRepository.class);
		collectEventHandler = mock(CollectEventHandler.class);
		pieceGdnService = mock(PieceGdnService.class);
		final TypeLadRadService typeLadRadService = mock(TypeLadRadService.class);
		final TypeValidator typeValidator = new TypeValidator();
		final Environment environment = mock(Environment.class);
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(false);
		final TypeAutomaticControlServiceImpl typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, typeValidator, null, new EdocIndexRepositoryImpl(), featureManager, pieceRepository, null, null, null,
				typeRepository, docReferenceService, new TypeAutomaticControlUtils());
		typeAutomaticControlService.setCollectRepository(collectRepository);
		final PieceValidator pieceValidator = new PieceValidator();
		final PiecesStatusActionsRepository piecesStatusActionsRepository = mock(PiecesStatusActionsRepository.class);
		pieceValidator.setPieceStatusRepository(piecesStatusActionsRepository);

		pieceAutomaticControlUtils = new PieceAutomaticControlUtils(pieceGdnService, typeAutomaticControlService);
		final PieceServiceImpl pieceService = new PieceServiceImpl(collectRepository, typeRepository, pieceRepository, new CollectValidator(), collectEventHandler, pieceGdnService, auditGenerator, environment, typeAutomaticControlService, featureManager,
				pieceAutomaticControlUtils);
		pieceService.setPieceValidator(pieceValidator);
		pieceActions = new PieceActionsImpl(pieceService, new CustomMapper());
		pieceActions.setEnvironment(environment);
		final EdocTypeRepository edocTypeRepository = mock(EdocTypeRepository.class);
		pieceService.setEdocTypeRepository(edocTypeRepository);
	}

	@Given("^in progress collect$")
	public void a_collect(List<Collect> data) throws Throwable {
		collect = data.get(0);
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@And("^containing a type$")
	public void on_a_type(List<Type> data) throws Throwable {
		type = data.get(0);
		final Set<Type> types = new HashSet<>();
		types.add(type);
		collect.setTypes(types);
		when(typeRepository.findOne(collect.getId(), type.getId())).thenReturn(type);

	}

	@Given("^an existing piece$")
	public void an_existing_piece(List<Piece> data) throws Throwable {
		piece = data.get(0);
		piece.setAcquisitionDate(Instant.now());
		final ByteBuffer pieceData = ByteBuffer.allocate(1000);
		when(pieceRepository.getPiece(collect.getId(), type.getId(), piece.getId())).thenReturn(piece);
		final Set<Piece> pieces = new HashSet<>();
		pieces.add(piece);
		type.setPieces(pieces);
		when(typeRepository.findOne(collect.getId(), type.getId())).thenReturn(type);
		when(pieceRepository.getPieceFromNas(piece.getId())).thenReturn(pieceData);
		// SecuredUserManager.set(piece.getOwnerId());
		when(pieceGdnService.getPieceData(piece.getId(), new Context(piece.getOwnerId(), "007"), piece.getIdDocGdn())).thenReturn(pieceData);
	}

	@When("^I search for the piece <\"([^\"]*)\">$")
	public void i_search_for_the_piece(String id) throws Throwable {
		try {
			pieceDataDTO = pieceActions.getPieceData(collect.getId(), type.getId(), UUID.fromString(id), new Context("01740005814400000", Channel.CLIENT_007.getValue()));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@When("^I search for the piece <\"([^\"]*)\"> related to Type <\"([^\"]*)\">$")
	public void i_search_for_the_piece_related_to_Type(String idPiece, String idType) throws Throwable {
		try {
			pieceDataDTO = pieceActions.getPieceData(collect.getId(), UUID.fromString(idType), UUID.fromString(idPiece), new Context("123456", "001"));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@Then("^I return the piece$")
	public void i_return_the_piece() throws Throwable {
		assertThat(pieceDataDTO).isNotNull();
		assertThat(pieceDataDTO.getId()).isEqualTo(piece.getId());
	}

	@Then("^I get the error code : <\"([^\"]*)\">$")
	public void i_return_the_error_code(String arg1) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);
		assertThat(exception.getMessage()).isEqualTo(arg1);
	}

}
