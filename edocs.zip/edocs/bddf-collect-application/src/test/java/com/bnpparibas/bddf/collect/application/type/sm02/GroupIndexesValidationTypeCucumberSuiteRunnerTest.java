package com.bnpparibas.bddf.collect.application.type.sm02;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(strict = true, plugin = { "pretty", "html:target/cucumber", "json:target/cucumber/typeSM02/cucumber.json" }, glue = { "com.bnpparibas.bddf.collect.application.type.sm02", "cucumber.api.spring", "cucumber.runtime.java.spring" })
public class GroupIndexesValidationTypeCucumberSuiteRunnerTest {

}
