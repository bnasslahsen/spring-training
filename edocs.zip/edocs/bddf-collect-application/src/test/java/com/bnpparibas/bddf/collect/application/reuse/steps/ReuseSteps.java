package com.bnpparibas.bddf.collect.application.reuse.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.core.env.Environment;

import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.OwnerDTO;
import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.collect.CollectActionsImpl;
import com.bnpparibas.bddf.collect.application.service.family.FamilyActionsImpl;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectServiceImpl;
import com.bnpparibas.bddf.collect.domain.collect.FamiliesManagmentAct;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReference;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeService;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ReuseSteps {

	private CollectAllDetailsDTO collect;
	private List<EdocType> edocTypes;
	private List<DocReference> references;
	private CollectActionsImpl collectActions;
	private Collect savedCollect;
	private Collect existingCollect;
	private Exception exception;
	private FamilyActionsImpl familyActions;

	public ReuseSteps() {
		final CollectServiceImpl collectService = mock(CollectServiceImpl.class);
		final Environment environment = mock(Environment.class);
		doAnswer(invocation -> {
			final Collect c = invocation.getArgument(0);

			c.getTypes().stream().filter(t -> t.isEnableReuse() && !t.isDigitalAllowed()).findAny().ifPresent(t -> {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_REUSE_FORBIDEN, t.getId().toString(), t.getLabel()));
			});

			final List<UUID> typesContainingSubtypes = c.getTypes().stream().map(Type::getParentId).collect(Collectors.toList());
			c.getTypes().stream().filter(t -> !Arrays.asList(FamiliesManagmentAct.ND.name(), FamiliesManagmentAct.DR.name()).contains(t.getFamilyCategory())).filter(
					t -> t.getParentId() == null && !typesContainingSubtypes.contains(t.getId()) && t.isEnableReuse() && edocTypes.stream().filter(edt -> edt.getValue().equals(t.getEdocType())).findAny().map(EdocType::isReuseEligibility).orElse(false))
					.forEach(t -> t.setPieces(referencesToPieces(t)));

			savedCollect = c;
			return null;
		}).when(collectService).addCollect(any(), any());

		collectActions = new CollectActionsImpl(collectService, new CustomMapper());
		collectActions.setEnvironment(environment);

		final TypeService typeService = mock(TypeService.class);

		doAnswer(invocation -> {
			final Map<UUID, Type> families = invocation.getArgument(1);

			if (existingCollect.getTypes().stream().anyMatch(t -> !t.getFamilyCategory().equals("OB")) && families.values().iterator().next().getFamilyCategory().equals("OB")) {

				final List<UUID> typesContainingSubtypes = existingCollect.getTypes().stream().map(Type::getParentId).collect(Collectors.toList());
				existingCollect.getTypes().stream().filter(
						t -> t.getParentId() == null && !typesContainingSubtypes.contains(t.getId()) && t.isEnableReuse() && edocTypes.stream().filter(edt -> edt.getValue().equals(t.getEdocType())).findAny().map(EdocType::isReuseEligibility).orElse(false))
						.forEach(t -> t.setPieces(referencesToPieces(t)));
			}

			savedCollect = existingCollect;
			return null;
		}).when(typeService).updateFamilies(any(), any(), any());

		familyActions = new FamilyActionsImpl(typeService, new CustomMapper());
	}

	private Set<Piece> referencesToPieces(Type t) {
		final Set<Piece> pieces = references.stream().filter(p -> t.getFamilyOwners().contains(p.getOwnerId()) && p.getEdocType().equals(t.getEdocType())).map(this::refToPiece).collect(Collectors.toSet());
		return references.stream().filter(p -> t.getFamilyOwners().contains(p.getOwnerId()) && p.getEdocType().equals(t.getEdocType())).map(this::refToPiece).collect(Collectors.toSet());
	}

	private Piece refToPiece(DocReference ref) {
		final Piece p = new Piece();
		p.setStatus("DF");
		p.setId(UUID.randomUUID());
		return p;
	}

	@Given("^A collect to save$")
	public void a_collect_to_save(List<CollectAllDetailsDTO> collects) throws Throwable {
		collect = collects.get(0);
	}

	@Given("^Owners in the collect to save$")
	public void owners_in_the_collect_to_save(List<OwnerDTO> owners) throws Throwable {
		collect.setOwners(owners);
	}

	@Given("^A family in the collect to save$")
	public void a_family_in_the_collect_to_save(List<FamilyDTO> families) throws Throwable {
		collect.setFamilies(families);
		families.stream().forEach(f -> f.setOwners(collect.getOwners().stream().map(OwnerDTO::getReference).collect(Collectors.toList())));
	}

	@Given("^An existing list of edoc-Type$")
	public void an_existing_list_of_edoc_Type(List<EdocType> edocTypes) throws Throwable {
		this.edocTypes = edocTypes;
	}

	@Given("^An existing list of reference documents$")
	public void an_existing_list_of_reference_documents(List<DocReference> references) throws Throwable {
		this.references = references;
	}

	@Given("^A list of types in the collect to save$")
	public void a_list_of_types_in_the_collect_to_save(List<TypeDTO> types) throws Throwable {
		collect.getFamilies().get(0).setTypes(types);
	}

	@When("^I save the collect$")
	public void i_save_the_collect() throws Throwable {
		try {
			collectActions.saveCollect(collect, new Context("123456", "001"));
		} catch (final Exception e) {
			exception = e;
		}
	}

	@Then("^There is no exepction$")
	public void there_is_no_exepction() throws Throwable {
		assertThat(exception).isNull();
	}

	@Then("^The collect is created$")
	public void the_collect_is_created() throws Throwable {
		assertThat(savedCollect).isNotNull();
	}

	@Then("^The type <\"([^\"]*)\"> contains (\\d+) piece\\(s\\) with a <\"([^\"]*)\"> status$")
	public void the_type_contains_piece_s_with_a_status(String typeId, int nbPiece, String pieceStatus) throws Throwable {
		assertThat(savedCollect.getTypes().stream().filter(t -> t.getEdocType().equals(typeId)).count()).isNotEqualTo(0);
		assertThat(savedCollect.getTypes().stream().filter(t -> t.getEdocType().equals(typeId)).findAny().get().getPieces().size()).isEqualTo(nbPiece);
		savedCollect.getTypes().stream().filter(t -> t.getEdocType().equals(typeId)).forEach(t -> t.getPieces().forEach(p -> assertThat(p.getStatus()).isEqualTo(pieceStatus)));
	}

	@Then("^Types do not contain piece$")
	public void types_do_not_contain_piece() throws Throwable {
		savedCollect.getTypes().stream().forEach(t -> assertThat(t.getPieces()).isEmpty());
	}

	@Then("^I expect an error message <\"([^\"]*)\">$")
	public void i_expect_an_error_message(String message) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception.getMessage()).isEqualTo(message);
	}

	@Given("^A list of subtypes$")
	public void a_list_of_subtypes(List<SubTypeDTO> subTypes) throws Throwable {
		collect.getFamilies().get(0).getTypes().get(0).setSubTypes(subTypes);
	}

	@Given("^Category family is <\"([^\"]*)\">$")
	public void category_family_is(String category) throws Throwable {
		collect.getFamilies().get(0).setCategory(category);
	}

	@Given("^An existing collect$")
	public void an_existing_collect(List<Collect> collects) throws Throwable {
		existingCollect = collects.get(0);
	}

	@Given("^An existing owners$")
	public void an_existing_owners(List<Owner> owners) throws Throwable {
		existingCollect.setOwners(new HashSet<>(owners));
	}

	@Given("^An existing type$")
	public void an_existing_type(List<Type> types) throws Throwable {
		existingCollect.setTypes(new HashSet<>(types));
		existingCollect.getTypes().forEach(t -> t.setFamilyOwners(existingCollect.getOwners().stream().map(Owner::getReference).collect(Collectors.toSet())));
	}

	@When("^I update family category to <\"([^\"]*)\">$")
	public void i_update_family_category_to(String category) throws Throwable {
		familyActions.updateFamilies(existingCollect.getId(), existingCollect.getTypes().stream().map(t -> tofamilyDTO(t, category)).collect(Collectors.toList()), new Context("1233564", "001"));
	}

	@Given("^A list of subtypes for family$")
	public void a_list_of_subtypes_for_family(List<Type> subTypes) throws Throwable {
		final List<Type> types = existingCollect.getTypes().stream().collect(Collectors.toList());
		subTypes.stream().forEach(t -> t.setParentId(types.get(0).getId()));
		subTypes.forEach(t -> t.setFamilyOwners(existingCollect.getOwners().stream().map(Owner::getReference).collect(Collectors.toSet())));
		existingCollect.getTypes().addAll(subTypes);
	}

	@Then("^Types of the family do not contain piece$")
	public void types_of_the_family_do_not_contain_piece() throws Throwable {
		final List<Type> types = existingCollect.getTypes().stream().collect(Collectors.toList());
		types.forEach(t -> assertThat(t.getPieces()).isEmpty());
	}

	private FamilyDTO tofamilyDTO(Type t, String category) {
		final FamilyDTO familyDTO = new FamilyDTO(t, Channel.SPIRIT.getValue());
		familyDTO.setOwners(new ArrayList<>(t.getFamilyOwners()));
		familyDTO.setTypes(Arrays.asList(new TypeDTO(t, Channel.SPIRIT.getValue())));
		familyDTO.setCategory(category);
		return familyDTO;
	}
}
