package com.bnpparibas.bddf.collect.application.utils;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Matcher;

public class HibernateValidationUtils {

	private static Validator VALIDATOR;
	static {
		final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		VALIDATOR = factory.getValidator();
	}

	public static Set<ConstraintViolation<Object>> validationFor(Object object, String fieldname) {
		return VALIDATOR.validateProperty(object, fieldname);
	}

	public static String onField(String fieldname) {
		return fieldname;
	}

	public static Matcher<Set<ConstraintViolation<Object>>> succedes() {
		return new PassesValidation();
	}

	// public static Matcher<Set<ConstraintViolation<Object>>> fails() {
	// return new Not(new PassesValidation());
	// }

	static class PassesValidation extends BaseMatcher<Set<ConstraintViolation<Object>>> {
		@Override
		public boolean matches(Object o) {
			boolean result = false;
			if (o instanceof Set) {
				result = ((Set) o).isEmpty();
			}
			return result;
		}

		@Override
		public void describeTo(Description description) {
			description.appendText("valid");
		}
	}
}