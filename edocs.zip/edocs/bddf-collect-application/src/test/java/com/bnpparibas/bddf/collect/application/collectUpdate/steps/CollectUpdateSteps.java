package com.bnpparibas.bddf.collect.application.collectUpdate.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.test.util.ReflectionTestUtils;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.OwnerDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.collect.CollectActions;
import com.bnpparibas.bddf.collect.application.service.collect.CollectActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.CollectServiceImpl;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.param.GdnParamRepository;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableSet;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CollectUpdateSteps {

	private CollectActions collectActions;

	private CollectServiceImpl collectService;
	private AuditGenerator auditGenerator;

	private CollectRepository collectRepository;
	private TypeRepository typeRepository;
	private GdnParamRepository gdnParamRepository;
	private List<OwnerDTO> ownersDTO;
	private List<FamilyDTO> familiesDTO;
	private CollectEventHandler collectEventHandler;

	private Set<Type> types;

	private Collect commonCollect;

	private Exception exception;

	private CollectAllDetailsDTO commonCollectAllDetailsDTO;

	private final Set<Collect> collects = new HashSet<>();

	public CollectUpdateSteps() {
		collectRepository = mock(CollectRepository.class);
		gdnParamRepository = mock(GdnParamRepository.class);
		collectEventHandler = mock(CollectEventHandler.class);
		typeRepository = mock(TypeRepository.class);
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(false);
		final TypeValidator typeValidator = new TypeValidator();
		final NomenclatureService nomenclatureService = mock(NomenclatureService.class);

		doAnswer(invocation -> {
			final UUID collectId = invocation.getArgument(0);
			return collects.stream().filter(collectL -> collectL.getId().equals(collectId)).findAny().orElse(null);
		}).when(collectRepository).findOne(any());

		doAnswer(invocation -> {
			final Collect collect = invocation.getArgument(0);
			collects.remove(collect);
			collects.add(collect);

			return null;
		}).when(collectRepository).endCollect(any());

		final Environment environment = mock(Environment.class);
		collectService = new CollectServiceImpl(collectRepository, typeRepository, gdnParamRepository, new CollectValidator(), collectEventHandler, auditGenerator, environment, typeValidator, new EdocTypesRepositoryImpl(), new EdocIndexRepositoryImpl());
		collectService.setNomenclatureService(nomenclatureService);
		collectActions = new CollectActionsImpl(collectService, new CustomMapper());
		ReflectionTestUtils.setField(collectService, "authorizedFormat", "PDF,PDF/A,PNG,JPEG,GIF,TIF,TIFF");
		collectService.setFeatureManager(featureManager);
	}

	@Given("^Existing collects$")
	public void existing_collects(List<Collect> collects) throws Throwable {
		this.collects.addAll(collects);
	}

	@Given("^Existing familiesManagmentActs in collect <\"([^\"]*)\">$")
	public void existing_familiesManagmentActs_in_collect(String idCollect, List<String> familiesManagementAct) throws Throwable {
		final Collect collect = collects.stream().filter(collectL -> collectL.getId().equals(UUID.fromString(idCollect))).findAny().orElse(null);
		assertThat(collect).isNotNull();
		collect.setFamiliesManagementAct(ImmutableSet.copyOf(familiesManagementAct));

	}

	@Given("^Existing owners in collect <\"([^\"]*)\">$")
	public void existing_owners_in_collect(String idCollect, List<Owner> owners) throws Throwable {
		final Collect collect = collects.stream().filter(collectL -> collectL.getId().equals(UUID.fromString(idCollect))).findAny().orElse(null);
		assertThat(collect).isNotNull();
		collect.setOwners(new HashSet<Owner>(owners));
	}

	@Given("^An existing list of types in collect <\"([^\"]*)\">$")
	public void an_existing_list_of_types_in_collect(String idCollect, List<Type> types) throws Throwable {
		final Collect collect = collects.stream().filter(collectL -> collectL.getId().equals(UUID.fromString(idCollect))).findAny().orElse(null);
		assertThat(collect).isNotNull();
		collect.setTypes(ImmutableSet.copyOf(types));
	}

	@Given("^a collect$")
	public void a_collect(List<CollectAllDetailsDTO> collectDTOs) throws Throwable {
		commonCollectAllDetailsDTO = collectDTOs.iterator().next();
		assertThat(commonCollectAllDetailsDTO).isNotNull();
	}

	@Given("^with owners in collect <\"([^\"]*)\"> to save$")
	public void with_owners_in_collect_to_save(String idCollect, List<OwnerDTO> ownersDTO) throws Throwable {
		assertThat(commonCollectAllDetailsDTO.getId()).isEqualTo(UUID.fromString(idCollect));
		commonCollectAllDetailsDTO.setOwners(ownersDTO);
	}

	@Given("^void owners in collect <\"([^\"]*)\">$")
	public void void_owners_in_collect(String idCollect) throws Throwable {
		assertThat(commonCollectAllDetailsDTO.getId()).isEqualTo(UUID.fromString(idCollect));

		commonCollectAllDetailsDTO.setOwners(new ArrayList<OwnerDTO>());
	}

	@Given("^list of families in collect <\"([^\"]*)\">$")
	public void list_of_families_in_collect(String idCollect, List<FamilyDTO> families) throws Throwable {
		assertThat(commonCollectAllDetailsDTO.getId()).isEqualTo(UUID.fromString(idCollect));

		commonCollectAllDetailsDTO.setFamilies(families);
	}

	@Given("^list of types in collect <\"([^\"]*)\">, family <\"([^\"]*)\">$")
	public void list_of_types_in_collect_family(String idCollect, String idFamily, List<TypeDTO> types) throws Throwable {
		assertThat(commonCollectAllDetailsDTO.getId()).isEqualTo(UUID.fromString(idCollect));
		assertThat(commonCollectAllDetailsDTO.getFamilies()).isNotEmpty();
		final FamilyDTO familyDTO = commonCollectAllDetailsDTO.getFamilies().stream().filter(familyDTOL -> familyDTOL.getId().equals(UUID.fromString(idFamily))).findAny().orElse(null);
		assertThat(familyDTO).isNotNull();
		familyDTO.setTypes(types);
	}

	@When("^I update the collect$")
	public void i_update_the_collect() throws Throwable {
		try {

			collectActions.updateCollect(commonCollectAllDetailsDTO.getId(), commonCollectAllDetailsDTO, new Context("1", "001", "001"));
		} catch (final Exception ex) {
			this.exception = ex;
		}
	}

	@Then("^there is no exception$")
	public void there_is_no_exception() throws Throwable {
		assertThat(exception).isNull();
	}

	@Then("^the collect <\"([^\"]*)\"> has one owner with reference <\"([^\"]*)\">, name <\"([^\"]*)\">, firstname <\"([^\"]*)\"> and nature <\"([^\"]*)\">$")
	public void the_collect_has_one_owner_with_reference_name_firstname_and_nature(String idCollect, String reference, String name, String firstname, String nature) throws Throwable {
		final Collect collect = collects.stream().filter(collectL -> collectL.getId().equals(UUID.fromString(idCollect))).findAny().orElse(null);
		assertThat(collect).isNotNull();
		assertThat(collect.getOwners()).isNotEmpty();
		final Owner owner = collect.getOwners().stream().filter(ownerL -> ownerL.getReference().equals(reference)).findAny().orElse(null);
		assertThat(owner).isNotNull();
		assertThat(owner.getName()).isEqualTo(name);
		assertThat(owner.getFirstname()).isEqualTo(firstname);
		assertThat(owner.getNature()).isEqualTo(new Integer(nature));
	}

	@Then("^in the collect <\"([^\"]*)\"> owners has (\\d+) element\\(s\\)$")
	public void in_the_collect_owners_has_element_s(String idCollect, int nbOwners) throws Throwable {
		final Collect collect = collects.stream().filter(collectL -> collectL.getId().equals(UUID.fromString(idCollect))).findAny().orElse(null);
		assertThat(collect).isNotNull();
		assertThat(collect.getOwners().size()).isEqualTo(nbOwners);
	}

	@Then("^the collect <\"([^\"]*)\"> does not have owner with reference <\"([^\"]*)\">$")
	public void the_collect_does_not_have_owner_with_reference(String idCollect, String reference) throws Throwable {
		final Collect collect = collects.stream().filter(collectL -> collectL.getId().equals(UUID.fromString(idCollect))).findAny().orElse(null);
		assertThat(collect).isNotNull();
		assertThat(collect.getOwners()).isNotEmpty();
		final Owner owner = collect.getOwners().stream().filter(ownerL -> ownerL.getReference().equals(reference)).findAny().orElse(null);
		assertThat(owner).isNull();
	}

	@Then("^collect <\"([^\"]*)\">, type <\"([^\"]*)\">  productLabel, entityLabel, familiesManagementAct, familyCategory were not changed$")
	public void collect_type_productLabel_entityLabel_familiesManagementAct_familyCategory_were_not_changed(String idCollect, String idType) throws Throwable {
		final Collect collect = collects.stream().filter(collectL -> collectL.getId().equals(UUID.fromString(idCollect))).findAny().orElse(null);
		assertThat(collect).isNotNull();
		assertThat(collect.getProductLabel()).isNotEqualTo("test");
		assertThat(collect.getEntityLabel()).isNotEqualTo("test");
		collect.getFamiliesManagementAct().stream().forEach(familyManagementActL -> assertThat(familyManagementActL).isNotEqualTo("test"));
		collect.getTypes().stream().filter(typeL -> typeL.getId().equals(UUID.fromString(idType))).forEach(type -> assertThat(type.getFamilyCategory()).isNotEqualTo("test"));

	}

}
