package com.bnpparibas.bddf.collect.application.type.sm01.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.Feature;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.IndexDTO;
import com.bnpparibas.bddf.collect.application.dto.OwnerDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.collect.CollectActionsImpl;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActionsImpl;
import com.bnpparibas.bddf.collect.application.service.type.TypeActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditEventService;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.audit.event.LadRadFeature;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.CollectServiceImpl;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.ladrad.LadRadValidator;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusFolderDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.TypeControls;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.GdnParamRepository;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnService;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.piece.validation.ValidationPieceRepository;
import com.bnpparibas.bddf.collect.domain.type.FamilyRepository;
import com.bnpparibas.bddf.collect.domain.type.LadRadRepository;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadService;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AutoAcceptationTypeSteps {

	private PieceActionsImpl pieceAction;
	private Collect existingCollect;
	private Collect savedCollect;
	private CollectAllDetailsDTO collectDTO;
	private TypeActionsImpl typeAction;
	private TypeAutomaticControlUtils typeAutomaticControlUtils;
	private CollectActionsImpl collectAction;

	public AutoAcceptationTypeSteps() throws InterruptedException {
		final CollectRepository collectRepository = mock(CollectRepository.class);
		final TypeRepository typeRepository = mock(TypeRepository.class);
		final CollectEventHandler collectEventHandler = mock(CollectEventHandler.class);
		final MessageSource messageSource = mock(MessageSource.class);
		final AuditGenerator auditGenerator = new AuditGenerator(messageSource);
		final PieceRepository pieceRepository = mock(PieceRepository.class);
		final ValidationPieceRepository validationPieceRepository = mock(ValidationPieceRepository.class);
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		final LadRadRepository ladRadRepository = mock(LadRadRepository.class);
		final EdocIndexRepository edocIndexRepository = new EdocIndexRepositoryImpl();
		final FeatureManager featureManagerLadRad = mock(FeatureManager.class);
		final NomenclatureService nomenclatureService = mock(NomenclatureService.class);
		final PieceGdnService pieceGdnService = mock(PieceGdnService.class);
		final FamilyRepository familyRepository = mock(FamilyRepository.class);
		final TypeValidator typeValidator = new TypeValidator();

		final LadRadValidator ladRadValidator = new LadRadValidator();
		final EdocTypeRepository edocTypeRepository = new EdocTypesRepositoryImpl();

		final TypeLadRadService typeLadRadService = new TypeLadRadServiceImpl(ladRadRepository, edocIndexRepository, typeRepository, edocTypeRepository, ladRadValidator);

		final TypeAutomaticControlUtils typeAutomaticControlUtils = new TypeAutomaticControlUtils(ladRadRepository, ladRadValidator, typeRepository, typeValidator, typeLadRadService, collectRepository, collectEventHandler, edocTypeRepository,
				nomenclatureService, edocIndexRepository, docReferenceService, featureManagerLadRad);

		final AuditEventService auditEventService = mock(AuditEventService.class);
		doNothing().when(auditEventService).sendAuditEventLadRAD(any(), any(), any(), any(), any(), any());
		doNothing().when(auditEventService).sendAuditEventLadRADFirstIteration(any(), any(), any(), any(), any(), any(), any(), any());
		doNothing().when(auditEventService).sendAuditEventLadRADSecondIteration(any(), any(), any(), any(), any(), any(), any());
		when(auditEventService.sendAuditEventForcedRecognition(any(), any(), any(), any(), any())).thenReturn(true);
		typeAutomaticControlUtils.setAuditEventService(auditEventService);

		final Environment environment = mock(Environment.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		when(environment.getProperty("param.controlIterationAllowed", Integer.class, 2)).thenReturn(3);
		when(environment.getProperty("auto-closing.delay", Integer.class, 360)).thenReturn(360);

		final CollectValidator customValidator = new CollectValidator();
		final PieceValidator pieceValidator = new PieceValidator();
		final PiecesStatusActionsRepository piecesStatusActionsRepository = mock(PiecesStatusActionsRepository.class);
		pieceValidator.setPieceStatusRepository(piecesStatusActionsRepository);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("TP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("VA"), eq("VA"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("DP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutPieces(eq("TP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutPieces(eq("DP"), any())).thenReturn(true);

		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("TP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DF"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DF"), eq("RC"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DF"), eq("RF"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("VA"), eq("VA"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("VA"), eq("RF"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("RC"), eq("RC"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("RC"), eq("RF"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("RC"), eq("VA"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DP"), eq("VA"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DP"), eq("RC"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DP"), eq("RF"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("RF"), eq("DP"), any())).thenReturn(true);

		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutType(eq("TP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutType(eq("DP"), any())).thenReturn(true);

		when(collectRepository.findOne(any())).thenAnswer(invocation -> {
			return existingCollect;
		});

		when(collectRepository.findOnlyCollect(any())).thenAnswer(invocation -> {
			return existingCollect;
		});

		doAnswer(invocation -> {
			savedCollect = invocation.getArgument(0);
			return null;
		}).when(collectRepository).add(any());

		when(ladRadRepository.getStatusFolder(any(), any())).then(invocation -> {
			return new StatusFolderDTO();
		});

		when(ladRadRepository.getStatusDocument(any(), any())).then(invocation -> {
			return new StatusDocumentDTO();
		});

		when(typeRepository.findOne(any(), any())).then(invocation -> {
			final UUID idCollect = invocation.getArgument(0);
			final UUID idType = invocation.getArgument(1);
			return existingCollect.getTypes().stream().filter(typeL -> typeL.getId().equals(idType)).findFirst().orElse(null);

		});

		doNothing().when(validationPieceRepository).deleteByID(any());

		// service
		final FeatureManager featureManager = mock(FeatureManager.class);
		doAnswer(invocation -> {

			final Feature featureTmp = invocation.getArgument(0);

			if (featureTmp instanceof LadRadFeature) {
				final LadRadFeature feature = (LadRadFeature) featureTmp;
				if ("000001".equals(feature.getLabel())) {
					return true;
				} else if ("100001".equals(feature.getLabel())) {
					return false;
				} else {
					throw new IllegalArgumentException();
				}
			} else {
				return new IllegalArgumentException();
			}

		}).when(featureManager).isActive(any());
		final TypeAutomaticControlServiceImpl typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, typeValidator, nomenclatureService, edocIndexRepository, featureManager, pieceRepository, null,
				new LadRadValidator(), edocTypeRepository, typeRepository, docReferenceService, typeAutomaticControlUtils);
		typeAutomaticControlService.setCollectRepository(collectRepository);
		typeAutomaticControlService.setLadRadRepository(ladRadRepository);
		typeAutomaticControlService.setAuditEventService(auditEventService);

		final PieceAutomaticControlUtils pieceAutomaticControlUtils = new PieceAutomaticControlUtils(pieceGdnService, typeAutomaticControlService);
		final PieceServiceImpl pieceService = new PieceServiceImpl(collectRepository, typeRepository, pieceRepository, customValidator, collectEventHandler, null, auditGenerator, environment, typeAutomaticControlService, featureManagerLadRad,
				pieceAutomaticControlUtils);
		pieceService.setEdocTypeRepository(edocTypeRepository);
		pieceService.setPieceValidator(pieceValidator);

		pieceAction = new PieceActionsImpl(pieceService, new CustomMapper());

		final TypeServiceImpl typeService = new TypeServiceImpl(collectRepository, typeRepository, customValidator, collectEventHandler, auditGenerator, docReferenceService, typeAutomaticControlService, familyRepository);
		typeAction = new TypeActionsImpl(typeService, new CustomMapper());

		typeService.setEdocTypeRepository(edocTypeRepository);
		typeService.setFeatureManager(featureManagerLadRad);
		typeService.setPieceValidator(pieceValidator);
		typeService.setTypeValidator(typeValidator);
		typeService.setPieceGdnService(pieceGdnService);
		typeService.setAuditEventService(auditEventService);
		typeService.setValidationPieceRepository(validationPieceRepository);

		final CollectServiceImpl collectService = new CollectServiceImpl(collectRepository, typeRepository, mock(GdnParamRepository.class), customValidator, collectEventHandler, auditGenerator, environment, typeValidator, edocTypeRepository,
				edocIndexRepository);
		collectService.setNomenclatureService(nomenclatureService);
		collectService.setFeatureManager(featureManager);
		collectAction = new CollectActionsImpl(collectService, new CustomMapper());
	}

	@Given("^An existing collect$")
	public void an_existing_collect(List<Collect> collects) throws Throwable {
		this.existingCollect = collects.get(0);
		existingCollect.setJourneyCode("000001");
	}

	@Given("^An existing Owners$")
	public void an_existing_Owners(List<Owner> owners) throws Throwable {
		this.existingCollect.setOwners(new HashSet<>(owners));
	}

	@Given("^An existing types$")
	public void an_existing_types(List<Type> types) throws Throwable {
		this.existingCollect.getTypes().addAll(types);
	}

	@Given("^existing pieces in type <\"([^\"]*)\">$")
	public void existing_pieces_in_type(String typeId, List<Piece> pieces) throws Throwable {
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get().setPieces(pieces.stream().collect(Collectors.toSet()));
	}

	@Given("^New indexes in type <\"([^\"]*)\">$")
	public void new_indexes_in_type(String typeId, List<Indexe> indexes) throws Throwable {
		indexes.forEach(indexe -> indexe.setOwnerIndex("1"));
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get().setIndexes(indexes.stream().collect(Collectors.toSet()));
	}

	@Given("^Existing completeness in type <\"([^\"]*)\">$")
	public void existing_completeness_in_type(String typeId, List<String> completeness) throws Throwable {
		existingCollect.getTypes().stream().filter(type -> typeId.equals(type.getId().toString())).findAny().get().setCompleteness(completeness.stream().collect(Collectors.toSet()));
	}

	@Given("^existing indexes in type <\"([^\"]*)\">$")
	public void existing_indexes_in_type(String typeId, List<Indexe> indexes) throws Throwable {
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get().setIndexes(indexes.stream().collect(Collectors.toSet()));
	}

	@Given("^existing typeJmc in piece <\"([^\"]*)\"> of type <\"([^\"]*)\">$")
	public void existing_typeJmc_in_piece_of_type(String idPiece, String typeId, List<String> typesJmc) throws Throwable {
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get().getPieces().stream().filter(p -> p.getId().toString().equals(idPiece)).findAny().get().setTypesJmc(typesJmc);// .stream().collect(Collectors.toList()));
	}

	@When("^I update pieces of type <\"([^\"]*)\">$")
	public void i_update_pieces_of_type(String typeId) throws Throwable {
		final List<PieceDTO> piecesDTO = existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get().getPieces().stream().map(piece -> new PieceDTO(piece, Channel.SPIRIT.getValue())).collect(Collectors.toList());
		pieceAction.updatePieces(existingCollect.getId(), existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get().getId(), piecesDTO, new Context("123456", Channel.SPIRIT.getValue()));
	}

	@When("^I update a type <\"([^\"]*)\">$")
	public void i_update_a_type(String typeId) throws Throwable {
		final SubTypeDTO typeDTO = new SubTypeDTO(existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get(), Channel.SPIRIT.getValue());
		typeDTO.setStatusControl(TypeControls.CT.getLabel());
		typeAction.updateType(existingCollect.getId(), UUID.fromString(typeId), typeDTO, new Context("123456", Channel.SPIRIT.getValue()));
	}

	@Then("^I expect pieces status <\"([^\"]*)\"> for the type <\"([^\"]*)\">$")
	public void i_expect_pieces_status_for_the_type(String pieceStatus, String typeId) throws Throwable {
		existingCollect.getTypes().stream().filter(type -> typeId.equals(type.getId().toString())).findAny().get().getPieces().forEach(piece -> {
			assertThat(piece.getStatus()).isEqualTo(pieceStatus);
		});
	}

	@Then("^I expect status <\"([^\"]*)\"> for the type <\"([^\"]*)\">$")
	public void i_expect_status_for_the_type(String typeStatus, String typeId) throws Throwable {
		assertThat(existingCollect.getTypes().stream().filter(type -> typeId.equals(type.getId().toString())).findAny().get().getStatus()).isEqualTo(typeStatus);
	}

	@Given("^autoAcceptationAllowed is <\"([^\"]*)\">$")
	public void autoacceptationallowed_is(String autoAcceptationAllowed) throws Throwable {
		existingCollect.setAutoAcceptationAllowed(Boolean.valueOf(autoAcceptationAllowed));
	}

	@Given("^A new collect$")
	public void a_new_collect(List<CollectAllDetailsDTO> collects) throws Throwable {
		collectDTO = collects.get(0);
		final List<String> familiesManagementAct = new ArrayList<String>(Arrays.asList("OB"));
		collectDTO.setFamiliesManagementAct(familiesManagementAct);
		collectDTO.setJourneyCode("000001");
	}

	@Given("^New Owners$")
	public void new_Owners(List<OwnerDTO> owners) throws Throwable {
		collectDTO.setOwners(owners);
	}

	@Given("^A new family$")
	public void a_new_family(List<FamilyDTO> families) throws Throwable {
		collectDTO.setFamilies(families);
	}

	@Given("^New types to add$")
	public void new_types_to_add(List<TypeDTO> types) throws Throwable {
		collectDTO.getFamilies().get(0).setTypes(types);
	}

	@Given("^New indexes in type$")
	public void existing_indexes_in_type(List<IndexDTO> indexes) throws Throwable {
		collectDTO.getFamilies().get(0).getTypes().get(0).setIndexes(indexes);
	}

	@When("^I save the collect$")
	public void i_save_the_collect() throws Throwable {
		collectAction.saveCollect(collectDTO, new Context("123456", "001"));
	}

	@Then("^I expect autoAcceptationAllowed to be equal to <\"([^\"]*)\">$")
	public void i_expect_autoAcceptationAllowed_to_be_equal_to(String value) throws Throwable {
		assertTrue(savedCollect.isAutoAcceptationAllowed() == Boolean.valueOf(value));
	}

}
