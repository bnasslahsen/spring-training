package com.bnpparibas.bddf.collect.application.typedelete.sm02.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.Feature;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.type.TypeActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditEventService;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.audit.event.LadRadFeature;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.ladrad.LadRadValidator;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusFolderDTO;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnService;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.piece.validation.ValidationPieceRepository;
import com.bnpparibas.bddf.collect.domain.type.FamilyRepository;
import com.bnpparibas.bddf.collect.domain.type.LadRadRepository;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadService;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TypeDeleteSteps {

	private TypeActionsImpl typeAction;
	private Collect existingCollect;
	private Exception currentException;

	public TypeDeleteSteps() throws InterruptedException {

		final CollectRepository collectRepository = mock(CollectRepository.class);
		final TypeRepository typeRepository = mock(TypeRepository.class);
		final CollectEventHandler collectEventHandler = mock(CollectEventHandler.class);
		final MessageSource messageSource = mock(MessageSource.class);
		final AuditGenerator auditGenerator = new AuditGenerator(messageSource);
		final PieceRepository pieceRepository = mock(PieceRepository.class);
		final ValidationPieceRepository validationPieceRepository = mock(ValidationPieceRepository.class);
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		final LadRadRepository ladRadRepository = mock(LadRadRepository.class);
		final EdocIndexRepository edocIndexRepository = new EdocIndexRepositoryImpl();
		final FeatureManager featureManagerLadRad = mock(FeatureManager.class);
		final NomenclatureService nomenclatureService = mock(NomenclatureService.class);
		final PieceGdnService pieceGdnService = mock(PieceGdnService.class);
		final FamilyRepository familyRepository = mock(FamilyRepository.class);
		final TypeValidator typeValidator = new TypeValidator();
		
		final Environment environment = mock(Environment.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		when(environment.getProperty("param.controlIterationAllowed", Integer.class, 2)).thenReturn(3);
		when(environment.getProperty("auto-closing.delay", Integer.class, 180)).thenReturn(180);
		when(environment.getProperty("waitingPeriod.inLoop.JMC_SET")).thenReturn("0");
		when(environment.getProperty("waitingPeriod.maxDuration.JMC_SET")).thenReturn("0");
		

		final LadRadValidator ladRadValidator = new LadRadValidator();
		final EdocTypeRepository edocTypeRepository = new EdocTypesRepositoryImpl();

		final TypeLadRadService typeLadRadService = new TypeLadRadServiceImpl(ladRadRepository, edocIndexRepository, typeRepository, edocTypeRepository, ladRadValidator);
		((TypeLadRadServiceImpl)typeLadRadService).setEnv(environment);

		final TypeAutomaticControlUtils typeAutomaticControlUtils = new TypeAutomaticControlUtils(ladRadRepository, ladRadValidator, typeRepository, typeValidator, typeLadRadService, collectRepository, collectEventHandler, edocTypeRepository,
				nomenclatureService, edocIndexRepository, docReferenceService, featureManagerLadRad);

		final AuditEventService auditEventService = mock(AuditEventService.class);
		doNothing().when(auditEventService).sendAuditEventLadRAD(any(), any(), any(), any(), any(), any());
		doNothing().when(auditEventService).sendAuditEventLadRADFirstIteration(any(), any(), any(), any(), any(), any(), any(), any());
		doNothing().when(auditEventService).sendAuditEventLadRADSecondIteration(any(), any(), any(), any(), any(), any(), any());
		when(auditEventService.sendAuditEventForcedRecognition(any(), any(), any(), any(), any())).thenReturn(true);
		typeAutomaticControlUtils.setAuditEventService(auditEventService);

		final CollectValidator customValidator = new CollectValidator();
		final PieceValidator pieceValidator = new PieceValidator();
		final PiecesStatusActionsRepository piecesStatusActionsRepository = mock(PiecesStatusActionsRepository.class);
		pieceValidator.setPieceStatusRepository(piecesStatusActionsRepository);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("TP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("VA"), eq("VA"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("DP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutPieces(eq("TP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutPieces(eq("DP"), any())).thenReturn(true);

		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("TP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DF"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DF"), eq("RC"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DF"), eq("RF"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("VA"), eq("VA"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("VA"), eq("RF"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("RC"), eq("RC"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("RC"), eq("RF"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("RC"), eq("VA"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DP"), eq("VA"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DP"), eq("RC"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DP"), eq("RF"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("RF"), eq("DP"), any())).thenReturn(true);

		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutType(eq("TP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutType(eq("DP"), any())).thenReturn(true);

		when(collectRepository.findOne(any())).thenAnswer(invocation -> {
			final UUID idCollect = invocation.getArgument(0);
			if(existingCollect.getId().equals(idCollect))
				return existingCollect;
			else
				return null;
		});

		when(collectRepository.findOnlyCollect(any())).thenAnswer(invocation -> {
			final UUID idCollect = invocation.getArgument(0);
			if(existingCollect.getId().equals(idCollect))
				return existingCollect;
			else
				return null;
		});

		when(ladRadRepository.getStatusFolder(any(), any())).then(invocation -> {
			return new StatusFolderDTO();
		});

		when(ladRadRepository.getStatusDocument(any(), any())).then(invocation -> {
			final String json = "{\"status\":\"2\",\"differedTimeStatus\":\"-2\",\"differedTimeStatusList\":{\"_children\":[],\"_nodeFactory\":{\"_cfgBigDecimalExact\":false}},\"reference\":\"x3caw1XBZQ\",\"externalRef\":\"d1c19a59-36db-45bb-8a60-725077445f4c-1\",\"totalPages\":1,\"processedPages\":1,\"pages\":[{\"pieces\":[{\"status\":\"2\",\"type\":\"tax_assessment_income_page1\",\"reference\":\"2SiiBoKUMK\",\"documentType\":\"tax_assessment_income\",\"documentFamily\":\"address_proof\",\"pieceOrder\":\"1\",\"matchExpectedDocFamily\":0,\"matchExpectedDocType\":0,\"matchExpectedType\":0}],\"processedPieces\":1,\"status\":\"2\",\"pageNumber\":1,\"refDocFamily\":\"address_proof\",\"businessStatus\":\"9\",\"reference\":\"1cghW9bVm1\"}]}";
			final ObjectMapper objectMapper = new ObjectMapper();
			try {
				return objectMapper.readValue(json, StatusDocumentDTO.class);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		});
		
		when(ladRadRepository.getPiece(any(), any())).then(invocation -> {
			return "{\"fields\":{\"name\":{\"kind\":\"corrected\",\"value\":\"Doe\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"firstname\":{\"kind\":\"computed\",\"value\":\"JEAN\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":0,\"message\":\"missing_piece_data_value\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"tax_year\":{\"kind\":\"extracted\",\"value\":\"2017\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":0,\"message\":null,\"status\":\"NOT_VALID\"},\"validity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"income_tax_reference\":{\"kind\":\"extracted\",\"value\":\"82675\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_CONTROLLED\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"tax_amount\":{\"kind\":\"extracted\",\"value\":\"1.00\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_CONTROLLED\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"notice_ref\":{\"kind\":\"extracted\",\"value\":\"1792B31088539\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"tax_number\":{\"kind\":null,\"value\":null,\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":0,\"message\":\"missing_piece_data_value\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"declarant_one\":{\"kind\":\"extracted\",\"value\":\"1343466604081C\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"declarant_two\":{\"kind\":\"extracted\",\"value\":\"0708457345302C\",\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"address\":{\"kind\":\"extracted\",\"value\":\"M MOURA JEAN LUC\\nOU MME HIPPOLYTE ANITA\\nM OU MME MOURA\\n14 AVENUE DU BOIS DE LA MARCHE\\n92420 VAUCRESSON\",\"transformed_value\":\"M MOURA JEAN LUC\\nOU MME HIPPOLYTE ANITA\\nM OU MME MOURA\\n14 Avenue du Bois de la Marche\\n92420 VAUCRESSON\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_CONTROLLED\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"rnvp_identity_name\":{\"kind\":\"extracted\",\"value\":\"M MOURA JEAN LUC\\nOU MME HIPPOLYTE ANITA\\nM OU MME MOURA\",\"transformed_value\":\"M MOURA JEAN LUC\\nOU MME HIPPOLYTE ANITA\\nM OU MME MOURA\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_CONTROLLED\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"rnvp_company_name\":{\"kind\":null,\"value\":null,\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":0,\"message\":\"missing_piece_data_value\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"rnvp_compl_int\":{\"kind\":null,\"value\":null,\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":0,\"message\":\"missing_piece_data_value\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"rnvp_compl_ext\":{\"kind\":null,\"value\":null,\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":0,\"message\":\"missing_piece_data_value\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"rnvp_street\":{\"kind\":\"extracted\",\"value\":\"14 Avenue du Bois de la Marche\",\"transformed_value\":\"14 Avenue du Bois de la Marche\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"rnvp_ldprbp\":{\"kind\":null,\"value\":null,\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":0,\"message\":\"missing_piece_data_value\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"rnvp_cp_town\":{\"kind\":\"extracted\",\"value\":\"92420 VAUCRESSON\",\"transformed_value\":\"92420 VAUCRESSON\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":100,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"rnvp_country\":{\"kind\":null,\"value\":null,\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":0,\"message\":\"missing_piece_data_value\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"barcode\":{\"kind\":null,\"value\":null,\"transformed_value\":null,\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":0,\"message\":\"missing_piece_data_value\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}}},\"validity_controls\":{\"back\":{\"CTRL_REFERENCE_AVIS\":\"OK\",\"CTRL_DECLARANT_1\":\"OK\",\"CTRL_DECLARANT_2\":\"OK\",\"CTRL_VOIE_COHERENT\":\"OK\",\"CTRL_VOIE_INDB\":\"OK\",\"CTRL_VOIE_NON_PROVISOIRE\":\"OK\",\"CTRL_LOCALITE_INDB\":\"OK\"},\"front\":{\"tax_assessment_is_recent\":\"OK\"}},\"conformity_controls\":{\"dossier_name\":\"OK\",\"dossier_firstname\":\"OK\",\"dossier_tax_year\":\"KO\"},\"controls\":{\"fraud_controls\":{\"fraud_document_creator\":{\"status\":\"NOT_APPLICABLE_WARNING\",\"kind\":\"computed\"}},\"validity_controls\":{\"CTRL_REFERENCE_AVIS\":{\"status\":\"OK\",\"kind\":\"computed\"},\"CTRL_DECLARANT_1\":{\"status\":\"OK\",\"kind\":\"computed\"},\"CTRL_DECLARANT_2\":{\"status\":\"OK\",\"kind\":\"computed\"},\"CTRL_VOIE_COHERENT\":{\"status\":\"OK\",\"kind\":\"computed\"},\"CTRL_VOIE_INDB\":{\"status\":\"OK\",\"kind\":\"computed\"},\"CTRL_VOIE_NON_PROVISOIRE\":{\"status\":\"OK\",\"kind\":\"computed\"},\"CTRL_LOCALITE_INDB\":{\"status\":\"OK\",\"kind\":\"computed\"},\"tax_assessment_is_recent\":{\"status\":\"OK\",\"kind\":\"computed\"}},\"conformity_controls\":{\"dossier_name\":{\"status\":\"OK\",\"kind\":\"computed\"},\"dossier_firstname\":{\"status\":\"OK\",\"kind\":\"computed\"},\"dossier_tax_year\":{\"status\":\"KO\",\"kind\":\"computed\"}}},\"type\":\"tax_assessment_income_page1\",\"document_family\":\"address_proof\",\"document_type\":\"tax_assessment_income\",\"mandatory\":null,\"data_type\":null,\"business_status\":null,\"creation_date\":\"2019-03-26 17:47:53\",\"last_dossier_analyze_date\":\"19-03-26 17:49:31\",\"fraud_controls\":{\"fraud_document_creator\":\"NOT_APPLICABLE_WARNING\"},\"images\":{\"image_original\":{\"selected\":0,\"href\":\"\\/images\\/piece\\/3Xg9QmmodS\"},\"image_warped\":{\"selected\":0,\"href\":\"\\/images\\/piece\\/04IbuUEVNX\"}},\"links\":{\"data\":{\"href\":\"\\/pieces\\/2SiiBoKUMK\"},\"status\":{\"href\":\"\\/pieces\\/2SiiBoKUMK\\/status\"},\"rawdata\":{\"href\":\"\\/pieces\\/2SiiBoKUMK\\/rawdata\"},\"document\":{\"href\":\"\\/documents\\/x3caw1XBZQ\\/status\"},\"page\":{\"href\":\"\\/pages\\/1cghW9bVm1\\/status\"},\"update\":{\"href\":\"\\/pieces\\/2SiiBoKUMK\\/update\"},\"differed_time_update\":{\"href\":\"\\/differed-time\\/pieces\\/2SiiBoKUMK\\/update\"},\"deactivate\":{\"href\":\"\\/pieces\\/2SiiBoKUMK\\/deactivate\"},\"force_piece_type\":{\"href\":\"\\/pieces\\/2SiiBoKUMK\\/forcePieceType\"}}}";
		});

		when(typeRepository.findOne(any(), any())).then(invocation -> {
			final UUID idType = invocation.getArgument(1);
			return existingCollect.getTypes().stream().filter(typeL -> typeL.getId().equals(idType)).findFirst().orElse(null);

		});
		
		doAnswer(invocation -> {
			final Type type = invocation.getArgument(0);
			final UUID idType = type.getId();
			existingCollect.getTypes().removeIf(typeL -> idType.equals(typeL.getId()) || idType.equals(typeL.getParentId()));
			return null;

		}).when(typeRepository).delete(any());

		doNothing().when(validationPieceRepository).deleteByID(any());

		// service
		final FeatureManager featureManager = mock(FeatureManager.class);
		doAnswer(invocation -> {

			final Feature featureTmp = invocation.getArgument(0);

			if (featureTmp instanceof LadRadFeature) {
				final LadRadFeature feature = (LadRadFeature) featureTmp;
				if ("000001".equals(feature.getLabel())) {
					return true;
				} else if ("100001".equals(feature.getLabel())) {
					return false;
				} else {
					throw new IllegalArgumentException();
				}
			} else {
				return new IllegalArgumentException();
			}

		}).when(featureManager).isActive(any());
		final TypeAutomaticControlServiceImpl typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, typeValidator, nomenclatureService, edocIndexRepository, featureManager, pieceRepository, null, new LadRadValidator(),
				edocTypeRepository, typeRepository, docReferenceService, typeAutomaticControlUtils);
		typeAutomaticControlService.setCollectRepository(collectRepository);
		typeAutomaticControlService.setLadRadRepository(ladRadRepository);
		typeAutomaticControlService.setAuditEventService(auditEventService);

		final TypeServiceImpl typeService = new TypeServiceImpl(collectRepository, typeRepository, customValidator, collectEventHandler, auditGenerator, docReferenceService, typeAutomaticControlService, familyRepository);
		typeAction = new TypeActionsImpl(typeService, new CustomMapper());

		typeService.setEdocTypeRepository(edocTypeRepository);
		typeService.setFeatureManager(featureManagerLadRad);
		typeService.setPieceValidator(pieceValidator);
		typeService.setTypeValidator(typeValidator);
		typeService.setPieceGdnService(pieceGdnService);
		typeService.setAuditEventService(auditEventService);
		typeService.setValidationPieceRepository(validationPieceRepository);
	}

	@Given("^An existing collect$")
	public void an_existing_collect(List<Collect> collects) throws Throwable {
		this.existingCollect = collects.get(0);
	}

	@Given("^An existing Owners$")
	public void an_existing_Owners(List<Owner> owners) throws Throwable {
		this.existingCollect.setOwners(new HashSet<>(owners));
	}

	@Given("^An existing types$")
	public void an_existing_types(List<Type> types) throws Throwable {
		this.existingCollect.getTypes().addAll(types);
	}

	@Given("^existing pieces in type <\"([^\"]*)\">$")
	public void existing_pieces_in_type(String idType, List<Piece> pieces) throws Throwable {
		pieces.forEach(pieceL -> pieceL.setState(PieceStates.ACTIF.getLabel()));
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(idType)).findAny().get().setPieces(pieces.stream().collect(Collectors.toSet()));
	}

	@Given("^Existing completeness in type$")
	public void existing_completeness_in_type(List<String> completeness) throws Throwable {
		existingCollect.getTypes().iterator().next().setCompleteness(completeness.stream().collect(Collectors.toSet()));
	}

	@Given("^existing indexes in type <\"([^\"]*)\">$")
	public void existing_indexes_in_type(String typeId, List<Indexe> indexes) throws Throwable {
		existingCollect.getTypes().iterator().next().setIndexes(indexes.stream().collect(Collectors.toSet()));
	}

	@When("^I delete a type <\"([^\"]*)\"> of collect <\"([^\"]*)\">$")
	public void i_delete_a_type_of_family_of_collect(String idTypeString, String idCollectString) throws Throwable {
		final UUID idCollect = UUID.fromString(idCollectString);
		final UUID idType = UUID.fromString(idTypeString);
		try {
			typeAction.deleteType(idCollect, idType, new Context("132456", "001"));			
		} catch(Exception e) {
			currentException = e;
		}
	}

	@Then("^type <\"([^\"]*)\"> is not deleted$")
	public void type_is_not_deleted(String typeId) throws Throwable {
		assertThat(existingCollect.getTypes().stream().filter(type -> typeId.equals(type.getId().toString())).findAny()).isNotEmpty();
	}

	@Then("^There is no exception$")
	public void there_is_no_exception() throws Throwable {
		assertThat(currentException).isNull();
	}

	@Then("^type <\"([^\"]*)\"> is deleted$")
	public void type_is_deleted(String typeId) throws Throwable {
		assertThat(existingCollect.getTypes().stream().filter(type -> typeId.equals(type.getId().toString())).findAny()).isEmpty();
	}

	@Then("^I expect error code <\"([^\"]*)\">$")
	public void i_expect_error_code(String codeError) throws Throwable {
		assertThat(currentException).isNotNull();
		assertThat(currentException.getMessage()).isEqualTo(codeError);
	}

}
