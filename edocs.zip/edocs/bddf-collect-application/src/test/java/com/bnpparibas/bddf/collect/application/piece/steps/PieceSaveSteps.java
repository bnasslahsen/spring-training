package com.bnpparibas.bddf.collect.application.piece.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.IntStream;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadService;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableSet;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PieceSaveSteps {

	private PieceActionsImpl pieceActions;
	private CollectRepository collectRepository;
	private TypeRepository typeRepository;
	private PieceRepository pieceRepository;

	private PieceDTO pieceDTO;
	private Collect collect;
	private Type type;
	private Piece piece;
	private Piece paperPiece;
	private Exception exception;
	private AuditGenerator auditGenerator;
	private PieceAutomaticControlUtils pieceAutomaticControlUtils;

	ByteBuffer bytes = ByteBuffer.allocate(1000);

	// UPL 2024SM01

	public PieceSaveSteps() {
		collectRepository = mock(CollectRepository.class);
		typeRepository = mock(TypeRepository.class);
		pieceRepository = mock(PieceRepository.class);
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		final CollectEventHandler collectEventHandler = mock(CollectEventHandler.class);
		final TypeLadRadService typeLadRadService = mock(TypeLadRadService.class);
		final TypeValidator typeValidator = new TypeValidator();
		final Environment environment = mock(Environment.class);
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(false);
		final TypeAutomaticControlServiceImpl typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, typeValidator, null, new EdocIndexRepositoryImpl(), featureManager, pieceRepository, null, null, null,
				typeRepository, docReferenceService, new TypeAutomaticControlUtils());
		typeAutomaticControlService.setCollectRepository(collectRepository);
		final PieceValidator pieceValidator = new PieceValidator();
		final PiecesStatusActionsRepository piecesStatusActionsRepository = mock(PiecesStatusActionsRepository.class);
		pieceValidator.setPieceStatusRepository(piecesStatusActionsRepository);

		pieceAutomaticControlUtils = new PieceAutomaticControlUtils(new PieceGdnServiceImpl(), typeAutomaticControlService);
		final PieceServiceImpl pieceService = new PieceServiceImpl(collectRepository, typeRepository, pieceRepository, new CollectValidator(), collectEventHandler, null, auditGenerator, environment, typeAutomaticControlService, featureManager,
				pieceAutomaticControlUtils);
		pieceService.setBlackListJmcFormat("");
		final EdocTypeRepository edocTypeRepository = mock(EdocTypeRepository.class);
		pieceService.setEdocTypeRepository(edocTypeRepository);
		pieceService.setPieceValidator(pieceValidator);
		pieceActions = new PieceActionsImpl(pieceService, new CustomMapper());
		pieceActions.setEnvironment(environment);
		this.pieceDTO = new PieceDTO();
		collect = new Collect(UUID.randomUUID(), "EC", Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", ImmutableSet.<String> of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIF", "TIFF"), ImmutableSet.<String> of("DP", "VA"),
				ImmutableSet.<String> of(), null, "AP001", false, false, 0, false, 0);
		type = new Type(UUID.randomUUID(), null, UUID.randomUUID(), new HashSet<>(Arrays.asList("01740005814400000")), "Justificatif d'identité", "OB", null, "Liste", null, "info compl famille Justificatif d'identité", "Carte d'identité",
				"Veuiller fournir le recto et verso de votre carte d'identité", true, null, 10000, 0, null, false, null, false, null, false, false, null, null, true);
		collect.setTypes(ImmutableSet.<Type> of(type));
	}

	@When("^I save the piece$")
	public void i_save_the_piece(List<PieceDTO> data) throws Throwable {
		pieceDTO = data.get(0);
		piece = new CustomMapper().convertFromPieceDTO(pieceDTO);
		try {
			Optional.ofNullable(collectRepository.findOne(collect.getId())).orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_NOT_FOUND)));
			pieceActions.addPiece(collect.getId(), type.getId(), pieceDTO, bytes, "application/pdf", new Context("123456", "001"));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@When("^I save the unauthorized format piece$")
	public void i_save_the_unauthorized_format_piece(List<PieceDTO> data) throws Throwable {
		pieceDTO = data.get(0);
		pieceDTO.setSize(100000);
		piece = new CustomMapper().convertFromPieceDTO(pieceDTO);
		try {
			pieceActions.addPiece(collect.getId(), type.getId(), pieceDTO, bytes, "application/doc", new Context("123456", "001"));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	/**
	 * Nominal case
	 */

	@Given("^a valid piece$")
	public void a_valid_piece() throws Throwable {
		collect.setTypes(ImmutableSet.<Type> of(type));
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@Then("^I return the id of the piece$")
	public void i_return_the_id_of_the_piece() throws Throwable {
		assertThat(exception).isNull();
	}

	/**
	 * Error cases
	 */

	@Given("^a piece with an excessive size$")
	public void a_piece_with_an_excessive_size() throws Throwable {
		collect.setTypes(ImmutableSet.<Type> of(type));
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@Given("^a piece with an unauthorized format$")
	public void a_piece_with_an_unauthorized_format() throws Throwable {
		type.setDigitalAllowed(false);
		collect.setTypes(ImmutableSet.<Type> of(type));
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@Given("^a valid piece associated to a no digital Allowed type$")
	public void a_valid_piece_associated_to_a_no_digital_Allowed_type() throws Throwable {
		type.setDigitalAllowed(false);
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@Then("^I return the error code : <\"([^\"]*)\">$")
	public void i_return_the_error_code(String arg1) throws Throwable {
		verify(pieceRepository, times(0)).addPieceData(piece.getId(), bytes, null, "");
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);
		assertThat(exception.getMessage()).isEqualTo(arg1);
	}

	@Given("^a valid piece and a type with the maximum number of pieces reached$")
	public void a_valid_piece_and_a_type_with_the_maximum_number_of_pieces_reached() throws Throwable {
		final List<Piece> piecesList = new ArrayList<>();
		IntStream.range(0, 5).forEach(i -> {
			piecesList.add(new Piece(UUID.randomUUID(), null, null, null, null, null, 0, "NUM", "TP", null, null, null, null, null, false));
		});
		type.setPieces(new HashSet<>(piecesList));
		collect.setTypes(ImmutableSet.<Type> of(type));
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@Given("^a valid numeric piece and a type with a paper$")
	public void a_valid_numeric_piece_and_a_type_with_a_paper() throws Throwable {
		paperPiece = new Piece(UUID.randomUUID(), "", "", "", "", Instant.now(), 1000, "PAP", "", "", "", "", null, null, false);
		type.setPieces(new HashSet<>(Arrays.asList(paperPiece)));
		collect.setTypes(ImmutableSet.<Type> of(type));
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);

	}

	@Then("^the paper piece is deleted$")
	public void the_paper_piece_is_deleted() throws Throwable {
		assertEquals(paperPiece.getState(), PieceStates.INACTIF.getLabel());
	}

	@Given("^a valid piece and a closed collect$")
	public void a_valid_piece_and_a_closed_collect() throws Throwable {
		collect.setStatus("CL");
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@Given("^a valid piece and a collect that doesn't exist$")
	public void a_valid_piece_and_a_collect_that_doesn_t_exist() throws Throwable {
		when(collectRepository.findOne(any())).thenReturn(null);
	}

	@Given("^a valid piece and a type that doesn't exist$")
	public void a_valid_piece_and_a_type_that_doesn_t_exist() throws Throwable {
		collect.setTypes(ImmutableSet.<Type> of());
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@Given("^a valid piece and a type that contains a subtype$")
	public void a_valid_piece_and_a_type_that_contains_a_subtype() throws Throwable {
		final Type subType = new Type();
		subType.setId(UUID.randomUUID());
		subType.setParentId(type.getId());
		collect.setTypes(new HashSet<>(Arrays.asList(type, subType)));
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@Given("^a valid piece and a type of a family ND$")
	public void a_valid_piece_and_a_type_of_a_family_ND() throws Throwable {
		type.setFamilyCategory("ND");
		collect.setTypes(ImmutableSet.<Type> of(type));
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@Given("^a valid numeric piece for the type with missing document$")
	public void a_valid_numeric_piece_for_the_type_with_missing_document() throws Throwable {
		type.setPendingDocument(true);
		collect.setTypes(ImmutableSet.<Type> of(type));
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@Given("^a valid piece paper for the type with missing document$")
	public void a_valid_piece_paper_for_the_type_with_missing_document() throws Throwable {
		type.setPendingDocument(true);
		type.setPaperAllowed(true);
		collect.setTypes(ImmutableSet.<Type> of(type));
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@Given("^a paper piece and a type where paperAllowed to false$")
	public void a_paper_piece_and_a_type_where_paperAllowed_to_false() throws Throwable {
		type.setPaperAllowed(false);
		collect.setTypes(ImmutableSet.<Type> of(type));
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@Given("^a paper piece and a type where paperAllowed to true$")
	public void a_paper_piece_and_a_type_where_paperAllowed_to_true() throws Throwable {
		type.setPaperAllowed(true);
		collect.setTypes(ImmutableSet.<Type> of(type));
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@Then("^the type pendingDocument is <\"([^\"]*)\">$")
	public void the_type_pendingDocument_is(String arg1) throws Throwable {
		assertThat(type.isPendingDocument()).isEqualTo(Boolean.valueOf(arg1));
	}
}
