package com.bnpparibas.bddf.collect.application.collect.params;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.Collection;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.springframework.core.io.ClassPathResource;

import com.bnp.schema.edoc.actions.ObjectFactory;
import com.bnp.schema.edoc.actions.PiecesStatusActions;
import com.bnp.schema.edoc.actions.PiecesStatusActions.StatusAction;
import com.bnp.schema.edoc.actions.PiecesStatusActions.StatusAction.PutPiecesDestinations;
import com.bnp.schema.edoc.actions.PiecesStatusActions.StatusAction.PutPiecesDestinations.PutPiecesDestination;
import com.bnp.schema.edoc.actions.PiecesStatusActions.StatusAction.PutTypeDestinations;
import com.bnp.schema.edoc.actions.PiecesStatusActions.StatusAction.PutTypeDestinations.PutTypeDestination;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.errors.TechnicalException;

public class PiecesStatusActionsImpl implements PiecesStatusActionsRepository {

	private List<StatusAction> actions;

	public PiecesStatusActionsImpl() {

		try {
			final InputStream inputStream = new ClassPathResource("PiecesStatusActions.xml").getInputStream();
			final Unmarshaller unmarshaller = JAXBContext.newInstance(ObjectFactory.class).createUnmarshaller();
			actions = ((PiecesStatusActions) unmarshaller.unmarshal(inputStream)).getStatusAction();
		} catch (final JAXBException | IOException e) {

			throw new TechnicalException(CollectErrorConstants.ERR_COL_TECH, e);
		}
	}

	@Override
	public boolean isNewPieceStatusAuthorizedForPutType(String actualStatus, String newStatus, String channel) {
		return actions.stream().filter(a -> actualStatus.equals(a.getValue())).findAny().map(StatusAction::getPutTypeDestinations).map(PutTypeDestinations::getPutTypeDestination).map(Collection::stream)
				.map(s -> s.filter(d -> d.getChannels().getChannel().contains(channel)).map(PutTypeDestination::getStatus).anyMatch(status -> status.equals(newStatus))).orElse(false);
	}

	@Override
	public boolean isNewPieceStatusAuthorizedForPutPieces(String actualStatus, String newStatus, String channel) {
		return actions.stream().filter(a -> actualStatus.equals(a.getValue())).findAny().map(StatusAction::getPutPiecesDestinations).map(PutPiecesDestinations::getPutPiecesDestination).map(Collection::stream)
				.map(s -> s.filter(d -> d.getChannels().getChannel().contains(channel)).map(PutPiecesDestination::getStatus).anyMatch(status -> status.equals(newStatus))).orElse(false);
	}

	@Override
	public boolean isDeleteAuthorizedForPutType(String actualStatus, String channel) {
		return actions.stream().filter(a -> actualStatus.equals(a.getValue())).findAny().map(StatusAction::getPutTypeDestinations).map(PutTypeDestinations::getPutTypeDestination).map(Collection::stream)
				.map(s -> s.filter(d -> d.getChannels().getChannel().contains(channel)).map(PutTypeDestination::getStatus).anyMatch(status -> status.equals(PieceStatus.SU.getLabel()))).orElse(false);
	}

	@Override
	public boolean isDeleteAuthorizedForPutPieces(String actualStatus, String channel) {
		return actions.stream().filter(a -> actualStatus.equals(a.getValue())).findAny().map(StatusAction::getPutPiecesDestinations).map(PutPiecesDestinations::getPutPiecesDestination).map(Collection::stream)
				.map(s -> s.filter(d -> d.getChannels().getChannel().contains(channel)).map(PutPiecesDestination::getStatus).anyMatch(status -> status.equals(PieceStatus.SU.getLabel()))).orElse(false);
	}

	public static void main(String[] args) throws JAXBException {
		final PiecesStatusActions piecesStatusActions = new PiecesStatusActions();
		final StatusAction dpec = new StatusAction();
		dpec.setValue("DP_EC");
		dpec.setPutPiecesDestinations(new PutPiecesDestinations());
		dpec.setPutTypeDestinations(new PutTypeDestinations());
		piecesStatusActions.getStatusAction().add(dpec);
		final Marshaller marshaller = JAXBContext.newInstance(ObjectFactory.class).createMarshaller();
		final StringWriter writer = new StringWriter();
		marshaller.marshal(piecesStatusActions, writer);
		System.out.println(writer.toString());
	}

}