package com.bnpparibas.bddf.collect.application.indexNomenclatures;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(strict = true, plugin = { "pretty", "html:target/cucumber", "json:target/cucumber/nomenclature/cucumber.json" }, glue = { "com.bnpparibas.bddf.collect.application.indexNomenclatures", "cucumber.api.spring",
		"cucumber.runtime.java.spring" })
public class IndexNomenclaturesCucumberSuiteRunnerTest {

}
