package com.bnpparibas.bddf.collect.application.collect.steps;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.stream.Collectors;

import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.OwnerDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CollectSaveSteps3 extends AbstractCollectSaveSteps {

	public CollectSaveSteps3() {
		super();

	}

	@Given("^A collect$")
	public void a_collect(List<CollectAllDetailsDTO> collect) throws Throwable {
		collectAllDetailsDTO = collect.get(0);
	}

	@Given("^A familiesManagmentActs$")
	public void existing_familiesManagmentActs_in_collect(List<String> familiesManagementAct) throws Throwable {
		collectAllDetailsDTO.setFamiliesManagementAct(familiesManagementAct);
	}

	@Given("^Owners$")
	public void owners(List<OwnerDTO> owners) throws Throwable {
		collectAllDetailsDTO.setOwners(owners);
	}

	@Given("^A family$")
	public void a_family(List<FamilyDTO> families) throws Throwable {
		collectAllDetailsDTO.setFamilies(families);
		families.forEach(f -> f.setOwners(collectAllDetailsDTO.getOwners().stream().map(OwnerDTO::getReference).collect(Collectors.toList())));
	}

	@Given("^A Type$")
	public void a_Type(List<TypeDTO> types) throws Throwable {
		collectAllDetailsDTO.getFamilies().forEach(f -> f.setTypes(types));
	}

	@When("^I save a collect with the edoc-type <\"([^\"]*)\">$")
	public void i_save_a_collect_with_the_edoc_type(String edocType) throws Throwable {
		try {
			collectAllDetailsDTO.getFamilies().forEach(f -> f.getTypes().forEach(t -> t.setEdocType(edocType)));
			collectDTO = collectAction.saveCollect(collectAllDetailsDTO, new Context("123456", "001"));// "123456", "001", "001");
		} catch (final Exception e) {
			exception = e;
		}
	}

	@Then("^There is no exepction$")
	public void there_is_no_exepction() throws Throwable {
		assertThat(exception).isNull();
	}

	@Then("^The collect is created$")
	public void the_collect_is_created() throws Throwable {
		assertThat(collectDTO).isNotNull();
	}

	@Then("^I expect error code <\"([^\"]*)\">$")
	public void i_expect_error_code(String message) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception.getMessage()).isEqualTo(message);
	}

	@Given("^A digital allowed false type$")
	public void a_digital_allowed_false_type() throws Throwable {
		collectAllDetailsDTO.getFamilies().forEach(f -> f.getTypes().forEach(t -> t.setDigitalAllowed(false)));
	}

	@Given("^A control required = (\\d+) type$")
	public void a_control_required_type(int controlRequired) throws Throwable {
		collectAllDetailsDTO.getFamilies().forEach(f -> f.getTypes().forEach(t -> t.setControlRequired(controlRequired)));
	}
}
