package com.bnpparibas.bddf.collect.application.index.sm014.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.IndexDTO;
import com.bnpparibas.bddf.collect.application.dto.OwnerDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.collect.CollectActionsImpl;
import com.bnpparibas.bddf.collect.application.service.family.FamilyActionsImpl;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActionsImpl;
import com.bnpparibas.bddf.collect.application.service.type.TypeActionsImpl;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectService;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.type.AmiService;
import com.bnpparibas.bddf.collect.domain.type.IndexStatus;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeService;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.collect.domain.type.VideoCodingDelay;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ReferenceValidationSteps {

	private PieceActionsImpl pieceAction;
	private TypeActionsImpl typeAction;
	private FamilyActionsImpl familyAction;
	private CollectActionsImpl collectAction;
	private Exception currentException;
	private Collect existingCollect;
	private Collect savedCollect;
	private PieceDTO pieceDTO;
	private SubTypeDTO typeDTO;
	private FamilyDTO familyDTO;
	private List<Piece> pieceToUpdateInDocReference = new ArrayList<>();
	private boolean eventFlag = false;
	private CollectAllDetailsDTO collectDTO;
	private AmiService amiService;
	private List<Piece> piecesSentToGdn = new ArrayList<>();
	private TypeValidator typeValidator = new TypeValidator();

	public ReferenceValidationSteps() throws InterruptedException {

		final CollectService collectService = mock(CollectService.class);
		final FeatureManager featureManager = mock(FeatureManager.class);
		final TypeService typeService = mock(TypeService.class);
		amiService = mock(AmiService.class);
		when(featureManager.isActive(any())).thenReturn(true);
		doAnswer(invocation -> {
			final Collect newCollect = invocation.getArgument(0);

			// RG207
			newCollect.getTypes().forEach(t -> typeValidator.initTypeVideoCodingDelay(t, true));
			newCollect.getTypes().forEach(t -> typeValidator.validateTypeVideoCodingDelay(t, true));

			savedCollect = newCollect;
			return UUID.randomUUID();
		}).when(collectService).addCollect(any(), any());
		doAnswer(invocation -> {
			final Set<Type> types = invocation.getArgument(1);

			// RG207
			types.forEach(t -> typeValidator.initTypeVideoCodingDelay(t, true));
			types.forEach(t -> typeValidator.validateTypeVideoCodingDelay(t, true));

			savedCollect = new Collect();
			savedCollect.setTypes(types);
			return UUID.randomUUID();
		}).when(typeService).addFamily(any(), any(), any());
		doAnswer(invocation -> {
			final Type type = invocation.getArgument(1);

			final String documentSet = "AMI" + "_" + type.getVideoCodingDelay();
			final Map<UUID, StatusDocumentDTO> listStatusDocumentJMC = new HashMap<>();
			final Set<Piece> piecesToBeSentToAMI = type.getPieces().stream().filter(piece -> PieceStates.ACTIF.getLabel().equals(piece.getState()) && !PieceStatus.RF.getLabel().equals(piece.getStatus())).collect(Collectors.toSet());
			final List<Indexe> indexes = new ArrayList<Indexe>(type.getIndexes());
			final String ownerIndex = "1";
			if (Arrays.asList(VideoCodingDelay.IMMEDIATE.getCode(), VideoCodingDelay.DELAYED.getCode()).contains(type.getVideoCodingDelay())) {
				piecesToBeSentToAMI.forEach(piece -> {

					final Set<Indexe> indexesSentToAMI = indexes.stream().filter(indexe -> !IndexStatus.OK.getCode().equals(indexe.getStatusControl()) && !indexe.isIndexable() && indexe.isVideoCoding()).collect(Collectors.toSet());

					if (CollectionUtils.isNotEmpty(indexesSentToAMI)) {
						// sendDocumentToAmi(piece.getId().toString() + "-" + ownerIndex, convertStringToVideoCodingDelay(type.getVideoCodingDelay()), AmiRequest.VIDEOCODAGE, type, indexesSentToAMI);
						piece.setControlIterationAchieved(9);
					}

					// listStatusDocumentJMC.put(piece.getId(), verifyStatusDocument(piece, ownerIndex, type.getId(), documentSet));
				});
				/// typeAutomaticControlUtils.extractIndexesPiece(idCollect, type, indexes, ownerIndex, listStatusDocumentJMC, documentSet, false);
			}
			type.getIndexes().stream().filter(index -> index.isVideoCoding() && index.getStatusControl().equals("KO")).forEach(index -> index.setStatusControl("OK"));
			piecesToBeSentToAMI.forEach(piece -> piece.setControlIterationAchieved(9));

			savedCollect = existingCollect;
			return null;
		}).when(amiService).sendAMIFirstIteration(any(), any(), any());
		final Environment environment = mock(Environment.class);
		collectAction = new CollectActionsImpl(collectService, new CustomMapper());
		collectAction.setEnvironment(environment);
		familyAction = new FamilyActionsImpl(typeService, new CustomMapper());
	}

	@Given("^An existing collect$")
	public void an_existing_collect(List<Collect> collects) throws Throwable {
		this.existingCollect = collects.get(0);
	}

	@Given("^An existing Owners$")
	public void an_existing_Owners(List<Owner> owners) throws Throwable {
		this.existingCollect.setOwners(new HashSet<>(owners));
	}

	@Given("^An existing types$")
	public void an_existing_types(List<Type> types) throws Throwable {
		this.existingCollect.getTypes().addAll(types);
	}

	@Given("^An existing sub-types$")
	public void an_existing_sub_types(List<Type> types) throws Throwable {
		this.existingCollect.getTypes().addAll(types);
	}

	@Given("^existing pieces in type <\"([^\"]*)\">$")
	public void existing_pieces_in_type(String idType, List<Piece> pieces) throws Throwable {
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(idType)).findAny().get().setPieces(pieces.stream().collect(Collectors.toSet()));
	}

	@Given("^new piece to add$")
	public void new_piece_to_add(List<PieceDTO> piecesDTO) throws Throwable {
		pieceDTO = piecesDTO.get(0);
	}

	@Given("^A type to modify$")
	public void a_type_to_modify(List<SubTypeDTO> typesDTO) throws Throwable {
		this.typeDTO = typesDTO.get(0);
	}

	@Given("^pieces in the type to modify$")
	public void pieces_in_the_type_to_modify(List<PieceDTO> piecesDTO) throws Throwable {
		this.typeDTO.setPieces(piecesDTO);
	}

	@Given("^A new family to be add$")
	public void a_new_family_to_be_add(List<FamilyDTO> families) throws Throwable {
		this.familyDTO = families.get(0);
	}

	@When("^I add the family$")
	public void i_add_the_family() throws Throwable {
		try {
			familyAction.addFamily(UUID.randomUUID(), familyDTO, new Context("123456", "001"));
		} catch (final Exception e) {
			currentException = e;
		}
	}

	@When("^I update a type <\"([^\"]*)\">$")
	public void i_update_a_type(String idType) throws Throwable {
		try {
			typeAction.updateType(existingCollect.getId(), UUID.fromString(idType), typeDTO, new Context("123456", "001"));
		} catch (final Exception e) {
			currentException = e;
		}
	}

	@Then("^I expect the status of all types in the family <\"([^\"]*)\"> are initialized$")
	public void i_expect_the_status_of_all_types_in_the_family_are_initialized(String familyId) throws Throwable {
		assertTrue(existingCollect.getTypes().stream().filter(t -> familyId.equals(t.getFamilyId().toString())).allMatch(t -> TypeStatus.IN.getLabel().equals(t.getStatus())));
	}

	@Given("^pieces to add$")
	public void pieces_to_add(List<PieceDTO> piecesDTO) throws Throwable {
		typeDTO.setPieces(piecesDTO);
	}

	@Then("^The type is validated with status <\"([^\"]*)\">$")
	public void the_type_is_validated_with_status(String status) throws Throwable {
		assertThat(status).isEqualTo(existingCollect.getTypes().iterator().next().getStatus());
	}

	@Then("^I expect validation event not to be sent$")
	public void i_expect_validation_event_not_to_be_sent() throws Throwable {
		assertFalse(eventFlag);
	}

	@Given("^A subtype to modify$")
	public void a_subtype_to_modify(List<Type> subTypes) throws Throwable {
		existingCollect.getTypes().add(subTypes.get(0));
	}

	@Then("^I get (\\d+) pieces added in reference table$")
	public void i_get_pieces_added_in_reference_table(int nbPieces) throws Throwable {
		assertThat(currentException).isNull();
		assertThat(pieceToUpdateInDocReference.size()).isEqualTo(nbPieces);
	}

	@When("^I add a new piece in type <\"([^\"]*)\">$")
	public void i_add_a_new_piece_in_type(String idType) throws Throwable {
		try {
			pieceAction.addPiece(existingCollect.getId(), UUID.fromString(idType), pieceDTO, null, "", new Context("123456", "001"));
		} catch (final Exception e) {
			currentException = e;
		}

	}

	@Given("^A new collect$")
	public void a_new_collect(List<CollectAllDetailsDTO> collects) throws Throwable {
		collectDTO = collects.get(0);
	}

	@Given("^New types to add for new family$")
	public void new_types_to_add_for_new_family(List<TypeDTO> typesDTO) throws Throwable {
		familyDTO.setTypes(typesDTO);
	}

	@Given("^New indexes in type for new family$")
	public void new_indexes_in_type_for_new_family(List<IndexDTO> indexesDTO) throws Throwable {
		familyDTO.getTypes().iterator().next().setIndexes(indexesDTO);
	}

	@When("^I add a collect <\"([^\"]*)\">$")
	public void i_add_a_collect(String idCollect) throws Throwable {
		try {
			collectAction.saveCollect(collectDTO, new Context("123456", "001"));
		} catch (final Exception e) {
			currentException = e;
		}
	}

	@Then("^The status of all types is initialized with <\"([^\"]*)\">$")
	public void the_status_of_all_types_is_initialized_with(String status) throws Throwable {
		assertTrue(savedCollect.getTypes().stream().allMatch(t -> TypeStatus.IN.getLabel().equals(t.getStatus())));
	}

	@Then("^There is exception CollectBusinessException with message containing <\"([^\"]*)\">$")
	public void there_is_exception_CollectBusinessException_with_message_containing(String message) throws Throwable {
		assertThat(currentException).isNotNull();
		assertThat(currentException.getMessage()).isEqualTo(message);
	}

	@Then("^I expect videoCodingDelay to be equal to <\"([^\"]*)\">$")
	public void i_expect_videoCodingDelay_to_be_equal_to(String value) throws Throwable {
		assertTrue(savedCollect.getTypes().stream().allMatch(type -> value.equalsIgnoreCase(type.getVideoCodingDelay())));
	}

	@Given("^A new family$")
	public void a_new_family(List<FamilyDTO> families) throws Throwable {
		collectDTO.setFamilies(families);
	}

	@Given("^New types to add$")
	public void new_types_to_add(List<TypeDTO> types) throws Throwable {
		collectDTO.getFamilies().get(0).setTypes(types);
	}

	@Given("^with pieces in type <\"([^\"]*)\">$")
	public void with_pieces_in_type(String idType, List<Piece> pieces) throws Throwable {
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(idType)).findAny().get().setPieces(pieces.stream().collect(Collectors.toSet()));
	}

	@Then("^pieces of other types are deleted$")
	public void pieces_of_other_types_are_deleted() throws Throwable {
		final Type existingType = existingCollect.getTypes().stream().filter(t -> typeDTO.getId().equals(t.getId())).findAny().get();
		assertThat(currentException).isNull();
		assertThat(existingCollect.getTypes().stream().filter(t -> !t.getId().equals(existingType.getId()) && t.getFamilyId().toString().equals(existingType.getFamilyId())).mapToInt(t -> t.getPieces().size()).sum()).isEqualTo(0);
	}

	@Then("^The status of the type <\"([^\"]*)\"> is set to <\"([^\"]*)\">$")
	public void the_status_of_the_type_is_set_to(String typeId, String status) throws Throwable {
		final Type existingType = existingCollect.getTypes().stream().filter(t -> typeId.equals(t.getId().toString())).findAny().get();
		assertThat(currentException).isNull();
		assertThat(existingType.getStatus()).isEqualTo(status);
	}

	@Given("^An new Owners$")
	public void an_new_Owners(List<OwnerDTO> owners) throws Throwable {
		collectDTO.setOwners(owners);
	}

	@Then("^Type <\"([^\"]*)\"> is updated with status <\"([^\"]*)\">$")
	public void type_is_updated_with_status(String typeId, String status) throws Throwable {
		final Optional<Type> type = existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny();
		assertTrue(type.isPresent());
		assertThat(type.get().getStatus()).isEqualTo(status);
	}

	@Then("^I expect type <\"([^\"]*)\"> containing (\\d+) pieces$")
	public void i_expect_type_containing_pieces(String typeId, int nbPieces) throws Throwable {
		final Optional<Type> type = existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny();
		assertTrue(type.isPresent());
		assertThat(nbPieces).isEqualTo(type.get().getPieces().size());
	}

	@Then("^Piece <\"([^\"]*)\"> is saved in gdn$")
	public void piece_is_saved_in_gdn(String pieceId) throws Throwable {
		assertThat(piecesSentToGdn).isNotEmpty();
		assertTrue(piecesSentToGdn.stream().filter(p -> p.getId().toString().equals(pieceId)).findAny().isPresent());
	}

	@Then("^No piece is saved in gdn$")
	public void no_piece_is_saved_in_gdn() throws Throwable {
		assertTrue(piecesSentToGdn == null || piecesSentToGdn.isEmpty());

	}

	@Then("^There is no exception$")
	public void there_is_no_exception() throws Throwable {
		assertThat(currentException).isNull();
	}

	@Given("^New indexes in type$")
	public void existing_indexes_in_type(List<IndexDTO> indexes) throws Throwable {
		collectDTO.getFamilies().get(0).getTypes().get(0).setIndexes(indexes);
	}

	@Given("^Existing completeness in type$")
	public void existing_completeness_in_type(List<String> completeness) throws Throwable {
		existingCollect.getTypes().iterator().next().setCompleteness(new HashSet<String>(completeness));
	}

	@Given("^null completeness$")
	public void null_completeness() throws Throwable {
		collectDTO.getFamilies().get(0).getTypes().get(0).setCompleteness(null);
	}

	@When("^I save the collect$")
	public void i_save_the_collect() throws Throwable {
		try {
			collectAction.saveCollect(collectDTO, new Context("123456", "001"));
		} catch (final Exception e) {
			currentException = e;
		}
	}

	@Then("^I expect error code <\"([^\"]*)\">$")
	public void i_expect_error_code(String codeError) throws Throwable {
		assertThat(currentException).isNotNull();
		assertThat(currentException.getMessage()).isEqualTo(codeError);
	}

	@Then("^I expect index label to be initialized$")
	public void i_expect_index_label_to_be_initialized() throws Throwable {
		final List<String> labels = new ArrayList<>();
		savedCollect.getTypes().forEach(t -> t.getIndexes().forEach(index -> labels.add(index.getLabel())));
		assertTrue(labels.isEmpty() || labels.stream().allMatch(label -> StringUtils.isNotEmpty(label)));
	}

	@Then("^I expect completeness to be initialized$")
	public void i_expect_completeness_to_be_initialized() throws Throwable {
		assertTrue(savedCollect.getTypes().stream().allMatch(type -> CollectionUtils.isNotEmpty(type.getCompleteness())));

	}

	@Then("^I expect indexOwner to be initialized$")
	public void i_expect_indexOwner_to_be_initialized() throws Throwable {
		assertTrue(savedCollect.getTypes().stream().filter(type -> type.getIndexes() != null).flatMap(type -> type.getIndexes().stream()).allMatch(index -> StringUtils.isNotEmpty(index.getOwnerIndex())));
	}

	@Given("^New subtypes to add$")
	public void new_subtypes_to_add(List<SubTypeDTO> subTypesDTO) throws Throwable {
		collectDTO.getFamilies().get(0).getTypes().get(0).setSubTypes(subTypesDTO);
	}

	@Given("^New indexes in subtype$")
	public void new_indexes_in_subtype(List<IndexDTO> indexes) throws Throwable {
		collectDTO.getFamilies().get(0).getTypes().get(0).getSubTypes().get(0).setIndexes(indexes);
	}

	@Given("^existing typeJmc in piece <\"([^\"]*)\">$")
	public void existing_typeJmc_in_piece(String idPiece, List<String> typesJmc) throws Throwable {
		existingCollect.getTypes().stream().flatMap(type -> type.getPieces().stream()).filter(piece -> piece.getId().toString().equals(idPiece)).forEach(piece -> piece.setTypesJmc(typesJmc));
	}

	@Given("^existing indexes in type <\"([^\"]*)\">$")
	public void existing_indexes_in_type(String idType, List<Indexe> indexes) throws Throwable {
		existingCollect.getTypes().stream().filter(type -> type.getId().toString().equals(idType)).forEach(type -> type.setIndexes(new HashSet<Indexe>(indexes)));
	}

	@When("^I send to AMI$")
	public void i_send_to_AMI() throws Throwable {
		try {
			amiService.sendAMIFirstIteration(existingCollect.getId(), existingCollect.getTypes().iterator().next(), "");
		} catch (final Exception e) {
			currentException = e;
		}
	}

	@Then("^I expect indexe <\"([^\"]*)\"> to be equal to <\"([^\"]*)\">$")
	public void i_expect_indexe_to_be_equal_to(String idIndex, String status) throws Throwable {
		assertTrue(savedCollect.getTypes().stream().filter(type -> type.getIndexes() != null).flatMap(type -> type.getIndexes().stream()).anyMatch(index -> index.getId().toString().equals(idIndex) && index.getStatusControl().equals(status)));
	}

	@Then("^I expect videoCoding to be equal to <\"([^\"]*)\">$")
	public void i_expect_videoCoding_to_be_equal_to(String status) throws Throwable {
		assertTrue(savedCollect.getTypes().stream().filter(type -> type.getIndexes() != null).flatMap(type -> type.getIndexes().stream()).allMatch(index -> Boolean.toString(index.isVideoCoding()).equals(status)));
	}

}
