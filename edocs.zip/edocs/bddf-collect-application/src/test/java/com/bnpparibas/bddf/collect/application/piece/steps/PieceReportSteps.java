package com.bnpparibas.bddf.collect.application.piece.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.domain.collect.FamiliesManagmentAct;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadService;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableSet;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PieceReportSteps {
	private PieceActionsImpl pieceActions;
	private CollectRepository collectRepository;
	private TypeRepository typeRepository;
	private PieceRepository pieceRepository;
	private CollectEventHandler collectEventHandler;

	private PieceDTO pieceDTO;
	private Collect collect;
	private Type type;
	private Piece piece;
	private Exception exception;
	private AuditGenerator auditGenerator;
	private PieceAutomaticControlUtils pieceAutomaticControlUtils;

	ByteBuffer bytes = ByteBuffer.allocate(1000);

	public PieceReportSteps() {
		collectRepository = mock(CollectRepository.class);
		typeRepository = mock(TypeRepository.class);
		collectEventHandler = mock(CollectEventHandler.class);
		pieceRepository = mock(PieceRepository.class);
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		final TypeLadRadService typeLadRadService = mock(TypeLadRadService.class);
		final TypeValidator typeValidator = new TypeValidator();
		final Environment environment = mock(Environment.class);
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(false);
		final TypeAutomaticControlServiceImpl typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, typeValidator, null, new EdocIndexRepositoryImpl(), featureManager, pieceRepository, null, null, null,
				typeRepository, docReferenceService, new TypeAutomaticControlUtils());
		final PieceValidator pieceValidator = new PieceValidator();
		final PiecesStatusActionsRepository piecesStatusActionsRepository = mock(PiecesStatusActionsRepository.class);
		pieceValidator.setPieceStatusRepository(piecesStatusActionsRepository);

		pieceAutomaticControlUtils = new PieceAutomaticControlUtils(new PieceGdnServiceImpl(), typeAutomaticControlService);
		final PieceServiceImpl pieceService = new PieceServiceImpl(collectRepository, typeRepository, pieceRepository, new CollectValidator(), collectEventHandler, null, auditGenerator, environment, typeAutomaticControlService, featureManager,
				pieceAutomaticControlUtils);
		pieceService.setPieceValidator(pieceValidator);
		pieceService.setBlackListJmcFormat("");
		final EdocTypeRepository edocTypeRepository = mock(EdocTypeRepository.class);
		pieceService.setEdocTypeRepository(edocTypeRepository);
		pieceActions = new PieceActionsImpl(pieceService, new CustomMapper());
		pieceActions.setEnvironment(environment);
		this.pieceDTO = new PieceDTO();
		collect = new Collect(UUID.randomUUID(), CollectStatus.EC.name(), Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", ImmutableSet.<String> of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIF", "TIFF"),
				ImmutableSet.<String> of(PieceStatus.TP.getLabel(), PieceStatus.DP.getLabel(), PieceStatus.VA.getLabel(), PieceStatus.RF.getLabel()),
				ImmutableSet.<String> of(FamiliesManagmentAct.OB.name(), FamiliesManagmentAct.ND.name(), FamiliesManagmentAct.DR.name(), FamiliesManagmentAct.DF.name()), null, "AP001", false, false, 0, false, 0);
		type = new Type(UUID.randomUUID(), null, UUID.randomUUID(), new HashSet<String>(Arrays.asList("01740005814400000")), "Justificatif d'identité", "OB", null, "Liste", null, "info compl famille Justificatif d'identité", "Carte d'identité",
				"Veuiller fournir le recto et verso de votre carte d'identité", true, null, 1000000, 0, null, false, null, false, null, false, false, null, null, true);
	}

	@Given("^a type$")
	public void a_type(List<Type> data) throws Throwable {
		type = data.get(0);
		when(typeRepository.findOne(collect.getId(), type.getId())).thenReturn(type);
	}

	@And("^on a collect$")
	public void on_a_collect(List<Collect> data) throws Throwable {
		collect = data.get(0);
		collect.setAllowedFile(ImmutableSet.<String> of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIF", "TIFF"));
		collect.setTypes(ImmutableSet.<Type> of(type));
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);

	}

	@When("^I report the piece$")
	public void i_report_the_piece(List<PieceDTO> data) throws Throwable {
		try {
			when(typeRepository.findOne(collect.getId(), type.getId())).thenReturn(type);
			pieceDTO = data.get(0);
			pieceActions.addPiece(collect.getId(), type.getId(), pieceDTO, bytes, null, new Context("123456", "001"));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@When("^I report on collect<\"([^\"]*)\"> and type<\"([^\"]*)\"> the piece$")
	public void i_report_on_collect_and_type_the_piece(String collectId, String typeId, List<PieceDTO> data) throws Throwable {
		try {
			when(typeRepository.findOne(collect.getId(), type.getId())).thenReturn(type);
			Optional.ofNullable(collectRepository.findOne(UUID.fromString(collectId))).orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_NOT_FOUND)));
			pieceDTO = data.get(0);
			pieceActions.addPiece(UUID.fromString(collectId), UUID.fromString(typeId), pieceDTO, null, null, new Context("123456", pieceDTO.getChannel()));
		} catch (final Exception e) {
			this.exception = e;
		}

	}

	@When("^I save on collect<\"([^\"]*)\"> and type<\"([^\"]*)\"> the digital piece$")
	public void i_save_on_collect_and_type_the_digital_piece(String arg1, String arg2, List<PieceDTO> data) throws Throwable {
		try {
			Optional.ofNullable(collectRepository.findOne(collect.getId())).orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_NOT_FOUND)));
			when(typeRepository.findOne(collect.getId(), type.getId())).thenReturn(type);
			pieceDTO = data.get(0);
			pieceDTO.setSize(5000);
			pieceActions.addPiece(UUID.fromString(arg1), UUID.fromString(arg2), pieceDTO, bytes, "application/pdf", new Context("123456", pieceDTO.getChannel()));
			UUID.fromString(arg1);
			// UUID.fromString(arg2);
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@Then("^I receive the error : <\"([^\"]*)\">$")
	public void i_receive_the_error(String arg1) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);
		assertThat(exception.getMessage()).isEqualTo(arg1);
	}

	@Then("^the piece is saved$")
	public void the_piece_is_saved() throws Throwable {
		assertThat(exception).isNull();

	}

	@Given("^a type with no existing digital piece$")
	public void a_type_with_no_existing_digital_piece() throws Throwable {

	}

	@Given("^a type with an existing digital temporary piece$")
	public void a_type_with_an_existing_digital_temporary_piece(List<Piece> data) throws Throwable {
		piece = data.get(0);
		piece.setAcquisitionDate(Instant.now());
		when(typeRepository.findOne(collect.getId(), type.getId())).thenReturn(type);
		type.setPieces(new HashSet<>(Arrays.asList(piece)));
		// when(pieceRepository.findPieceByType(collect.getId(), type.getId())).thenReturn(new HashSet<>(Arrays.asList(piece)));
		when(pieceRepository.getPiece(collect.getId(), type.getId(), piece.getId())).thenReturn(piece);
	}

	@Given("^a type with an existing piece in paper format$")
	public void a_type_with_an_existing_piece_in_paper_format(List<Piece> data) throws Throwable {

		piece = data.get(0);
		piece.setAcquisitionDate(Instant.now());
		when(pieceRepository.getPiece(collect.getId(), type.getId(), piece.getId())).thenReturn(piece);
		type.setPieces(new HashSet<>(Arrays.asList(piece)));
		when(typeRepository.findOne(collect.getId(), type.getId())).thenReturn(type);
	}

	@Given("^a type with no existing piece$")
	public void a_type_with_no_existing_piece() throws Throwable {

	}

	@Given("^a type with an existing digital validated piece$")
	public void a_type_with_an_existing_digital_validated_piece(List<Piece> data) throws Throwable {
		piece = data.get(0);
		piece.setAcquisitionDate(Instant.now());
		when(pieceRepository.getPiece(collect.getId(), type.getId(), piece.getId())).thenReturn(piece);
	}

	@Given("^a type with subtypes$")
	public void a_type_with_subtypes(List<Type> data) throws Throwable {
		final Set<Type> typeSet = new HashSet<>();
		typeSet.add(type);
		data.forEach(typeSet::add);
		collect.setTypes(typeSet);
		// when(typeRepository.findByCollect(collect.getId())).thenReturn(typeList);
		// when(typeRepository.getType(collect.getId(), type.getId())).thenReturn(typeList.get(0));
	}

}