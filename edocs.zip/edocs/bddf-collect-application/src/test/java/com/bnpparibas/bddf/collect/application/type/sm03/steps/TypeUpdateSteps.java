package com.bnpparibas.bddf.collect.application.type.sm03.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.Feature;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.type.TypeActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditEventService;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.audit.event.LadRadFeature;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.ladrad.LadRadValidator;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusFolderDTO;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnService;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.piece.validation.ValidationPieceRepository;
import com.bnpparibas.bddf.collect.domain.type.FamilyRepository;
import com.bnpparibas.bddf.collect.domain.type.LadRadRepository;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadService;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TypeUpdateSteps {

	private TypeActionsImpl typeActions;
	private List<Collect> collects = new ArrayList<>();
	private Exception exception;
	private SubTypeDTO typeFound;
	private SubTypeDTO typeToUpdate;
	private CollectRepository collectRepository;
	private TypeRepository typeRepository;
	private CollectEventHandler collectEventHandler;
	private AuditGenerator auditGenerator;
	private PieceRepository pieceRepository;
	private EdocTypeRepository edocTypeRepository;
	private TypeValidator typeValidator = new TypeValidator();
	private PieceAutomaticControlUtils pieceAutomaticControlUtils;
	private ValidationPieceRepository validationPieceRepository;

	public TypeUpdateSteps() {

		collectRepository = mock(CollectRepository.class);
		typeRepository = mock(TypeRepository.class);
		collectEventHandler = mock(CollectEventHandler.class);
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		pieceRepository = mock(PieceRepository.class);
		validationPieceRepository = mock(ValidationPieceRepository.class);
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		final LadRadRepository ladRadRepository = mock(LadRadRepository.class);
		final EdocIndexRepository edocIndexRepository = mock(EdocIndexRepository.class);
		final FeatureManager featureManagerLadRad = mock(FeatureManager.class);
		final NomenclatureService nomenclatureService = mock(NomenclatureService.class);
		final PieceGdnService pieceGdnService = mock(PieceGdnService.class);
		final FamilyRepository familyRepository = mock(FamilyRepository.class);

		final LadRadValidator ladRadValidator = new LadRadValidator();
		edocTypeRepository = mock(EdocTypeRepository.class);

		final TypeLadRadService typeLadRadService = new TypeLadRadServiceImpl(ladRadRepository, edocIndexRepository, typeRepository, edocTypeRepository, ladRadValidator);

		final TypeAutomaticControlUtils typeAutomaticControlUtils = new TypeAutomaticControlUtils(ladRadRepository, ladRadValidator, typeRepository, typeValidator, typeLadRadService, collectRepository, collectEventHandler, edocTypeRepository,
				nomenclatureService, edocIndexRepository, docReferenceService, featureManagerLadRad);

		final AuditEventService auditEventService = mock(AuditEventService.class);
		doNothing().when(auditEventService).sendAuditEventLadRAD(any(), any(), any(), any(), any(), any());
		doNothing().when(auditEventService).sendAuditEventLadRADFirstIteration(any(), any(), any(), any(), any(), any(), any(), any());
		doNothing().when(auditEventService).sendAuditEventLadRADSecondIteration(any(), any(), any(), any(), any(), any(), any());
		when(auditEventService.sendAuditEventForcedRecognition(any(), any(), any(), any(), any())).thenReturn(true);
		typeAutomaticControlUtils.setAuditEventService(auditEventService);

		final Environment environment = mock(Environment.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		when(environment.getProperty("param.controlIterationAllowed", Integer.class, 3)).thenReturn(1);

		final CollectValidator customValidator = new CollectValidator();
		final PieceValidator pieceValidator = new PieceValidator();
		final PiecesStatusActionsRepository piecesStatusActionsRepository = mock(PiecesStatusActionsRepository.class);
		pieceValidator.setPieceStatusRepository(piecesStatusActionsRepository);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("TP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("VA"), eq("VA"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("DP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutPieces(eq("TP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutPieces(eq("DP"), any())).thenReturn(true);

		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("TP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DF"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DF"), eq("RC"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DF"), eq("RF"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("VA"), eq("VA"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("VA"), eq("RF"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("RC"), eq("RC"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("RC"), eq("RF"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("RC"), eq("VA"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DP"), eq("VA"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DP"), eq("RC"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DP"), eq("RF"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("RF"), eq("DP"), any())).thenReturn(true);

		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutType(eq("TP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutType(eq("DP"), any())).thenReturn(true);

		when(collectRepository.findOne(any())).thenAnswer(invocation -> {
			final UUID collectId = invocation.getArgument(0);
			return collects.stream().filter(collectL -> collectL.getId().equals(collectId)).findFirst().get();
		});

		when(collectRepository.findOnlyCollect(any())).thenAnswer(invocation -> {
			final UUID collectId = invocation.getArgument(0);
			return collects.stream().filter(collectL -> collectL.getId().equals(collectId)).findFirst().get();
		});

		when(ladRadRepository.getStatusFolder(any(), any())).then(invocation -> {
			return new StatusFolderDTO();
		});

		when(ladRadRepository.getStatusDocument(any(), any())).then(invocation -> {
			return new StatusDocumentDTO();
		});

		when(typeRepository.findOne(any(), any())).then(invocation -> {
			final UUID idCollect = invocation.getArgument(0);
			final UUID idType = invocation.getArgument(1);
			final Collect c = collects.stream().filter(collectL -> collectL.getId().equals(idCollect)).findFirst().get();
			return c.getTypes().stream().filter(typeL -> typeL.getId().equals(idType)).findFirst().orElse(null);

		});

		doNothing().when(validationPieceRepository).deleteByID(any());

		// service
		final FeatureManager featureManager = mock(FeatureManager.class);
		doAnswer(invocation -> {

			final Feature featureTmp = invocation.getArgument(0);

			if (featureTmp instanceof LadRadFeature) {
				final LadRadFeature feature = (LadRadFeature) featureTmp;
				if ("000001".equals(feature.getLabel())) {
					return true;
				} else if ("100001".equals(feature.getLabel())) {
					return false;
				} else {
					throw new IllegalArgumentException();
				}
			} else {
				return new IllegalArgumentException();
			}

		}).when(featureManager).isActive(any());
		final TypeAutomaticControlServiceImpl typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, typeValidator, null, edocIndexRepository, featureManager, pieceRepository, null, new LadRadValidator(),
				edocTypeRepository, typeRepository, docReferenceService, typeAutomaticControlUtils);
		typeAutomaticControlService.setCollectRepository(collectRepository);
		typeAutomaticControlService.setLadRadRepository(ladRadRepository);
		typeAutomaticControlService.setAuditEventService(auditEventService);

		pieceAutomaticControlUtils = new PieceAutomaticControlUtils(pieceGdnService, typeAutomaticControlService);
		final PieceServiceImpl pieceService = new PieceServiceImpl(collectRepository, typeRepository, pieceRepository, customValidator, collectEventHandler, null, auditGenerator, environment, typeAutomaticControlService, featureManagerLadRad,
				pieceAutomaticControlUtils);
		pieceService.setEdocTypeRepository(edocTypeRepository);
		pieceService.setPieceValidator(pieceValidator);

		final TypeServiceImpl typeService = new TypeServiceImpl(collectRepository, typeRepository, customValidator, collectEventHandler, auditGenerator, docReferenceService, typeAutomaticControlService, familyRepository);
		typeActions = new TypeActionsImpl(typeService, new CustomMapper());

		typeService.setEdocTypeRepository(edocTypeRepository);
		typeService.setFeatureManager(featureManagerLadRad);
		typeService.setPieceValidator(pieceValidator);
		typeService.setTypeValidator(typeValidator);
		typeService.setPieceGdnService(pieceGdnService);
		typeService.setAuditEventService(auditEventService);
		typeService.setValidationPieceRepository(validationPieceRepository);

	}

	@Given("^Existing collects$")
	public void existing_collects(List<Collect> collects) throws Throwable {
		this.collects.addAll(collects);
	}

	@Given("^Existing types in collect <\"([^\"]*)\">$")
	public void existing_types_in_collect(String collectId, List<Type> types) throws Throwable {
		collects.stream().filter(c -> c.getId().toString().equals(collectId)).forEach(c -> c.setTypes(new HashSet<>(types)));
	}

	@Given("^Pieces in type <\"([^\"]*)\"> in collect <\"([^\"]*)\">$")
	public void pieces_in_type_in_collect(String typeId, String collectId, List<Piece> pieces) throws Throwable {
		pieces.forEach(p -> p.setAcquisitionDate(Instant.now()));
		collects.stream().filter(c -> c.getId().toString().equals(collectId)).map(Collect::getTypes).flatMap(Collection::stream).filter(t -> t.getId().toString().equals(typeId)).forEach(t -> t.setPieces(new HashSet<>(pieces)));
	}

	@When("^I search the type <\"([^\"]*)\"> in the collect <\"([^\"]*)\">$")
	public void i_search_the_type_in_the_collect(String typeId, String collectId) throws Throwable {
		try {
			typeFound = typeActions.getType(UUID.fromString(collectId), UUID.fromString(typeId), new Context("123456", Channel.SPIRIT.getValue()));
		} catch (final Exception e) {
			exception = e;
		}
	}

	@Then("^I expect error code <\"([^\"]*)\">$")
	public void i_expect_error_code(String message) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception.getMessage()).isEqualTo(message);
	}

	@Then("^Type <\"([^\"]*)\"> is returned$")
	public void type_is_returned(String typeId) throws Throwable {
		assertThat(typeFound).isNotNull();
		assertThat(typeFound.getId()).isNotNull();
		assertThat(typeFound.getId().toString()).isEqualTo(typeId);
	}

	@Given("^A type to modify$")
	public void a_type_to_modify(List<SubTypeDTO> typeToUpdate) throws Throwable {
		this.typeToUpdate = typeToUpdate.get(0);
	}

	@Given("^Pieces in type to modify$")
	public void pieces_in_type_to_modify(List<PieceDTO> piecesDTO) throws Throwable {
		typeToUpdate.setPieces(piecesDTO);
	}

	@When("^I update the type <\"([^\"]*)\"> in the collect <\"([^\"]*)\">$")
	public void i_update_the_type_in_the_collect(String typeId, String collectId) throws Throwable {
		try {
			typeActions.updateType(UUID.fromString(collectId), UUID.fromString(typeId), typeToUpdate, new Context("123456", Channel.SPIRIT.getValue()));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@Then("^There is no exception$")
	public void there_is_no_exception() throws Throwable {
		assertThat(exception).isNull();
	}

	@Then("^Piece in collect <\"([^\"]*)\"> and type <\"([^\"]*)\"> with id <\"([^\"]*)\"> is updated with status <\"([^\"]*)\">$")
	public void piece_in_collect_and_type_with_id_is_updated_with_status(String collectId, String typeId, String pieceId, String pieceStatus) throws Throwable {
		final Optional<Collect> collect = collects.stream().filter(c -> c.getId().toString().equals(collectId)).findAny();
		assertTrue(collect.isPresent());
		final Optional<Type> type = collect.get().getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny();
		assertTrue(type.isPresent());
		final Optional<Piece> piece = type.get().getActivePieces().stream().filter(p -> p.getId().toString().equals(pieceId)).findAny();
		assertTrue(piece.isPresent());
		assertThat(piece.get().getStatus()).isEqualTo(pieceStatus);
	}

	@Then("^Empty RejectionReason for Piece <\"([^\"]*)\"> of Type <\"([^\"]*)\"> of collect <\"([^\"]*)\">$")
	public void empty_RejectionReason_for_Piece_of_Type_of_collect(String pieceId, String typeId, String collectId) throws Throwable {
		final Type type = collects.stream().filter(c -> c.getId().toString().equals(collectId)).findAny().get().getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get();
		final Optional<Piece> piece = type.getActivePieces().stream().filter(p -> p.getId().toString().equals(pieceId)).findAny();
		assertTrue(piece.isPresent());
		assertThat(piece.get().getRejectionComment()).isNullOrEmpty();
		assertThat(piece.get().getRejectionReason()).isNullOrEmpty();
	}

	@Then("^Type in collect <\"([^\"]*)\"> and type <\"([^\"]*)\"> is updated with status <\"([^\"]*)\">$")
	public void type_in_collect_and_type_is_updated_with_status(String collectId, String typeId, String typeStatus) throws Throwable {
		final Optional<Collect> collect = collects.stream().filter(c -> c.getId().toString().equals(collectId)).findAny();
		assertTrue(collect.isPresent());
		final Optional<Type> type = collect.get().getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny();
		assertTrue(type.isPresent());
		assertThat(type.get().getStatus()).isEqualTo(typeStatus);
	}

	@Then("^Attribute pending document of type <\"([^\"]*)\"> in the collect <\"([^\"]*)\"> is set to <\"([^\"]*)\">$")
	public void attribute_pending_document_of_type_in_the_collect_is_set_to(String typeId, String collectId, String pendingDocument) throws Throwable {
		final Optional<Collect> collect = collects.stream().filter(c -> c.getId().toString().equals(collectId)).findAny();
		assertTrue(collect.isPresent());
		final Optional<Type> type = collect.get().getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny();
		assertTrue(type.isPresent());
		assertThat(String.valueOf(type.get().isPendingDocument())).isEqualTo(pendingDocument);
	}

	@Then("^RejectionProfile equals <\"([^\"]*)\"> for Piece <\"([^\"]*)\"> of Type <\"([^\"]*)\"> of collect <\"([^\"]*)\">$")
	public void rejectionprofile_equals_for_Piece_of_Type_of_collect(String rejectionProfile, String pieceId, String typeId, String collectId) throws Throwable {
		final Type type = collects.stream().filter(c -> c.getId().toString().equals(collectId)).findAny().get().getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get();
		final Optional<Piece> piece = type.getPieces().stream().filter(p -> p.getId().toString().equals(pieceId)).findAny();
		assertTrue(piece.isPresent());
		assertThat(piece.get().getRejectionProfile()).isEqualTo(rejectionProfile);

	}

	@Then("^PendingDocumentProfile equals <\"([^\"]*)\"> for Type <\"([^\"]*)\"> of collect <\"([^\"]*)\">$")
	public void pendingdocumentprofile_equals_for_Type_of_collect(String pendingDocumentProfile, String typeId, String collectId) throws Throwable {
		final Optional<Collect> collect = collects.stream().filter(c -> c.getId().toString().equals(collectId)).findAny();
		assertTrue(collect.isPresent());
		final Optional<Type> type = collect.get().getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny();
		assertTrue(type.isPresent());
		assertThat(String.valueOf(type.get().getPendingDocumentProfile())).isEqualTo(pendingDocumentProfile);
	}

	@Then("^status equals <\"([^\"]*)\"> for Type <\"([^\"]*)\"> of collect <\"([^\"]*)\">$")
	public void status_equals_for_Type_of_collect(String status, String typeId, String collectId) throws Throwable {
		final Optional<Collect> collect = collects.stream().filter(c -> c.getId().toString().equals(collectId)).findAny();
		assertTrue(collect.isPresent());
		final Optional<Type> type = collect.get().getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny();
		assertTrue(type.isPresent());
		assertThat(String.valueOf(type.get().getStatus())).isEqualTo(status);
	}

}
