package com.bnpparibas.bddf.collect.application.collect.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.UUID;

import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CollectSaveSteps extends AbstractCollectSaveSteps {

	public CollectSaveSteps() {
		super();
	}

	@Given("^a collect with a list of owners, and a family with an owner \\(not on this list\\)$")
	public void a_collect_with_a_list_of_owners_and_a_family_with_an_owner_not_on_this_list(DataTable data) throws Throwable {
		final UUID id = UUID.fromString("b4b9e7d1-d358-4d99-b900-77202fda9cc0");
		createOurOwners(id, data);
		createOurFamilies(id, data);
		createACollecte(id, data);
		doNothing().when(collectRepository).add(commonCollect);
	}

	@Then("^I return the error code : <\"([^\"]*)\"> \\(owner not in the list\\)$")
	public void i_return_the_error_code_owner_not_in_the_list(String arg1) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);

	}

	@Given("^a collect with management acts=remettre$")
	public void a_collect_with_management_acts_remettre(DataTable data) throws Throwable {
		final UUID id = UUID.fromString("b4b9e7d1-d358-4d99-b900-77202fda9cc0");
		createOurOwners(id, data);
		createOurFamilies(id, data);
		createACollecte(id, data);
		doNothing().when(collectRepository).add(commonCollect);
	}

	@Then("^I return the error code : <\"([^\"]*)\"> \\(incorrect management acts\\)$")
	public void i_return_the_error_code_incorrect_management_acts(String arg1) throws Throwable {
		verify(collectRepository, times(0)).add(commonCollect);
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);
		assertThat(exception.getMessage()).isEqualTo(arg1);
	}

	/* SCENARIO 4. ***********/
	@Given("^a collect with missing Type Label$")
	public void a_collect_with_missing_GDNType(DataTable data) throws Throwable {
		final UUID id = UUID.fromString("b4b9e7d1-d358-4d99-b900-77202fda9cc0");
		createOurOwners(id, data);
		createOurFamilies(id, data);
		createACollecte(id, data);
		doNothing().when(collectRepository).add(commonCollect);
	}

	@Then("^I return the error code : UPLFCT(\\d+) \\(missing Type Label\\)$")
	public void i_return_the_error_code_UPLFCT_missing_gdnType(int arg1) throws Throwable {
		final TypeDTO typeDTO = collectAllDetailsDTO.getFamilies().get(0).getTypes().get(0);
		// assertThat(validationFor(typeDTO, onField("label")), fails());
		assertThat(true);
	}

	/* SCENARIO 5. ***********/
	@Given("^collect with propertyType Liste, containing one kind of type$")
	public void collect_with_propertyType_Liste_containing_one_kind_of_type(DataTable data) throws Throwable {
		final UUID id = UUID.fromString("b4b9e7d1-d358-4d99-b900-77202fda9cc0");
		createOurOwners(id, data);
		createOurFamilies(id, data);
		createACollecte(id, data);
		doNothing().when(collectRepository).add(commonCollect);
	}

	@Then("^I return the error code : <\"([^\"]*)\"> \\(one kind of type\\)$")
	public void i_return_the_error_code_one_kind_of_type(String arg1) throws Throwable {
		verify(collectRepository, times(0)).add(commonCollect);
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);
		assertThat(exception.getMessage()).isEqualTo(arg1);

	}

	/* SCENARIO 6. ***********/
	@Given("^collect with with the correct structure$")
	public void collect_with_with_the_correct_structure(DataTable data) throws Throwable {
		final UUID id = UUID.fromString("b4b9e7d1-d358-4d99-b900-77202fda9cc0");
		createOurOwners(id, data);
		createOurFamilies(id, data);
		createACollecte(id, data);
		doNothing().when(collectRepository).add(commonCollect);

	}

	@Then("^a return the collect$")
	public void a_return_the_collect() throws Throwable {
		// verify(collectRepository, times(1)).add(commonCollect, owners, types);
		assertThat(exception).isNull();
	}

	/* SCENARIO 7. ***********/
	@Given("^a collect without any owner associated$")
	public void a_collect_without_any_owner_associated(DataTable data) throws Throwable {
		final UUID id = UUID.fromString("b4b9e7d1-d358-4d99-b900-77202fda9cc0");
		createOurOwners(id, data);
		ownersDTO = new ArrayList<>();
		createOurFamilies(id, data);
		createACollecte(id, data);

		doNothing().when(collectRepository).add(commonCollect);
	}

	@Then("^I return the error code : <\"([^\"]*)\"> \\(collect with no owner associated\\)$")
	public void i_return_the_error_code_collect_with_no_owner_associated(String arg1) throws Throwable {
		verify(collectRepository, times(0)).add(commonCollect);
	}

	@Given("^collect either digitalAllowed and paperAllowed to false$")
	public void collect_either_digitalAllowed_and_paperAllowed_to_false(DataTable data) throws Throwable {
		final UUID id = UUID.fromString("b4b9e7d1-d358-4d99-b900-77202fda9cc0");
		createOurOwners(id, data);
		createOurFamilies(id, data);
		createACollecte(id, data);
		doNothing().when(collectRepository).add(commonCollect);
		when(gdnParamRepository.getGdnParam()).thenReturn(gdnParam());
	}

	/* Common When for all scenarios. ***********/

	@When("^I register the collect$")
	public void i_register_the_collect() throws Throwable {
		try {
			collectAction.saveCollect(collectAllDetailsDTO, new Context("123456", "001"));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@Then("^I return the error code : <\"([^\"]*)\">$")
	public void i_return_the_error_code(String message) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);
		assertThat(exception.getMessage()).isEqualTo(message);
	}

}
