package com.bnpparibas.bddf.collect.application.index.sm08.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.family.FamilyActions;
import com.bnpparibas.bddf.collect.application.service.family.FamilyActionsImpl;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActionsImpl;
import com.bnpparibas.bddf.collect.application.service.type.TypeActions;
import com.bnpparibas.bddf.collect.application.service.type.TypeActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditEventService;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.index.IndexeJmc;
import com.bnpparibas.bddf.collect.domain.ladrad.LadRadValidator;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusFolderDTO;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureServiceImpl;
import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.type.ControlRequired;
import com.bnpparibas.bddf.collect.domain.type.FamilyRepository;
import com.bnpparibas.bddf.collect.domain.type.LadRadRepository;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadService;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableSet;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DeletePieceWithIndexesSteps {

	private PieceActionsImpl pieceActions;
	private TypeActions typeActions;
	private FamilyActions familyActions;
	private CollectRepository collectRepository;
	private PieceRepository pieceRepository;
	private TypeRepository typeRepository;
	private Collect collect;
	private Exception exception;
	private boolean deleted;
	private CollectEventHandler collectEventHandler;
	private AuditGenerator auditGenerator;
	private final List<Collect> collects = new ArrayList<>();
	private Type type;
	private Piece piece;
	private TypeValidator typeValidator = new TypeValidator();
	final EdocTypeRepository edocTypeRepository;
	final EdocIndexRepository edocIndexRepository;
	private PieceAutomaticControlUtils pieceAutomaticControlUtils;
	// UPL3019SM02

	public DeletePieceWithIndexesSteps() {
		collectRepository = mock(CollectRepository.class);
		typeRepository = mock(TypeRepository.class);
		collectEventHandler = mock(CollectEventHandler.class);
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		pieceRepository = mock(PieceRepository.class);
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		final LadRadRepository ladRadRepository = mock(LadRadRepository.class);
		final FeatureManager featureManagerLadRad = mock(FeatureManager.class);
		when(featureManagerLadRad.isActive(any())).thenReturn(true);
		final NomenclatureService nomenclatureService = mock(NomenclatureServiceImpl.class);
		final FamilyRepository familyRepository = mock(FamilyRepository.class);
		final PieceGdnServiceImpl pieceGdnServiceImpl = mock(PieceGdnServiceImpl.class);

		final LadRadValidator ladRadValidator = new LadRadValidator();
		edocTypeRepository = new EdocTypesRepositoryImpl();
		edocIndexRepository = new EdocIndexRepositoryImpl();

		final TypeLadRadService typeLadRadService = new TypeLadRadServiceImpl(ladRadRepository, edocIndexRepository, typeRepository, edocTypeRepository, ladRadValidator);

		final TypeAutomaticControlUtils typeAutomaticControlUtils = new TypeAutomaticControlUtils(ladRadRepository, ladRadValidator, typeRepository, typeValidator, typeLadRadService, collectRepository, collectEventHandler, edocTypeRepository,
				nomenclatureService, edocIndexRepository, docReferenceService, featureManagerLadRad);
		final AuditEventService auditEventService = mock(AuditEventService.class);
		doNothing().when(auditEventService).sendAuditEventLadRAD(any(), any(), any(), any(), any(), any());
		doNothing().when(auditEventService).sendAuditEventLadRADFirstIteration(any(), any(), any(), any(), any(), any(), any(), any());
		doNothing().when(auditEventService).sendAuditEventLadRADSecondIteration(any(), any(), any(), any(), any(), any(), any());
		when(auditEventService.sendAuditEventForcedRecognition(any(), any(), any(), any(), any())).thenReturn(true);
		typeAutomaticControlUtils.setAuditEventService(auditEventService);

		final Environment environment = mock(Environment.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");

		final CollectValidator customValidator = new CollectValidator();
		final PieceValidator pieceValidator = new PieceValidator();
		final PiecesStatusActionsRepository piecesStatusActionsRepository = mock(PiecesStatusActionsRepository.class);
		pieceValidator.setPieceStatusRepository(piecesStatusActionsRepository);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("TP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("VA"), eq("VA"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("DP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutPieces(eq("TP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutPieces(eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("TP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("VA"), eq("VA"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutType(eq("DP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutType(eq("TP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutType(eq("DP"), any())).thenReturn(true);

		when(collectRepository.findOne(any())).thenAnswer(invocation -> {
			final UUID collectId = invocation.getArgument(0);
			return collects.stream().filter(collectL -> collectL.getId().equals(collectId)).findFirst().get();
		});

		when(collectRepository.findOnlyCollect(any())).thenAnswer(invocation -> {
			final UUID collectId = invocation.getArgument(0);
			return collects.stream().filter(collectL -> collectL.getId().equals(collectId)).findFirst().get();
		});

		when(ladRadRepository.getStatusFolder(any(), any())).then(invocation -> {
			return new StatusFolderDTO();
		});

		when(ladRadRepository.getStatusDocument(any(), any())).then(invocation -> {
			return new StatusDocumentDTO();
		});
		// doNothing().when(typeLadRadService).uploadDocument(any(), any(), any(), any(), any(), any(), any());

		// service
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(true);
		final TypeAutomaticControlServiceImpl typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, typeValidator, null, edocIndexRepository, featureManager, pieceRepository, null, new LadRadValidator(),
				edocTypeRepository, typeRepository, docReferenceService, typeAutomaticControlUtils);
		typeAutomaticControlService.setCollectRepository(collectRepository);
		typeAutomaticControlService.setLadRadRepository(ladRadRepository);
		typeAutomaticControlService.setNomenclatureService(nomenclatureService);
		pieceAutomaticControlUtils = new PieceAutomaticControlUtils(pieceGdnServiceImpl, typeAutomaticControlService);
		final PieceServiceImpl pieceService = new PieceServiceImpl(collectRepository, typeRepository, pieceRepository, customValidator, collectEventHandler, null, auditGenerator, environment, typeAutomaticControlService, featureManager,
				pieceAutomaticControlUtils);
		pieceService.setEdocTypeRepository(edocTypeRepository);
		pieceService.setPieceValidator(pieceValidator);
		pieceActions = new PieceActionsImpl(pieceService, new CustomMapper());
		pieceActions.setEnvironment(environment);
		final TypeServiceImpl typeService = new TypeServiceImpl(collectRepository, typeRepository, customValidator, collectEventHandler, auditGenerator, docReferenceService, typeAutomaticControlService, familyRepository);
		typeActions = new TypeActionsImpl(typeService, new CustomMapper());
		familyActions = new FamilyActionsImpl(typeService, new CustomMapper());
		typeService.setEdocTypeRepository(edocTypeRepository);
		typeService.setFeatureManager(featureManagerLadRad);
		typeService.setPieceValidator(pieceValidator);
		typeService.setTypeValidator(typeValidator);
		typeService.setAuditEventService(auditEventService);
	}

	@Given("^A collect$")
	public void a_collect(List<Collect> collects) throws Throwable {
		this.collects.addAll(collects);

	}

	@Given("^on a type collect <\"([^\"]*)\">$")
	public void on_a_type_collect(String collectId, List<Type> data) throws Throwable {
		final Type typeTmp = data.get(0);
		typeTmp.setControlRequired(ControlRequired.CONTROL_JMC.getCode());
		final Collect collectTmp = collects.stream().filter(collect -> collect.getId().equals(UUID.fromString(collectId))).findFirst().get();
		typeValidator.initTypeCompleteness(typeTmp, edocTypeRepository.findAll(), collectTmp.getTypes());
		collectTmp.setTypes(ImmutableSet.<Type> of(typeTmp));

	}

	@Given("^existing pieces type <\"([^\"]*)\">$")
	public void existing_pieces_type(String typeId, List<Piece> pieces) throws Throwable {
		pieces.forEach(piece -> piece.setState(PieceStates.ACTIF.toString()));
		final Type typeTmp = collects.stream().flatMap(collect -> collect.getTypes().stream()).filter(type -> type.getId().equals(UUID.fromString(typeId))).findFirst().get();
		typeTmp.setPieces(new HashSet<>(pieces));
		final Collect collectTmp = collects.stream().filter(collect -> collect.getTypes().stream().anyMatch(type -> type.getId().equals(typeTmp.getId()))).findFirst().get();
		typeTmp.getActivePieces().stream().forEach(pieceIdx -> when(pieceRepository.getPiece(collectTmp.getId(), typeTmp.getId(), pieceIdx.getId())).thenReturn(pieceIdx));
	}

	@Given("^existing typeJmc in piece <\"([^\"]*)\">$")
	public void existing_typeJmc_in_piece(String idPiece, List<String> typesJmc) throws Throwable {
		collects.stream().flatMap(collect -> collect.getTypes().stream()).flatMap(type -> type.getActivePieces().stream()).filter(piece -> piece.getId().equals(UUID.fromString(idPiece))).forEach(piece -> piece.setTypesJmc(typesJmc));
	}

	@Given("^Collect <\"([^\"]*)\">$")
	public void collect(String collectId) throws Throwable {
		collect = collects.stream().filter(collect -> collect.getId().equals(UUID.fromString(collectId))).findFirst().get();
		type = collect.getTypes().iterator().next();
	}

	@Given("^existing indexes in type <\"([^\"]*)\">$")
	public void existing_indexes_in_type(String typeId, List<Indexe> indexes) throws Throwable {
		indexes.forEach(index -> index.setOwnerIndex("1"));
		type.setIndexes(indexes.stream().collect(Collectors.toSet()));
	}

	@Given("^typeJMC for index <\"([^\"]*)\">$")
	public void typejmc_for_index(String idIndex, List<IndexeJmc> indexesJmc) throws Throwable {
		type.getIndexes().stream().filter(index -> index.getId().toString().equals(idIndex)).forEach(index -> index.getIndexesJmc().addAll(indexesJmc));
	}

	@When("^i delete the piece <\"([^\"]*)\"> with deletePiece$")
	public void i_delete_the_piece_with_deletePiece(String idPiece) throws Throwable {
		try {
			piece = type.getActivePieces().stream().filter(pieceL -> pieceL.getId().equals(UUID.fromString(idPiece))).findFirst().get();
			deleted = pieceActions.deletePiece(collect.getId(), type.getId(), piece.getId(), new Context("123456", "001"));
			final int i = 1;
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@When("^i delete the piece <\"([^\"]*)\"> with putPiece$")
	public void i_delete_the_piece_with_putPiece(String idPiece) throws Throwable {
		try {
			piece = type.getActivePieces().stream().filter(px -> px.getId().equals(UUID.fromString(idPiece))).findAny().get();
			final List<PieceDTO> pieces = type.getActivePieces().stream().filter(piece -> !piece.getId().equals(UUID.fromString(idPiece))).map(piece -> new PieceDTO(piece, "001")).collect(Collectors.toList());
			pieceActions.updatePieces(collect.getId(), type.getId(), pieces, new Context("123456", "001"));
			deleted = true;
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@When("^i delete the piece <\"([^\"]*)\"> with putType$")
	public void i_delete_the_piece_with_putType(String idPiece) throws Throwable {
		try {
			piece = type.getActivePieces().stream().filter(px -> px.getId().equals(UUID.fromString(idPiece))).findAny().get();
			final List<PieceDTO> pieces = type.getActivePieces().stream().filter(piece -> !piece.getId().equals(UUID.fromString(idPiece))).map(piece -> new PieceDTO(piece, "001")).collect(Collectors.toList());
			final SubTypeDTO subtypeDTO = new SubTypeDTO(type, Channel.SPIRIT.getValue());
			subtypeDTO.setPieces(pieces);
			typeActions.updateType(collect.getId(), type.getId(), subtypeDTO, new Context("123456", Channel.SPIRIT.getValue()));
			deleted = true;
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@When("^i delete all pieces with putPiece$")
	public void i_delete_all_pieces_with_putPiece() throws Throwable {
		try {

			final List<PieceDTO> pieces = new ArrayList<>();
			pieceActions.updatePieces(collect.getId(), type.getId(), pieces, new Context("123456", "001"));
			deleted = true;
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@When("^i delete all the pieces with putType$")
	public void i_delete_all_the_pieces_with_putType() throws Throwable {
		try {
			final SubTypeDTO subtypeDTO = new SubTypeDTO(type, Channel.SPIRIT.getValue());
			typeActions.updateType(collect.getId(), type.getId(), subtypeDTO, new Context("123456", Channel.SPIRIT.getValue()));
			deleted = true;
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@When("^i delete all the pieces with putFamily$")
	public void i_delete_all_the_pieces_with_putFamily() throws Throwable {
		try {
			final CustomMapper customMapper = new CustomMapper();

			final Set<Type> types = new HashSet<>(new ArrayList<Type>(Arrays.asList(type)));
			type.setFamilyOwners(new HashSet<String>(Arrays.asList("01740005814400000")));
			type.getActivePieces().forEach(piece -> piece.setAcquisitionDate(Instant.now()));
			type.getActivePieces().forEach(piece -> piece.setUpdateDate(Instant.now()));
			type.setFamiliesManagementActFamily(new HashSet<String>(Arrays.asList("OB", "ND")));

			final FamilyDTO familyDTO = new FamilyDTO();
			familyDTO.setCategory("ND");
			familyDTO.setId(type.getFamilyId());
			familyDTO.setFamiliesManagementAct(new ArrayList(type.getFamiliesManagementActFamily()));

			familyActions.updateFamilies(collect.getId(), Arrays.asList(familyDTO), new Context("123456", Channel.SPIRIT.getValue()));
			deleted = true;
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@Then("^indexes\\.extractedValue are equal to <\"([^\"]*)\"> for piece <\"([^\"]*)\">$")
	public void indexes_extractedValue_are_equal_to_for_piece(String value, String idPiece) throws Throwable {
		collect.getTypes().iterator().next().getIndexes().stream().forEach(index -> {
			if (index.getIndexesJmc().stream().anyMatch(indexJmc -> indexJmc.getIdPiece().equals(UUID.fromString(idPiece)))) {
				if (value.equals("null")) {
					assertThat(index.getExtractedValue()).isNull();
				} else {
					assertThat(index.getExtractedValue()).isEqualTo(value);
				}

			}
		});
	}

	@Then("^indexes\\.statusControl are equal to <\"([^\"]*)\">  for piece <\"([^\"]*)\">$")
	public void indexes_statusControl_are_equal_to_for_piece(String value, String idPiece) throws Throwable {
		assertThat(piece.getId()).isEqualTo(UUID.fromString(idPiece));
		collect.getTypes().iterator().next().getIndexes().stream().forEach(index -> {
			if (index.getIndexesJmc().stream().anyMatch(indexJmc -> indexJmc.getIdPiece().equals(UUID.fromString(idPiece)))) {
				if (value.equals("null")) {
					assertThat(index.getStatusControl()).isNull();
				} else {
					assertThat(index.getStatusControl()).isEqualTo(value);
				}

			}
		});
	}

	@Then("^indexes\\.msgControl are equal to <\"([^\"]*)\">  for piece <\"([^\"]*)\">$")
	public void indexes_msgControl_are_equal_to_for_piece(String value, String idPiece) throws Throwable {
		assertThat(piece.getId()).isEqualTo(UUID.fromString(idPiece));
		collect.getTypes().iterator().next().getIndexes().stream().forEach(index -> {
			if (index.getIndexesJmc().stream().anyMatch(indexJmc -> indexJmc.getIdPiece().equals(UUID.fromString(idPiece)))) {
				if (value.equals("null")) {
					assertThat(index.getMessageControl()).isNull();
				} else {
					assertThat(index.getMessageControl()).isEqualTo(value);
				}

			}
		});
	}

	@Then("^indexes\\.extractedValue are equal to <\"([^\"]*)\"> for all$")
	public void indexes_extractedValue_are_equal_to_for_all(String value) throws Throwable {
		collect.getTypes().iterator().next().getIndexes().stream().forEach(index -> {
			if (value.equals("null")) {
				assertThat(index.getExtractedValue()).isNull();
			} else {
				assertThat(index.getExtractedValue()).isEqualTo(value);
			}

		});
	}

	@Then("^indexes\\.statusControl are equal to <\"([^\"]*)\">  for all$")
	public void indexes_statusControl_are_equal_to_for_all(String value) throws Throwable {
		collect.getTypes().iterator().next().getIndexes().stream().forEach(index -> {
			if (value.equals("null")) {
				assertThat(index.getStatusControl()).isNull();
			} else {
				assertThat(index.getStatusControl()).isEqualTo(value);
			}

		});
	}

	@Then("^indexes\\.msgControl are equal to <\"([^\"]*)\">  for all$")
	public void indexes_msgControl_are_equal_to_for_all(String value) throws Throwable {
		collect.getTypes().iterator().next().getIndexes().stream().forEach(index -> {
			if (value.equals("null")) {
				assertThat(index.getMessageControl()).isNull();
			} else {
				assertThat(index.getMessageControl()).isEqualTo(value);
			}

		});
	}

	@Then("^ctrlStatus of type <\"([^\"]*)\"> is <\"([^\"]*)\">$")
	public void ctrlstatus_of_type_is(String idType, String value) throws Throwable {
		assertThat(exception).isNull();
		assertThat(deleted).isTrue();
		assertThat(type.getId().equals(UUID.fromString(idType))).isTrue();
		if (value.equals("null")) {
			assertThat(type.getStatusControl()).isNull();
		} else {
			assertThat(type.getStatusControl()).isEqualTo(value);
		}

	}

	@Then("^ctrlCompleteness of type <\"([^\"]*)\"> is <\"([^\"]*)\">$")
	public void ctrlcompleteness_of_type_is(String idType, String value) throws Throwable {
		assertThat(type.getId().equals(UUID.fromString(idType))).isTrue();
		if (value.equals("null")) {
			assertThat(type.getCompletenessControl()).isNullOrEmpty();
		} else {
			assertThat(type.getCompletenessControl()).isEqualTo(value);
		}
	}

}
