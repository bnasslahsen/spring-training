package com.bnpparibas.bddf.collect.application.index.sm08;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;

import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.domain.collect.CollectService;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@SpringBootTest(classes = { CollectValidator.class, CustomMapper.class, CollectService.class })
@RunWith(Cucumber.class)
@CucumberOptions(strict = true, plugin = { "pretty", "html:target/cucumber", "json:target/cucumber/index/sm08/cucumber.json" }, glue = { "com.bnpparibas.bddf.collect.application.index.sm08", "cucumber.api.spring", "cucumber.runtime.java.spring" })
public class DeletePieceWithIndexCucumberSuiteRunnerTest {
}