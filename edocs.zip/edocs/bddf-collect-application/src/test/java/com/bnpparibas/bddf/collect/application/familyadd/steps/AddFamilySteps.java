package com.bnpparibas.bddf.collect.application.familyadd.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.togglz.core.manager.FeatureManager;

import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.application.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.family.FamilyActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.LadRadFeature;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.FamiliesManagmentAct;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReference;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeService;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddFamilySteps {

	private FamilyActionsImpl familyAction;
	private FamilyDTO family;
	private Exception exception;
	private List<Collect> existingCollects;
	private CollectValidator customValidator = new CollectValidator();
	private TypeValidator typeValidator = new TypeValidator();
	private FeatureManager featureManager;
	private List<DocReference> references;

	public AddFamilySteps() throws InterruptedException {
		final TypeService typeService = mock(TypeService.class);

		familyAction = new FamilyActionsImpl(typeService, new CustomMapper());

		featureManager = mock(FeatureManager.class);

		doAnswer(invocation -> {
			final UUID collectId = invocation.getArgument(0);
			final Set<Type> familyTypes = invocation.getArgument(1);

			final Collect collect = existingCollects.stream().filter(c -> c.getId().equals(collectId)).findAny().orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_NOT_FOUND)));

			customValidator.validateFamily(collect, new ArrayList<>(familyTypes));
			final List<EdocType> edocTypes = (new EdocTypesRepositoryImpl()).findAll();
			final boolean sendToLadRadEnabled = Optional.ofNullable(LadRadFeature.fromLabel(collect.getJourneyCode())).map(featureManager::isActive).orElse(true);
			familyTypes.forEach(t -> typeValidator.validateType(t, edocTypes, collect, sendToLadRadEnabled));
			collect.getTypes().addAll(familyTypes);
			collect.getTypes().stream().filter(t -> t.isEnableReuse() && Arrays.asList(FamiliesManagmentAct.OB.name(), FamiliesManagmentAct.FA.name()).contains(t.getFamilyCategory())).forEach(t -> t.setPieces(referencesToPieces(t)));

			return null;
		}).when(typeService).addFamily(any(), any(), any());

	}

	private Set<Piece> referencesToPieces(Type t) {
		return references.stream().filter(p -> t.getFamilyOwners().contains(p.getOwnerId()) && p.getEdocType().equals(t.getEdocType())).map(this::refToPiece).collect(Collectors.toSet());
	}

	private Piece refToPiece(DocReference ref) {
		final Piece p = new Piece();
		p.setStatus("DF");
		p.setId(UUID.randomUUID());
		return p;
	}

	@Given("^Existing collects$")
	public void existing_collects(List<Collect> collects) throws Throwable {
		existingCollects = collects;
		when(featureManager.isActive(any())).thenReturn(false);
	}

	@Given("^Existing familiesManagmentActs in collect <\"([^\"]*)\">$")
	public void existing_familiesManagmentActs_in_collect(String collectId, DataTable familiesManagementActs) throws Throwable {
		existingCollects.stream().filter(c -> c.getId().toString().equals(collectId)).forEach(c -> c.setFamiliesManagementAct(new HashSet<>(familiesManagementActs.cells(0).get(0))));
	}

	@Given("^Existing owners in collect <\"([^\"]*)\">$")
	public void existing_owners_in_collect(String collectId, List<Owner> owners) throws Throwable {
		existingCollects.stream().filter(c -> c.getId().toString().equals(collectId)).forEach(c -> c.setOwners(new HashSet<>(owners)));
	}

	@Given("^An existing list of types in collect <\"([^\"]*)\">$")
	public void an_existing_list_of_types_in_collect(String collectId, List<Type> types) throws Throwable {
		existingCollects.stream().filter(c -> c.getId().toString().equals(collectId)).forEach(c -> c.setTypes(new HashSet<>(types)));
	}

	@Given("^a family to add$")
	public void a_family_to_add(List<FamilyDTO> familyDTO) throws Throwable {
		family = familyDTO.get(0);

	}

	@Given("^Owners references in family to save$")
	public void owners_in_family_to_save(DataTable owners) throws Throwable {
		family.setOwners(owners.cells(0).get(0));
	}

	@Given("^Types in family to save$")
	public void types_in_family_to_save(List<TypeDTO> types) throws Throwable {
		family.setTypes(types);
	}

	@When("^I register the family in collect <\"([^\"]*)\">$")
	public void i_register_the_family(String colllectId) throws Throwable {
		try {
			familyAction.addFamily(UUID.fromString(colllectId), family, new Context("132456", "001"));
		} catch (final Exception e) {
			exception = e;
		}
	}

	@Then("^I return the error code : <\"([^\"]*)\">$")
	public void i_return_the_error_code(String message) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception.getMessage()).isEqualTo(message);
	}

	@Then("^there is no exception$")
	public void there_is_no_exception() throws Throwable {
		assertThat(exception).isNull();
	}

	@Given("^edoc type is activated$")
	public void edoc_type_is_activated() throws Throwable {
		when(featureManager.isActive(any())).thenReturn(true);
	}

	@Given("^An existing list of reference documents$")
	public void an_existing_list_of_reference_documents(List<DocReference> references) throws Throwable {
		this.references = references;
	}

	@Then("^types in the collect <\"([^\"]*)\"> contains (\\d+) pieces$")
	public void types_in_the_collect_contains_pieces(String collectId, int nbrpieces) throws Throwable {
		final Collect collect = existingCollects.stream().filter(c -> c.getId().toString().equals(collectId)).findAny().orElse(null);
		assertThat(collect).isNotNull();
		assertThat(collect.getTypes().stream().mapToInt(t -> t.getPieces().size()).sum()).isEqualTo(nbrpieces);
	}
}
