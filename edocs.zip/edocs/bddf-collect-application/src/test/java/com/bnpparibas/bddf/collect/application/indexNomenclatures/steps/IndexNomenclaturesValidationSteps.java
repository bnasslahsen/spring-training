package com.bnpparibas.bddf.collect.application.indexNomenclatures.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnp.schema.edoc.index.Indexes.EdocIndex;
import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.IndexDTO;
import com.bnpparibas.bddf.collect.application.dto.OwnerDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.collect.CollectActionsImpl;
import com.bnpparibas.bddf.collect.application.service.family.FamilyActionsImpl;
import com.bnpparibas.bddf.collect.application.service.nomenclature.NomenclatureAction;
import com.bnpparibas.bddf.collect.application.service.nomenclature.NomenclatureDto;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectService;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.nomenclature.Nomenclature;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeService;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class IndexNomenclaturesValidationSteps {

	private FamilyActionsImpl familyAction;
	private CollectActionsImpl collectAction;
	private Exception currentException;
	private Exception currentExceptionFamily;
	private FamilyDTO family;
	private CollectAllDetailsDTO collectDTO;
	private CollectAllDetailsDTO collectDTOCountry;

	private TypeValidator typeValidator = new TypeValidator();
	private CustomMapper customMapper = new CustomMapper();
	private FeatureManager featureManager = mock(FeatureManager.class);
	private List<Collect> existingCollects;
	final TypeService typeService = mock(TypeService.class);
	private FamilyDTO familyCountry;
	private Exception currentExceptionCountry;
	private List<Collect> existingCollectsCountry;
	private Exception currentExceptionFamilyCountry;
	private FamilyDTO familyCountryGood;
	private Exception currentExceptionFamilyCountryGood;

	public IndexNomenclaturesValidationSteps() throws InterruptedException {

		final CollectService collectService = mock(CollectService.class);
		final FeatureManager featureManager = mock(FeatureManager.class);
		final NomenclatureAction nomenclatureAction = mock(NomenclatureAction.class);

		final TypeService typeService = mock(TypeService.class);

		familyAction = new FamilyActionsImpl(typeService, new CustomMapper());

		when(featureManager.isActive(any())).thenReturn(true);
		final Environment environment = mock(Environment.class);
		doAnswer(invocation -> {

			final List<NomenclatureDto> dtos = new ArrayList<>();
			NomenclatureDto dto = new NomenclatureDto();
			dto.setCode("10000000000000001");
			dto.setValue("F");
			dto.setLabel("Féminin");

			dtos.add(dto);

			dto = new NomenclatureDto();
			dto.setCode("10000000000000001");
			dto.setValue("M");
			dto.setLabel("Masculin");

			dtos.add(dto);

			dto = new NomenclatureDto();
			dto.setCode("10000000000000007");
			dto.setValue("DNK");
			dto.setLabel("Danemark");

			dtos.add(dto);

			return dtos;

		}).when(nomenclatureAction).getNomemclature(any());

		doAnswer(invocation -> {
			final List<EdocIndex> edocIndexes = (new EdocIndexRepositoryImpl()).findAll();
			final List<NomenclatureDto> nomenclaturesDto = nomenclatureAction.getNomemclature(new Context("123456", "001"));
			final List<Nomenclature> nomenclatures = nomenclaturesDto.stream().map(customMapper::toNomemclature).collect(Collectors.toList());
			final Collect newCollect = invocation.getArgument(0);
			// RG185 - Vérifier index conforme à nomenclature pour pays et genre
			newCollect.getTypes().forEach(t -> typeValidator.validateTypeIndexReferenceNomenclature(t, nomenclatures));

			return UUID.randomUUID();
		}).when(collectService).addCollect(any(), any());

		doAnswer(invocation -> {
			final UUID collectId = invocation.getArgument(0);
			final Set<Type> familyTypes = invocation.getArgument(1);

			final Collect collect = existingCollects.stream().filter(c -> c.getId().equals(collectId)).findAny().orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_NOT_FOUND)));
			final List<NomenclatureDto> nomenclaturesDto = nomenclatureAction.getNomemclature(new Context("123456", "001"));
			final List<Nomenclature> nomenclatures = nomenclaturesDto.stream().map(customMapper::toNomemclature).collect(Collectors.toList());
			familyTypes.forEach(t -> typeValidator.validateTypeIndexReferenceNomenclature(t, nomenclatures));
			collect.getTypes().addAll(familyTypes);

			return null;
		}).when(typeService).addFamily(any(), any(), any());

		collectAction = new CollectActionsImpl(collectService, new CustomMapper());
		collectAction.setEnvironment(environment);

	}

	@Given("^A new collect$")
	public void a_new_collect(List<CollectAllDetailsDTO> collects) throws Throwable {
		collectDTO = collects.get(0);
	}

	@Given("^A new family$")
	public void a_new_family(List<FamilyDTO> families) throws Throwable {
		collectDTO.setFamilies(families);
	}

	@Given("^An new Owners$")
	public void an_new_Owners(List<OwnerDTO> owners) throws Throwable {
		collectDTO.setOwners(owners);
	}

	@Given("^New types to add$")
	public void new_types_to_add(List<TypeDTO> types) throws Throwable {
		collectDTO.getFamilies().get(0).setTypes(types);
	}

	@Given("^New indexes in type$")
	public void existing_indexes_in_type(List<IndexDTO> indexes) throws Throwable {
		collectDTO.getFamilies().get(0).getTypes().get(0).setIndexes(indexes);
	}

	@When("^I save the collect$")
	public void i_save_the_collect() throws Throwable {
		try {
			collectAction.saveCollect(collectDTO, new Context("132456", "001", "001"));
		} catch (final Exception e) {
			currentException = e;
		}
	}

	@Then("^I expect error code <\"([^\"]*)\">$")
	public void i_expect_error_code(String codeError) throws Throwable {
		assertThat(currentException).isNotNull();
		assertThat(currentException.getMessage()).isEqualTo(codeError);
	}

	@Given("^Existing collects$")
	public void existing_collects(List<Collect> collects) throws Throwable {
		existingCollects = collects;
		when(featureManager.isActive(any())).thenReturn(false);
	}

	@Given("^Existing familiesManagmentActs in collect <\"([^\"]*)\">$")
	public void existing_familiesManagmentActs_in_collect(String collectId, DataTable familiesManagementActs) throws Throwable {
		existingCollects.stream().filter(c -> c.getId().toString().equals(collectId)).forEach(c -> c.setFamiliesManagementAct(new HashSet<>(familiesManagementActs.cells(0).get(0))));
	}

	@Given("^Existing owners in collect <\"([^\"]*)\">$")
	public void existing_owners_in_collect(String collectId, List<Owner> owners) throws Throwable {
		existingCollects.stream().filter(c -> c.getId().toString().equals(collectId)).forEach(c -> c.setOwners(new HashSet<>(owners)));
	}

	@Given("^An existing list of types in collect <\"([^\"]*)\">$")
	public void an_existing_list_of_types_in_collect(String collectId, List<Type> types) throws Throwable {
		existingCollects.stream().filter(c -> c.getId().toString().equals(collectId)).forEach(c -> c.setTypes(new HashSet<>(types)));
	}

	@Given("^a family to add$")
	public void a_family_to_add(List<FamilyDTO> familyDTO) throws Throwable {
		family = familyDTO.get(0);

	}

	@Given("^Owners references in family to save$")
	public void owners_in_family_to_save(DataTable owners) throws Throwable {
		family.setOwners(owners.cells(0).get(0));
	}

	@Given("^Types in family to save$")
	public void types_in_family_to_save(List<TypeDTO> types) throws Throwable {
		family.setTypes(types);
	}

	@Given("^New indexes in type for family$")
	public void new_indexes_in_type_for_family(List<IndexDTO> indexes) throws Throwable {
		family.getTypes().get(0).setIndexes(indexes);
	}

	@When("^I register the family in collect <\"([^\"]*)\">$")
	public void i_register_the_family(String collectId) throws Throwable {
		currentExceptionFamily = null;
		try {
			familyAction.addFamily(UUID.fromString(collectId), family, new Context("132456", "001"));
		} catch (final Exception e) {
			currentExceptionFamily = e;
		}
	}

	@Then("^I expect error code family <\"([^\"]*)\">$")
	public void i_expect_error_code_family(String codeError) throws Throwable {
		assertThat(currentExceptionFamily).isNotNull();
		assertThat(currentExceptionFamily.getMessage()).isEqualTo(codeError);
	}

	@Then("^there is no exception$")
	public void there_is_no_exception() throws Throwable {
		assertThat(currentException).isNull();
	}

	@Given("^A new collect country$")
	public void a_new_collect_country(List<CollectAllDetailsDTO> collects) throws Throwable {
		collectDTOCountry = collects.get(0);
	}

	@Given("^A new family country$")
	public void a_new_family_country(List<FamilyDTO> families) throws Throwable {
		collectDTOCountry.setFamilies(families);
	}

	@Given("^An new Owners country$")
	public void an_new_Owners_country(List<OwnerDTO> owners) throws Throwable {
		collectDTOCountry.setOwners(owners);
	}

	@Given("^New types to add country$")
	public void new_types_to_add_country(List<TypeDTO> types) throws Throwable {
		collectDTOCountry.getFamilies().get(0).setTypes(types);
	}

	@Given("^New indexes in type country$")
	public void new_indexes_in_type_country(List<IndexDTO> indexes) throws Throwable {
		collectDTOCountry.getFamilies().get(0).getTypes().get(0).setIndexes(indexes);
	}

	@When("^I save the collect country$")
	public void i_save_the_collect_country() throws Throwable {
		currentExceptionCountry = null;
		try {
			collectAction.saveCollect(collectDTOCountry, new Context("123456", "001", "001"));
		} catch (final Exception e) {
			currentExceptionCountry = e;
		}
	}

	@Then("^I expect error code country <\"([^\"]*)\">$")
	public void i_expect_error_code_country(String codeError) throws Throwable {
		assertThat(currentExceptionCountry).isNotNull();
		assertThat(currentExceptionCountry.getMessage()).isEqualTo(codeError);
	}

	@Then("^there is not exception country$")
	public void there_is_not_exception_country() throws Throwable {
		assertThat(currentExceptionCountry).isNull();
	}

	@Given("^a family to add country$")
	public void a_family_to_add_country(List<FamilyDTO> familyDTO) throws Throwable {
		familyCountry = familyDTO.get(0);
	}

	@Given("^Owners references in family to save country$")
	public void owners_references_in_family_to_save_country(DataTable owners) throws Throwable {
		familyCountry.setOwners(owners.cells(0).get(0));
	}

	@Given("^Types in family to save country$")
	public void types_in_family_to_save_country(List<TypeDTO> types) throws Throwable {
		familyCountry.setTypes(types);
	}

	@Given("^New indexes in type for family country$")
	public void new_indexes_in_type_for_family_country(List<IndexDTO> indexes) throws Throwable {
		familyCountry.getTypes().get(0).setIndexes(indexes);
	}

	@When("^I register the family in collect country <\"([^\"]*)\">$")
	public void i_register_the_family_in_collect_country(String collectId) throws Throwable {
		currentExceptionFamilyCountry = null;
		try {
			familyAction.addFamily(UUID.fromString(collectId), familyCountry, new Context("132456", "001"));
		} catch (final Exception e) {
			currentExceptionFamilyCountry = e;
		}
	}

	@Then("^I expect error code family country <\"([^\"]*)\">$")
	public void i_expect_error_code_family_country(String codeError) throws Throwable {
		assertThat(currentExceptionFamilyCountry).isNotNull();
		assertThat(currentExceptionFamilyCountry.getMessage()).isEqualTo(codeError);
	}

	@Given("^a family to add goodcountry$")
	public void a_family_to_add_goodcountry(List<FamilyDTO> familyDTO) throws Throwable {
		familyCountryGood = familyDTO.get(0);
	}

	@Given("^Owners references in family to save goodcountry$")
	public void owners_references_in_family_to_save_goodcountry(DataTable owners) throws Throwable {
		familyCountryGood.setOwners(owners.cells(0).get(0));
	}

	@Given("^Types in family to save goodcountry$")
	public void types_in_family_to_save_goodcountry(List<TypeDTO> types) throws Throwable {
		familyCountryGood.setTypes(types);
	}

	@Given("^New indexes in type for family goodcountry$")
	public void new_indexes_in_type_for_family_goodcountry(List<IndexDTO> indexes) throws Throwable {
		familyCountryGood.getTypes().get(0).setIndexes(indexes);
	}

	@When("^I register the family in collect goodcountry <\"([^\"]*)\">$")
	public void i_register_the_family_in_collect_goodcountry(String collectId) throws Throwable {
		currentExceptionFamilyCountryGood = null;
		try {
			familyAction.addFamily(UUID.fromString(collectId), familyCountryGood, new Context("132456", "001"));
		} catch (final Exception e) {
			currentExceptionFamilyCountryGood = e;
		}
	}

	@Then("^there is no exception family goodcountry <\"([^\"]*)\">$")
	public void there_is_no_exception_family_goodcountry(String arg1) throws Throwable {
		assertThat(currentExceptionFamilyCountryGood).isNull();
	}

}
