package com.bnpparibas.bddf.collect.application.collect.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableSet;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CollectSteps extends AbstractCollectSaveSteps {

	private String user;

	public CollectSteps() {
		super();
	}

	/**
	 * UPL 1007
	 */

	@Given("^a collect$")
	public void a_collect(DataTable data) throws Throwable {
		final List<String> col = data.raw().get(0);
		commonCollect = new Collect(UUID.randomUUID(), CollectStatus.EC.name(), Instant.now(), null, col.get(0), col.get(1), col.get(2), col.get(3), null, ImmutableSet.copyOf(col.get(4).split(",")), ImmutableSet.copyOf(col.get(5).split(",")), null,
				col.get(6), false, false, 0, false, 0);
		when(collectRepository.findOne(commonCollect.getId())).thenReturn(commonCollect);
	}

	@And("^owned by$")
	public void owned_by(List<Owner> data) throws Throwable {
		commonCollect.setOwners(new HashSet<>(data));
	}

	@When("^I retrieve the collect with user <\"([^\"]*)\">$")
	public void i_retrieve_the_collect_with_user(String userId) throws Throwable {
		// SecuredUserManager.set(arg1);
		this.user = userId;
		try {
			final List<String> references = commonCollect.getOwners().stream().map(o -> o.getReference()).collect(Collectors.toList());

			Optional.ofNullable(userId).orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_HABLITATION_NOT_AUTHORIZED, userId, commonCollect.getId().toString())));
			if (!references.contains(userId)) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_HABLITATION_NOT_AUTHORIZED, userId, commonCollect.getId().toString()));
			}
			collectAllDetailsDTO = collectAction.getCollect(commonCollect.getId(), new Context(userId, Channel.CLIENT_007.getValue()));
		} catch (final Exception ex) {
			this.exception = ex;
		}
	}

	// SCENARIO 1.

	@Then("^I recive the collect$")
	public void i_recive_the_collect() throws Throwable {
		assertThat(exception).isNull();
		assertThat(collectAllDetailsDTO.getOwners().get(0).getReference()).isEqualTo(user);
	}

	// SCENARIO 2.
	@Then("^I recive an error: <\"([^\"]*)\">$")
	public void i_recive_an_error(String arg1) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);
		assertThat(exception.getMessage()).isEqualTo(arg1);
	}
}
