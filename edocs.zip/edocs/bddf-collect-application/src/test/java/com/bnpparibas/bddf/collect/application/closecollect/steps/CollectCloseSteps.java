package com.bnpparibas.bddf.collect.application.closecollect.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.collect.CollectActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.CollectServiceImpl;
import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.param.GdnParamRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableSet;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CollectCloseSteps {

	private CollectActionsImpl collectAction;

	private CollectServiceImpl collectService;

	private CollectRepository collectRepository;
	private TypeRepository typeRepository;
	private GdnParamRepository gdnParamRepository;
	private CollectEventHandler collectEventHandler;

	private Collect commonCollect;
	private Type type;
	private Piece piece;

	private Exception exception;
	private AuditGenerator auditGenerator;
	private CollectAllDetailsDTO commonCollectAllDetailsDTO;

	public CollectCloseSteps() {
		collectRepository = mock(CollectRepository.class);
		typeRepository = mock(TypeRepository.class);
		gdnParamRepository = mock(GdnParamRepository.class);
		collectEventHandler = mock(CollectEventHandler.class);
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(false);
		final TypeValidator typeValidator = new TypeValidator();

		final Environment environment = mock(Environment.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		collectService = new CollectServiceImpl(collectRepository, typeRepository, gdnParamRepository, new CollectValidator(), collectEventHandler, auditGenerator, environment, typeValidator, new EdocTypesRepositoryImpl(), new EdocIndexRepositoryImpl());
		collectAction = new CollectActionsImpl(collectService, new CustomMapper());
		collectAction.setEnvironment(environment);
		collectService.setFeatureManager(featureManager);

	}

	/* Common When for all scenarios. ***********/
	@Given("^a collect to close$")
	public void a_collect_to_close(DataTable data) throws Throwable {
		if (commonCollect == null) {
			final List<String> col = data.raw().get(0);
			commonCollect = new Collect(UUID.fromString(col.get(0)), col.get(1), ZonedDateTime.parse(col.get(2)).toInstant(), null, col.get(4), col.get(5), col.get(6), col.get(7), ImmutableSet.<String> of(), ImmutableSet.<String> of(),
					ImmutableSet.<String> of(), null, col.get(8), false, false, 0, false, 0);
			commonCollectAllDetailsDTO = new CollectAllDetailsDTO(commonCollect);

		}
		when(collectRepository.findOne(commonCollect.getId())).thenReturn(commonCollect);
	}

	@When("^I close the collect <\"([^\"]*)\">$")
	public void i_close_the_collect(String collectId) throws Throwable {
		try {
			commonCollectAllDetailsDTO.setCollectStatus("CL");
			collectAction.updateCollect(UUID.fromString(collectId), commonCollectAllDetailsDTO, new Context("123456", "001"));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	/* scenarios 1. ***********/
	@Given("^an existing collect in progress that can be closed$")
	public void an_existing_collect_in_progress_that_can_be_closed(List<Type> data) throws Throwable {
		type = data.get(0);
		if (type.getId() == null) {
			type.setId(UUID.randomUUID());
			type.setFamilyId(UUID.randomUUID());
		}
		commonCollect.setTypes(ImmutableSet.<Type> of(type));

	}

	@Given("^a Piece$")
	public void a_Piece(List<Piece> data) throws Throwable {
		piece = data.get(0);
		piece.setAcquisitionDate(Instant.now());
		type.setPieces(ImmutableSet.<Piece> of(piece));
	}

	@Then("^the collect is closed$")
	public void the_collect_is_closed() throws Throwable {

		assertThat(exception).isNull();
		assertThat(commonCollect.getStatus()).isEqualTo(CollectStatus.CL.name());
	}

	/* scenarios 2. ***********/
	@Given("^a non existant collect$")
	public void a_non_existant_collect(List<Type> data) throws Throwable {
		type = data.get(0);
		if (type.getId() == null) {
			type.setId(UUID.randomUUID());
			type.setFamilyId(UUID.randomUUID());
		}
		commonCollect.setTypes(ImmutableSet.<Type> of(type));
	}

	@Then("^I receive the error code : <\"([^\"]*)\">$")
	public void i_receive_the_error_code(String arg1) throws Throwable {
		verify(collectRepository, times(0)).add(commonCollect);
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);
		assertThat(exception.getMessage()).isEqualTo(arg1);
	}

	@Given("^a collect containing a type with pending document activated for a mandatory familiy \\(OB\\)$")
	public void a_collect_containing_a_type_with_pending_document_activated_for_a_mandatory_familiy_OB(List<Type> data) throws Throwable {
		type = data.get(0);
		if (type.getId() == null) {
			type.setId(UUID.randomUUID());
			type.setFamilyId(UUID.randomUUID());
		}
		commonCollect.setTypes(ImmutableSet.<Type> of(type));
	}

	@Given("^containing a non validated piece for a mandatory familiy \\(OB\\)$")
	public void containing_a_non_validated_piece_for_a_mandatory_familiy_OB(List<Type> data) throws Throwable {
		type = data.get(0);
		if (type.getId() == null) {
			type.setId(UUID.randomUUID());
			type.setFamilyId(UUID.randomUUID());
		}
		commonCollect.setTypes(ImmutableSet.<Type> of(type));
	}

	@Given("^containing a Deposed piece not valid$")
	public void containing_a_Deposed_piece_not_valid(List<Piece> data) throws Throwable {
		piece = data.get(0);
		piece.setAcquisitionDate(Instant.now());
	}

	@Given("^a collect with a mandatory familiy \\(OB\\) without piece$")
	public void a_collect_with_a_mandatory_familiy_OB_without_piece(List<Type> data) throws Throwable {
		type = data.get(0);
		if (type.getId() == null) {
			type.setId(UUID.randomUUID());
			type.setFamilyId(UUID.randomUUID());
		}
		commonCollect.setTypes(ImmutableSet.<Type> of(type));
	}

	@Given("^a collect with a familiy already provided \\(DF\\) without piece$")
	public void a_collect_with_a_familiy_already_provided_DF_without_piece(List<Type> data) throws Throwable {
		type = data.get(0);
		if (type.getId() == null) {
			type.setId(UUID.randomUUID());
			type.setFamilyId(UUID.randomUUID());
		}
		commonCollect.setTypes(ImmutableSet.<Type> of(type));
	}

	@Then("^I receive the message <\"([^\"]*)\">$")
	public void i_receive_the_message(String arg1) throws Throwable {
		verify(collectRepository, times(0)).add(commonCollect);
	}

	@Given("^an existing collect with a facultative family with invalidate pieces$")
	public void an_existing_collect_with_a_facultative_family_with_invalidate_pieces(List<Type> data) throws Throwable {
		type = data.get(0);
		if (type.getId() == null) {
			type.setId(UUID.randomUUID());
			type.setFamilyId(UUID.randomUUID());
		}
		commonCollect.setTypes(ImmutableSet.<Type> of(type));
	}

}
