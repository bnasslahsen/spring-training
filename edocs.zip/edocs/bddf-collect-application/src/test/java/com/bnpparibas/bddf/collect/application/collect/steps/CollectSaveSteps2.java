package com.bnpparibas.bddf.collect.application.collect.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.OwnerDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableSet;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CollectSaveSteps2 extends AbstractCollectSaveSteps {

	public CollectSaveSteps2() {
		owners = new ArrayList<>();
		owners.add(new Owner("01740005814400000", "SETAH", "Alex", null, 1, "1234567", null));
		owners.add(new Owner("01740005814500000", "SETAH", "Alice", null, 1, "1234567", null));

		types = new ArrayList<>();
		types.add(new Type(UUID.randomUUID(), null, UUID.randomUUID(), new HashSet<String>(Arrays.asList("01740005814400000")), "Médicale", "OB", "déja fourni", "Fixe", null, "info compl famille assurance", null, "Médicale 1", true, null,
				new Random().nextLong(), 0, null, false, null, false, null, false, false, null, null, true));
		types.add(new Type(UUID.randomUUID(), null, UUID.randomUUID(), new HashSet<String>(Arrays.asList("01740005814400000")), "Médicale", "OB", "déja fourni", "Fixe", null, "info compl famille assurance", null, "Médicale 2", true, null,
				new Random().nextLong(), 0, null, false, null, false, null, false, false, null, null, true));
		types.add(new Type(UUID.randomUUID(), null, UUID.randomUUID(), new HashSet<String>(Arrays.asList("01740005814400000")), "Justificatif d'identité", "OB", null, "Fixe", null, "info compl famille Justificatif d'identité", "Carte d'identité",
				"Veuiller fournir le recto et verso de votre carte d'identité", true, null, new Random().nextLong(), 0, null, false, null, false, null, false, false, null, null, true));
		types.stream().forEach(type -> type.setEdocType("00000000000000001"));
	}

	/* Common When for all scenarios. ***********/

	@When("^I save the collect$")
	public void i_register_the_collect() throws Throwable {
		try {
			collectDTO = collectAction.saveCollect(collectAllDetailsDTO, new Context("123456", "001"));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@Then("^I recive the error code : <\"([^\"]*)\">$")
	public void i_return_the_error_code(String arg1) throws Throwable {
		verify(collectRepository, times(0)).add(commonCollect);
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);
		assertThat(exception.getMessage()).isEqualTo(arg1);
	}

	/**
	 ********* UPL1003V2**********
	 */

	/* SCENARIO 1. ***********/
	@Given("^a valid collect$")
	public void a_valid_collect(DataTable data) throws Throwable {
		final List<String> col = data.raw().get(0);
		commonCollect = new Collect(UUID.randomUUID(), CollectStatus.EC.name(), Instant.now(), null, col.get(0), col.get(1), col.get(2), col.get(3), null, ImmutableSet.copyOf(col.get(4).split(",")),
				ImmutableSet.copyOf(Optional.ofNullable(col.get(5)).orElse("").split(",")), null, col.get(6), false, false, 0, false, 0);
		this.collectAllDetailsDTO = new CollectAllDetailsDTO(commonCollect);
		ownersDTO = Arrays.asList(new OwnerDTO(owners.get(0)));

		familiesDTO = new CustomMapper().convertToFamilyDTO(new HashSet<>(types), Channel.SPIRIT.getValue());
		collectAllDetailsDTO.setFamilies(familiesDTO);
		collectAllDetailsDTO.setOwners(ownersDTO);
	}

	@And("^containing a type with an unkown gdnType$")
	public void containing_a_type_with_an_unkown_gdnType(List<Type> typeList) throws Throwable {
		typeList.get(0).setId(UUID.randomUUID());
		typeList.get(0).setFamilyId(UUID.randomUUID());
		ownersDTO = Arrays.asList(new OwnerDTO(owners.get(0)));
		final Set<String> refs = new HashSet<>();
		refs.add(owners.get(0).getReference());
		typeList.forEach(t -> t.setFamilyOwners(refs));
		familiesDTO = new CustomMapper().convertToFamilyDTO(new HashSet<>(typeList), Channel.SPIRIT.getValue());
		this.collectAllDetailsDTO.setFamilies(familiesDTO);
		this.collectAllDetailsDTO.setOwners(ownersDTO);
		doNothing().when(collectRepository).add(commonCollect);
	}

	/* SCENARIO 2. ***********/
	@Given("^a collect with an unknown familyManagmentAct$")
	public void a_collect_with_an_unknown_familyManagmentAct(DataTable data) throws Throwable {
		final List<String> col = data.raw().get(0);
		commonCollect = new Collect(UUID.randomUUID(), CollectStatus.EC.name(), Instant.now(), null, col.get(0), col.get(1), col.get(2), col.get(3), null, ImmutableSet.copyOf(col.get(4).split(",")), ImmutableSet.copyOf(col.get(5).split(",")), null,
				col.get(6), false, false, 0, false, 0);
		this.collectAllDetailsDTO = new CollectAllDetailsDTO(commonCollect);
		ownersDTO = Arrays.asList(new OwnerDTO(owners.get(0)));
		familiesDTO = new CustomMapper().convertToFamilyDTO(new HashSet<>(types), Channel.SPIRIT.getValue());
		collectAllDetailsDTO.setFamilies(familiesDTO);
		this.collectAllDetailsDTO.setOwners(ownersDTO);
	}

	/* SCENARIO 3. ***********/

	@And("^containing a family with an unkown category$")
	public void containing(List<Type> typeList) throws Throwable {
		typeList.get(0).setId(UUID.randomUUID());
		typeList.get(0).setFamilyId(UUID.randomUUID());
		ownersDTO = Arrays.asList(new OwnerDTO(owners.get(0)));
		final Set<String> refs = new HashSet<>();
		refs.add(owners.get(0).getReference());
		typeList.forEach(t -> {
			t.setFamilyOwners(refs);
			t.setEdocType("00000000000000001");
			t.setFamiliesManagementActFamily(ImmutableSet.of("OB"));
			t.setFamilyCategory("ND");
		});
		familiesDTO = new CustomMapper().convertToFamilyDTO(new HashSet<>(typeList), Channel.SPIRIT.getValue());
		this.collectAllDetailsDTO.setFamilies(familiesDTO);
		this.collectAllDetailsDTO.setOwners(ownersDTO);
		doNothing().when(collectRepository).add(commonCollect);
	}

	/* SCENARIO 4. ***********/
	@And("^containing a derogated family without a categoryComment$")
	public void containing_a_derogated_family_without_a_categoryComment(List<Type> typeList) throws Throwable {
		typeList.get(0).setId(UUID.randomUUID());
		typeList.get(0).setFamilyId(UUID.randomUUID());
		ownersDTO = Arrays.asList(new OwnerDTO(owners.get(0)));
		final Set<String> refs = new HashSet<>();
		refs.add(owners.get(0).getReference());
		typeList.forEach(t -> t.setFamilyOwners(refs));
		familiesDTO = new CustomMapper().convertToFamilyDTO(new HashSet<>(typeList), Channel.SPIRIT.getValue());
		this.collectAllDetailsDTO.setFamilies(familiesDTO);
		this.collectAllDetailsDTO.setOwners(ownersDTO);
		doNothing().when(collectRepository).add(commonCollect);
	}

	/* SCENARIO 5. ***********/
	@Given("^a collect with an unknown collectManagmentAct$")
	public void a_collect_with_an_unknown_collectManagmentAct(DataTable data) throws Throwable {
		final List<String> col = data.raw().get(0);
		commonCollect = new Collect(UUID.randomUUID(), CollectStatus.EC.name(), Instant.now(), null, col.get(0), col.get(1), col.get(2), col.get(3), null, ImmutableSet.copyOf(col.get(4).split(",")), ImmutableSet.copyOf(col.get(5).split(",")),
				ImmutableSet.copyOf(col.get(7).split(",")), col.get(6), false, false, 0, false, 0);
		this.collectAllDetailsDTO = new CollectAllDetailsDTO(commonCollect);
		ownersDTO = Arrays.asList(new OwnerDTO(owners.get(0)));
		familiesDTO = new CustomMapper().convertToFamilyDTO(new HashSet<>(types), Channel.SPIRIT.getValue());
		collectAllDetailsDTO.setFamilies(familiesDTO);
		this.collectAllDetailsDTO.setOwners(ownersDTO);
	}

	@Given("^containing a digital allowed type with a missing gdnType$")
	public void containing_a_digital_allowed_type_with_a_missing_gdnType(List<Type> typeList) throws Throwable {
		typeList.get(0).setId(UUID.randomUUID());
		typeList.get(0).setFamilyId(UUID.randomUUID());
		ownersDTO = Arrays.asList(new OwnerDTO(owners.get(0)));
		final Set<String> refs = new HashSet<>();
		refs.add(owners.get(0).getReference());
		typeList.forEach(t -> t.setFamilyOwners(refs));
		familiesDTO = new CustomMapper().convertToFamilyDTO(new HashSet<>(typeList), Channel.SPIRIT.getValue());
		this.collectAllDetailsDTO.setFamilies(familiesDTO);
		this.collectAllDetailsDTO.setOwners(ownersDTO);
		doNothing().when(collectRepository).add(commonCollect);
	}

	/* SCENARIO 7. ***********/
	@Given("^a validate collect$")
	public void a_validate_collect(DataTable data) throws Throwable {
		final List<String> col = data.raw().get(0);
		commonCollect = new Collect(UUID.randomUUID(), CollectStatus.EC.name(), Instant.now(), null, col.get(0), col.get(1), col.get(2), col.get(3), null, ImmutableSet.copyOf(col.get(4).split(",")),
				ImmutableSet.copyOf(Optional.ofNullable(col.get(5)).orElse("").split(",")), null, col.get(6), false, false, 0, false, Integer.valueOf(col.get(7)));
		this.collectAllDetailsDTO = new CollectAllDetailsDTO(commonCollect);
		ownersDTO = Arrays.asList(new OwnerDTO(owners.get(0)));

		familiesDTO = new CustomMapper().convertToFamilyDTO(new HashSet<>(types), Channel.SPIRIT.getValue());
		collectAllDetailsDTO.setFamilies(familiesDTO);
		collectAllDetailsDTO.setOwners(ownersDTO);
	}

	@Given("^containing a control required type with a missing contorl document type$")
	public void containing_a_control_required_type_with_a_missing_contorl_document_type(List<Type> typeList) throws Throwable {
		typeList.get(0).setId(UUID.randomUUID());
		typeList.get(0).setFamilyId(UUID.randomUUID());
		ownersDTO = Arrays.asList(new OwnerDTO(owners.get(0)));
		final Set<String> refs = new HashSet<>();
		refs.add(owners.get(0).getReference());
		typeList.forEach(t -> t.setFamilyOwners(refs));
		familiesDTO = new CustomMapper().convertToFamilyDTO(new HashSet<>(typeList), Channel.SPIRIT.getValue());
		this.collectAllDetailsDTO.setFamilies(familiesDTO);
		this.collectAllDetailsDTO.setOwners(ownersDTO);
		when(gdnParamRepository.getGdnParam()).thenReturn(CollectSaveSteps.gdnParam());
		doNothing().when(collectRepository).add(commonCollect);
	}

	@Given("^having an owner$")
	public void having_an_owner(List<Owner> data) throws Throwable {
		owners = new ArrayList<>();

		owners.add(data.get(0));
		// when(collectService.getCollectsByOwners(ImmutableSet.<String> of(owners.get(0).getReference()), commonCollect.getJourneyCode())).thenReturn(Sets.newSet(commonCollect));
	}

	@When("^I save another collect$")
	public void i_save_another_collect(DataTable data) throws Throwable {
		final List<String> col = data.raw().get(0);
		commonCollect = new Collect(UUID.randomUUID(), CollectStatus.EC.name(), Instant.now(), null, col.get(0), col.get(1), col.get(2), col.get(3), null, ImmutableSet.copyOf(col.get(4).split(",")), ImmutableSet.copyOf(col.get(5).split(",")), null,
				col.get(6), false, false, 0, false, 0);
		this.collectAllDetailsDTO = new CollectAllDetailsDTO(commonCollect);
		ownersDTO = Arrays.asList(new OwnerDTO(owners.get(0)));
		familiesDTO = new CustomMapper().convertToFamilyDTO(new HashSet<>(types), Channel.SPIRIT.getValue());
		this.collectAllDetailsDTO.setFamilies(familiesDTO);
		this.collectAllDetailsDTO.setOwners(ownersDTO);

		when(gdnParamRepository.getGdnParam()).thenReturn(CollectSaveSteps.gdnParam());
	}

	@When("^having the same owner$")
	public void having_the_same_owner(List<OwnerDTO> data) throws Throwable {
		collectAllDetailsDTO.setOwners(data);
		try {
			collectDTO = collectAction.saveCollect(collectAllDetailsDTO, new Context("123456", "001", "001"));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@Then("^the collect is saved with alert$")
	public void the_collect_is_saved_with_alert() throws Throwable {
		assertThat(exception).isNull();
		// assertThat(collectDTO.getAlert()).isNotBlank();
	}
}