package com.bnpparibas.bddf.collect.application.collect.steps;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.test.util.ReflectionTestUtils;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.CollectDTO;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.OwnerDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.collect.CollectActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.CollectServiceImpl;
import com.bnpparibas.bddf.collect.domain.collect.FamiliesManagmentAct;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.param.GdnParamRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.google.common.collect.ImmutableSet;

import cucumber.api.DataTable;

public class AbstractCollectSaveSteps {

	protected CollectActionsImpl collectAction;

	protected CollectServiceImpl collectService;
	protected AuditGenerator auditGenerator;

	protected CollectRepository collectRepository;
	protected TypeRepository typeRepository;
	protected GdnParamRepository gdnParamRepository;
	protected List<OwnerDTO> ownersDTO;
	protected List<Owner> owners;
	protected List<FamilyDTO> familiesDTO;
	protected CollectEventHandler collectEventHandler;
	protected List<Type> types;
	protected Collect commonCollect;
	protected CollectDTO collectDTO;
	protected Exception exception;
	protected CollectAllDetailsDTO collectAllDetailsDTO;

	public AbstractCollectSaveSteps() {
		collectRepository = mock(CollectRepository.class);
		gdnParamRepository = mock(GdnParamRepository.class);
		collectEventHandler = mock(CollectEventHandler.class);
		typeRepository = mock(TypeRepository.class);
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(true);
		final TypeValidator typeValidator = new TypeValidator();
		final NomenclatureService nomenclatureService = mock(NomenclatureService.class);

		final Environment environment = mock(Environment.class);
		when(environment.getProperty("param.controlIterationAllowed", Integer.class, 2)).thenReturn(2);
		final CollectValidator collectValidator = new CollectValidator();
		collectValidator.setEnvironment(environment);
		collectService = new CollectServiceImpl(collectRepository, typeRepository, gdnParamRepository, collectValidator, collectEventHandler, auditGenerator, environment, typeValidator, new EdocTypesRepositoryImpl(), new EdocIndexRepositoryImpl());
		collectService.setNomenclatureService(nomenclatureService);
		collectAction = new CollectActionsImpl(collectService, new CustomMapper());
		collectAction.setEnvironment(environment);
		ReflectionTestUtils.setField(collectService, "authorizedFormat", "PDF,PDF/A,PNG,JPEG,GIF,TIF,TIFF");
		this.collectAllDetailsDTO = new CollectAllDetailsDTO();
		collectService.setFeatureManager(featureManager);
	}

	/**
	 * Get the right cell
	 */
	protected String getRowCell(int row, int cell, DataTable data) {
		return data.getGherkinRows().get(row).getCells().get(cell);
	}

	/**
	 * Creates a collect using idCollect
	 */
	public void createACollecte(UUID idCollect, DataTable data) {
		this.commonCollect = new Collect(idCollect, getRowCell(0, 1, data), Instant.now(), null, getRowCell(0, 3, data), getRowCell(0, 4, data), getRowCell(0, 5, data), getRowCell(0, 6, data),
				ImmutableSet.<String> of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIF", "TIFF"), ImmutableSet.<String> of(getRowCell(0, 7, data)),
				ImmutableSet.<String> of(FamiliesManagmentAct.OB.name(), FamiliesManagmentAct.ND.name(), FamiliesManagmentAct.DR.name()), null, "", false, false, 0, false, 0);
		this.collectAllDetailsDTO = new CollectAllDetailsDTO(commonCollect);
		this.collectAllDetailsDTO.setOwners(ownersDTO);
		this.collectAllDetailsDTO.setFamilies(familiesDTO);
	}

	/**
	 * Creation of our owners
	 *
	 * @param idCollect
	 */
	protected void createOurOwners(UUID idCollect, DataTable data) {
		final List<Owner> ownersBis = new ArrayList<Owner>();
		data.getGherkinRows().stream().forEach(row -> {
			if (!getRowCell(0, 9, data).isEmpty()) {
				final Owner owner = new Owner(getRowCell(0, 9, data), getRowCell(0, 10, data), getRowCell(0, 11, data), null, 01, "1234567", null);
				ownersBis.add(owner);
			}
		});
		if (!ownersBis.isEmpty()) {
			ownersDTO = ownersBis.stream().map(owner -> new OwnerDTO(owner)).collect(Collectors.toList());
		}

	}

	protected void createOurFamilies(UUID id, DataTable data) {
		parseTheDatas(data);
		familiesDTO = new CustomMapper().convertToFamilyDTO(new HashSet<>(types), Channel.SPIRIT.getValue());

	}

	protected boolean trueOrFalse(String s) {
		if (s.equals("Oui")) {
			return true;
		} else {
			return false;
		}
	}

	protected static Map<String, Long> gdnParam() {
		return Collections.unmodifiableMap(Stream.of(new SimpleEntry<String, Long>("20090343", (long) 10485760), new SimpleEntry<String, Long>("20090091", (long) 10485760)).collect(Collectors.toMap((e) -> e.getKey(), (e) -> e.getValue())));
	}

	protected void parseTheDatas(DataTable data) {
		final Set<Type> typesBis = new HashSet<>();

		final UUID idFamilly = UUID.randomUUID();
		data.getGherkinRows().stream().forEach(row -> {
			final String owners = data.getGherkinRows().get(0).getCells().get(14);
			final Set<String> listOwners = new HashSet<>();
			Arrays.asList(owners.split(",")).stream().forEach(listOwners::add);

			final UUID idType = UUID.randomUUID();
			final Type type = new Type(idType, null, idFamilly, listOwners, row.getCells().get(15), row.getCells().get(16), null, row.getCells().get(17), row.getCells().get(18), row.getCells().get(19), row.getCells().get(21), row.getCells().get(22),
					trueOrFalse(row.getCells().get(23)), "", 100000, Integer.valueOf(row.getCells().get(26)), null, false, "", false, null, false, false, null, null, true);

			type.setEdocType("00000000000000001");
			type.setControlRequired(0);
			typesBis.add(type);
			if (!row.getCells().get(14).isEmpty()) {
				final UUID idSubType = UUID.randomUUID();
				final Type subType = new Type(idSubType, idType, idFamilly, listOwners, row.getCells().get(15), row.getCells().get(16), null, row.getCells().get(17), row.getCells().get(18), row.getCells().get(19), row.getCells().get(21),
						row.getCells().get(22), trueOrFalse(row.getCells().get(23)), "", 10000, Integer.valueOf(row.getCells().get(26)), null, false, "", false, null, false, false, null, null, true);

				subType.setEdocType("00000000000000001");
				subType.setControlRequired(0);
				typesBis.add(subType);
			}
		});
		types = new ArrayList<>(typesBis);
	}

}
