package com.bnpparibas.bddf.collect.application.index.sm04.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.core.env.Environment;

import com.bnp.schema.edoc.index.Indexes.EdocIndex;
import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActionsImpl;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.index.IndexeJmc;
import com.bnpparibas.bddf.collect.domain.ladrad.LadRadValidator;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceService;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CalculateIndicatorsPieceSteps {

	private PieceActionsImpl pieceAction;
	private Collect existingCollect;
	private LadRadValidator ladRadValidator = new LadRadValidator();

	public CalculateIndicatorsPieceSteps() throws InterruptedException {

		final PieceService pieceService = mock(PieceService.class);
		final Environment environment = mock(Environment.class);
		doAnswer(invocation -> {
			final Set<Piece> pieces = invocation.getArgument(2);
			final List<EdocType> edocTypes = (new EdocTypesRepositoryImpl()).findAll();
			final List<EdocIndex> edocIndexes = (new EdocIndexRepositoryImpl()).findAll();
			pieces.forEach(piece -> {
				ladRadValidator.calculateIndicatorsPieces(piece, existingCollect.getTypes().iterator().next(), edocTypes, edocIndexes);
				existingCollect.getTypes().iterator().next().setPieces(pieces);
			});
			ladRadValidator.calculateIndicatorsType(existingCollect.getTypes().iterator().next(), edocTypes);
			return UUID.randomUUID();
		}).when(pieceService).updatePieces(any(), any(), any(), any());
		pieceAction = new PieceActionsImpl(pieceService, new CustomMapper());
		pieceAction.setEnvironment(environment);
	}

	@Given("^An existing collect$")
	public void an_existing_collect(List<Collect> collects) throws Throwable {
		this.existingCollect = collects.get(0);
	}

	@Given("^An existing Owners$")
	public void an_existing_Owners(List<Owner> owners) throws Throwable {
		this.existingCollect.setOwners(new HashSet<>(owners));
	}

	@Given("^An existing types$")
	public void an_existing_types(List<Type> types) throws Throwable {
		this.existingCollect.getTypes().addAll(types);
	}

	@Given("^existing pieces in type <\"([^\"]*)\">$")
	public void existing_pieces_in_type(String idType, List<Piece> pieces) throws Throwable {
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(idType)).findAny().get().setPieces(pieces.stream().collect(Collectors.toSet()));
	}

	@Given("^Existing completeness in type$")
	public void existing_completeness_in_type(List<String> completeness) throws Throwable {
		existingCollect.getTypes().iterator().next().setCompleteness(completeness.stream().collect(Collectors.toSet()));
	}

	@Given("^existing indexes in type <\"([^\"]*)\">$")
	public void existing_indexes_in_type(String typeId, List<Indexe> indexes) throws Throwable {
		existingCollect.getTypes().iterator().next().setIndexes(indexes.stream().collect(Collectors.toSet()));
	}

	@Given("^existing indexes_jmc in indexe <\"([^\"]*)\">$")
	public void existing_indexes_jmc_in_indexe(String indexId, List<IndexeJmc> indexesJmc) throws Throwable {
		existingCollect.getTypes().iterator().next().getIndexes().stream().filter(idx -> idx.getId().toString().equals(indexId)).findFirst().get().setIndexesJmc(indexesJmc);
	}

	@Given("^existing typeJmc in piece <\"([^\"]*)\">$")
	public void existing_typeJmc_in_piece(String idPiece, List<String> typesJmc) throws Throwable {
		existingCollect.getTypes().iterator().next().getPieces().stream().filter(p -> p.getId().toString().equals(idPiece)).findAny().get().setTypesJmc(typesJmc);// .stream().collect(Collectors.toList()));
	}

	@When("^I update pieces$")
	public void i_update_pieces() throws Throwable {
		final List<PieceDTO> piecesDTO = existingCollect.getTypes().iterator().next().getPieces().stream().map(piece -> new PieceDTO(piece, Channel.SPIRIT.getValue())).collect(Collectors.toList());
		pieceAction.updatePieces(existingCollect.getId(), existingCollect.getTypes().iterator().next().getId(), piecesDTO, new Context("123456", "001"));
	}

	@Then("^I expect CTRL_RECO <\"([^\"]*)\"> in piece <\"([^\"]*)\">$")
	public void i_expect_CTRL_RECO_in_piece(String typeControl, String pieceId) throws Throwable {
		assertThat(existingCollect.getTypes().iterator().next().getPieces().stream().filter(p -> p.getId().toString().equals(pieceId)).findAny().get().getTypeControl()).isEqualTo(typeControl);
	}

	@Then("^I expect CTRL_EXTR <\"([^\"]*)\"> in piece <\"([^\"]*)\">$")
	public void i_expect_CTRL_EXTR_in_piece(String extractionControl, String pieceId) throws Throwable {
		assertThat(existingCollect.getTypes().iterator().next().getPieces().stream().filter(p -> p.getId().toString().equals(pieceId)).findAny().get().getExtractionControl()).isEqualTo(extractionControl);
	}

	@Then("^I expect CTRL_COHE <\"([^\"]*)\"> in piece <\"([^\"]*)\">$")
	public void i_expect_CTRL_COHE_in_piece(String coherenceControl, String pieceId) throws Throwable {
		assertThat(existingCollect.getTypes().iterator().next().getPieces().stream().filter(p -> p.getId().toString().equals(pieceId)).findAny().get().getCoherenceControl()).isEqualTo(coherenceControl);
	}

	@Then("^I expect statusControl <\"([^\"]*)\"> in piece <\"([^\"]*)\">$")
	public void i_expect_statusControl_in_piece(String statusControl, String pieceId) throws Throwable {
		assertThat(existingCollect.getTypes().iterator().next().getPieces().stream().filter(p -> p.getId().toString().equals(pieceId)).findAny().get().getStatusControl()).isEqualTo(statusControl);
	}

	@Then("^I expect completenessControl <\"([^\"]*)\">$")
	public void i_expect_completenessControl(String completenessControl) throws Throwable {
		assertThat(existingCollect.getTypes().iterator().next().getCompletenessControl()).isEqualTo(completenessControl);
	}

	@Then("^I expect statusControl <\"([^\"]*)\"> for the type$")
	public void i_expect_statusControl_for_the_type(String ctrlStatus) throws Throwable {
		assertThat(existingCollect.getTypes().iterator().next().getStatusControl()).isEqualTo(ctrlStatus);
	}

}
