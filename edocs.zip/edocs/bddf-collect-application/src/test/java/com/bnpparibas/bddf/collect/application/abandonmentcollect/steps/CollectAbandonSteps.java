package com.bnpparibas.bddf.collect.application.abandonmentcollect.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.collect.CollectActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.CollectServiceImpl;
import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.param.GdnParamRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableSet;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CollectAbandonSteps {

	private CollectActionsImpl collectAction;

	private CollectServiceImpl collectService;

	private CollectRepository collectRepository;
	private TypeRepository typeRepository;
	private GdnParamRepository gdnParamRepository;
	private CollectEventHandler collectEventHandler;
	private Exception exception;
	private Collect collect;
	private AuditGenerator auditGenerator;
	private CollectAllDetailsDTO commonCollectAllDetailsDTO;

	public CollectAbandonSteps() {
		collectRepository = mock(CollectRepository.class);
		typeRepository = mock(TypeRepository.class);
		collectEventHandler = mock(CollectEventHandler.class);
		gdnParamRepository = mock(GdnParamRepository.class);
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(false);
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		final TypeValidator typeValidator = new TypeValidator();
		final Environment environment = mock(Environment.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		collectService = new CollectServiceImpl(collectRepository, typeRepository, gdnParamRepository, new CollectValidator(), collectEventHandler, auditGenerator, environment, typeValidator, new EdocTypesRepositoryImpl(), new EdocIndexRepositoryImpl());
		collectService.setFeatureManager(featureManager);
		collectAction = new CollectActionsImpl(collectService, new CustomMapper());
		collectAction.setEnvironment(environment);

	}

	@Given("^a collect to abandon$")
	public void a_collect_to_abandon(DataTable data) throws Throwable {
		if (collect == null) {
			final List<String> col = data.raw().get(0);
			collect = new Collect(UUID.fromString(col.get(0)), col.get(1), ZonedDateTime.parse(col.get(2)).toInstant(), null, col.get(4), col.get(5), col.get(6), col.get(7), ImmutableSet.<String> of(), ImmutableSet.<String> of(),
					ImmutableSet.<String> of(), null, col.get(8), false, false, 0, false, 0);
			commonCollectAllDetailsDTO = new CollectAllDetailsDTO(collect);

		}
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
	}

	@Given("^I close the collect <\"([^\"]*)\"> before abandon$")
	public void i_close_the_collect_before_abandon(String arg1) throws Throwable {
		commonCollectAllDetailsDTO.setCollectStatus("CL");
		collectAction.updateCollect(UUID.fromString(arg1), commonCollectAllDetailsDTO, new Context("123456", "001"));
	}

	@When("^I abandon the collect <\"([^\"]*)\">$")
	public void i_abandon_the_collect(String collectId) throws Throwable {
		try {
			// new SecurityInterceptor(collectService).checkCollect(false, UUID.fromString(collectId), "001");
			commonCollectAllDetailsDTO.setCollectStatus("AB");
			collectAction.updateCollect(UUID.fromString(collectId), commonCollectAllDetailsDTO, new Context("123456", "001"));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@Then("^the collect is abandoned$")
	public void the_collect_is_abandoned() throws Throwable {
		assertThat(exception).isNull();
		assertThat(collect.getStatus()).isEqualTo(CollectStatus.AB.name());
	}

	@Then("^I get the error <\"([^\"]*)\">$")
	public void i_get_the_error(String arg1) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);
		assertThat(exception.getMessage()).isEqualTo(arg1);
	}

	@When("^I get the collect <\"([^\"]*)\"> with channel <\"([^\"]*)\">$")
	public void i_get_the_collect_with_channel(String collectId, String channel) throws Throwable {
		try {
			// new SecurityInterceptor(collectService).checkCollect(true, UUID.fromString(collectId), channel);
			collectAction.getCollect(UUID.fromString(collectId), new Context("1234567891011", channel));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

}
