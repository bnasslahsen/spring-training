package com.bnpparibas.bddf.collect.application.referencesm03.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;

import java.security.acl.Owner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.core.env.Environment;

import com.bnpparibas.bddf.collect.application.collect.params.PiecesStatusActionsImpl;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActionsImpl;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceService;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ReferenceValidationSteps {

	private PieceActionsImpl pieceAction;
	private Exception currentException;
	private Collect existingCollect;
	private SubTypeDTO typeDTO;
	private List<PieceDTO> piecesDTO;
	private List<Piece> piecesSentToGdn = new ArrayList<>();
	private String channel;

	// A renommer + deplacer
	private Pair<Piece, Piece> buildPair(Piece piece, Set<Piece> pieces) {
		return Pair.of(piece, pieces.stream().filter(p -> p.equals(piece)).findAny().orElse(null));
	}

	public ReferenceValidationSteps() throws InterruptedException {
		final PieceService pieceService = mock(PieceService.class);
		final PieceValidator pieceValidator = new PieceValidator();
		final PiecesStatusActionsRepository piecesStatusActionsRepository = new PiecesStatusActionsImpl();
		pieceValidator.setPieceStatusRepository(piecesStatusActionsRepository);
		final Environment environment = mock(Environment.class);
		doAnswer(invocation -> {
			final UUID idType = invocation.getArgument(1);
			final Set<Piece> pieces = invocation.getArgument(2);
			final Context context = invocation.getArgument(3);
			final Set<Piece> piecesToRemove = new HashSet<>();
			final Type existingType = existingCollect.getTypes().stream().filter(t -> t.getId().equals(idType)).findAny().get();
			pieces.stream().map(piece -> buildPair(piece, existingType.getPieces())).forEach(pair -> pieceValidator.validatePutPiecesStatus(pair.getRight(), pair.getLeft().getStatus(), context.getCanal()));
			// Suppresion des pièces non envoyées
			piecesToRemove.addAll(existingType.getPieces());
			piecesToRemove.removeAll(pieces);
			existingType.getPieces().removeAll(piecesToRemove);
			piecesSentToGdn = existingType.getPieces().stream().filter(p -> Arrays.asList(PieceStatus.DF.getLabel(), PieceStatus.TP.getLabel()).contains(p.getStatus())).collect(Collectors.toList());
			return UUID.randomUUID();
		}).when(pieceService).updatePieces(any(), any(), any(), any());
		pieceAction = new PieceActionsImpl(pieceService, new CustomMapper());
		pieceAction.setEnvironment(environment);
	}

	@Given("^An existing collect$")
	public void an_existing_collect(List<Collect> collects) throws Throwable {
		this.existingCollect = collects.get(0);
	}

	@Given("^An existing Owners$")
	public void an_existing_Owners(List<Owner> owners) throws Throwable {
		this.existingCollect.setOwners(new HashSet(owners));
	}

	@Given("^An existing types$")
	public void an_existing_types(List<Type> types) throws Throwable {
		this.existingCollect.getTypes().addAll(types);
	}

	@Given("^existing pieces in type <\"([^\"]*)\">$")
	public void existing_pieces_in_type(String idType, List<Piece> pieces) throws Throwable {
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(idType)).findAny().get().setPieces(pieces.stream().collect(Collectors.toSet()));
	}

	@Given("^pieces to modify$")
	public void pieces_to_modify(List<PieceDTO> piecesDTO) throws Throwable {
		this.piecesDTO = piecesDTO;
	}

	@Given("^A type to modify$")
	public void a_type_to_modify(List<SubTypeDTO> typesDTO) throws Throwable {
		this.typeDTO = typesDTO.get(0);
	}

	@Given("^pieces in the type to modify$")
	public void pieces_in_the_type_to_modify(List<PieceDTO> piecesDTO) throws Throwable {
		this.typeDTO.setPieces(piecesDTO);
	}

	@When("^I update a type <\"([^\"]*)\"> of a collect <\"([^\"]*)\">$")
	public void i_update_a_type(String typeId, String collectId) throws Throwable {
		try {
			pieceAction.updatePieces(UUID.fromString(collectId), UUID.fromString(typeId), piecesDTO, new Context("123456", channel));
		} catch (final Exception e) {
			currentException = e;
		}
	}

	@Then("^there is no exception$")
	public void there_is_no_exception() throws Throwable {
		assertThat(currentException).isNull();
	}

	@Then("^Piece <\"([^\"]*)\"> is saved in gdn$")
	public void piece_is_saved_in_gdn(String pieceId) throws Throwable {
		assertThat(piecesSentToGdn).isNotEmpty();
		assertTrue(piecesSentToGdn.stream().filter(p -> p.getId().toString().equals(pieceId)).findAny().isPresent());
	}

	@Then("^I expect error code : <\"([^\"]*)\">$")
	public void i_expect_error_code(String codeError) throws Throwable {
		assertThat(currentException).isNotNull();
		assertThat(currentException.getMessage()).isEqualTo(codeError);
	}

	@Given("^channel is <\"([^\"]*)\">$")
	public void channel_is(String channel) throws Throwable {
		this.channel = channel;
	}
}
