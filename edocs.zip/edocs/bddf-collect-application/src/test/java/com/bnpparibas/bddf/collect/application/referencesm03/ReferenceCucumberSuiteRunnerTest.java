package com.bnpparibas.bddf.collect.application.referencesm03;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(strict = true, plugin = { "pretty", "html:target/cucumber", "json:target/cucumber/referencesSM03/cucumber.json" }, glue = { "com.bnpparibas.bddf.collect.application.referencesm03" })
public class ReferenceCucumberSuiteRunnerTest {

}
