package com.bnpparibas.bddf.collect.application.index.sm01.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActionsImpl;
import com.bnpparibas.bddf.collect.application.service.type.TypeActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditEventService;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceService;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeService;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AutoValidationTypeSteps {

	private PieceActionsImpl pieceAction;
	private Collect existingCollect;
	private TypeActionsImpl typeAction;
	private TypeAutomaticControlUtils typeAutomaticControlUtils;

	public AutoValidationTypeSteps() throws InterruptedException {

		final PieceService pieceService = mock(PieceService.class);
		final TypeService typeService = mock(TypeService.class);
		final CollectRepository collectRepository = mock(CollectRepository.class);
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		final TypeRepository typeRepository = mock(TypeRepository.class);
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(true);
		final Environment environment = mock(Environment.class);

		doAnswer(invocation -> {
			final UUID collectId = invocation.getArgument(0);
			if (existingCollect.getId().equals(collectId)) {
				return existingCollect;
			} else {
				throw new IllegalArgumentException();
			}
		}).when(collectRepository).findOne(any());

		doAnswer(invocation -> {
			final UUID collectId = invocation.getArgument(0);
			if (existingCollect.getId().equals(collectId)) {
				return existingCollect;
			} else {
				throw new IllegalArgumentException();
			}
		}).when(collectRepository).findOnlyCollect(any());

		typeAutomaticControlUtils = new TypeAutomaticControlUtils();
		typeAutomaticControlUtils.setCollectRepository(collectRepository);
		typeAutomaticControlUtils.setDocReferenceService(docReferenceService);
		typeAutomaticControlUtils.setTypeRepository(typeRepository);
		typeAutomaticControlUtils.setFeatureManager(featureManager);
		typeAutomaticControlUtils.setEnvironment(environment);

		final AuditEventService auditEventService = mock(AuditEventService.class);
		doNothing().when(auditEventService).sendAuditEventLadRAD(any(), any(), any(), any(), any(), any());
		doNothing().when(auditEventService).sendAuditEventLadRADFirstIteration(any(), any(), any(), any(), any(), any(), any(), any());
		doNothing().when(auditEventService).sendAuditEventLadRADSecondIteration(any(), any(), any(), any(), any(), any(), any());
		when(auditEventService.sendAuditEventForcedRecognition(any(), any(), any(), any(), any())).thenReturn(true);
		typeAutomaticControlUtils.setAuditEventService(auditEventService);

		doAnswer(invocation -> {
			final UUID collectId = invocation.getArgument(0);
			final UUID typeId = invocation.getArgument(1);
			final Type type = existingCollect.getTypes().stream().filter(typeL -> typeL.getId().equals(typeId)).findAny().orElseThrow(() -> new IllegalArgumentException());
			typeAutomaticControlUtils.autoValidateType(collectId, type, new Context("1", Channel.SPIRIT.getValue(), "001"), any());

			return UUID.randomUUID();
		}).when(pieceService).updatePieces(any(), any(), any(), any());

		doAnswer(invocation -> {

			final UUID collectId = invocation.getArgument(0);
			final UUID typeId = invocation.getArgument(1);
			final Type type = existingCollect.getTypes().stream().filter(typeL -> typeL.getId().equals(typeId)).findAny().orElseThrow(() -> new IllegalArgumentException());
			typeAutomaticControlUtils.autoValidateType(collectId, type, new Context("1", Channel.SPIRIT.getValue(), "001"), any());
			return UUID.randomUUID();
		}).when(typeService).updateType(any(), any(), any(), any());

		pieceAction = new PieceActionsImpl(pieceService, new CustomMapper());
		pieceAction.setEnvironment(environment);
		typeAction = new TypeActionsImpl(typeService, new CustomMapper());
	}

	@Given("^An existing collect$")
	public void an_existing_collect(List<Collect> collects) throws Throwable {
		this.existingCollect = collects.get(0);
		existingCollect.setJourneyCode("000001");
	}

	@Given("^An existing Owners$")
	public void an_existing_Owners(List<Owner> owners) throws Throwable {
		this.existingCollect.setOwners(new HashSet<>(owners));
	}

	@Given("^An existing types$")
	public void an_existing_types(List<Type> types) throws Throwable {
		this.existingCollect.getTypes().addAll(types);
	}

	@Given("^existing pieces in type <\"([^\"]*)\">$")
	public void existing_pieces_in_type(String typeId, List<Piece> pieces) throws Throwable {
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get().setPieces(pieces.stream().collect(Collectors.toSet()));
	}

	@Given("^Existing completeness in type <\"([^\"]*)\">$")
	public void existing_completeness_in_type(String typeId, List<String> completeness) throws Throwable {
		existingCollect.getTypes().stream().filter(type -> typeId.equals(type.getId().toString())).findAny().get().setCompleteness(completeness.stream().collect(Collectors.toSet()));
	}

	@Given("^existing indexes in type <\"([^\"]*)\">$")
	public void existing_indexes_in_type(String typeId, List<Indexe> indexes) throws Throwable {
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get().setIndexes(indexes.stream().collect(Collectors.toSet()));
	}

	@Given("^existing typeJmc in piece <\"([^\"]*)\"> of type <\"([^\"]*)\">$")
	public void existing_typeJmc_in_piece_of_type(String idPiece, String typeId, List<String> typesJmc) throws Throwable {
		existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get().getPieces().stream().filter(p -> p.getId().toString().equals(idPiece)).findAny().get().setTypesJmc(typesJmc);// .stream().collect(Collectors.toList()));
	}

	@When("^I update pieces of type <\"([^\"]*)\">$")
	public void i_update_pieces_of_type(String typeId) throws Throwable {
		final List<PieceDTO> piecesDTO = existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get().getPieces().stream().map(piece -> new PieceDTO(piece, Channel.SPIRIT.getValue())).collect(Collectors.toList());
		pieceAction.updatePieces(existingCollect.getId(), existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get().getId(), piecesDTO, new Context("123456", Channel.SPIRIT.getValue()));
	}

	@When("^I update a type <\"([^\"]*)\">$")
	public void i_update_a_type(String typeId) throws Throwable {
		final SubTypeDTO typeDTO = new SubTypeDTO(existingCollect.getTypes().stream().filter(t -> t.getId().toString().equals(typeId)).findAny().get(), Channel.SPIRIT.getValue());
		typeAction.updateType(existingCollect.getId(), UUID.fromString(typeId), typeDTO, new Context("123456", Channel.SPIRIT.getValue()));
	}

	@Then("^I expect pieces status <\"([^\"]*)\"> for the type <\"([^\"]*)\">$")
	public void i_expect_pieces_status_for_the_type(String pieceStatus, String typeId) throws Throwable {
		existingCollect.getTypes().stream().filter(type -> typeId.equals(type.getId().toString())).findAny().get().getPieces().forEach(piece -> {
			assertThat(piece.getStatus()).isEqualTo(pieceStatus);
		});
	}

	@Then("^I expect status <\"([^\"]*)\"> for the type <\"([^\"]*)\">$")
	public void i_expect_status_for_the_type(String typeStatus, String typeId) throws Throwable {
		assertThat(existingCollect.getTypes().stream().filter(type -> typeId.equals(type.getId().toString())).findAny().get().getStatus()).isEqualTo(typeStatus);
	}

}
