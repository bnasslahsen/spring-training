package com.bnpparibas.bddf.collect.application.familydelete.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.family.FamilyActionsImpl;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeServiceImpl;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DeleteFamilySteps {

	private List<Collect> collects;
	private String familyId;

	private FamilyActionsImpl familyActions;
	private Exception exception;
	private CustomMapper customMapper = new CustomMapper();
	private CollectValidator customValidator = new CollectValidator();

	public DeleteFamilySteps() {
		final TypeServiceImpl typeService = mock(TypeServiceImpl.class);
		familyActions = new FamilyActionsImpl(typeService, customMapper);

		doAnswer(invocation -> {
			final UUID collectId = invocation.getArgument(0);
			final Collect collect = collects.stream().filter(c -> c.getId().equals(collectId)).findAny().get();
			customValidator.validateFamilyExistance(UUID.fromString(familyId), collect.getTypes(), collectId);
			collect.getTypes().stream().forEach(t -> {
				t.getPieces().clear();
			});
			collect.setTypes(collect.getTypes().stream().filter(t -> !t.getFamilyId().toString().equals(familyId)).collect(Collectors.toSet()));
			return null;
		}).when(typeService).deleteFamily(any(), any(), any());

	}

	@Given("^Existing collects$")
	public void existing_collects(List<Collect> collects) throws Throwable {
		this.collects = collects;
	}

	@Given("^Existing familiesManagmentActs in collect <\"([^\"]*)\">$")
	public void existing_familiesManagmentActs_in_collect(String collectId, DataTable acts) throws Throwable {
		collects.stream().filter(c -> c.getId().toString().equals(collectId)).forEach(c -> c.setFamiliesManagementAct(new HashSet<>(acts.cells(0).get(0))));
	}

	@Given("^An existing list of types in collect <\"([^\"]*)\">$")
	public void an_existing_list_of_types_in_collect(String collectId, List<Type> types) throws Throwable {
		collects.stream().filter(c -> c.getId().toString().equals(collectId)).forEach(c -> c.setTypes(new HashSet<>(types)));
	}

	@Given("^Existing owners in collect <\"([^\"]*)\">$")
	public void existing_owners_in_collect(String collectId, List<Owner> owners) throws Throwable {
		collects.stream().filter(c -> c.getId().toString().equals(collectId)).forEach(c -> c.setOwners(new HashSet<>(owners)));
	}

	@Given("^Existing pieces in type <\"([^\"]*)\"> and collect <\"([^\"]*)\">$")
	public void existing_pieces_in_type_and_collect(String typeId, String collectId, List<Piece> pieces) throws Throwable {
		collects.stream().filter(c -> c.getId().toString().equals(collectId)).map(Collect::getTypes).flatMap(Collection::stream).filter(t -> t.getId().toString().equals(typeId)).forEach(t -> t.setPieces(new HashSet<>(pieces)));
	}

	@Given("^a family to delete <\"([^\"]*)\">$")
	public void a_family_to_delete(String familyId) throws Throwable {
		this.familyId = familyId;
	}

	@When("^I delete the family in collect <\"([^\"]*)\">$")
	public void i_delete_the_family_in_collect(String collectId) throws Throwable {
		try {
			familyActions.deleteFamily(UUID.fromString(collectId), UUID.fromString(familyId), new Context("132456", "001"));
		} catch (final Exception e) {
			exception = e;
		}
	}

	@Then("^I return the error code : <\"([^\"]*)\">$")
	public void i_return_the_error_code(String message) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception.getMessage()).isEqualTo(message);
	}

	@Then("^There is no exception$")
	public void there_is_no_exception() throws Throwable {
		assertThat(exception).isNull();
	}

	@Then("^types in the collect <\"([^\"]*)\"> are <(\\d+)>$")
	public void types_in_the_collect_are(String collectId, int nbrTypes) throws Throwable {
		final Collect collect = collects.stream().filter(c -> c.getId().toString().equals(collectId)).findAny().get();
		assertThat(collect.getTypes().size()).isEqualTo(nbrTypes);
	}

}
