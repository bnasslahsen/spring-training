package com.bnpparibas.bddf.collect.application.referencesm02;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(strict = true, plugin = { "pretty", "html:target/cucumber", "json:target/cucumber/referencesSM02/cucumber.json" }, glue = { "com.bnpparibas.bddf.collect.application.referencesm02", "cucumber.api.spring", "cucumber.runtime.java.spring" })
public class ReferenceCucumberSuiteRunnerTest {

}
