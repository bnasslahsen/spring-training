package com.bnpparibas.bddf.collect.application.piece.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadService;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableSet;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PieceDeleteSteps {

	private PieceActionsImpl pieceActions;
	private CollectRepository collectRepository;
	private PieceRepository pieceRepository;
	private TypeRepository typeRepository;
	private CollectEventHandler collectEventHandler;

	private Collect collect;
	private Piece piece;
	private Type type;

	private Exception exception;
	private boolean deleted;
	private AuditGenerator auditGenerator;
	private PieceAutomaticControlUtils pieceAutomaticControlUtils;

	// UPL3010SM01

	public PieceDeleteSteps() {
		collectRepository = mock(CollectRepository.class);
		typeRepository = mock(TypeRepository.class);
		collectEventHandler = mock(CollectEventHandler.class);
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		pieceRepository = mock(PieceRepository.class);
		final TypeLadRadService typeLadRadService = mock(TypeLadRadService.class);
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);

		final TypeValidator typeValidator = new TypeValidator();
		final Environment environment = mock(Environment.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		final CollectValidator customValidator = new CollectValidator();
		final PieceValidator pieceValidator = new PieceValidator();
		final PiecesStatusActionsRepository piecesStatusActionsRepository = mock(PiecesStatusActionsRepository.class);
		pieceValidator.setPieceStatusRepository(piecesStatusActionsRepository);

		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("TP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutPieces(eq("TP"), any())).thenReturn(true);

		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(false);
		final TypeAutomaticControlServiceImpl typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, typeValidator, null, new EdocIndexRepositoryImpl(), featureManager, pieceRepository, null, null, null,
				typeRepository, docReferenceService, new TypeAutomaticControlUtils());
		typeAutomaticControlService.setCollectRepository(collectRepository);

		pieceAutomaticControlUtils = new PieceAutomaticControlUtils(new PieceGdnServiceImpl(), typeAutomaticControlService);
		final PieceServiceImpl pieceService = new PieceServiceImpl(collectRepository, typeRepository, pieceRepository, customValidator, collectEventHandler, null, auditGenerator, environment, typeAutomaticControlService, featureManager,
				pieceAutomaticControlUtils);
		pieceService.setPieceValidator(pieceValidator);
		pieceActions = new PieceActionsImpl(pieceService, new CustomMapper());
		pieceActions.setEnvironment(environment);
		collect = new Collect(UUID.randomUUID(), "EC", Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", ImmutableSet.<String> of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIF", "TIFF"), ImmutableSet.<String> of("DP", "VA"),
				ImmutableSet.<String> of(), null, "AP001", false, false, 0, false, 0);
		type = new Type(UUID.randomUUID(), null, UUID.randomUUID(), new HashSet<>(Arrays.asList("01740005814400000")), "Justificatif d'identité", "OB", null, "Liste", null, "info compl famille Justificatif d'identité", "Carte d'identité",
				"Veuiller fournir le recto et verso de votre carte d'identité", true, null, new Random().nextLong(), 0, null, false, null, false, null, false, false, null, null, true);
		collect.setTypes(ImmutableSet.<Type> of(type));
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
		final EdocTypeRepository edocTypeRepository = mock(EdocTypeRepository.class);
		pieceService.setEdocTypeRepository(edocTypeRepository);

	}

	@Given("^an existing temporary piece$")
	public void an_existing_temporary_piece(List<Piece> data) throws Throwable {
		piece = data.get(0);
		piece.setAcquisitionDate(Instant.now());
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);
		when(typeRepository.findOne(collect.getId(), type.getId())).thenReturn(type);
		type.setPieces(new HashSet<>(data));
		when(pieceRepository.getPiece(collect.getId(), type.getId(), piece.getId())).thenReturn(piece);
	}

	@When("^I delete the piece <\"([^\"]*)\"> with channel <\"([^\"]*)\">$")
	public void i_delete_the_piece_with_channel(String id, String channel) throws Throwable {
		try {

			deleted = pieceActions.deletePiece(collect.getId(), type.getId(), UUID.fromString(id), new Context("123456", channel));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@Then("^the piece is deleted$")
	public void the_piece_is_deleted() throws Throwable {
		assertThat(exception).isNull();
		assertThat(deleted).isTrue();
	}

	@Then("^I get an error : <\"([^\"]*)\">$")
	public void i_get_an_error(String arg1) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);
		assertThat(exception.getMessage()).isEqualTo(arg1);
	}

}
