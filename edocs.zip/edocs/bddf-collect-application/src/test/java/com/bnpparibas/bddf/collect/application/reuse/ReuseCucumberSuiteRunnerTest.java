package com.bnpparibas.bddf.collect.application.reuse;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(strict = true, plugin = { "pretty", "html:target/cucumber", "json:target/cucumber/reuse/cucumber.json" }, glue = { "com.bnpparibas.bddf.collect.application.reuse" })
public class ReuseCucumberSuiteRunnerTest {

}
