package com.bnpparibas.bddf.collect.application.piece.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.application.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.piece.PieceActionsImpl;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadService;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableSet;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PieceDeleteSteps2 {

	private PieceActionsImpl pieceActions;
	private CollectRepository collectRepository;
	private PieceRepository pieceRepository;
	private TypeRepository typeRepository;
	private Collect collect;
	private Piece piece;
	private Type type;
	private Exception exception;
	private boolean deleted;
	private CollectEventHandler collectEventHandler;
	private AuditGenerator auditGenerator;
	private PieceAutomaticControlUtils pieceAutomaticControlUtils;

	// UPL3019SM02

	public PieceDeleteSteps2() {
		collectRepository = mock(CollectRepository.class);
		typeRepository = mock(TypeRepository.class);
		collectEventHandler = mock(CollectEventHandler.class);
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		pieceRepository = mock(PieceRepository.class);
		final TypeLadRadService typeLadRadService = mock(TypeLadRadService.class);
		final TypeValidator typeValidator = new TypeValidator();
		final Environment environment = mock(Environment.class);
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		final CollectValidator customValidator = new CollectValidator();
		final PieceValidator pieceValidator = new PieceValidator();
		final PiecesStatusActionsRepository piecesStatusActionsRepository = mock(PiecesStatusActionsRepository.class);
		pieceValidator.setPieceStatusRepository(piecesStatusActionsRepository);

		when(piecesStatusActionsRepository.isNewPieceStatusAuthorizedForPutPieces(eq("TP"), eq("DP"), any())).thenReturn(true);
		when(piecesStatusActionsRepository.isDeleteAuthorizedForPutPieces(eq("TP"), any())).thenReturn(true);
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(false);
		final TypeAutomaticControlServiceImpl typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, typeValidator, null, new EdocIndexRepositoryImpl(), featureManager, pieceRepository, null, null, null,
				typeRepository, docReferenceService, new TypeAutomaticControlUtils());
		typeAutomaticControlService.setCollectRepository(collectRepository);
		pieceAutomaticControlUtils = new PieceAutomaticControlUtils(new PieceGdnServiceImpl(), typeAutomaticControlService);
		final PieceServiceImpl pieceService = new PieceServiceImpl(collectRepository, typeRepository, pieceRepository, customValidator, collectEventHandler, null, auditGenerator, environment, typeAutomaticControlService, featureManager,
				pieceAutomaticControlUtils);
		pieceService.setPieceValidator(pieceValidator);
		pieceActions = new PieceActionsImpl(pieceService, new CustomMapper());
		pieceActions.setEnvironment(environment);
		final EdocTypeRepository edocTypeRepository = mock(EdocTypeRepository.class);
		pieceService.setEdocTypeRepository(edocTypeRepository);

	}

	@Given("^A collect$")
	public void a_collect(List<Collect> data) throws Throwable {
		collect = data.get(0);
		when(collectRepository.findOne(collect.getId())).thenReturn(collect);

	}

	@And("^on a type$")
	public void on_a_type(List<Type> data) throws Throwable {
		type = data.get(0);
		collect.setTypes(ImmutableSet.<Type> of(type));
	}

	@Given("^An existing piece$")
	public void an_existing_piece(List<Piece> data) throws Throwable {
		piece = data.get(0);
		piece.setAcquisitionDate(Instant.now());
		when(pieceRepository.getPiece(collect.getId(), type.getId(), piece.getId())).thenReturn(piece);
		type.setPieces(new HashSet<>(data));
	}

	@When("^i delete the piece <\"([^\"]*)\"> with channel <\"([^\"]*)\">$")
	public void i_delete_the_piece_with_channel(String id, String channel) throws Throwable {
		try {

			deleted = pieceActions.deletePiece(collect.getId(), type.getId(), piece.getId(), new Context("123456", channel));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@Then("^The piece is deleted$")
	public void the_piece_is_deleted() throws Throwable {
		assertThat(exception).isNull();
		assertThat(deleted).isTrue();
	}

	@When("^I delete the piece <\"([^\"]*)\">with id collect <\"([^\"]*)\">and id type<\"([^\"]*)\"> with channel <\"([^\"]*)\">$")
	public void i_delete_the_piece_with_id_collect_and_id_type_with_channel(String idPiece, String idCollect, String idType, String channel) throws Throwable {
		try {
			deleted = pieceActions.deletePiece(UUID.fromString(idCollect), UUID.fromString(idType), UUID.fromString(idPiece), new Context("123456", channel));
		} catch (final Exception e) {
			this.exception = e;
		}

	}

	@Then("^I return an error : <\"([^\"]*)\">$")
	public void i_return_an_error(String arg1) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception).isInstanceOf(CollectBusinessException.class);
		assertThat(exception.getMessage()).isEqualTo(arg1);
	}

	@Then("^type id <\"([^\"]*)\"> has status to <\"([^\"]*)\">$")
	public void type_id_has_status_to(String idType, String status) throws Throwable {
		assertThat(exception).isEqualTo(null);
		assertThat(type.getStatus()).isEqualTo(status);
	}

	@When("^I delete the piece <\"([^\"]*)\"> via savePieces with id collect <\"([^\"]*)\">and id type<\"([^\"]*)\"> with channel <\"([^\"]*)\">$")
	public void i_delete_the_piece_via_savePieces_with_id_collect_and_id_type_with_channel(String idPiece, String idCollect, String idType, String channel) throws Throwable {
		try {
			boolean deleted = false;
			final List<PieceDTO> pieces = type.getPieces().stream().filter(piece -> !piece.getId().equals(UUID.fromString(idPiece))).map(piece -> new PieceDTO(piece, channel)).collect(Collectors.toList());
			pieceActions.updatePieces(UUID.fromString(idCollect), UUID.fromString(idType), pieces, new Context("1", channel));
			deleted = true;
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@Given("^a piece with an non existing collect$")
	public void a_piece_with_an_non_existing_collect(List<Piece> data) throws Throwable {
		piece = data.get(0);
		piece.setAcquisitionDate(Instant.now());
		when(pieceRepository.getPiece(collect.getId(), type.getId(), piece.getId())).thenReturn(piece);

	}

	@Given("^a piece with an non existing type$")
	public void a_piece_with_an_non_existing_type(List<Piece> data) throws Throwable {
		piece = data.get(0);
		piece.setAcquisitionDate(Instant.now());
		when(pieceRepository.getPiece(collect.getId(), type.getId(), piece.getId())).thenReturn(piece);

	}

	@Given("^a piece in a collect closed$")
	public void a_piece_in_a_collect_closed(List<Piece> data) throws Throwable {

		piece = data.get(0);
		piece.setAcquisitionDate(Instant.now());
		when(pieceRepository.getPiece(collect.getId(), type.getId(), piece.getId())).thenReturn(piece);
		collect.setStatus(CollectStatus.CL.name());

	}

	@Given("^type id <\"([^\"]*)\"> to <\"([^\"]*)\">$")
	public void type_id_to(String idType, String status) throws Throwable {
		assertThat(type.getId()).isEqualTo(UUID.fromString(idType));
		type.setStatus(TypeStatus.valueOf(status).getLabel());
	}

}
