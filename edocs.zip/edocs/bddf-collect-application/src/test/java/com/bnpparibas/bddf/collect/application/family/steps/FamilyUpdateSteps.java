package com.bnpparibas.bddf.collect.application.family.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.service.family.FamilyActionsImpl;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeServiceImpl;
import com.bnpparibas.bddf.rest.Context;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FamilyUpdateSteps {

	private List<Collect> collects;
	private List<FamilyDTO> families;
	private FamilyActionsImpl familyActions;
	private Exception exception;
	private final CollectValidator customValidator = new CollectValidator();

	public FamilyUpdateSteps() {
		final TypeServiceImpl typeService = mock(TypeServiceImpl.class);
		familyActions = new FamilyActionsImpl(typeService, new CustomMapper());

		doAnswer(invocation -> {
			final UUID collectId = invocation.getArgument(0);
			final Map<UUID, Type> families = invocation.getArgument(1);

			final Collect collect = collects.stream().filter(c -> c.getId().equals(collectId)).findAny().get();

			final Map<UUID, String> oldCategories = collect.getTypes().stream().collect(Collectors.toMap(Type::getFamilyId, Type::getFamilyCategory));

			customValidator.validateUpdateFamilies(oldCategories.keySet(), families, collectId, collect.getFamiliesManagementAct() != null ? collect.getFamiliesManagementAct() : new HashSet());

			collect.getTypes().stream().forEach(t -> {
				final Type newFam = families.get(t.getFamilyId());
				t.setFamilyCategory(newFam.getFamilyCategory());
				if (t.getFamilyCategory().equals("ND") || t.getFamilyCategory().equals("DR")) {
					t.getPieces().clear();
				}
			});

			return null;
		}).when(typeService).updateFamilies(any(), any(), any());
	}

	@Given("^Existing collects$")
	public void existing_collects(List<Collect> collects) throws Throwable {
		this.collects = collects;
	}

	@Given("^Existing familiesManagmentActs in collect <\"([^\"]*)\">$")
	public void existing_familiesManagmentActs_in_collect(String collectId, DataTable acts) throws Throwable {
		collects.stream().filter(c -> c.getId().toString().equals(collectId)).forEach(c -> c.setFamiliesManagementAct(new HashSet<>(acts.cells(0).get(0))));
	}

	@Given("^An existing list of types in collect <\"([^\"]*)\">$")
	public void an_existing_list_of_types_in_collect(String collectId, List<Type> types) throws Throwable {
		collects.stream().filter(c -> c.getId().toString().equals(collectId)).forEach(c -> c.setTypes(new HashSet<>(types)));
	}

	@Given("^Existing pieces in type <\"([^\"]*)\"> and collect <\"([^\"]*)\">$")
	public void existing_pieces_in_type_and_collect(String typeId, String collectId, List<Piece> pieces) throws Throwable {
		collects.stream().filter(c -> c.getId().toString().equals(collectId)).map(Collect::getTypes).flatMap(Collection::stream).filter(t -> t.getId().toString().equals(typeId)).forEach(t -> t.setPieces(new HashSet<>(pieces)));
	}

	@Given("^Families to save$")
	public void families_to_save(List<FamilyDTO> families) throws Throwable {
		this.families = families;
	}

	@Given("^Existing familiesManagmentActs in family <\"([^\"]*)\"> and collect <\"([^\"]*)\">$")
	public void existing_familiesManagmentActs_in_family_and_collect(String familyId, String collectId, DataTable familiesManagmentActs) throws Throwable {
		collects.stream().filter(c -> c.getId().toString().equals(collectId)).map(Collect::getTypes).flatMap(Collection::stream).filter(t -> t.getFamilyId().toString().equals(familyId))
				.forEach(t -> t.setFamiliesManagementActFamily(new HashSet<>(familiesManagmentActs.cells(0).get(0))));
	}

	@Given("^Families to save with familiesManagmentActs$")
	public void families_to_save_with_familiesManagmentActs(DataTable familyManagementActs) throws Throwable {
		families.stream().forEach(f -> f.setFamiliesManagementAct(familyManagementActs.cells(0).get(0)));
	}

	@When("^I update the families of collect <\"([^\"]*)\">$")
	public void i_update_the_families_of_collect(String collectId) throws Throwable {
		try {
			familyActions.updateFamilies(UUID.fromString(collectId), families, new Context("123456", "001"));
		} catch (final Exception e) {
			this.exception = e;
		}
	}

	@Then("^There is no exception$")
	public void there_is_no_exception() throws Throwable {
		assertThat(exception).isNull();
	}

	@Then("^The family <\"([^\"]*)\"> status of collect <\"([^\"]*)\"> is updated to <\"([^\"]*)\">$")
	public void the_family_status_of_collect_is_updated_to(String familyId, String collectId, String expectedSatus) throws Throwable {
		collects.stream().filter(c -> c.getId().toString().equals(collectId)).map(Collect::getTypes).flatMap(Collection::stream).forEach(t -> assertThat(t.getFamilyCategory()).isEqualTo(expectedSatus));
	}

	@Then("^Types of in family <\"([^\"]*)\"> in collect <\"([^\"]*)\"> does not contain piece$")
	public void types_of_in_family_in_collect_does_not_contain_piece(String familyId, String collectId) throws Throwable {
		assertThat(collects.stream().filter(c -> c.getId().toString().equals(collectId)).map(Collect::getTypes).flatMap(Collection::stream).filter(t -> t.getFamilyId().toString().equals(familyId)).mapToInt(t -> t.getPieces().size()).sum()).isEqualTo(0);
	}

	@Then("^I Expect error code <\"([^\"]*)\">$")
	public void i_Expect_error_code(String message) throws Throwable {
		assertThat(exception).isNotNull();
		assertThat(exception.getMessage()).isEqualTo(message);
	}

}
