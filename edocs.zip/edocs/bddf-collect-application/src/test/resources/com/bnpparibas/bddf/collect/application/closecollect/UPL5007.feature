Feature: UPL5007

########################################################## 0 #

Background:
Given a collect to close
#     | idCollect                                  | status   | creationDate        			|endDate| entityLabel | productLabel       | stepLabel   | idJourney | sendingApplicationCode |
      | a8fd3e39-b2c7-4932-b758-e6f36d2020c7       | EC		  | 2017-05-02T18:25:34.985+02:00   | null	| Retail      | Credit Immobilier  | Solvabilite | 100000    |                 AP00851|
########################################################## 1 #
Scenario: close a collect successfully

Given  an existing collect in progress that can be closed 
#|--------------------------------------------------------------FAMILY----------------------------------|---------------------------TYPE----------------------------------------------------------|
 | familyOwners      | familyLabel             | familyCategory	| familyPropertyType | familyIconCode   | label             | digitalAllowed |  controlRequired |pendingDocument |
 |01740005814400000  | justificatif de revenus | OB		   		| Fixe         		 | PICTO_REVENUS    | Avis d imposition | true           |  0	            | 	 false	    |

And a Piece
#|-------------------------PIECE---------------------------|
 |label    |ownerId          |receivedFormat|status|channel|
 |page1.pdf|01740005814400000|  NUM         |  VA  |   004 |
When I close the collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">
Then the collect is closed


########################################################## 2 #
#Scenario: closing a non existing collect
#
#Given a non existant collect 
##|--------------------------------------------------------------FAMILY----------------------------------|---------------------------TYPE----------------------------------------------------------|
# | familyOwners      | familyLabel             | familyCategory	| familyPropertyType | familyIconCode   | label             | digitalAllowed |  controlRequired |pendingDocument |
# | 01740005814400000 | justificatif de revenus | OB		   		| Fixe        		 | PICTO_REVENUS    | Avis d imposition | true           |  0	            | 	 false		|
#When I close the collect <"99999999-b2c7-4932-b758-e6f36d2020c7">
#Then I receive the error code : <"ERR-FUNC-UPD-00030">
#

########################################################## 3 #
Scenario: close a collect with pending document 

Given a collect containing a type with pending document activated for a mandatory familiy (OB)
#|--------------------------------------------------------------FAMILY----------------------------------|---------------------------TYPE------------------------------------------------------------------|
 | familyOwners      | familyLabel             | familyCategory	| familyPropertyType | familyIconCode   | label             | digitalAllowed |  controlRequired |pendingDocument |
 | 01740005814400000 | justificatif de revenus | OB		   		| Fixe       	     | PICTO_REVENUS    | Avis d imposition | true           |  0	            | 	 true		|
And a Piece
#|-------------------------PIECE---------------------------|
 |label    |ownerId          |receivedFormat|status|channel|
 |page1.pdf|01740005814400000|  NUM         |  VA  |   004 |
When I close the collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">
Then I receive the error code : <"ERR-FUNC-UPD-00019">


########################################################## 4 #

Scenario: close a collect with a non validated piece for a mandatory familiy - OB 

Given containing a non validated piece for a mandatory familiy (OB)
#|--------------------------------------------------------------FAMILY----------------------------------|---------------------------TYPE----------------------------------------------------------|
 | familyOwners      | familyLabel             | familyCategory | familyPropertyType | familyIconCode   | label             | digitalAllowed |  controlRequired |pendingDocument |
 | 01740005814400000 | justificatif de revenus | OB		   		| Fixe        		 | PICTO_REVENUS    | Avis d imposition | true           |  0	            | 	 false		|
And containing a Deposed piece not valid
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel |
|a3af3040-6945-46be-940f-f34122999999	| page1.pdf	| 01740005814400000	| NUM				|	DP			| 004	  | 
When I close the collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">
Then I receive the error code : <"ERR-FUNC-UPD-00019">


########################################################## 5 #

Scenario: close a collect with a mandatory familiy - OB - that does not contain a piece

Given a collect with a mandatory familiy (OB) without piece
#|--------------------------------------------------------------FAMILY----------------------------------|---------------------------TYPE----------------------------------------------------------|
 | familyOwners      | familyLabel             | familyCategory | familyPropertyType | familyIconCode   | label             | digitalAllowed |  controlRequired |pendingDocument |
 | 01740005814400000 | justificatif de revenus | OB		   		| Fixe        		 | PICTO_REVENUS    | Avis d imposition | true           |  0	            | 	 false		|

When I close the collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">
Then I receive the error code : <"ERR-FUNC-UPD-00019">


########################################################## 6 #
Scenario: close a collect with a familiy already provided -DF- that does not contain a piece

Given a collect with a familiy already provided (DF) without piece

#|--------------------------------------------------------------FAMILY----------------------------------|---------------------------TYPE----------------------------------------------------------|
 | familyOwners      | familyLabel             | familyCategory | familyPropertyType | familyIconCode   | label             | digitalAllowed |  controlRequired |pendingDocument |
 | 01740005814400000 | justificatif de revenus | DF		   		| Fixe        		 | PICTO_REVENUS    | Avis d imposition | true           | 0	            | 	 false		|
When I close the collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">
Then I receive the message <"Des pages du document sont en attente de collecte">

########################################################## 6 #
Scenario: close a collect successfully with a facultative family

Given  an existing collect with a facultative family with invalidate pieces
#|--------------------------------------------------------------FAMILY----------------------------------|---------------------------TYPE----------------------------------------------------------|
 | familyOwners      | familyLabel             | familyCategory	| familyPropertyType | familyIconCode   | label             | digitalAllowed |  controlRequired |pendingDocument |
 |01740005814400000  | justificatif de revenus | FA		   		| Fixe         		 | PICTO_REVENUS    | Avis d imposition | true           |  0	            | 	 false	    |

And a Piece
#|-------------------------PIECE---------------------------|
 |label    |ownerId          |receivedFormat|status|channel|
 |page1.pdf|01740005814400000|  NUM         |  DP  |   004 |
When I close the collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">
Then the collect is closed