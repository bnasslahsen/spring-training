Feature: UPL001019

Background:
Given Existing collects
 | id                                     | entityLabel        | productLabel  	   | stepLabel   | journeyCode | piecesManagementAct 		            | familiesManagementAct           | sendingApplicationCode  |
 |  a6b15173-a48f-4861-b67a-7283e30f3d4c  | Retail             | Credit Immobilier | Solvabilite | 100000      | DP,RC	             	              | OB,DF,DR			                  |   AP00851				        |

## collect 1
And Existing familiesManagmentActs in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND | DR |
And Existing owners in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
|reference          	| name     | firstname | nature|
| 01740005814400000  	| Durand   | Jean      | 01    |
And An existing list of types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | familyId                             | familyCategory | edocType          |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 56b15173-a48f-4861-b67a-7283e30f3d4c | OB             | 00000000000000001 |


## CP
########################################################## 1 #
Scenario: add a owner valid case
Given a collect
 | id                                     | entityLabel        | productLabel  	   | stepLabel   | journeyCode | piecesManagementAct 		            | familiesManagementAct           | sendingApplicationCode  |
 |  a6b15173-a48f-4861-b67a-7283e30f3d4c  | Retail             | Credit Immobilier | Solvabilite | 100000      | DP,RC	             	              | OB,DF,DR			                  |   AP00851				        |
And Existing familiesManagmentActs in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND | DR |
And list of families in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | OB        |
And list of types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">, family <"56b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | edocType          |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 00000000000000001 | 
And with owners in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> to save
|reference          	| name   | firstname | nature|
| 01740005814400000  	| Durand | Jean      | 01    |
| 01740005814157951   | Durand | Jeanine   | 01    |
When I update the collect  
Then there is no exception
And in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> owners has 2 element(s)
And the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> has one owner with reference <"01740005814400000">, name <"Durand">, firstname <"Jean"> and nature <"01">
And the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> has one owner with reference <"01740005814157951">, name <"Durand">, firstname <"Jeanine"> and nature <"01">

## CNP RG7
########################################################## 2 #
Scenario: add a owner with no name
Given a collect
 | id                                     | entityLabel        | productLabel  	   | stepLabel   | journeyCode | piecesManagementAct 		            | familiesManagementAct           | sendingApplicationCode  |
 |  a6b15173-a48f-4861-b67a-7283e30f3d4c  | Retail             | Credit Immobilier | Solvabilite | 100000      | DP,RC	             	              | OB,DF,DR			                  |   AP00851				        |
And Existing familiesManagmentActs in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND | DR |
And list of families in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | OB       |
And list of types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">, family <"56b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | edocType          |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 00000000000000001 | 
And with owners in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> to save
|reference          	| name   | firstname | nature|
| 01740005814400000  	| Durand | Jean      | 01    |
| 01740005814157951   |        | Jeanine   | 01    |
When I update the collect  
Then there is no exception
Then the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> has one owner with reference <"01740005814400000">, name <"Durand">, firstname <"Jean"> and nature <"01">
And the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> does not have owner with reference <"01740005814157951">
And in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> owners has 1 element(s)

#CNP RG7
########################################################## 3 #
Scenario: add a owner with invalid reference
Given a collect
 | id                                     | entityLabel        | productLabel  	   | stepLabel   | journeyCode | piecesManagementAct 		            | familiesManagementAct           | sendingApplicationCode  |
 |  a6b15173-a48f-4861-b67a-7283e30f3d4c  | Retail             | Credit Immobilier | Solvabilite | 100000      | DP,RC	             	              | OB,DF,DR			                  |   AP00851				        |
And Existing familiesManagmentActs in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND | DR |
And list of families in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | OB        |
And list of types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">, family <"56b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | edocType          |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 00000000000000001 | 
And with owners in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> to save
|reference          	| name   | firstname | nature|
| 01740005814400000  	| Durand | Jean      | 01    |
| 01740005814157      | Durand | Jeanine   | 01    |
When I update the collect  
Then there is no exception
Then the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> has one owner with reference <"01740005814400000">, name <"Durand">, firstname <"Jean"> and nature <"01">
And in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> owners has 1 element(s)
And the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> does not have owner with reference <"01740005814157">



#RG198 
########################################################## 4 #
Scenario: change a existing owner
Given a collect
 | id                                     | entityLabel        | productLabel  	   | stepLabel   | journeyCode | piecesManagementAct 		            | familiesManagementAct           | sendingApplicationCode  |
 |  a6b15173-a48f-4861-b67a-7283e30f3d4c  | Retail             | Credit Immobilier | Solvabilite | 100000      | DP,RC	             	              | OB,DF,DR			                  |   AP00851				        |
And Existing familiesManagmentActs in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND | DR |
And list of families in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | OB        |
And list of types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">, family <"56b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | edocType          |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 00000000000000001 | 
And with owners in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> to save
|reference          	| name   | firstname | nature|
| 01740005814400000  	| Durand | Mickaël   | 01    |
When I update the collect  
Then there is no exception
And in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> owners has 1 element(s)
And the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> has one owner with reference <"01740005814400000">, name <"Durand">, firstname <"Jean"> and nature <"01">


#RG197
########################################################## 5 #
Scenario: delete all owners
Given a collect
 | id                                     | entityLabel        | productLabel  	   | stepLabel   | journeyCode | piecesManagementAct 		            | familiesManagementAct           | sendingApplicationCode  |
 |  a6b15173-a48f-4861-b67a-7283e30f3d4c  | Retail             | Credit Immobilier | Solvabilite | 100000      | DP,RC	             	              | OB,DF,DR			                  |   AP00851				        |
And Existing familiesManagmentActs in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND | DR |
And list of families in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | OB        |
And list of types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">, family <"56b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | edocType          |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 00000000000000001 | 
And void owners in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
When I update the collect  
Then there is no exception
And in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> owners has 1 element(s)
And the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> has one owner with reference <"01740005814400000">, name <"Durand">, firstname <"Jean"> and nature <"01">



# RG199
########################################################## 6 #
Scenario: modify productLabel, entityLabel, familiesManagementAct, familyCategory
Given a collect
 | id                                     | entityLabel        | productLabel  	   | stepLabel   | journeyCode | piecesManagementAct 		            | familiesManagementAct           | sendingApplicationCode  |
 |  a6b15173-a48f-4861-b67a-7283e30f3d4c  | test               | test              | Solvabilite | 100000      | DP,RC	             	              | OB,DF,DR,test			              |   AP00851				        |
And Existing familiesManagmentActs in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND | DR |
And list of families in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | test     |
And list of types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">, family <"56b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | edocType          |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 00000000000000001 | 
And with owners in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> to save
|reference          	| name   | firstname | nature|
| 01740005814400000  	| Durand | Jean      | 01    |
When I update the collect  
Then there is no exception
And collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">, type <"16b15173-a48f-4861-b67a-7283e30f3d4c">  productLabel, entityLabel, familiesManagementAct, familyCategory were not changed
And in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> owners has 1 element(s)
And the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> has one owner with reference <"01740005814400000">, name <"Durand">, firstname <"Jean"> and nature <"01">


