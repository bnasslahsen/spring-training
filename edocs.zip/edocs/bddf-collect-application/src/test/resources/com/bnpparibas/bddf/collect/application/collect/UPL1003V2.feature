Feature: UPL1003V2

# V0.0 : Initialisation

########################################################## 2 #
Scenario: Save a collect with an unknown familyManagmentAct - collect level
Given a collect with an unknown familyManagmentAct
#    | entityLabel | productLabel  		| stepLabel   | journeyCode | piecesManagementAct 		| familiesManagementAct           | sendingApplicationCode	|
 	 | Retail      | Credit Immobilier  | Solvabilite | 100000      | DP,RC	             	    | OB,ND,XX			              |   AP00851				|

When I save the collect
Then I recive the error code : <"ERR-FUNC-UPD-00003">

########################################################## 3 #
Scenario: Save a collect with an unknown familyManagmentAct - family level
Given a valid collect
#    | entityLabel | productLabel  		| stepLabel   | journeyCode | piecesManagementAct 	| familiesManagementAct	| sendingApplicationCode	|
 	 | Retail      | Credit Immobilier  | Solvabilite | 100000      | DP,RC	             	| OB,ND                 |   AP00851				|
And containing a family with an unkown category
#|--------------------------------------------------------------FAMILY----------------------------|---------------------------TYPE-----------------------------------------|
 | familyOwners            | familyLabel             | familyCategory    	| familiesManagementActFamily | familyPropertyType | familyIconCode         | label             | digitalAllowed  | controlRequired |
 | 01740005814400000       | justificatif de revenus | ND		   		    | OB,XX   		              | Fixe               | PICTO_REVENUS          | Avis d imposition | true            | 0	            |
When I save the collect
Then I recive the error code : <"ERR-FUNC-UPD-00017">

########################################################## 4 #
Scenario: Save a collect without categoryComment on a derogated family
Given a valid collect
#    | entityLabel | productLabel  		| stepLabel   | journeyCode | piecesManagementAct 		| familiesManagementAct           | sendingApplicationCode	|
 	 | Retail      | Credit Immobilier  | Solvabilite | 100000      | DP,RC	             	    | OB,ND,DR			              |   AP00851				|
And containing a derogated family without a categoryComment
#|--------------------------------------------------------------FAMILY----------------------------|---------------------------TYPE-----------------------------------------|
 | familyOwners            | familyLabel             | familyCategory    	| familyPropertyType | familyIconCode         | label             | digitalAllowed | controlRequired |
 | 01740005814400000 | justificatif de revenus | DR		   		| Fixe         | PICTO_REVENUS    | Avis d imposition | true                                   | 0	           |
When I save the collect
Then I recive the error code : <"ERR-FUNC-UPD-00023">

########################################################## 5 #
Scenario: Save a collect with an unknown collectManagmentAct - collect level
Given a collect with an unknown collectManagmentAct
#    | entityLabel | productLabel  		| stepLabel   | journeyCode | piecesManagementAct 		| familiesManagementAct      | sendingApplicationCode	| collectManagementAct     |
 	 | Retail      | Credit Immobilier  | Solvabilite | 100000      | DP,RC	             	    | OB,ND,XX			         |   AP00851				| AB,CL,XX                 |

When I save the collect
Then I recive the error code : <"ERR-FUNC-UPD-00003">



########################################################## 6 #
Scenario: Save a collect with an unalowed controlIterationAllowed number
Given a validate collect
#    | entityLabel | productLabel  		| stepLabel   | journeyCode | piecesManagementAct 		| familiesManagementAct           | sendingApplicationCode	|controlIterationAllowed |
 	 | Retail      | Credit Immobilier  | Solvabilite | 100000      | DP,RC	             	    | OB,ND,DR			              |   AP00851				|10                      |
 	 
When I save the collect
Then I recive the error code : <"ERR-FUNC-UPD-00110"> 