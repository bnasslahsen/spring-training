Feature: UPL3010SM01

# V0.1 : création des scénarios

########################################################## 1 #
Scenario: delete an existing temporary piece
Given an existing temporary piece
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel | state |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				|	TP			| 007	  |	ACTIF |		
When I delete the piece <"a3af3040-6945-46be-940f-f3412233199b"> with channel <"001">
Then the piece is deleted

########################################################## 2 #
Scenario: delete  a nonexistent piece 
Given an existing temporary piece
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel | state |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				|	TP			| 007	  | ACTIF |	
When I delete the piece <"aaaaaaaa-6945-46be-940f-f3412233199b"> with channel <"001">
Then I get an error : <"ERR-FUNC-UPD-00028">

########################################################## 3 #
Scenario: delete an existing piece uploaded by client 
Given an existing temporary piece
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel | state |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				|	TP			| 007	  | ACTIF |	
When I delete the piece <"a3af3040-6945-46be-940f-f3412233199b"> with channel <"001">
Then the piece is deleted
