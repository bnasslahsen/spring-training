Feature: UPL1013

Background:
Given Existing collects
| id                                   | entityLabel |
| a6b15173-a48f-4861-b67a-7283e30f3d4c | Retail      |
| b6b15173-a48f-4861-b67a-7283e30f3d4c | Autre       |
| c6b15173-a48f-4861-b67a-7283e30f3d4c | Autre       |

## collect 1
And Existing familiesManagmentActs in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND | DR |
And An existing list of types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | familyId                             | familyCategory |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 56b15173-a48f-4861-b67a-7283e30f3d4c | OB             |
And Existing pieces in type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> and collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   |
| 26b15173-a48f-4861-b67a-7283e30f3d4c |

## collect 2
And Existing familiesManagmentActs in collect <"b6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | DR |
And An existing list of types in collect <"b6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | familyId                             | familyCategory |
| 18b15173-a48f-4861-b67a-7283e30f3d4c | 98b15173-a48f-4861-b67a-7283e30f3d4c | OB             |


## collect 3 without familiesManagmentActs
And An existing list of types in collect <"c6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | familyId                             | familyCategory |
| 19b15173-a48f-4861-b67a-7283e30f3d4c | 88b15173-a48f-4861-b67a-7283e30f3d4c | OB             |
And Existing familiesManagmentActs in family <"88b15173-a48f-4861-b67a-7283e30f3d4c"> and collect <"c6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND |

################################################################

Scenario: Update a family containing pieces from OB to ND
Given Families to save
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | ND       |
When I update the families of collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then There is no exception
And The family <"56b15173-a48f-4861-b67a-7283e30f3d4c"> status of collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> is updated to <"ND">
And Types of in family <"56b15173-a48f-4861-b67a-7283e30f3d4c"> in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> does not contain piece
## RG 69

################################################################

Scenario: Update a family containing pieces from OB to DR
Given Families to save
| id                                   | category | categoryComment |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | DR       | dérogé          |
When I update the families of collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then There is no exception
And The family <"56b15173-a48f-4861-b67a-7283e30f3d4c"> status of collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> is updated to <"DR">
And Types of in family <"56b15173-a48f-4861-b67a-7283e30f3d4c"> in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> does not contain piece
## RG 69

################################################################

Scenario: Update a family with unauthorized status
Given Families to save
| id                                   | category |
| 98b15173-a48f-4861-b67a-7283e30f3d4c | ND       |
When I update the families of collect <"b6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I Expect error code <"ERR-FUNC-UPD-00024">

## RG 70
Scenario: Update a family containing pieces from OB to DR without comment
Given Families to save
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | DR       |
When I update the families of collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I Expect error code <"ERR-FUNC-UPD-00023">
## RG 48

################################################################

Scenario: Update an unkown family
Given Families to save
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | ND       |
| 77715173-a48f-4861-b67a-7283e30f3d4c | ND       |
When I update the families of collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I Expect error code <"ERR-FUNC-UPD-00036">

Scenario: Update families with mising families
Given Families to save
| id                                   | category |
When I update the families of collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I Expect error code <"ERR-FUNC-UPD-00052">

## RG 115

################################################################

Scenario: Update families with familiesActManagement in family
Given Families to save
| id                                   | category |
| 88b15173-a48f-4861-b67a-7283e30f3d4c | ND       |
And Families to save with familiesManagmentActs
| OB | ND | 
When I update the families of collect <"c6b15173-a48f-4861-b67a-7283e30f3d4c">
Then There is no exception
And The family <"88b15173-a48f-4861-b67a-7283e30f3d4c"> status of collect <"c6b15173-a48f-4861-b67a-7283e30f3d4c"> is updated to <"ND">


