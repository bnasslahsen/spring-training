Feature: UPL3019SM01

# V0.1 : création des scénarios
Background:
Given a type
| id                                	| label             |pendingDocument | pendingDocumentLabel |digitalAllowed|maxSizeDoc| paperAllowed |
|0b6a45c7-4eee-421b-b96d-9f391cddf711	| Avis d imposition |     false      |						| true		   |10000	  | true |

And on a collect
	 | id                                  		  | status 		  | entityLabel | productLabel       | stepLabel   | journeyCode | sendingApplicationCode |
     | a8fd3e39-b2c7-4932-b758-e6f36d2020c7       | EC			  | Retail      | Credit Immobilier  | Solvabilite | 000256   	 |       AP00851          |

########################################################## 1 #
Scenario: upload of a piece in paper format without existing digital document for the type
Given a type with no existing digital piece
When I report the piece
	| label   	| ownerId        	| receivedFormat    | status		| channel |
	| page1.pdf	| 01740005814400000	| PAP				|	VA   		| 001	  |
Then the piece is saved

########################################################## 2 #
Scenario: upload of a piece in paper format with an existing temporary digital document for the type
Given a type with an existing digital temporary piece
	| label   	| ownerId        	| receivedFormat    | status		| channel |
	| page1.pdf	| 01740005814400000	| NUM				|	TP			| 001	  |
When I report on collect<"a8fd3e39-b2c7-4932-b758-e6f36d2020c7"> and type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> the piece
	| label   	| receivedFormat    | status		| channel |
	| page1.pdf	| PAP				|	RC			| 001	  |
Then the piece is saved

########################################################## 3 #
Scenario: upload of a piece in paper format with an existing digital document validated for the type
Given a type with an existing digital validated piece
          
	| label   	| ownerId        	| receivedFormat    | status		| channel |
	| page1.pdf	| 01740005814400000	| NUM				|	VA			| 001	  |

When I report on collect<"a8fd3e39-b2c7-4932-b758-e6f36d2020c7"> and type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> the piece
	| label   	| receivedFormat    | status		| channel |
	| page1.pdf	| PAP				|	VA			| 001	  |
Then the piece is saved
########################################################## 4 #
Scenario: upload of a piece in paper format with status refused and rejected reason empty- RG47
When I report on collect<"a8fd3e39-b2c7-4932-b758-e6f36d2020c7"> and type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> the piece
	| label   	| receivedFormat    | status		| channel |rejectionReason|rejectionComment|
	| page1.pdf	| PAP				|	RF			| 001	  |			 	  |                |
	
Then I receive the error : <"ERR-FUNC-UPD-00016">

########################################################## 5 #
Scenario: upload of a piece in paper format with status refused whith arejected reason=Autre and rejected comment empty- RG49
Given a type with no existing piece      

When I report on collect<"a8fd3e39-b2c7-4932-b758-e6f36d2020c7"> and type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> the piece
	| label   	| receivedFormat    | status		| channel |rejectionReason|rejectionComment|
	| page1.pdf	| PAP				|	RF			| 001	  |	Autre   	  |                |

Then I receive the error : <"ERR-FUNC-UPD-00027">


########################################################## 6 #
Scenario: upload of a piece in paper format with status deposed - RG54
Given a type with no existing piece
          
When I report on collect<"a8fd3e39-b2c7-4932-b758-e6f36d2020c7"> and type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> the piece
	| label   	| receivedFormat    | status		| channel |
	| page1.pdf	| PAP				|	DP			| 001	  |

Then I receive the error : <"ERR-FUNC-UPD-00032">

########################################################## 7 #
Scenario: upload of a piece in paper format with an non existing collect - RG76
Given a type with no existing piece

When I report on collect<"a3af3040-6945-46be-940f-f3419999999b"> and type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> the piece
	| label   	| receivedFormat    | status		| channel |
	| page1.pdf	| PAP				|	VA			| 001	  |
	
Then I receive the error : <"ERR-FUNC-UPD-00030">
########################################################## 8 #
Scenario: upload of a piece in paper format with an non existing type - RG80
Given a type with no existing piece

When I report on collect<"a8fd3e39-b2c7-4932-b758-e6f36d2020c7"> and type<"a3af3040-6945-46be-940f-f3419999999b"> the piece
	| label   	| receivedFormat    | status		| channel |
	| page1.pdf	| PAP				|	VA			| 001	  |
	
Then I receive the error : <"ERR-FUNC-UPD-00035">
########################################################## 9 #

Scenario: upload of two pieces in paper format for the type - RG82
Given a type with an existing piece in paper format         
	| label   	| ownerId        	| receivedFormat    | status		| channel | state |
	| page1.pdf	| 01740005814400000	| PAP				|	VA			| 001	  | ACTIF |

When I report on collect<"a8fd3e39-b2c7-4932-b758-e6f36d2020c7"> and type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> the piece
	| label   	| receivedFormat    | status		| channel |
	| page1.pdf	| PAP				|	VA			| 001	  |
Then I receive the error : <"ERR-FUNC-UPD-00037">

########################################################## 10 #

Scenario: Discount of a pieces in paper format for the type - RG83
Given a type with subtypes
          
| id                                	| label             	|pendingDocument | pendingDocumentLabel | parentId							 |
|3d951d74-8948-41d5-82c4-e9d3e29578cf	| Avis d imposition A1  |     false      |						|0b6a45c7-4eee-421b-b96d-9f391cddf711|
|1a8a89ad-62de-420a-b5df-f8432dcca2d1	| Avis d imposition A2  |     false      |						|0b6a45c7-4eee-421b-b96d-9f391cddf711|
	
When I report on collect<"a8fd3e39-b2c7-4932-b758-e6f36d2020c7"> and type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> the piece
	| label   	| receivedFormat    | status		| channel |
	| page1.pdf	| PAP				|	VA			| 001	  |
Then I receive the error : <"ERR-FUNC-UPD-00038">

########################################################## 11 #
Scenario: upload of a piece in paper format with client channel - RG86
Given a type with no existing piece
When I report on collect<"a8fd3e39-b2c7-4932-b758-e6f36d2020c7"> and type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> the piece
	| label   	| receivedFormat    | status		| channel |
	| page1.pdf	| PAP				|	VA			| 007	  |
Then I receive the error : <"ERR-FUNC-UPD-00040">

########################################################## 12 #
Scenario: upload of a piece in digital format with an existing paper document validated for the type - RG87 - RG87
Given a type with an existing piece in paper format         
	| label   	| ownerId        	| receivedFormat    | status		| channel | state |
	| page1.pdf	| 123456			| PAP				|	VA			| 001	  | ACTIF |

When I save on collect<"a8fd3e39-b2c7-4932-b758-e6f36d2020c7"> and type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> the digital piece
	| label   	| ownerId        	| receivedFormat    | channel |
	| page1.pdf	| 01740005814400000	| NUM				| 007	  |
Then I receive the error : <"ERR-FUNC-UPD-00041">
########################################################## 13 #
Scenario: upload of a piece in digital format with an existing paper document refused for the type - RG87
Given a type with an existing piece in paper format         
	| label   	| ownerId        	| receivedFormat    | status		| rejectionReason	| channel |
	| page1.pdf	| 123456			| PAP				|	RF			|	qualité doc		| 001	  |

When I save on collect<"a8fd3e39-b2c7-4932-b758-e6f36d2020c7"> and type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> the digital piece
	| label   	| ownerId        	| receivedFormat    | channel |
	| page1.pdf	| 01740005814400000	| NUM				| 007	  |
Then the piece is saved