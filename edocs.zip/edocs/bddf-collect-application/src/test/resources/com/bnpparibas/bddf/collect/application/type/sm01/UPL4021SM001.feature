Feature: UPL4021SM001

Background:

Given An existing collect
| entityLabel | productLabel      | id                                   | controlIterationAllowed |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 |           3             |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label     | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType | statusControl | completenessControl | 
| Quittance | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 3               | OB             | 00000000000000001 | Liste              | KO            | OK                  | 
| Quittance | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 3               | OB             | 00000000000000001 | Liste              | ERR           | KO                  | 
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| code               | category |
| 10000000000000001  | OB       |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
| code               | category |
| 10000000000000001  | OB       |


# Cas d’un type accepté automatiquement suite à updateType avec itération max réalisée et retour contrôle auto KO
Scenario: update type auto-accepting it while statusControl of type is KO and max iteration is achieved

Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | receivedFormat | status       | controlIterationAchieved |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  |     NUM        | DP           |           2              |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  |     NUM        | DP           |           2              |
And New indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| code               | category |  correctedValue | label  | minSize | maxSize |
| 10000000000000001  | OB       | Nom             | Nom    |   1     |   100   |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea"> of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| identity_card_verso |
And autoAcceptationAllowed is <"true">

When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">

Then I expect pieces status <"RC"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
And  I expect status <"RC_AUTO"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">



# Cas d’un type accepté automatiquement suite à updatePiece avec itération max réalisée et retour contrôle auto KO ( TODO)
#Scenario: update pieces auto-accepting it while statusControl of type is KO and max iteration is achieved
#Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
#| id                                   | ownerId            | receivedFormat | status       | controlIterationAchieved |
#| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  |     NUM        | DP           | 9                        |
#| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  |     NUM        | DP           | 9                        |
#And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea"> of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
#| identity_card_recto |
#And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb"> of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
#| identity_card_verso |
#And autoAcceptationAllowed is <"true">
#
#When I update pieces of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
#
#Then I expect pieces status <"RC"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
#And  I expect status <"RC_AUTO"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">



# Cas d’un type accepté automatiquement suite à updateType avec itération max réalisée et retour contrôle auto ERR
Scenario: update type auto-accepting it while statusControl of type is KO and max iteration is achieved

Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
| id                                   | ownerId            | receivedFormat | status       | controlIterationAchieved |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  |     NUM        | DP           | 2                        |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  |     NUM        | DP           | 2                        |
And New indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
| code               | category |  correctedValue | label  | minSize | maxSize |
| 10000000000000001  | OB       | Nom             | Nom    |   1     |   100   |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea"> of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
| identity_card_verso |
And autoAcceptationAllowed is <"true">

When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">

Then I expect pieces status <"RC"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
And  I expect status <"RC_AUTO"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">



# Cas d’un type accepté automatiquement suite à updatePiece avec itération max réalisée et retour contrôle auto ERR ( TODO)
#Scenario: update pieces auto-accepting it while statusControl of type is KO and max iteration is achieved
#Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
#| id                                   | ownerId            | receivedFormat | status       | controlIterationAchieved |
#| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  |     NUM        | DP           | 9                        |
#| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  |     NUM        | DP           | 9                        |
#And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea"> of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
#| identity_card_recto |
#And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb"> of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
#| identity_card_verso |
#And autoAcceptationAllowed is <"true">
#
#When I update pieces of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
#
#Then I expect pieces status <"RC"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
#And  I expect status <"RC_AUTO"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">



# Cas d’un type non accepté automatiquement suite à updatType avec itération max réalisée et retour contrôle auto KO et autoAcceptationAllowed=false
Scenario: update type while AutoAcceptationAllowed is false, not auto-accepting it

Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | receivedFormat | status       | controlIterationAchieved |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  |     NUM        | DP           | 2                        |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  |     NUM        | DP           | 2                        |
And New indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| code               | category |  correctedValue | label  | minSize | maxSize |
| 10000000000000001  | OB       | Nom             | Nom    |   1     |   100   |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea"> of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| identity_card_recto |
And autoAcceptationAllowed is <"false">

When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">

Then I expect pieces status <"DP"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
And  I expect status <"IN"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">



# Cas d’un type non accepté automatiquement suite à updatPiece avec itération max réalisée et retour contrôle auto KO et autoAcceptationAllowed=false
Scenario: update pieces while AutoAcceptationAllowed is false, not auto-accepting it
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
| id                                   | ownerId            | receivedFormat | status       | controlIterationAchieved |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  |     NUM        | DP           | 9                        |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  |     NUM        | DP           | 9                        |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea"> of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb"> of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
| identity_card_verso |
And autoAcceptationAllowed is <"false">

When I update pieces of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">

Then I expect pieces status <"DP"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
And  I expect status <"IN"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">



## Cas de création d'une collecte avec autoAcceptationAllowed non renseigné
Scenario: Save a collect initializing autoAcceptationAllowed to false
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category | propertyType |
| Justificatif de domicile | OB       | Fixe         |
And New Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status | controlRequired | digitalAllowed |       edocType       |
| CIN       | false           | IN     |       3         |     true       |   00000000000000001  |
And New indexes in type
| code               | category |  referenceValue | label  | minSize | maxSize |
| 10000000000000001  | OB       | Nom             | Nom    |   1     |   100   |
| 10000000000000002  | OB       | Prenom          | Prénom |   1     |   100   |

When I save the collect

Then I expect autoAcceptationAllowed to be equal to <"false">

