Feature: UPL2029SM002

Background:
## repository
Given An existing collect
| entityLabel | productLabel      | id                                   |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label     | pendingDocument | status | id                                   | familyId                             | familyLabel              | familyCategory | edocType          | familyPropertyType |
| Quittance | false           | VA     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | Justificatif de domicile | OB             | 00000000000000001 | Liste              |
| Quittance | false           |        | 8f8ee7cf-6f59-4338-8353-5735fd8933e6 | 8f8ee7cf-6f59-4338-8353-5735fd893323 | Justificatif de domicile | OB             | 00000000000000001 | Liste              |
| Quittance | false           | VA     | 8f8ee7cf-6f59-4338-8353-5735fd8933e4 | 8f8ee7cf-6f59-4338-8353-5735fd893324 | Justificatif de domicile | ND             | 00000000000000001 | Liste              |
| Quittance | false           |        | 8f8ee7cf-6f59-4338-8353-5735fd8933e3 | 8f8ee7cf-6f59-4338-8353-5735fd893325 | Justificatif de domicile | OB             | 00000000000000001 | Liste              |
| Quittance | false           |        | 8f8ee7cf-6f59-4338-8353-5735fd8933f3 | 8f8ee7cf-6f59-4338-8353-5735fd893325 | Justificatif de domicile | OB             | 00000000000000001 | Liste              |
| Quittance | false           |        | 8f8ee7cf-6f59-4338-8353-5735fd8933e2 | 8f8ee7cf-6f59-4338-8353-5735fd893325 | Justificatif de domicile | OB             | 00000000000000007 | Liste              |
| Quittance | false           |        | 8f8ee7cf-6f59-4338-8353-5735fd8933e1 | 8f8ee7cf-6f59-4338-8353-5735fd893327 | Justificatif de domicile | OB             | 00000000000000001 | Liste              |
| Quittance | false           |        | 8f8ee7cf-6f59-4338-8353-5735fd8933f1 | 8f8ee7cf-6f59-4338-8353-5735fd893327 | Justificatif de domicile | OB             | 00000000000000001 | Liste              |
| Quittance | false           |        | 8f8ee7cf-6f59-4338-8353-5735fd8933e0 | 8f8ee7cf-6f59-4338-8353-5735fd893321 | Justificatif de domicile | OB             | 00000000000000007 | Liste              |
| Quittance | false           |        | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 8f8ee7cf-6f59-4338-8353-5735fd893321 | Justificatif de domicile | OB             | 00000000000000001 | Liste              |
| Quittance | false           |        | 1f8ee7cf-6f59-4338-8353-5735fd8933ea | 8f8ee7cf-6f59-4338-8353-5735fd89332b | Justificatif de domicile | OB             | 00000000000000001 | Liste              |
| Quittance | false           |        | 2f8ee7cf-6f59-4338-8353-5735fd8933ea | 8f8ee7cf-6f59-4338-8353-5735fd89332b | Justificatif de domicile | OB             | 00000000000000001 | Liste              |
| Quittance | false           |        | 3f8ee7cf-6f59-4338-8353-5735fd8933ea | 8f8ee7cf-6f59-4338-8353-5735fd89332b | Justificatif de domicile | OB             | 00000000000000001 | Liste              |
| Quittance | false           |        | 4f8ee7cf-6f59-4338-8353-5735fd8933ea | 8f8ee7cf-6f59-4338-8353-5735fd89332b | Justificatif de domicile | OB             | 00000000000000001 | Fixe               |
| Quittance | false           | RC     | 5f8ee7cf-6f59-4338-8353-5735fd8933ea | 8f8ee7cf-6f59-4338-8353-5735fd89332b | Justificatif de domicile | OB             | 00000000000000001 | Fixe               |
And An existing sub-types
| label     | pendingDocument | status | id                                   | familyId                             | familyLabel              | familyCategory | edocType          | parentId                             |
| Quittance | false           |        | 8f8ee7cf-6f59-4338-8353-5735fd8933e5 | 8f8ee7cf-6f59-4338-8353-5735fd893323 | Justificatif de domicile | OB             | 00000000000000001 | 8f8ee7cf-6f59-4338-8353-5735fd8933e6 |
And existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ec | 01740005814157951  | VA           |
And existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e5">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8934ea | 01740005814157951  | DF           |
| 8f8ee7cf-6f59-4338-8353-5735fd8934eb | 01740005814157951  | DF           |
| 8f8ee7cf-6f59-4338-8353-5735fd8934ec | 01740005814157951  | DF           |
And existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e3">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935eb | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | DP           |
And existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933f3">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ea | 01740005814157951  | DF           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935eb | 01740005814157951  | DF           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | DF           |
And existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e2">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935eb | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | DP           |
And existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e1">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935eb | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | DP           |
And existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933f1">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ea | 01740005814157951  | DF           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935eb | 01740005814157951  | DF           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | DF           |
And existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e0">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ea | 01740005814157951  | DF           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935eb | 01740005814157951  | DF           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | DF           |
And existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ea | 01740005814157951  | DF           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935eb | 01740005814157951  | DF           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | DF           |
And existing pieces in type <"1f8ee7cf-6f59-4338-8353-5735fd8933ea">
| id                                   | ownerId            | status       | referenceGdnId | referencePieceId                     |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | DF           | GD4554665564   | 1f8ee7cf-6f59-4338-8353-5735fd8933e5 |
And existing pieces in type <"2f8ee7cf-6f59-4338-8353-5735fd8933ea">
| id                                   | ownerId            | status       | referenceGdnId | referencePieceId                     |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | DP           | GD444554564    | 1f8ee7cf-6f59-4338-8353-5735fd8933e5 |
And existing pieces in type <"3f8ee7cf-6f59-4338-8353-5735fd8933ea">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | DP           |
And existing pieces in type <"4f8ee7cf-6f59-4338-8353-5735fd8933ea">
| id                                   | ownerId            | status       | referenceGdnId  | referencePieceId                     |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ea | 01740005814157951  | DF           | GD444554564     | 1f8ee7cf-6f59-4338-8353-5735fd8933e5 |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | DP           |                 |                                      |
 
And A list of edoc-Type
| value             | jmcType       | gdnType  | reuseEligibility |
| 00000000000000001 | identity_card | 20090091 | true             |
| 00000000000000017 |               | 20090091 | true             |
| 00000000000000007 | payment       | 20090222 | false            |
And An existing document reference
| ownerId            | edocType          |
| 00000000000000099  | 00000000000000007 |

## RG98
Scenario: update a type with validated pieces and no pending document
Given A type to modify
| label     | pendingDocument | id                                   | status |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | VA     |
And pieces to add
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | IN           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ec | 01740005814157951  | VA           |
When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
Then I expect error code : <"ERR-FUNC-UPD-00051">

## RG98
Scenario: update a type with validated pieces and no pending document
Given A type to modify
| label     | pendingDocument | id                                   | status |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e1 | VA     |
And pieces to add
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ec | 01740005814157951  | VA           |
When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
Then there is no exception
And Type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> is updated with status <"VA">

## RG120
Scenario: update a type with collected/validated pieces and no pending document
Given A type to modify
| label     | pendingDocument | id                                   | status |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | RC     |
And pieces to add
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | RC           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ec | 01740005814157951  | VA           |
When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
Then I expect error code : <"ERR-FUNC-UPD-00051">

## RG120
Scenario: update a type with collected/validated pieces and no pending document
Given A type to modify
| label     | pendingDocument | id                                   | status |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e2 | RC     |
And pieces to add
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | RC           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ec | 01740005814157951  | VA           |
When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
Then there is no exception
And Type <"8f8ee7cf-6f59-4338-8353-5735fd8933e2"> is updated with status <"RC">

## RG100
Scenario: add a collect
Given A new collect
| entityLabel | productLabel      | id                                   |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933d1 |
And A new family
| id                                   | label                    | category |
| 8f8ee7cf-6f59-4338-8353-5735fd893356 | Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And new types to add
| label     | pendingDocument | id                                   | status |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd893111 |        |
| CIN       | false           | 8f8ee7cf-6f59-4338-8353-5735fd893222 | RC     |

When I add a collect <"8f8ee7cf-6f59-4338-8353-5735fd8933d1">
Then there is no exception
And The status of all types is initialized with <"IN">

## RG101
Scenario: add a piece for a validated type

Given new piece to add
| label    | receivedFormat       |
| CIN.jpeg | NUM                  |

When I add a new piece in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> 
Then I expect error code : <"ERR-FUNC-UPD-00049">

Scenario: update a validated type by modifying a piece
And A type to modify
| label     | pendingDocument | id                                   |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 |
And pieces in the type to modify
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | RF           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ec | 01740005814157951  | VA           |

When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
Then I expect error code : <"ERR-FUNC-UPD-00049">

Scenario: update a validated type
Given A type to modify
| label     | pendingDocument | id                                   |
| Quittance | true            | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 |

When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
Then I expect error code : <"ERR-FUNC-UPD-00049">

### RG102
Scenario: update all pieces status
Given A type to modify
| label     | pendingDocument | id                                   |
| Quittance | true            | 8f8ee7cf-6f59-4338-8353-5735fd8933e3 |
And GDN is <"false">
And pieces in the type to modify
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ea | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935eb | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | VA           |

When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e3">
Then there is no exception
And I expect validation event not to be sent

Scenario: update from DF
Given A type to modify
| label     | pendingDocument | id                                   | status |
| Quittance | false           | 1f8ee7cf-6f59-4338-8353-5735fd8933ea | VA     |
And pieces in the type to modify
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | VA           |
When I update a type <"1f8ee7cf-6f59-4338-8353-5735fd8933ea">
Then there is no exception
And Piece <"8f8ee7cf-6f59-4338-8353-5735fd8935ec"> is saved in gdn
And Type <"1f8ee7cf-6f59-4338-8353-5735fd8933ea"> is updated with status <"VA">

Scenario: update from DP with ref != null
Given A type to modify
| label     | pendingDocument | id                                   | status |
| Quittance | false           | 2f8ee7cf-6f59-4338-8353-5735fd8933ea | VA     |
And pieces in the type to modify
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | VA           |
When I update a type <"2f8ee7cf-6f59-4338-8353-5735fd8933ea">
Then there is no exception
And No piece is saved in gdn
And Type <"2f8ee7cf-6f59-4338-8353-5735fd8933ea"> is updated with status <"VA">

Scenario: update from DP with ref == null
Given A type to modify
| label     | pendingDocument | id                                   | status |
| Quittance | false           | 3f8ee7cf-6f59-4338-8353-5735fd8933ea | VA     |
And pieces in the type to modify
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | VA           |
When I update a type <"3f8ee7cf-6f59-4338-8353-5735fd8933ea">
Then there is no exception
And Piece <"8f8ee7cf-6f59-4338-8353-5735fd8935ec"> is saved in gdn
And Type <"3f8ee7cf-6f59-4338-8353-5735fd8933ea"> is updated with status <"VA">

Scenario: update from DP and DF deleting DF
Given A type to modify
| label     | pendingDocument | id                                   | status |
| Quittance | false           | 4f8ee7cf-6f59-4338-8353-5735fd8933ea | VA     |
And pieces in the type to modify
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | VA           |
When I update a type <"4f8ee7cf-6f59-4338-8353-5735fd8933ea">
Then there is no exception
And No piece is saved in gdn
And Type <"4f8ee7cf-6f59-4338-8353-5735fd8933ea"> is updated with status <"VA">
And I get 1 pieces added in reference table

## RG105
Scenario: update the category of a family 

Given Families to update
| id                                   | label                    | category |
| 8f8ee7cf-6f59-4338-8353-5735fd893324 | Justificatif de domicile | OB       |
| 8f8ee7cf-6f59-4338-8353-5735fd893322 | Justificatif de domicile | OB       |
| 8f8ee7cf-6f59-4338-8353-5735fd893323 | Justificatif de domicile | OB       |
| 8f8ee7cf-6f59-4338-8353-5735fd893325 | Justificatif de domicile | OB       |
| 8f8ee7cf-6f59-4338-8353-5735fd893327 | Justificatif de domicile | OB       |
| 8f8ee7cf-6f59-4338-8353-5735fd893321 | Justificatif de domicile | OB       |
| 8f8ee7cf-6f59-4338-8353-5735fd89332b | Justificatif de domicile | OB       |
And types in family to update <"8f8ee7cf-6f59-4338-8353-5735fd893324">
| label     | pendingDocument | id                                   |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e4 |
And types in family to update <"8f8ee7cf-6f59-4338-8353-5735fd893322">
| label     | pendingDocument | id                                   |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 |
And types in family to update <"8f8ee7cf-6f59-4338-8353-5735fd893323">
| label     | pendingDocument | id                                   |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e6 |
And types in family to update <"8f8ee7cf-6f59-4338-8353-5735fd893325">
| label     | pendingDocument | id                                   |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e3 |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e2 |
And types in family to update <"8f8ee7cf-6f59-4338-8353-5735fd893327">
| label     | pendingDocument | id                                   |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e1 |
And types in family to update <"8f8ee7cf-6f59-4338-8353-5735fd893321">
| label     | pendingDocument | id                                   |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e1 |
And types in family to update <"8f8ee7cf-6f59-4338-8353-5735fd89332b">
| label     | pendingDocument | id                                   |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e1 |

When I update a family
Then there is no exception
And I expect the status of all types in the family <"8f8ee7cf-6f59-4338-8353-5735fd893324"> are initialized

## RG106
Scenario: update subtype with new pieces

Given A type to modify
| label     | pendingDocument | id                                   | status |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e5 | VA     |
And pieces to add
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8934ea | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8934eb | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8934ec | 01740005814157951  | VA           |
# type validé ??#
When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e5">
Then there is no exception
And I get 0 pieces added in reference table

## RG108
Scenario: update type with new pieces for Reused edoc-type 

Given A type to modify
| label     | pendingDocument | id                                   | status       |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e1 | VA           |
And pieces to add
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ea | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935eb | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | VA           |
# type validé ??#
When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e1">
Then I get 3 pieces added in reference table

## RG108
Scenario: update type with new pieces for no Reused edoc-type 

Given A type to modify
| label     | pendingDocument | id                                   | status       |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e2 | VA           |
And pieces to add
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | VA           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ec | 01740005814157951  | VA           |
# type validé ??#
When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e2">
Then there is no exception
And I get 0 pieces added in reference table


## RG90
Scenario: add a piece for a type while having another type in the family with none DF status

Given new piece to add
| label    | receivedFormat       |
| CIN.jpeg | NUM                  |
When I add a new piece in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e2">
Then I expect error code : <"ERR-FUNC-UPD-00044">

## RG90
Scenario: add a piece for a type while having another type in the family with DF status

Given new piece to add
| label    | receivedFormat       |
| CIN.jpeg | NUM                  |
When I add a new piece in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e1">
Then there is no exception
And I expect type <"8f8ee7cf-6f59-4338-8353-5735fd8933e1"> containing 4 pieces

## RG116 A la validation d'un type appartenant à une famille de propert-type=Liste, supprimer les pièces des autres types
Scenario: update a type setting the status to VA
Given A type to modify
| label     | pendingDocument | id                                   |
| Quittance | false           | 8f8ee7cf-6f59-4338-8353-5735fd8933e3 |
When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e3">
Then there is no exception
And pieces of other types are deleted

## RG121 - Suite à l'ajout d'une pièce papier validé/recueilli, le statut du type passe respectivement à VA ou RC
Scenario: add paper piece with validated status
Given new piece to add
| label    | receivedFormat       | status |
| CIN.jpeg | PAP                  | VA     |

When I add a new piece in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e1"> 
Then there is no exception
And The status of the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e1"> is set to <"VA">

Scenario: add paper piece with RC status
Given new piece to add
| label    | receivedFormat       | status |
| CIN.jpeg | PAP                  | RC     |

When I add a new piece in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e1"> 
Then there is no exception
And The status of the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e1"> is set to <"RC">

## RG127 - Suite à l'ajout d'une pièce dans un type RC, le statut du type repasse à IN
Scenario: add piece in Type with RC status
Given new piece to add
| label    | receivedFormat       | status |
| CIN.jpeg | NUM                  | TP     |

When I add a new piece in type <"5f8ee7cf-6f59-4338-8353-5735fd8933ea"> 
Then there is no exception
And The status of the type <"5f8ee7cf-6f59-4338-8353-5735fd8933ea"> is set to <"IN">