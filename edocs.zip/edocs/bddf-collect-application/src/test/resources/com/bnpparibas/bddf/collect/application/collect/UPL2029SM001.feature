Feature: UPL2029SM001

Background:
Given A collect
| entityLabel | productLabel      | journeyCode |
| Retail      | Crédit immobilier | 100000      |

And A familiesManagmentActs
| OB | ND | DR |
And Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And A family
| label                    | category | propertyType |
| Justificatif de domicile | OB       | Fixe        |
And A Type
| label     | controlRequired | digitalAllowed | paperAllowed |
| Quittance | 0               | true           | true         |

## Cas passant
Scenario: Save a collect with an edoc-type
When I save a collect with the edoc-type <"00000000000000001">
Then There is no exepction
And The collect is created

## RG91
Scenario: Save a collect with an unkown edoc-type
When I save a collect with the edoc-type <"00000000000000099">
Then I expect error code <"ERR-FUNC-UPD-00045">

## RG92
Scenario: Save a collect with an empty edoc-type
When I save a collect with the edoc-type <"">
Then I expect error code <"ERR-FUNC-UPD-00046">

Scenario: Save a collect with an empty edoc-type and digital allowed = false
Given A digital allowed false type
When I save a collect with the edoc-type <"">
Then There is no exepction
And The collect is created

## RG99
Scenario: Save a collect with an empty jmc-type
Given A control required = 3 type
When I save a collect with the edoc-type <"00000000000000022">
Then I expect error code <"ERR-FUNC-UPD-00048">

Scenario: Save a collect with an empty edoc-type and required = 0
Given A control required = 0 type
When I save a collect with the edoc-type <"00000000000000017">
Then There is no exepction
And The collect is created







