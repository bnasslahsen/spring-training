Feature: UPL001017

# Dernière mise a jour : 04/01/2018.
# V0.0 : Initialisation

########################################################## 2 #

Background:
Given Existing collects
| id                                   | entityLabel |  status    | journeyCode |
| a6b15173-a48f-4861-b67a-7283e30f3d4c | Retail      |            | 100000      |
| b6b15173-a48f-4861-b67a-7283e30f3d4c | Autre       |            | 100000      |
| d6b15173-a48f-4861-b67a-7283e30f3d4c | Autre       |            | 100000      |
| b6b15173-a48f-4861-b67a-7283e30f3d5c | Autre       |     AB     | 100000      |

## collect 1
And Existing familiesManagmentActs in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND | DR |
And Existing owners in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| reference         | name |
| 01740005814157951 | Jean |
And An existing list of types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | familyId                             | familyCategory | edocType          |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 56b15173-a48f-4861-b67a-7283e30f3d4c | OB             | 00000000000000001 |

## collect 2
And Existing familiesManagmentActs in collect <"b6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB |
And Existing owners in collect <"b6b15173-a48f-4861-b67a-7283e30f3d4c">
| reference | name |
| 000000000 | Jean |
And An existing list of types in collect <"b6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | familyId                             | familyCategory | edocType          |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 56b15173-a48f-4861-b67a-7283e30f3d4c | OB             | 00000000000000001 |

## collect 3
And Existing familiesManagmentActs in collect <"b6b15173-a48f-4861-b67a-7283e30f3d5c">
| OB | ND | DR |
And Existing owners in collect <"b6b15173-a48f-4861-b67a-7283e30f3d5c">
| reference        | name |
| 01740005814157951 | Jean |
And An existing list of types in collect <"b6b15173-a48f-4861-b67a-7283e30f3d5c">
| id                                   | familyId                             | familyCategory | 
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 56b15173-a48f-4861-b67a-7283e30f3d4c | OB             | 

## collect 4
And Existing familiesManagmentActs in collect <"d6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND | DR |
And Existing owners in collect <"d6b15173-a48f-4861-b67a-7283e30f3d4c">
| reference         | name |
| 01740005814157951 | Jean |
And An existing list of types in collect <"d6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | familyId                             | familyCategory | 
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 56b15173-a48f-4861-b67a-7283e30f3d4c | OB             | 

And An existing list of reference documents
| ownerId           | edocType          | label               | referenceGdnId  | referencePieceId                     |
| 01740005814157951 | 00000000000000001 | carteIdentite1.jpg  | GD0566255       | b6b15173-a48f-4861-b67a-7283e30f3d5e |
| 01740005814157951 | 00000000000000002 | carteIdentite2.jpg  | GD0566257       | b6b15173-a48f-4861-b67a-7283e30f3d5e |
| 01740005814157951 | 00000000000000017 | livretDeFamille.jpg | GD0465456       | b6b15173-a48f-4861-b67a-7283e30f3d5e |



Scenario: add a family with an owner not registered in the collect
#RG5
Given a family to add
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | OB       |
And Owners references in family to save
| 000000001 |
And Types in family to save
| label    | edocType          |
| Quitance | 00000000000000001 |
When I register the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I return the error code : <"ERR-FUNC-UPD-00002">



#RG5
Scenario: add a family with an owner registered in the collect

Given a family to add
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | OB       |
And Owners references in family to save
| 01740005814157951 |
And Types in family to save
| label    | edocType          |
| Quitance | 00000000000000001 |
When I register the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">

#RG8
Scenario: add a family with Family-propertyType Liste, containing one kind of type

Given a family to add
| id                                   | category | propertyType |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | OB       | Liste        |
And Owners references in family to save
| 01740005814157951 |
And Types in family to save
| label    | edocType          |
| Quitance | 00000000000000001 |

When I register the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I return the error code : <"ERR-FUNC-UPD-00004">

#RG45
Scenario: add a family with unknown family management Act 

Given a family to add
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | XX       |
And Owners references in family to save
| 01740005814157951 |
And Types in family to save
| label    |   digitalAllowed |
| Quitance |   true           |

When I register the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I return the error code : <"ERR-FUNC-UPD-00003">

#RG48
Scenario: add a family with type DR without comment

Given a family to add
| id                                   | category | propertyType |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | DR       | Fixe         |
And Owners references in family to save
| 01740005814157951 |
And Types in family to save
| label    |   digitalAllowed |
| Quitance |   true           |

When I register the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I return the error code : <"ERR-FUNC-UPD-00023">

#RG77
Scenario: add a family with a category not exist in family mangement act

Given a family to add
| id                                   | category | propertyType |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | FA       | Fixe         |
And Owners references in family to save
| 01740005814157951 |
And Types in family to save
| label    | 
| Quitance | 

When I register the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I return the error code : <"ERR-FUNC-UPD-00017">


#RG91
Scenario: add a family with unknown type e-doc 

Given a family to add
| id                                   | category | propertyType |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | OB       | Fixe         |
And Owners references in family to save
| 01740005814157951 |
And Types in family to save
| label    |  edocType   | digitalAllowed |
| Quitance |  XXXXXXXXXX | true           |
And edoc type is activated            

When I register the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I return the error code : <"ERR-FUNC-UPD-00045">

#RG92
Scenario: add a family with missing type e-doc and digital is allowed

Given a family to add
| id                                   | category | propertyType |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | OB       | Fixe         |
And Owners references in family to save
| 01740005814157951 |
And Types in family to save
| label    |   digitalAllowed |
| Quitance |   true           |
And edoc type is activated            

When I register the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I return the error code : <"ERR-FUNC-UPD-00046">

#RG94
Scenario: add a family with missing type e-doc and digital is allowed

Given a family to add
| id                                   | category | propertyType |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | OB       | Fixe         |
And Owners references in family to save
| 01740005814157951 |
And Types in family to save
| label    |   digitalAllowed | enableReuse |
| Quitance |   false          | true        |
And edoc type is activated            

When I register the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I return the error code : <"ERR-FUNC-UPD-00047">


#RG97 RG93 RG117
Scenario: add a family with enableReuse and existing refDoc

Given a family to add
 | category | propertyType |
 | OB       | Fixe         |
And Owners references in family to save
| 01740005814157951 |
And Types in family to save
| label    |   digitalAllowed | enableReuse  | controlRequired   | edocType               |
| Quitance |   true           | true         |  0                | 00000000000000001      |
| Quitance |   true           | true         |  0                | 00000000000000017      |
And edoc type is activated          

When I register the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then there is no exception
And types in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> contains 2 pieces

#RG97 RG93 RG117
Scenario: add a family with enableReuse and existing refDoc

Given a family to add
 | category | propertyType |
 | ND       | Fixe         |
And Owners references in family to save
| 01740005814157951 |
And Types in family to save
| label    |   digitalAllowed | enableReuse  | controlRequired   | edocType               |
| Quitance |   true           | true         |  0                | 00000000000000001      |
| Quitance |   true           | true         |  0                | 00000000000000017      |
And edoc type is activated          

When I register the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then there is no exception
And types in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> contains 0 pieces


##RG99
Scenario: add a family with control is required and type JMC is null

Given a family to add
 | category | propertyType |
 | OB       | Fixe         |
And Owners references in family to save
| 01740005814157951 | 
And Types in family to save
| label    |   digitalAllowed | enableReuse | controlRequired | edocType 			   |
| Quitance |   true           | true        |  1              | 00000000000000022      |
And edoc type is activated            

When I register the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I return the error code : <"ERR-FUNC-UPD-00048">


