Feature: UPL4006SM01

Background:
Given Existing collects
| id                                   | entityLabel | journeyCode |
| a6b15173-a48f-4861-b67a-7283e30f3d4c | Retail      | 000001      |
And Existing types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | familyId                             | familyCategory |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 56b15173-a48f-4861-b67a-7283e30f3d4c | OB             |
And Pieces in type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 75c9a389-af72-4ea4-a78c-562115855eab | page1.pdf | 01740005814400000 | NUM            | RC    | 007     | 
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e26 | page2.pdf | 01740005814400000 | NUM            | DP    | 007     |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e27 | page3.pdf | 01740005814400000 | NUM            | DF    | 007     |

Given Existing collects
| id                                   | entityLabel | journeyCode | 
| a6b15173-a48f-4861-b67a-7283e30f3d11 | Retail      | 000001      |
And Existing types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d11">
| id                                   | familyId                             | familyCategory |
| 16b15173-a48f-4861-b67a-7283e30f3d11 | 56b15173-a48f-4861-b67a-7283e30f3d11 | OB             |
And Pieces in type <"16b15173-a48f-4861-b67a-7283e30f3d11"> in collect <"a6b15173-a48f-4861-b67a-7283e30f3d11">
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e28 | page4.pdf | 01740005814400000 | NUM            | RF    | 007     |

Given Existing collects
| id                                   | entityLabel | journeyCode | 
| a6b15173-a48f-4861-b67a-7283e30f3d5c | Retail      | 000001      |
And Existing types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d5c">
| id                                   | familyId                             | familyCategory | status |
| 16b15173-a48f-4861-b67a-7283e30f3d5c | 56b15173-a48f-4861-b67a-7283e30f3d5c | OB             | IN     |

Given Existing collects
| id                                   | entityLabel | journeyCode |
| a6b15173-a48f-4861-b67a-7283e30f3d6c | Retail      | 100001      |
And Existing types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d6c">
| id                                   | familyId                             | familyCategory | status |
| 16b15173-a48f-4861-b67a-7283e30f3d6c | 56b15173-a48f-4861-b67a-7283e30f3d6c | OB             | RC     |
And Pieces in type <"16b15173-a48f-4861-b67a-7283e30f3d6c"> in collect <"a6b15173-a48f-4861-b67a-7283e30f3d6c">
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 75c9a389-af72-4ea4-a78c-562115855eac | page1.pdf | 01740005814400000 | PAP            | RC    | 007     | 


Given Existing collects
| id                                   | entityLabel | journeyCode |
| a6b15173-a48f-4861-b67a-7283e30f3d7c | Retail      | 000001      |
And Existing types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d7c">
| id                                   | familyId                             | familyCategory | status | controlRequired |
| 16b15173-a48f-4861-b67a-7283e30f3d7c | 56b15173-a48f-4861-b67a-7283e30f3d7c | OB             | IN     |        3        |
And Pieces in type <"16b15173-a48f-4861-b67a-7283e30f3d7c"> in collect <"a6b15173-a48f-4861-b67a-7283e30f3d7c">
| id                                   | label     | ownerId           | receivedFormat | status| channel | statusControl | typeControl |
| 75c9a389-af72-4ea4-a78c-562115855eac | page1.pdf | 01740005814400000 | PAP            | DP    | 007     | KO            | KO_UNK      | 

Given Existing collects
| id                                   | entityLabel | journeyCode | 
| a6b15173-a48f-4861-b67a-7283e30f3d12 | Retail      | 000001      |
And Existing types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d12">
| id                                   | familyId                             | familyCategory | status |
| 16b15173-a48f-4861-b67a-7283e30f3d12 | 56b15173-a48f-4861-b67a-7283e30f3d12 | OB             |  IN    |
And Pieces in type <"16b15173-a48f-4861-b67a-7283e30f3d12"> in collect <"a6b15173-a48f-4861-b67a-7283e30f3d12">
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e29 | page4.pdf | 01740005814400000 | NUM            | RC    | 001     |

Given Existing collects
| id                                   | entityLabel | journeyCode | 
| a6b15173-a48f-4861-b67a-7283e30f3d13 | Retail      | 000001      |
And Existing types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d13">
| id                                   | familyId                             | familyCategory | status |
| 16b15173-a48f-4861-b67a-7283e30f3d13 | 56b15173-a48f-4861-b67a-7283e30f3d13 | OB             |  VA    |
And Pieces in type <"16b15173-a48f-4861-b67a-7283e30f3d13"> in collect <"a6b15173-a48f-4861-b67a-7283e30f3d13">
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e30 | page4.pdf | 01740005814400000 | NUM            | VA    | 001     |


Scenario: Get a type that does not exist
When I search the type <"16b15173-a48f-4861-b67a-7283e30faaaa"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I expect error code <"ERR-FUNC-UPD-00035">


Scenario: Get a type that exists
When I search the type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then There is no exception
And Type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> is returned

Scenario: Update a type
Given A type to modify
| id                                   |
| 16b15173-a48f-4861-b67a-7283e30f3d4c |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 75c9a389-af72-4ea4-a78c-562115855eab | page1.pdf | 01740005814400000 | NUM            | RC    | 007     | 
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e26 | page2.pdf | 01740005814400000 | NUM            | VA    | 007     |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e27 | page3.pdf | 01740005814400000 | NUM            | RC    | 007     |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then There is no exception
And Piece in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> and type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> with id <"0af22b14-1e7f-4ebe-8feb-f1baaa903e26"> is updated with status <"VA">

## RG 47 
Scenario: Update a type with a RF piece with reason
Given A type to modify
| id                                   |
| 16b15173-a48f-4861-b67a-7283e30f3d4c |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel | rejectionReason |
| 75c9a389-af72-4ea4-a78c-562115855eab | page1.pdf | 01740005814400000 | NUM            | RC    | 007     |                 |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e26 | page2.pdf | 01740005814400000 | NUM            | RF    | 007     | Piece mauvaise  |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e27 | page3.pdf | 01740005814400000 | NUM            | DP    | 007     |                 |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then There is no exception
And Piece in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> and type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> with id <"0af22b14-1e7f-4ebe-8feb-f1baaa903e26"> is updated with status <"RF">


Scenario: Update a type with a RF piece without reason
Given A type to modify
| id                                   |
| 16b15173-a48f-4861-b67a-7283e30f3d4c |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 75c9a389-af72-4ea4-a78c-562115855eab | page1.pdf | 01740005814400000 | NUM            | RC    | 007     | 
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e26 | page2.pdf | 01740005814400000 | NUM            | RF    | 007     |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e27 | page3.pdf | 01740005814400000 | NUM            | DP    | 007     |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I expect error code <"ERR-FUNC-UPD-00016">

## RG 73
Scenario: Update a type with pendingDocument = true and no comment
Given A type to modify
| id                                   | pendingDocument |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | true            |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 75c9a389-af72-4ea4-a78c-562115855eab | page1.pdf | 01740005814400000 | NUM            | RC    | 007     | 
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e26 | page2.pdf | 01740005814400000 | NUM            | VA    | 007     |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e27 | page3.pdf | 01740005814400000 | NUM            | DP    | 007     |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I expect error code <"ERR-FUNC-UPD-00026">

Scenario: Update a type with pendingDocument = true and a comment
Given A type to modify
| id                                   | pendingDocument | pendingDocumentLabel |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | true            | Il manque le recto   |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 75c9a389-af72-4ea4-a78c-562115855eab | page1.pdf | 01740005814400000 | NUM            | RC    | 007     | 
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e26 | page2.pdf | 01740005814400000 | NUM            | VA    | 007     |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e27 | page3.pdf | 01740005814400000 | NUM            | DP    | 007     |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then There is no exception
And Attribute pending document of type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> is set to <"true">

## RG 40
Scenario: Update a type with unauthorized action
Given A type to modify
| id                                   |
| 16b15173-a48f-4861-b67a-7283e30f3d4c |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 75c9a389-af72-4ea4-a78c-562115855eab | page1.pdf | 01740005814400000 | NUM            | TP    | 007     | 
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e26 | page2.pdf | 01740005814400000 | NUM            | VA    | 007     |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e27 | page3.pdf | 01740005814400000 | NUM            | DP    | 007     |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I expect error code <"ERR-FUNC-UPD-00012">

## RG 79
Scenario: Update a type with unkown action
Given A type to modify
| id                                   |
| 16b15173-a48f-4861-b67a-7283e30f3d4c |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 75c9a389-af72-4ea4-a78c-562115855eab | page1.pdf | 01740005814400000 | NUM            | XX    | 007     | 
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e26 | page2.pdf | 01740005814400000 | NUM            | VA    | 007     |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e27 | page3.pdf | 01740005814400000 | NUM            | DP    | 007     |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I expect error code <"ERR-FUNC-UPD-00029">

## RG 47 : QC342 : DF -> RF
Scenario: Update a type DF to RF
Given A type to modify
| id                                   |
| 16b15173-a48f-4861-b67a-7283e30f3d4c |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel | rejectionReason |
| 75c9a389-af72-4ea4-a78c-562115855eab | page1.pdf | 01740005814400000 | NUM            | RC    | 007     |                 |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e26 | page2.pdf | 01740005814400000 | NUM            | DP    | 007     |                 |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e27 | page3.pdf | 01740005814400000 | NUM            | RF    | 007     |  Piece mauvaise |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then There is no exception
And Piece in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> and type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> with id <"0af22b14-1e7f-4ebe-8feb-f1baaa903e27"> is updated with status <"RF">


Scenario: Update a type without pieces
Given A type to modify
| id                                   | status |
| 16b15173-a48f-4861-b67a-7283e30f3d5c | VA     |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d5c"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d5c">
Then I expect error code <"ERR-FUNC-UPD-00065">

Scenario: Update a type GDN with PAP piece from RC to VA
Given A type to modify
| id                                   | status |
| 16b15173-a48f-4861-b67a-7283e30f3d6c | VA     |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 75c9a389-af72-4ea4-a78c-562115855eac | page1.pdf | 01740005814400000 | PAP            | VA    | 007     | 
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d6c"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d6c">
Then There is no exception
And Piece in collect <"a6b15173-a48f-4861-b67a-7283e30f3d6c"> and type <"16b15173-a48f-4861-b67a-7283e30f3d6c"> with id <"75c9a389-af72-4ea4-a78c-562115855eac"> is updated with status <"VA">
And Type in collect <"a6b15173-a48f-4861-b67a-7283e30f3d6c"> and type <"16b15173-a48f-4861-b67a-7283e30f3d6c"> is updated with status <"VA">

Scenario: Update a type to RC with OK_MAN piece
Given A type to modify
| id                                   | status | controlRequired |
| 16b15173-a48f-4861-b67a-7283e30f3d7c | RC     |        3        |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel | statusControl | typeControl |
| 75c9a389-af72-4ea4-a78c-562115855eac | page1.pdf | 01740005814400000 | PAP            | RC    | 007     | KO            | OK_MAN      |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d7c"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d7c">
Then There is no exception


##  UPL003024.SM001
### - rejectionProfile
# CP
Scenario: Update a type RC to RF without profile set
Given A type to modify
| id                                   |
| 16b15173-a48f-4861-b67a-7283e30f3d12 |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel | rejectionReason | rejectionComment |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e29 | page4.pdf | 01740005814400000 | NUM            | RF    | 001     |     Autre       |     secretBO     |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d12"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d12">
Then  There is no exception
And Piece in collect <"a6b15173-a48f-4861-b67a-7283e30f3d12"> and type <"16b15173-a48f-4861-b67a-7283e30f3d12"> with id <"0af22b14-1e7f-4ebe-8feb-f1baaa903e29"> is updated with status <"RF">
And RejectionProfile equals <"BO"> for Piece <"0af22b14-1e7f-4ebe-8feb-f1baaa903e29"> of Type <"16b15173-a48f-4861-b67a-7283e30f3d12"> of collect <"a6b15173-a48f-4861-b67a-7283e30f3d12">

#CP
Scenario: Update a type RC to RF with profile set to FO
Given A type to modify
| id                                   |
| 16b15173-a48f-4861-b67a-7283e30f3d12 |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel | rejectionReason  | rejectionComment |  rejectionProfile |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e29 | page4.pdf | 01740005814400000 | NUM            | RF    | 001     |      Autre       | secretFO         |         FO        |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d12"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d12">
Then  There is no exception
And Piece in collect <"a6b15173-a48f-4861-b67a-7283e30f3d12"> and type <"16b15173-a48f-4861-b67a-7283e30f3d12"> with id <"0af22b14-1e7f-4ebe-8feb-f1baaa903e29"> is updated with status <"RF">
And RejectionProfile equals <"FO"> for Piece <"0af22b14-1e7f-4ebe-8feb-f1baaa903e29"> of Type <"16b15173-a48f-4861-b67a-7283e30f3d12"> of collect <"a6b15173-a48f-4861-b67a-7283e30f3d12">

Scenario: Update a type RC to RF with profile set to an incorrect value
#CNP
Given A type to modify
| id                                   |
| 16b15173-a48f-4861-b67a-7283e30f3d12 |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel | rejectionReason  | rejectionComment | rejectionProfile |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e29 | page4.pdf | 01740005814400000 | NUM            | RF    | 001     |       Autre      | secretBO         |        AB        |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d12"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d12">
Then I expect error code <"ERR-FUNC-UPD-00089">

### - pendingDocumentProfile
# CP
Scenario: Update a type pendingDocument true without profile set 
Given A type to modify
| id                                   | pendingDocument |   pendingDocumentLabel   |
| 16b15173-a48f-4861-b67a-7283e30f3d12 |      true       |   il manque un fichier   |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e29 | page4.pdf | 01740005814400000 | NUM            | RC    | 001     | 
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d12"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d12">
Then  There is no exception
And PendingDocumentProfile equals <"BO"> for Type <"16b15173-a48f-4861-b67a-7283e30f3d12"> of collect <"a6b15173-a48f-4861-b67a-7283e30f3d12">

#CP
Scenario: Update a type pendingDocument true with profile set to FO 
Given A type to modify
| id                                   | pendingDocument |   pendingDocumentLabel   | pendingDocumentProfile |
| 16b15173-a48f-4861-b67a-7283e30f3d12 |      true       |   il manque un fichier   |          FO            |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e29 | page4.pdf | 01740005814400000 | NUM            | RC    | 001     | 
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d12"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d12">
Then  There is no exception
And PendingDocumentProfile equals <"FO"> for Type <"16b15173-a48f-4861-b67a-7283e30f3d12"> of collect <"a6b15173-a48f-4861-b67a-7283e30f3d12">

#CNP
Scenario: Update a type pendingDocument true with profile set to an incorrect value
Given A type to modify
| id                                   | pendingDocument |   pendingDocumentLabel   | pendingDocumentProfile |
| 16b15173-a48f-4861-b67a-7283e30f3d12 |      true       |   il manque un fichier   |         AB             |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e29 | page4.pdf | 01740005814400000 | NUM            | RC    | 001     |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d12"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d12">
Then I expect error code <"ERR-FUNC-UPD-00090">

##  UPL003024.SM002
# CP
Scenario: Update a type VA to RF BO
Given A type to modify
| id                                   | status |
| 16b15173-a48f-4861-b67a-7283e30f3d13 |   IN   |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel | rejectionReason | rejectionComment | rejectionProfile |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e30 | page4.pdf | 01740005814400000 | NUM            | RF    | 001     |     Autre       |     secretBO     |        BO        |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d13"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d13">
Then  There is no exception
And status equals <"IN"> for Type <"16b15173-a48f-4861-b67a-7283e30f3d13"> of collect <"a6b15173-a48f-4861-b67a-7283e30f3d13">

#CNP
Scenario: Update a type VA to RF FO
Given A type to modify
| id                                   | status |
| 16b15173-a48f-4861-b67a-7283e30f3d13 |   IN   |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel | rejectionReason | rejectionComment | rejectionProfile |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e30 | page4.pdf | 01740005814400000 | NUM            | RF    | 001     |     Autre       |     secretBO     |        FO        |
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d13"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d13">
Then I expect error code <"ERR-FUNC-UPD-00049">

#CP
Scenario: Update a type VA pendingDocument true BO
Given A type to modify
| id                                   | pendingDocument |   pendingDocumentLabel   | pendingDocumentProfile   | status |
| 16b15173-a48f-4861-b67a-7283e30f3d13 |      true       |   il manque un fichier   |         BO               |  IN    |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e30 | page4.pdf | 01740005814400000 | NUM            | VA    | 001     | 
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d13"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d13">
Then  There is no exception
And status equals <"IN"> for Type <"16b15173-a48f-4861-b67a-7283e30f3d13"> of collect <"a6b15173-a48f-4861-b67a-7283e30f3d13">

#CNP
Scenario: Update a type VA pendingDocument true FO
Given A type to modify
| id                                   | pendingDocument |   pendingDocumentLabel   | pendingDocumentProfile   | status |
| 16b15173-a48f-4861-b67a-7283e30f3d13 |      true       |   il manque un fichier   |         FO               |  IN    |
And Pieces in type to modify
| id                                   | label     | ownerId           | receivedFormat | status| channel |
| 0af22b14-1e7f-4ebe-8feb-f1baaa903e30 | page4.pdf | 01740005814400000 | NUM            | VA    | 001     | 
When I update the type <"16b15173-a48f-4861-b67a-7283e30f3d13"> in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d13">
Then I expect error code <"ERR-FUNC-UPD-00049">