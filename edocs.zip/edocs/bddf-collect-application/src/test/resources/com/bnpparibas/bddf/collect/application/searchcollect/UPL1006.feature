Feature: UPL1006
# V0.1 : création des scénarios

Scenario: search with a list of owners having a collect in common
Given two individual HOME collect and one in common 
#     |-----------------------------------------------------------------COLLECT-------------------------------------------------------------------------------------------------------|--------------------OWNER-------------------------|
      | idCollect                             | status   | creationDate        | entityLabel | productLabel       | stepLabel   | idJourney  | managementAct | sendingApplicationCode | reference          | name   | firstName | nature |
      | 0b6a45c7-4eee-421b-b96d-9f391cddf711  | En cours | 01/02/2017 12:15:10 | Retail      | Credit Immobilier  | Solvabilite | 100000     |	Déposer		 |		AP001			  | 01740005814400000  | Durand | Jean      | 01     |  
      | 3d951d74-8948-41d5-82c4-e9d3e29578cf  | En cours | 01/02/2017 12:15:10 | Retail      | Credit Immobilier  | Solvabilite | 100000     |	Validé		 |		AP001	  		  | 01740005814200000  | Durand | Marie     | 01     |
      | b4b9e7d1-d358-4d99-b900-77202fda9cc0  | En cours | 01/02/2017 12:15:10 | Retail      | Credit Immobilier  | Solvabilite | 100000     |	Déposer		 |		AP001			  | 01740005814400000  | Durand | Jean      | 01     |  
      | b4b9e7d1-d358-4d99-b900-77202fda9cc0  | En cours | 01/02/2017 12:15:10 | Retail      | Credit Immobilier  | Solvabilite | 100000     |	Déposer		 |		AP001			  | 01740005814200000  | Durand | Marie     | 01     |

When I search for home solva collects owned by Jean or Marie 
Then I get a list of three collects

Scenario: search with a non existant owner
Given an individual EERBPF collect owned by Jean
#     |---------------------------------------------------------------------------------------------- COLLECT -----------------------------------------------------------------------------|----------------- OWNER --------------------------|
      | idCollect                             | status   | creationDate        | entityLabel 	| productLabel        | stepLabel   | idJourney  | managementAct  | sendingApplicationCode | reference          | name   | firstName | nature |
      | 0b6a45c7-4eee-421b-b96d-9f391cddf711  | En cours | 01/02/2017 12:15:10 | Banque privée  | Entrée en relation  | Autre		| 200000     |	Déposer		  |		AP001			   | 01740005814400000  | Durand | Jean      | 01     |

When I search for Marie collects  
Then I get an empty list

Scenario: search with an existant owner on a different journey 
Given an individual HOME collect owned by Jean
#     |---------------------------------------------------------------------------------------------- COLLECT ------------------------------------------------------------------------|----------------- OWNER --------------------------|
      | idCollect                             | status   | creationDate        | entityLabel | productLabel       | stepLabel   | idJourney  | managementAct | sendingApplicationCode | reference          | name   | firstName | nature |
      | 0b6a45c7-4eee-421b-b96d-9f391cddf711  | En cours | 01/02/2017 12:15:10 | Retail      | Credit Immobilier  | Solvabilite | 100000     |	Déposer		 |		AP001			  | 01740005814400000  | Durand | Jean      | 01     |
When I search for EERBPF collects owned by Jean
Then I get an empty list