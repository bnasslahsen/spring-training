Feature: UPL1003


# Dernière mise a jour : 07/04/2017.
# V0.0 : Initialisation
# V0.1 : Enrichessement des scénarios

########################################################## 2 #


Scenario: Save a collect with an owner not registered in the collect

Given a collect with a list of owners, and a family with an owner (not on this list)

#     |----------------------------------------------------------------------------- COLLECT -------------------------------------------------------------------------------------------------------|----------------- OWNER --------------------------|--------------------------------------------------- FAMILY --------------------------------------------------------------------------------|------------------------------------------------------------------------------ TYPE ---------------------------------------------------------------------------------|----------------------- SUB TYPE ------------------------------|
#     | idCollect                                  | status   | creationDate        | entityLabel | productLabel       | stepLabel   | idJourney | managementAct           | sendingApplicationCode | reference          | name   | firstName | nature | id | owners            | label                   | category    | propertyType | iconCode         | additionalInformation                  | id                                   | label             | additionalInformation       | digitalAllowed |   externalDocumentType | controlRequired | id | label                 | additionalInformation            |  
      | 0b6a45c7-4eee-421b-b96d-9f391cddf711       | EC		  | 01/02/2017 12:15:10 | Retail      | Credit Immobilier  | Solvabilite | 100000    | DP	                   |                 AP00851| 01740005814400000  | Durand | Jean      | 01     | 03 | 01000000000000000 | justificatif de revenus | OB		 	| Fixe         | PICTO_REVENUS    | InfoAddFamille justificatif de revenus | 0b6a45c7-4eee-421b-b96d-9f391cddf711 | Avis d imposition |InfoAddType Avis d imposition| Oui            |                        | 0	             | 12 | Avis d imposition A-1 | InfoAddType Avis d imposition A-1|

When I register the collect
Then I return the error code : <"ERR-FUNC-UPD-00002"> (owner not in the list)

########################################################## 3 #


Scenario: Save a collect with incorrect management acts

Given a collect with management acts=remettre

#     |----------------------------------------------------------------------------- COLLECT ----------------------------------------------------------------------------------------------------------|----------------- OWNER --------------------------|--------------------------------------------------- FAMILY --------------------------------------------------------------------------------|------------------------------------------------------------------------ TYPE ---------------------------------------------------------------------------------------|----------------------- SUB TYPE ------------------------------|
#     | idCollect                                  | status   | creationDate        | entityLabel | productLabel       | stepLabel   | idJourney | managementAct              | sendingApplicationCode | reference          | name   | firstName | nature | id | owners            | label                   | category    | propertyType | iconCode         | additionalInformation                  | id                                   | label             | additionalInformation       | digitalAllowed |  externalDocumentType | controlRequired | id | label                 | additionalInformation            |  
      | 0b6a45c7-4eee-421b-b96d-9f391cddf717       | Ec		  | 01/02/2017 12:15:10 | Retail      | Credit Immobilier  | Solvabilite | 100000    | RM		                  |                 AP00851| 01740005814400000  | Durand | Jean      | 01     | 03 | 01740005814400000 | justificatif de revenus | OB		   | Fixe         | PICTO_REVENUS    | InfoAddFamille justificatif de revenus | 0b6a45c7-4eee-421b-b96d-9f391cddf711 | Avis d imposition |InfoAddType Avis d imposition| Oui            |                       | 0	            | 12 | Avis d imposition A-1 | InfoAddType Avis d imposition A-1|

When I register the collect
Then I return the error code : <"ERR-FUNC-UPD-00003"> (incorrect management acts)

########################################################## 4 #


Scenario: Save a collect with missing required fields

Given a collect with missing Type Label

#     |----------------------------------------------------------------------------- COLLECT ----------------------------------------------------------------------------------------------------------|----------------- OWNER --------------------------|--------------------------------------------------- FAMILY --------------------------------------------------------------------------------|----------------------------------------------------------------------------------- TYPE ----------------------------------------------------------------------------|----------------------- SUB TYPE ------------------------------|
#     | idCollect                                  | status   | creationDate        | entityLabel | productLabel       | stepLabel   | idJourney | managementAct              | sendingApplicationCode | reference          | name   | firstName | nature | id | owners            | label                   | category    | propertyType | iconCode         | additionalInformation                  | id                                   | label             | additionalInformation       | digitalAllowed |   externalDocumentType | controlRequired | id | label                 | additionalInformation            |  
      | 0b6a45c7-4eee-421b-b96d-9f391cddf711       | Ec		  | 01/02/2017 12:15:10 | Retail      | Credit Immobilier  | Solvabilite | 100000    | DP		                  |                 AP00851| 01740005814400000  | Durand | Jean      | 01     | 03 | 01740005814400000 | justificatif de revenus | OB		   | Fixe         | PICTO_REVENUS    | InfoAddFamille justificatif de revenus | 0b6a45c7-4eee-421b-b96d-9f391cddf711 | 					 |InfoAddType Avis d imposition| Oui            |                        | 0	            | 12 | Avis d imposition A-1 | InfoAddType Avis d imposition A-1|

When I register the collect
Then I return the error code : UPLFCT0007 (missing Type Label)

########################################################## 5 #


Scenario: Save a collect with Family-propertyType Liste, containing one kind of type

Given collect with propertyType Liste, containing one kind of type


#     |----------------------------------------------------------------------------- COLLECT ----------------------------------------------------------------------------------------------------------|----------------- OWNER --------------------------|--------------------------------------------------- FAMILY --------------------------------------------------------------------------------|------------------------------------------------------------------------------ TYPE -------------------------------------------------------------------------------------|----------------------- SUB TYPE ------------------------------|
#     | idCollect                                  | status   | creationDate        | entityLabel | productLabel       | stepLabel   | idJourney | managementAct              | sendingApplicationCode | reference          | name   | firstName | nature | id | owners            | label                   | category     | propertyType | iconCode         | additionalInformation                  | id                                   | label               | additionalInformation         | digitalAllowed |   externalDocumentType | controlRequired| id | label                 | additionalInformation            |
      | 0b6a45c7-4eee-421b-b96d-9f391cddf711       | En cours | 01/02/2017 12:15:10 | Retail      | Credit Immobilier  | Solvabilite | 100000    | DP		                  |                 AP00851| 01740005814400000  | Durand | Jean      | 01     | 04 | 01740005814400000 | justificatif de revenus | OB		 	| Liste        | PICTO_REVENUS    | InfoAddFamille justificatif de revenus | 0b6a45c7-4eee-421b-b96d-9f391cddf711 | Avis d imposition   |InfoAddType Avis d imposition  | Oui            |                        | 0	            | 12 | Avis d imposition A-1 | InfoAddType Avis d imposition A-1|

When I register the collect
Then I return the error code : <"ERR-FUNC-UPD-00004"> (one kind of type)

########################################################## 6 #


Scenario: Save a collect with the correct structure

Given collect with with the correct structure

#     |----------------------------------------------------------------------------- COLLECT ----------------------------------------------------------------------------------------------------------|----------------- OWNER --------------------------|--------------------------------------------------- FAMILY ----------------------------------------------------------------------------------|------------------------------------------------------------------------------------- TYPE ------------------------------------------------------------------------------|----------------------- SUB TYPE ------------------------------| 
#     | idCollect                                  | status   | creationDate        | entityLabel | productLabel       | stepLabel   | idJourney | managementAct              | sendingApplicationCode | reference          | name   | firstName | nature | id | owners            | label                    | category    | propertyType | iconCode         | additionalInformation                   | id                                   | label               | additionalInformation         | digitalAllowed |  externalDocumentType | controlRequired | id | label                 | additionalInformation            | 
      | 0b6a45c7-4eee-421b-b96d-9f391cddf711       | En cours | 01/02/2017 12:15:10 | Retail      | Credit Immobilier  | Solvabilite | 100000    | DP		                  |                 AP00851| 01740005814400000  | Durand | Jean      | 01     | 04 | 01740005814400000 | justificatif de revenus  | OB 			| Liste        | PICTO_REVENUS    | InfoAddFamille justificatif de revenus  | 0b6a45c7-4eee-421b-b96d-9f391cddf711 | Avis d imposition   |InfoAddType Avis d imposition  | Oui            |                       | 0	              | 12 | Avis d imposition A-1 | InfoAddType Avis d imposition A-1| 
      | 0b6a45c7-4eee-421b-b96d-9f391cddf711       | En cours | 01/02/2017 12:15:10 | Retail      | Credit Immobilier  | Solvabilite | 100000    | DP		                  |                 AP00851| 01740005814200000  | Durand | Jeanne    | 01     | 04 | 01740005814200000 | justificatif de revenus  | OB 			| Liste        | PICTO_REVENUS    | InfoAddFamille justificatif de revenus  | 0b6a45c7-4eee-421b-b96d-9f391cddf717 | Bulletin de salaire |InfoAddType Bulletin de salaire| Oui            |                       | 0	              |  1  |                       |                                  | 
      | 0b6a45c7-4eee-421b-b96d-9f391cddf711       | En cours | 01/02/2017 12:15:10 | Retail      | Credit Immobilier  | Solvabilite | 100000    | DP		                  |                 AP00851| 01740005814400000  | Durand | Jean      | 01     | 03 | 01740005814400000 | justificatif de domicile | OB 			| Fixe         |                  | InfoAddFamille justificatif de domicile | 0b6a45c7-4eee-421b-b96d-9f391cddf711 | Taxe habitation     |InfoAddType Taxe habitation    | Oui            |                       | 0	              |  2  |                       |                                  |

When I register the collect
Then a return the collect

########################################################## 7 #

Scenario: A collect without any owners

Given a collect without any owner associated

#     |--------------------------------------------------------------------------------------- COLLECT ------------------------------------------------------------------------------------------------|----------------- OWNER --------------------------|--------------------------------------------------- FAMILY ----------------------------------------------------------------------------------|----------------------------------------------------------------------------------- TYPE --------------------------------------------------------------------------------|----------------------- SUB TYPE ------------------------------| 
#     | idCollect                                  | status   | creationDate        | entityLabel | productLabel       | stepLabel   | idJourney | managementAct              | sendingApplicationCode | reference          | name   | firstName | nature | id | owners            | label                    | category    | propertyType | iconCode         | additionalInformation                   | id                                   | label               | additionalInformation         | digitalAllowed | externalDocumentType | controlRequired | id | label                 | additionalInformation            | 
      | 0b6a45c7-4eee-421b-b96d-9f391cddf711       | En cours | 01/02/2017 12:15:10 | Retail      | Credit Immobilier  | Solvabilite | 100000    | DP 		                  |                 AP00851|                    |        |           |        | 09 |                   | justificatif de revenus  | OB		 	| Fixe         | PICTO_REVENUS    | InfoAddFamille justificatif de revenus  | 0b6a45c7-4eee-421b-b96d-9f391cddf711 | Avis d imposition   |InfoAddType Avis d imposition  | Oui            |                      | 0	              | 12 | Avis d imposition A-1 | InfoAddType Avis d imposition A-1| 
      
When I register the collect
Then I return the error code : <"validation"> (collect with no owner associated)


Scenario: Save a collect either digitalAllowed and paperAllowed to false

Given collect either digitalAllowed and paperAllowed to false

#     |----------------------------------------------------------------------------- COLLECT ----------------------------------------------------------------------------------------------------------|----------------- OWNER --------------------------|--------------------------------------------------- FAMILY ----------------------------------------------------------------------------------|------------------------------------------------------------------------------------- TYPE ------------------------------------------------------------------------------|----------------------- SUB TYPE ------------------------------| 
#     | idCollect                                  | status   | creationDate        | entityLabel | productLabel       | stepLabel   | idJourney | managementAct              | sendingApplicationCode | reference          | name   | firstName | nature | id | owners            | label                    | category    | propertyType | iconCode         | additionalInformation                   | id                                   | label               | additionalInformation         | digitalAllowed |  externalDocumentType | controlRequired | id | label                 | additionalInformation            | 
       | 0b6a45c7-4eee-421b-b96d-9f391cddf711       | En cours | 01/02/2017 12:15:10 | Retail      | Credit Immobilier  | Solvabilite | 100000    | DP		                  |                 AP00851| 01740005814400000  | Durand | Jean      | 01     | 04 | 01740005814400000 | justificatif de revenus  | OB 			| Fixe        | PICTO_REVENUS    | InfoAddFamille justificatif de revenus  | 0b6a45c7-4eee-421b-b96d-9f391cddf711 | Avis d imposition   |InfoAddType Avis d imposition   | Non            |                       | 0	              | 12 | Avis d imposition A-1 | InfoAddType Avis d imposition A-1| 
 
When I register the collect
Then I return the error code : <"ERR-FUNC-UPD-00086">