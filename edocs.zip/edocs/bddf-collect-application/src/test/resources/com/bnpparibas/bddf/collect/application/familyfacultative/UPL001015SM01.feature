Feature: UPL001015

# Dernière mise a jour : 04/01/2018.
# V0.0 : Initialisation

########################################################## 2 #

Background:
Given Existing collects
| id                                   | entityLabel |
| a6b15173-a48f-4861-b67a-7283e30f3d4c | Retail      |
| b6b15173-a48f-4861-b67a-7283e30f3d4c | Autre       |
| c6b15173-a48f-4861-b67a-7283e30f3d4c | Autre       |

## collect 1
And Existing familiesManagmentActs in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND | DR | FA |
And An existing list of types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | familyId                             | familyCategory |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 56b15173-a48f-4861-b67a-7283e30f3d4c | OB             |
And Existing pieces in type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> and collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   |
| 26b15173-a48f-4861-b67a-7283e30f3d4c |

## collect 2
And Existing familiesManagmentActs in collect <"b6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | DR |
And An existing list of types in collect <"b6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | familyId                             | familyCategory |
| 18b15173-a48f-4861-b67a-7283e30f3d4c | 98b15173-a48f-4861-b67a-7283e30f3d4c | OB             |

## collect 3
And Existing familiesManagmentActs in collect <"c6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND | DR | FA |
And An existing list of types in collect <"c6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | familyId                             | familyCategory |
| 19b15173-a48f-4861-b67a-7283e30f3d4c | 88b15173-a48f-4861-b67a-7283e30f3d4c | FA             |
And Existing pieces in type <"19b15173-a48f-4861-b67a-7283e30f3d4c"> and collect <"c6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   |
| 26b15173-a48f-4861-b67a-7283e30f3d4c |


## RG 113
Scenario: Update a family containing pieces from OB to FA
Given Families to update
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | FA       |
When I update the families of collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then There is no exception
And The family <"56b15173-a48f-4861-b67a-7283e30f3d4c"> status of collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> is updated to <"FA">
And Types of in family <"56b15173-a48f-4861-b67a-7283e30f3d4c"> in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> contain piece

## RG 114
Scenario: Update a family containing pieces from FA to ND
Given Families to update
| id                                   | category |
| 88b15173-a48f-4861-b67a-7283e30f3d4c | ND       |
When I update the families of collect <"c6b15173-a48f-4861-b67a-7283e30f3d4c">
Then There is no exception
And The family <"88b15173-a48f-4861-b67a-7283e30f3d4c"> status of collect <"c6b15173-a48f-4861-b67a-7283e30f3d4c"> is updated to <"ND">
And Types of in family <"88b15173-a48f-4861-b67a-7283e30f3d4c"> in collect <"c6b15173-a48f-4861-b67a-7283e30f3d4c"> does not contain piece

## RG 114
Scenario: Update a family containing pieces from FA to DR
Given Families to update
| id                                   | category | categoryComment |
| 88b15173-a48f-4861-b67a-7283e30f3d4c | DR       | dérogé          |
When I update the families of collect <"c6b15173-a48f-4861-b67a-7283e30f3d4c">
Then There is no exception
And The family <"88b15173-a48f-4861-b67a-7283e30f3d4c"> status of collect <"c6b15173-a48f-4861-b67a-7283e30f3d4c"> is updated to <"DR">
And Types of in family <"88b15173-a48f-4861-b67a-7283e30f3d4c"> in collect <"c6b15173-a48f-4861-b67a-7283e30f3d4c"> does not contain piece






