Feature: UPL001021SM002

#CNP
Scenario: Suppression type avec idCollect non correct
Given An existing collect
| entityLabel | productLabel      | id                                   | autoValidation | journeyCode | controlIterationAllowed | status |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | true           |  000001     |            3            |   EC   |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label           | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType |
| Avis imposition | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 0               | OB             | 00000000000000004 | Fixe              |
When I delete a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> of collect <"8f8ee7cf-6f59-4338-8353-5735fd8933e9">
Then I expect error code <"ERR-FUNC-UPD-00030">
And type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> is not deleted

#CNP
Scenario: Suppression type avec idType non correct
Given An existing collect
| entityLabel | productLabel      | id                                   | autoValidation | journeyCode | controlIterationAllowed | status |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | true           |  000001     |            3            |   EC   |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label           | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType |
| Avis imposition | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 0               | OB             | 00000000000000004 | Fixe              |
When I delete a type <"8f8ee7cf-6f59-4338-8353-5735fd8933f1"> of collect <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
Then I expect error code <"ERR-FUNC-UPD-00035">
And type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> is not deleted

#CNP
Scenario: Suppression type avec collecte AB
Given An existing collect
| entityLabel | productLabel      | id                                   | autoValidation | journeyCode | controlIterationAllowed | status |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | true           |  000001     |            3            |   AB   |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label           | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType |
| Avis imposition | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 0               | OB             | 00000000000000004 | Fixe              |
When I delete a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> of collect <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
Then I expect error code <"ERR-FUNC-UPD-00018">
And type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> is not deleted

#CNP
Scenario: Suppression type avec collecte CL
Given An existing collect
| entityLabel | productLabel      | id                                   | autoValidation | journeyCode | controlIterationAllowed | status |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | true           |  000001     |            3            |   CL   |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label           | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType |
| Avis imposition | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 0               | OB             | 00000000000000004 | Fixe              |
When I delete a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> of collect <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
Then I expect error code <"ERR-FUNC-UPD-00018">
And type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> is not deleted

#CNP
Scenario: Suppression type avec status VA
Given An existing collect
| entityLabel | productLabel      | id                                   | autoValidation | journeyCode | controlIterationAllowed | status |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | true           |  000001     |            3            |   EC   |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label           | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType |
| Avis imposition | false           | VA     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 0               | OB             | 00000000000000004 | Fixe              |
When I delete a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> of collect <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
Then I expect error code <"ERR-FUNC-UPD-00096">
And type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> is not deleted

#CNP
Scenario: Suppression type avec une famille Liste
Given An existing collect
| entityLabel | productLabel      | id                                   | autoValidation | journeyCode | controlIterationAllowed | status |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | true           |  000001     |            3            |   IN   |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label           | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType |
| Avis imposition | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 0               | OB             | 00000000000000004 | Liste              |
| Avis imposition | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 0               | OB             | 00000000000000004 | Liste              |
When I delete a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> of collect <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
Then I expect error code <"ERR-FUNC-UPD-00004">
And type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> is not deleted

#CNP
Scenario: Suppression type avec statusControl à EC
Given An existing collect
| entityLabel | productLabel      | id                                   | autoValidation | journeyCode | controlIterationAllowed | status |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | true           |  000001     |            3            |   IN   |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label           | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType | statusControl |
| Avis imposition | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 3               | OB             | 00000000000000004 | Fixe               |       EC      |
| Avis imposition | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 3               | OB             | 00000000000000004 | Fixe               |       EC      |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | ownerIndex | referenceValue | groupLabel | indexable |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000002 | OB       | 1          | Jean           | group1     | true      |
When I delete a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> of collect <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
Then I expect error code <"ERR-FUNC-UPD-00066">
And type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> is not deleted



#CP
Scenario: Suppression type
Given An existing collect
| entityLabel | productLabel      | id                                   | autoValidation | journeyCode | controlIterationAllowed | status |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | true           |  000001     |            3            |   EC   |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label           | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType |
| Avis imposition | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 0               | OB             | 00000000000000004 | Fixe              |
| Avis imposition | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 0               | OB             | 00000000000000004 | Fixe              |
When I delete a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> of collect <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
Then There is no exception
And type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> is deleted



