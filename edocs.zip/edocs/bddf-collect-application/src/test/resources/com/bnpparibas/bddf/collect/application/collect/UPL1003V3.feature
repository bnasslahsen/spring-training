Feature: UPL1003V3

########################################################## 3 #
Scenario: Save a collect with the same owner/journeyCode of an existing one
Given a valid collect
#    | entityLabel | productLabel  		| stepLabel   | journeyCode | piecesManagementAct 		| familiesManagementAct           | sendingApplicationCode	|
 	 | Retail      | Credit Immobilier  | Solvabilite | 100000      | DP,RC	             	    | OB,DF,DR			              |   AP00851				|
And having an owner
|reference          	| name   | firstname | nature|
| 01740005814400000  	| Durand | Jean      | 01    | 
When I save another collect
#| entityLabel | productLabel  	   | stepLabel   | journeyCode | piecesManagementAct 		| familiesManagementAct           | sendingApplicationCode	|
 | Retail      | Credit Immobilier  | Solvabilite | 100000      | DP,RC	             	    | OB,DF,DR			              |   AP00851				|
And having the same owner
|reference          	| name   | firstname | nature|
| 01740005814400000  	| Durand | Jean      | 01    | 
Then the collect is saved with alert