Feature: UPL2029SM003

Background:
## repository
Given An existing collect
| entityLabel | productLabel      | id                                   |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 |
And An existing types
| label     | pendingDocument | status | id                                   | familyId                             | familyLabel              | familyCategory | edocType          | familyPropertyType |
| Quittance | false           | VA     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | Justificatif de domicile | OB             | 00000000000000001 | Liste              |
| Quittance | false           |        | 8f8ee7cf-6f59-4338-8353-5735fd8933e6 | 8f8ee7cf-6f59-4338-8353-5735fd893323 | Justificatif de domicile | OB             | 00000000000000001 | Liste              |
| Quittance | false           | VA     | 8f8ee7cf-6f59-4338-8353-5735fd8933e4 | 8f8ee7cf-6f59-4338-8353-5735fd893324 | Justificatif de domicile | ND             | 00000000000000001 | Liste              |
| Quittance | false           |        | 8f8ee7cf-6f59-4338-8353-5735fd8933e3 | 8f8ee7cf-6f59-4338-8353-5735fd893325 | Justificatif de domicile | OB             | 00000000000000001 | Liste              |
| Quittance | false           |        | 8f8ee7cf-6f59-4338-8353-5735fd8933f3 | 8f8ee7cf-6f59-4338-8353-5735fd893325 | Justificatif de domicile | OB             | 00000000000000001 | Liste              |

And existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933f3">
| id                                   | ownerId            | status       | referenceGdnId | referencePieceId                     |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ea | 01740005814157951  | DF           | GD25535353535  | af8ee7cf-6f59-4338-8353-5735fd893325 |
| 8f8ee7cf-6f59-4338-8353-5735fd8935eb | 01740005814157951  | DF           | GD55535353535  | af8ee7cf-6f59-4338-8353-5735fd893325 |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ec | 01740005814157951  | DF           | GD35535353535  | af8ee7cf-6f59-4338-8353-5735fd893325 |
# Cas de soumission d’une pièce DF et suppression d’une pièce DF via le putPieces
Scenario: add a DF piece and delete another DF piece
Given pieces to modify
| id                                   | ownerId           | status |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ea | 01740005814157951 | DP     |
And channel is <"001">

When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933f3"> of a collect <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
Then there is no exception
And Piece <"8f8ee7cf-6f59-4338-8353-5735fd8935ea"> is saved in gdn

## RG40 : Si action requise impossible par rapport au statut de la pièce d'un type donné
Scenario: add a piece with wrong status
Given pieces to modify
| id                                   | ownerId           | status |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ea | 01740005814157951 | VA     |
And channel is <"001">

When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933f3"> of a collect <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
Then I expect error code : <"ERR-FUNC-UPD-00012">

## RG110 : Cas de soumission d’une pièce DF depuis un canal client
Scenario: add a DF piece with Client channel
Given pieces to modify
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8935ea | 01740005814157951  | DP           |
And channel is <"007">
When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933f3"> of a collect <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
Then I expect error code : <"ERR-FUNC-UPD-00012">

