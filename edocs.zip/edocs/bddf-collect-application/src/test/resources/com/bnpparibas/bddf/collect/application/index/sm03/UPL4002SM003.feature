Feature: UPL4002SM003

Background:

Given An existing collect
| entityLabel | productLabel      | id                                   |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label     | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType |
| Quittance | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 3               | OB             | 00000000000000001 | Liste              |
And Existing completeness in type
| 20000000000000001 |
| 20000000000000002 |

###158 Scenario1 :Index OB Is OK
Scenario: Index OB Is OK
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl  | idPiece                              | idPieceJmc |
| Pascal                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"OK"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">

###158:Index OB Is KO_EXTR
Scenario: Index OB Is KO_EXTR
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl  | idPiece | idPieceJmc|
|                           |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"KO_EXTR"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">

###158:Index OB Is KO_UNK
Scenario: Index OB Is KO_UNK
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       |
When I update pieces
Then I expect statusControl <"KO_UNK"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">

###158:Index OB Is KO_EXTR when JMC return NOT_APPLICABLE_KO 
Scenario: Index OB Is KO_EXTR when JMC return NOT_APPLICABLE_KO
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl         | idPiece                              | idPieceJmc|
| Pascal                    |  NOT_APPLICABLE_KO    | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"KO_EXTR"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">

###158:Index OB Is KO_EXTR when JMC return NOT_APPLICABLE_WARNING 
Scenario: Index OB Is KO_EXTR when JMC return NOT_APPLICABLE_WARNING
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl           | idPiece                              | idPieceJmc|
| Pascal                    |  NOT_APPLICABLE_WARNING | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"KO_EXTR"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">


###158:Index OB Is KO_COHE
Scenario: Index OB Is KO_COHE
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl  | idPiece | idPieceJmc|
| Pascal                    |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"KO_COHE"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">

###158:Index OB Is KO_MULT when two different piece jmc same type
Scenario: Index OB Is KO_COHE when two piece jmc same type
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl  | idPiece | idPieceJmc|
| Pascal1                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
| Pascal2                    |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000102  |
When I update pieces
Then I expect statusControl <"KO_MULT"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">

###158:Index OB Is KO_COHE when two  same piece jmc same type
Scenario: Index OB Is KO_COHE when two piece jmc same type
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl  | idPiece | idPieceJmc|
| Pascal1                    |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
| Pascal1                    |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000102  |
When I update pieces
Then I expect statusControl <"KO_COHE"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">

###158:Index OB Is KO_MULT when two piece edoc
Scenario: Index OB Is KO_MULT when two piece edoc
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl  | idPiece | idPieceJmc|
| Pascal1                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 000000101  |
| Pascal2                    |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000102  |
When I update pieces
Then I expect statusControl <"KO_MULT"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">


###158:Index FA Is WARNING_EXTR
Scenario: Index FA Is WARNING_EXTR
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | FA       | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl  | idPiece | idPieceJmc|
|                           |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"WARNING_EXTR"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">

###158:Index FA Is WARNING_COHE
Scenario: Index FA Is WARNING_COHE
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | FA       | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl  | idPiece | idPieceJmc|
|   Pascal                        |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"WARNING_COHE"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">

###158:Index FA Is WARNING_UNK
Scenario: Index FA Is WARNING_UNK
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | FA       | 
When I update pieces
Then I expect statusControl <"WARNING_UNK"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">

###158:Index FA Is WARNING_EXTR when JMC return NOT_APPLICABLE_KO 
Scenario: Index FA Is WARNING_UNK when JMC return NOT_APPLICABLE_KO 
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | FA       | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl         | idPiece                              | idPieceJmc|
| Pascal                    |  NOT_APPLICABLE_KO    | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"WARNING_EXTR"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">

###158:Index FA Is WARNING_EXTR  when JMC return NOT_APPLICABLE_WARNING 
Scenario: Index FA Is WARNING_UNK when JMC return NOT_APPLICABLE_WARNING
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | FA       | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl           | idPiece                              | idPieceJmc|
| Pascal                    |  NOT_APPLICABLE_WARNING | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"WARNING_EXTR"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">
