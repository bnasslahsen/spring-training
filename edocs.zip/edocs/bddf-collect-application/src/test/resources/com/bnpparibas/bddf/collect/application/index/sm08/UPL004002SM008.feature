Feature: UPL004002SM008

Background:
Given A collect
	 | id                                  		  | status 	| entityLabel | productLabel       | stepLabel   | journeyCode | sendingApplicationCode |
     | 6c016e27-2f1a-46d1-b87f-c8250f77ea30       | EC		| Retail      | Credit Immobilier  | Solvabilite | 200001   	 |       AP00851          |
And on a type collect <"6c016e27-2f1a-46d1-b87f-c8250f77ea30">
	 | id                                	  | label             |pendingDocument | pendingDocumentLabel | statusControl | familyId                             | familyCategory | edocType          |
	 |91a269c1-d310-4e40-bfba-4e4fc915c340	| Avis d imposition |     false      |						          |	OK            | 56b15173-a48f-4861-b67a-7283e30f3d40 | OB             | 00000000000000001 |
And existing pieces type <"91a269c1-d310-4e40-bfba-4e4fc915c340">
| id                                	| label   	| ownerId        	  | receivedFormat          | status		| channel   | typeControl   | statusControl | state |
|ad91db48-c66a-4dd1-9e26-173e1d441621	| page1.pdf	| 01740005814400000	  | NUM				        |	DP			| 007	    |	OK          |      OK       | ACTIF |
|ad91db48-c66a-4dd1-9e26-173e1d441622	| page1.pdf	| 01740005814400000	  | NUM				        |	DP		  	| 007	    |	OK          |      OK       | ACTIF |
|ad91db48-c66a-4dd1-9e26-173e1d441623	| page1.pdf	| 01740005814400000	  | NUM				        |	DP			| 007	    |	OK          |      OK       | ACTIF |
And existing typeJmc in piece <"ad91db48-c66a-4dd1-9e26-173e1d441621">
|identity_card_recto|
And existing typeJmc in piece <"ad91db48-c66a-4dd1-9e26-173e1d441622">
|identity_card_verso|
And existing typeJmc in piece <"ad91db48-c66a-4dd1-9e26-173e1d441623">
|identity_card_verso|


Given A collect
	 | id                                  		  | status 	| entityLabel | productLabel       | stepLabel   | journeyCode | sendingApplicationCode |
     | 6c016e27-2f1a-46d1-b87f-c8250f77ea31      | EC		| Retail      | Credit Immobilier  | Solvabilite | 200001   	 |       AP00851          |
And on a type collect <"6c016e27-2f1a-46d1-b87f-c8250f77ea31">
	 | id                                	  | label             |pendingDocument | pendingDocumentLabel | statusControl | familyId                             | familyCategory | edocType          |
	 |91a269c1-d310-4e40-bfba-4e4fc915c341	| Avis d imposition |     false      |						          |	KO            | 56b15173-a48f-4861-b67a-7283e30f3d41 | OB             | 00000000000000001 |
And existing pieces type <"91a269c1-d310-4e40-bfba-4e4fc915c341">
| id                                	| label   	| ownerId        	  | receivedFormat    | status		| channel   | typeControl   | 
|67faf5b9-5051-46ac-8844-2a5871cd5741	| page1.pdf	| 01740005814400000	| NUM				        |	VA			  | 007	    |	OK          |
|67faf5b9-5051-46ac-8844-2a5871cd5742	| page1.pdf	| 01740005814400000	| NUM				        |	DP		  	| 007	    |	OK          |
|67faf5b9-5051-46ac-8844-2a5871cd5744 | page1.pdf	| 01740005814400000	| NUM				        |	DP			  | 007	    |	KO_UKN      |         
And existing typeJmc in piece <"67faf5b9-5051-46ac-8844-2a5871cd5741">
|identity_card_recto|
And existing typeJmc in piece <"67faf5b9-5051-46ac-8844-2a5871cd5742">
|identity_card_verso|



Given A collect
	 | id                                  		  | status 	| entityLabel | productLabel       | stepLabel   | journeyCode | sendingApplicationCode |
     | 6c016e27-2f1a-46d1-b87f-c8250f77ea32      | EC		| Retail      | Credit Immobilier  | Solvabilite | 200001   	 |       AP00851          |
And on a type collect <"6c016e27-2f1a-46d1-b87f-c8250f77ea32">
	 | id                                	  | label             |pendingDocument | pendingDocumentLabel | statusControl | familyId                             | familyCategory | edocType          |
	 |91a269c1-d310-4e40-bfba-4e4fc915c342	| Avis d imposition |     false      |						          |	OK            | 56b15173-a48f-4861-b67a-7283e30f3d42 | OB             | 00000000000000002 |
And existing pieces type <"91a269c1-d310-4e40-bfba-4e4fc915c342">
| id                                	| label   	| ownerId        	  | receivedFormat    | status		| channel | typeControl |
|67faf5b9-5051-46ac-8844-2a5871cd5745	| page1.pdf	| 01740005814400000	| NUM				        |	DP			  | 007	    |	OK          | 
And existing typeJmc in piece <"67faf5b9-5051-46ac-8844-2a5871cd5745">
| passport  |

	 
########################################################## 1 #

#RG182
Scenario: delete an existing piece with indexes ctrlReco OK via deletePiece
Given Collect <"6c016e27-2f1a-46d1-b87f-c8250f77ea30">
Given existing indexes in type <"91a269c1-d310-4e40-bfba-4e4fc915c340">
| id                                   | code              | category | statusControl | extractedValue |
| fcbc051d-075b-41b0-8af4-527c3128cb78 | 10000000000000001 | OB       | OK            | test           |
| 15dfb172-9ef2-457d-b1ae-011168e8fa86 | 10000000000000002 | OB       | OK            | test           |
And typeJMC for index <"fcbc051d-075b-41b0-8af4-527c3128cb78">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | ad91db48-c66a-4dd1-9e26-173e1d441621 | OK            |
And typeJMC for index <"15dfb172-9ef2-457d-b1ae-011168e8fa86">
| idPieceJmc        | idPiece                              | statusControl |
| 000000102         | ad91db48-c66a-4dd1-9e26-173e1d441622 | OK            |
And typeJMC for index <"15dfb172-9ef2-457d-b1ae-011168e8fa86">
| idPieceJmc        | idPiece                              | statusControl |
| 000000103         | ad91db48-c66a-4dd1-9e26-173e1d441623 | OK            |
When i delete the piece <"ad91db48-c66a-4dd1-9e26-173e1d441623"> with deletePiece
Then indexes.extractedValue are equal to <"null"> for piece <"ad91db48-c66a-4dd1-9e26-173e1d441623">
Then indexes.statusControl are equal to <"null">  for piece <"ad91db48-c66a-4dd1-9e26-173e1d441623">
Then indexes.msgControl are equal to <"null">  for piece <"ad91db48-c66a-4dd1-9e26-173e1d441623">
Then ctrlStatus of type <"91a269c1-d310-4e40-bfba-4e4fc915c340"> is <"OK">
Then ctrlCompleteness of type <"91a269c1-d310-4e40-bfba-4e4fc915c340"> is <"OK">
 

Scenario: delete an existing piece with indexes ctrlReco OK via putPiece
Given Collect <"6c016e27-2f1a-46d1-b87f-c8250f77ea30">
Given existing indexes in type <"91a269c1-d310-4e40-bfba-4e4fc915c340">
| id                                   | code              | category | statusControl | extractedValue |
| fcbc051d-075b-41b0-8af4-527c3128cb78 | 10000000000000001 | OB       | OK            | test           |
| 15dfb172-9ef2-457d-b1ae-011168e8fa86 | 10000000000000002 | OB       | OK            | test           |
And typeJMC for index <"fcbc051d-075b-41b0-8af4-527c3128cb78">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | ad91db48-c66a-4dd1-9e26-173e1d441621 | OK            |
And typeJMC for index <"15dfb172-9ef2-457d-b1ae-011168e8fa86">
| idPieceJmc        | idPiece                              | statusControl |
| 000000102         | ad91db48-c66a-4dd1-9e26-173e1d441622 | OK            |
And typeJMC for index <"15dfb172-9ef2-457d-b1ae-011168e8fa86">
| idPieceJmc        | idPiece                              | statusControl |
| 000000103         | ad91db48-c66a-4dd1-9e26-173e1d441623 | OK            |
When i delete the piece <"ad91db48-c66a-4dd1-9e26-173e1d441623"> with deletePiece
Then indexes.extractedValue are equal to <"null"> for piece <"ad91db48-c66a-4dd1-9e26-173e1d441623">
Then indexes.statusControl are equal to <"null">  for piece <"ad91db48-c66a-4dd1-9e26-173e1d441623">
Then indexes.msgControl are equal to <"null">  for piece <"ad91db48-c66a-4dd1-9e26-173e1d441623">
Then ctrlStatus of type <"91a269c1-d310-4e40-bfba-4e4fc915c340"> is <"OK">
Then ctrlCompleteness of type <"91a269c1-d310-4e40-bfba-4e4fc915c340"> is <"OK">


Scenario: delete an existing piece with indexes ctrlReco OK via putType
Given Collect <"6c016e27-2f1a-46d1-b87f-c8250f77ea30">
Given existing indexes in type <"91a269c1-d310-4e40-bfba-4e4fc915c340">
| id                                   | code              | category | statusControl | extractedValue |
| fcbc051d-075b-41b0-8af4-527c3128cb78 | 10000000000000001 | OB       | OK            | test           |
| 15dfb172-9ef2-457d-b1ae-011168e8fa86 | 10000000000000002 | OB       | OK            | test           |
And typeJMC for index <"fcbc051d-075b-41b0-8af4-527c3128cb78">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | ad91db48-c66a-4dd1-9e26-173e1d441621 | OK            |
And typeJMC for index <"15dfb172-9ef2-457d-b1ae-011168e8fa86">
| idPieceJmc        | idPiece                              | statusControl |
| 000000102         | ad91db48-c66a-4dd1-9e26-173e1d441622 | OK            |
And typeJMC for index <"15dfb172-9ef2-457d-b1ae-011168e8fa86">
| idPieceJmc        | idPiece                              | statusControl |
| 000000103         | ad91db48-c66a-4dd1-9e26-173e1d441623 | OK            |
When i delete the piece <"ad91db48-c66a-4dd1-9e26-173e1d441623"> with deletePiece
Then indexes.extractedValue are equal to <"null"> for piece <"ad91db48-c66a-4dd1-9e26-173e1d441623">
Then indexes.statusControl are equal to <"null">  for piece <"ad91db48-c66a-4dd1-9e26-173e1d441623">
Then indexes.msgControl are equal to <"null">  for piece <"ad91db48-c66a-4dd1-9e26-173e1d441623">
Then ctrlStatus of type <"91a269c1-d310-4e40-bfba-4e4fc915c340"> is <"OK">
Then ctrlCompleteness of type <"91a269c1-d310-4e40-bfba-4e4fc915c340"> is <"OK">



######################################################################

#RG183
Scenario: delete an existing piece with piece with ctrlReco KO_UKN via putPiece
Given Collect <"6c016e27-2f1a-46d1-b87f-c8250f77ea31">
Given existing indexes in type <"91a269c1-d310-4e40-bfba-4e4fc915c341">
| id                                   | code              | category | statusControl | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            |
| 8f8ee7cf-6f59-4338-8353-5735f1111114 | 10000000000000002 | OB       | KO_UNK        |
And typeJMC for index <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | 67faf5b9-5051-46ac-8844-2a5871cd5741 | OK            |
And typeJMC for index <"8f8ee7cf-6f59-4338-8353-5735f1111114">
| idPieceJmc        | idPiece                              | statusControl |
| 000000102         | 67faf5b9-5051-46ac-8844-2a5871cd5742 | OK            |     	
When i delete the piece <"67faf5b9-5051-46ac-8844-2a5871cd5744"> with putPiece
Then ctrlStatus of type <"91a269c1-d310-4e40-bfba-4e4fc915c341"> is <"OK">

Scenario: delete an existing piece with indexe with ctrlReco KO_UKN via deletePiece
Given Collect <"6c016e27-2f1a-46d1-b87f-c8250f77ea31">
Given existing indexes in type <"91a269c1-d310-4e40-bfba-4e4fc915c341">
| id                                   | code              | category | statusControl | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            |
| 8f8ee7cf-6f59-4338-8353-5735f1111114 | 10000000000000002 | OB       | KO_UNK        |
And typeJMC for index <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | 67faf5b9-5051-46ac-8844-2a5871cd5741 | OK            |
And typeJMC for index <"8f8ee7cf-6f59-4338-8353-5735f1111114">
| idPieceJmc        | idPiece                              | statusControl |
| 000000102         | 67faf5b9-5051-46ac-8844-2a5871cd5742 | OK            |
When i delete the piece <"67faf5b9-5051-46ac-8844-2a5871cd5744"> with deletePiece
Then ctrlStatus of type <"91a269c1-d310-4e40-bfba-4e4fc915c341"> is <"OK">


Scenario: delete an existing piece with indexe with ctrlReco KO_UKN via putType
Given Collect <"6c016e27-2f1a-46d1-b87f-c8250f77ea31">
Given existing indexes in type <"91a269c1-d310-4e40-bfba-4e4fc915c341">
| id                                   | code              | category | statusControl | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            |
| 8f8ee7cf-6f59-4338-8353-5735f1111114 | 10000000000000002 | OB       | KO_UNK        |
And typeJMC for index <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | 67faf5b9-5051-46ac-8844-2a5871cd5741 | OK            |
And typeJMC for index <"8f8ee7cf-6f59-4338-8353-5735f1111114">
| idPieceJmc        | idPiece                              | statusControl |
| 000000102         | 67faf5b9-5051-46ac-8844-2a5871cd5742 | OK            |
When i delete the piece <"67faf5b9-5051-46ac-8844-2a5871cd5744"> with putType
Then ctrlStatus of type <"91a269c1-d310-4e40-bfba-4e4fc915c341"> is <"OK">


######################################################################

#RG184
Scenario: delete all existing pieces with indexes ctrlReco OK via deletePiece
Given Collect <"6c016e27-2f1a-46d1-b87f-c8250f77ea32">
Given existing indexes in type <"91a269c1-d310-4e40-bfba-4e4fc915c342">
| id                                   | code              | category | statusControl | extractedValue |
| fcbc051d-075b-41b0-8af4-527c3128cb78 | 10000000000000001 | OB       | OK            | test           |
And typeJMC for index <"fcbc051d-075b-41b0-8af4-527c3128cb78">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | 67faf5b9-5051-46ac-8844-2a5871cd5745 | OK            |
When i delete the piece <"67faf5b9-5051-46ac-8844-2a5871cd5745"> with deletePiece
Then indexes.extractedValue are equal to <"null"> for piece <"67faf5b9-5051-46ac-8844-2a5871cd5745">
Then indexes.statusControl are equal to <"null">  for piece <"67faf5b9-5051-46ac-8844-2a5871cd5745">
Then indexes.msgControl are equal to <"null">  for piece <"67faf5b9-5051-46ac-8844-2a5871cd5745">
Then ctrlStatus of type <"91a269c1-d310-4e40-bfba-4e4fc915c342"> is <"null">
Then ctrlCompleteness of type <"91a269c1-d310-4e40-bfba-4e4fc915c342"> is <"null">


Scenario: delete all existing pieces with indexes ctrlReco OK via putPiece
Given Collect <"6c016e27-2f1a-46d1-b87f-c8250f77ea30">
Given existing indexes in type <"91a269c1-d310-4e40-bfba-4e4fc915c340">
| id                                   | code              | category | statusControl | extractedValue |
| fcbc051d-075b-41b0-8af4-527c3128cb78 | 10000000000000001 | OB       | OK            | test           |
| 15dfb172-9ef2-457d-b1ae-011168e8fa86 | 10000000000000002 | OB       | OK            | test           |
| a8f1a74f-871a-4351-9f51-7d526626d71c | 10000000000000002 | OB       | OK            | test           |
| 4d9c3866-e80b-4911-a723-3cf2bc44aaa2 | 10000000000000002 | OB       | OK            | test           |
And typeJMC for index <"fcbc051d-075b-41b0-8af4-527c3128cb78">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | ad91db48-c66a-4dd1-9e26-173e1d441621 | OK            |
And typeJMC for index <"15dfb172-9ef2-457d-b1ae-011168e8fa86">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | ad91db48-c66a-4dd1-9e26-173e1d441622 | OK            |
And typeJMC for index <"a8f1a74f-871a-4351-9f51-7d526626d71c">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | ad91db48-c66a-4dd1-9e26-173e1d441623 | OK            |
And typeJMC for index <"4d9c3866-e80b-4911-a723-3cf2bc44aaa2">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | ad91db48-c66a-4dd1-9e26-173e1d441624 | OK            |
When i delete all pieces with putPiece
Then indexes.extractedValue are equal to <"null"> for all
Then indexes.statusControl are equal to <"null">  for all
Then indexes.msgControl are equal to <"null">  for all

Then ctrlStatus of type <"91a269c1-d310-4e40-bfba-4e4fc915c340"> is <"null">
Then ctrlCompleteness of type <"91a269c1-d310-4e40-bfba-4e4fc915c340"> is <"null">

Scenario: delete all existing pieces with indexes ctrlReco OK via putType
Given Collect <"6c016e27-2f1a-46d1-b87f-c8250f77ea30">
Given existing indexes in type <"91a269c1-d310-4e40-bfba-4e4fc915c340">
| id                                   | code              | category | statusControl | extractedValue |
| fcbc051d-075b-41b0-8af4-527c3128cb78 | 10000000000000001 | OB       | OK            | test           |
| 15dfb172-9ef2-457d-b1ae-011168e8fa86 | 10000000000000002 | OB       | OK            | test           |
| a8f1a74f-871a-4351-9f51-7d526626d71c | 10000000000000002 | OB       | OK            | test           |
| 4d9c3866-e80b-4911-a723-3cf2bc44aaa2 | 10000000000000002 | OB       | OK            | test           |
And typeJMC for index <"fcbc051d-075b-41b0-8af4-527c3128cb78">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | ad91db48-c66a-4dd1-9e26-173e1d441621 | OK            |
And typeJMC for index <"15dfb172-9ef2-457d-b1ae-011168e8fa86">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | ad91db48-c66a-4dd1-9e26-173e1d441622 | OK            |
And typeJMC for index <"a8f1a74f-871a-4351-9f51-7d526626d71c">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | ad91db48-c66a-4dd1-9e26-173e1d441623 | OK            |
And typeJMC for index <"4d9c3866-e80b-4911-a723-3cf2bc44aaa2">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | ad91db48-c66a-4dd1-9e26-173e1d441624 | OK            |
When i delete all the pieces with putType
Then indexes.extractedValue are equal to <"null"> for all
Then indexes.statusControl are equal to <"null">  for all
Then indexes.msgControl are equal to <"null">  for all

Then ctrlStatus of type <"91a269c1-d310-4e40-bfba-4e4fc915c340"> is <"null">
Then ctrlCompleteness of type <"91a269c1-d310-4e40-bfba-4e4fc915c340"> is <"null">



Scenario: delete all existing pieces with indexes ctrlReco OK via putFamily
Given Collect <"6c016e27-2f1a-46d1-b87f-c8250f77ea30">
Given existing indexes in type <"91a269c1-d310-4e40-bfba-4e4fc915c340">
| id                                   | code              | category | statusControl | extractedValue |
| fcbc051d-075b-41b0-8af4-527c3128cb78 | 10000000000000001 | OB       | OK            | test           |
| 15dfb172-9ef2-457d-b1ae-011168e8fa86 | 10000000000000002 | OB       | OK            | test           |
| a8f1a74f-871a-4351-9f51-7d526626d71c | 10000000000000002 | OB       | OK            | test           |
| 4d9c3866-e80b-4911-a723-3cf2bc44aaa2 | 10000000000000002 | OB       | OK            | test           |
And typeJMC for index <"fcbc051d-075b-41b0-8af4-527c3128cb78">
| idPieceJmc        | idPiece                              | statusControl |
| 000000101         | ad91db48-c66a-4dd1-9e26-173e1d441621 | OK            |
And typeJMC for index <"15dfb172-9ef2-457d-b1ae-011168e8fa86">
| idPieceJmc        | idPiece                              | statusControl |
| 000000102         | ad91db48-c66a-4dd1-9e26-173e1d441622 | OK            |
And typeJMC for index <"a8f1a74f-871a-4351-9f51-7d526626d71c">
| idPieceJmc        | idPiece                              | statusControl |
| 000000103         | ad91db48-c66a-4dd1-9e26-173e1d441623 | OK            |
And typeJMC for index <"4d9c3866-e80b-4911-a723-3cf2bc44aaa2">
| idPieceJmc        | idPiece                              | statusControl |
| 000000104         | ad91db48-c66a-4dd1-9e26-173e1d441624 | OK            |
When i delete all the pieces with putFamily
Then indexes.extractedValue are equal to <"null"> for all
Then indexes.statusControl are equal to <"null">  for all
Then indexes.msgControl are equal to <"null">  for all

Then ctrlStatus of type <"91a269c1-d310-4e40-bfba-4e4fc915c340"> is <"null">
Then ctrlCompleteness of type <"91a269c1-d310-4e40-bfba-4e4fc915c340"> is <"null">


