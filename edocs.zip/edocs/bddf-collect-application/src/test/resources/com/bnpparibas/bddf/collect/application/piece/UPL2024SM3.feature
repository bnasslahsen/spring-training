Feature: UPL2024SM3
# V0.1 : création des scénarios

Background: 
Given a temporary piece
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel |  state |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				|	TP			| 007	  |  ACTIF  |


########################################################## 1 #
Scenario: save pieces on gdn
Given a piece with authorized status change
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel | state |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				|	DP			| 007	  | ACTIF |
When I save the pieces on gdn
Then I return <"Les documents ont bien été transmis">

########################################################## 2 #
Scenario: unauthorized action
Given a piece with unauthorized status change
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel | state |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				|	VA			| 007	  |	ACTIF |
When I save the pieces on gdn
Then I get the exception : <"ERR-FUNC-UPD-00012">

########################################################### 4 #
Scenario: inexistant piece
Given a non-existing piece 
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel | state |
|a3af3040-6945-46be-940f-f34122999999	| page1.pdf	| 01740005814400000	| NUM				|	DP			| 007	  | ACTIF |
When I save the pieces on gdn
Then I get the exception : <"ERR-FUNC-UPD-00028">

########################################################### 5 #
Scenario: excessive list
Given a list of piece 
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel | 
|b2a60f54-4c84-4c49-82e6-e422169d9b71	| page1.pdf	| 01740005814400000	| NUM				|	DP			| 007	  | 
|46487dc8-d922-490c-b25b-96861b175188	| page2.pdf	| 01740005814400000	| NUM				|	DP			| 007	  | 
|6c866a03-ecb8-494a-821e-a5a45aa88455	| page3.pdf	| 01740005814400000	| NUM				|	DP			| 007	  | 
|41c042eb-a1e9-40a7-b7b0-b84855c464a2	| page4.pdf	| 01740005814400000	| NUM				|	DP			| 007	  | 
|096e4323-3586-40d1-a804-214d9c49f62a	| page5.pdf	| 01740005814400000	| NUM				|	DP			| 007	  | 
|a3af3040-6945-46be-940f-f34122999999	| page6.pdf	| 01740005814400000	| NUM				|	DP			| 007	  | 
When I save the pieces on gdn
Then I get the exception : <"ERR-FUNC-UPD-00010">