Feature: UPL5008SM1
########################################################## 0 #

Background:
Given a collect to abandon
#| idCollect                                  | status   | creationDate        			 |endDate| entityLabel | productLabel       | stepLabel   | idJourney | sendingApplicationCode |
 | a8fd3e39-b2c7-4932-b758-e6f36d2020c7       | EC		 | 2017-05-02T18:25:34.985+02:00 | null	 | Retail      | Credit Immobilier  | Solvabilite | 100000    |                 AP00851|

########################################################## 1 #
Scenario: Abondon collect successfully
When I abandon the collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">
Then the collect is abandoned

########################################################### 2 #
#Scenario: Abondon a non existing collect
#When I abandon the collect <"99999e39-b2c7-4932-b758-e6f36d999999">
#Then I get the error <"ERR-FUNC-UPD-00030">

########################################################## 3 #
#Scenario: Abondon a closed collect
#Given I close the collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7"> before abandon
#When I abandon the collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">
#Then I get the error <"ERR-FUNC-UPD-00018">

########################################################## 4 #
#Scenario: Get an abandoned collect by client
#When I abandon the collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">
#And I get the collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7"> with channel <"007">
#Then I get the error <"ERR-FUNC-UPD-00021"> 