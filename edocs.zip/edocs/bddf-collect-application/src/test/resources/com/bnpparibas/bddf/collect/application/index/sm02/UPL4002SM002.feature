Feature: UPL4002SM002

### RG129
Scenario: Save a collect with an unkown edoc-index
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And New indexes in type
| code               | category |
| 10000000000000001  | OB       |
| 50000000000000002  | OB       |

When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00055">

### RG131 - scenario1
Scenario: Save a collect with no index and controlRequired 3
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | controlRequired |
| CIN       | false           | 3               |

When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00057">

### RG131 - scenario2
Scenario: Save a collect with ND index and controlRequired 3
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | controlRequired |
| CIN       | false           | 3               |
And New indexes in type
| code               | category |
| 10000000000000001  | ND       |
| 10000000000000002  | ND       |

When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00057">

### RG132
Scenario: Save a collect with a wrong category
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And New indexes in type
| code               | category |
| 10000000000000001  | OB       |
| 10000000000000002  | AA       |

When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00058">

### RG133
Scenario: Save a collect initializing index labels
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And New indexes in type
| code               | category |  referenceValue |
| 10000000000000001  | OB       | Nom             |
| 10000000000000002  | OB       | Prenom          |
When I save the collect
Then There is no exception
Then I expect index label to be initialized

### RG135
Scenario: Save a collect with unknown controlRequired
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | controlRequired |
| CIN       | false           | 4               |
When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00060">

### RG136
Scenario: Save a collect with a wrong reference format
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And New indexes in type
| code              | referenceValue | category |
| 10000000000000001 | Nom            | OB       |
| 10000000000000005 | 01011950       | OB       |

When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00061">


### Cas passant : RG144
Scenario: Save a collect with index in subtype
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | controlRequired |
| CIN       | false           | 3               |
And New subtypes to add
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And New indexes in subtype
| code               | category | referenceValue |
| 10000000000000001  | ND       | Nom            |
| 10000000000000002  | OB       | Prenom         |

When I save the collect
Then There is no exception


### RG190 CP
Scenario: Save a collect with a null completeness
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status | controlRequired | edocType          |
| CIN       | false           | IN     | 3               | 00000000000000001 |
And null completeness
And New indexes in type
| code               | category | referenceValue |
| 10000000000000001  | OB       | Nom            |
When I save the collect
Then There is no exception
Then I expect completeness to be initialized


### RG191 CNP
Scenario: Save a collect with an unkown completeness
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And Existing completeness in type
| 20000000000000001 | 20000000000000002 | 50000000000000001 |
And New indexes in type
| code               | category | referenceValue |
| 10000000000000001  | OB       | Nom            |
When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00071">

Scenario: Save a collect with an unkown subtype's completeness
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And New subtypes to add
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And Existing completeness in subtype
| 20000000000000001 | 20000000000000002 | 50000000000000001 |
And New indexes in subtype
| code               | category | referenceValue |
| 10000000000000001  | OB       | Nom            |
When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00071">

### RG192 CP
Scenario: Save a collect with a uninitialized indexOwner
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status | controlRequired |
| CIN       | false           | IN     | 3               |
And null completeness
And New indexes in type
| code               | category | referenceValue |
| 10000000000000001  | OB       | Nom            |
When I save the collect
Then There is no exception
Then I expect indexOwner to be initialized


### RG193 CNP
Scenario: Save a collect with two indexes with the same indexOwner
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And New indexes in type
| code               | category | ownerIndex | referenceValue |
| 10000000000000001  | OB       | 1          | Nom            |
| 10000000000000001  | OB       | 1          | Nom            |
When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00073">

### RG193 CP
Scenario: Save a collect with two indexes but different indexOwner
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And New indexes in type
| code               | category | ownerIndex | referenceValue |
| 10000000000000001  | OB       | 1          | Nom            |
| 10000000000000001  | OB       | 2          | Nom            |
When I save the collect
Then There is no exception

### RG192 CNP
Scenario: Save a collect with two indexes with the same indexOwner
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And New indexes in type
| code               | category | ownerIndex | referenceValue |
| 10000000000000001  | OB       | a          | Nom            |
When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00072">

### ERROR 77
Scenario: Save a collect with unauthorized Index
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status | edocType          |
| CIN       | false           | IN     | 00000000000000001 |
And New indexes in type
| code               | category | referenceValue |
| 10000000000000027  | OB       |                |
When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00077">

### ERROR 97
Scenario: Save a collect with unauthorized Index in type 
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status | edocType          |
| CIN       | false           | IN     | 00000000000000001 |
And New indexes in type
| code               | category | referenceValue |
| 10000000000000027  | OB       |                |
And New subtypes to add
| label     | pendingDocument | status | 
| CIN       | false           | IN     |
And New indexes in subtype
| code               | category | referenceValue |
| 10000000000000027  | OB       |                |
When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00097">


### ERROR 98
Scenario: Save a collect with unauthorized Completeness in Type with subType
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status | edocType          |
| CIN       | false           | IN     | 00000000000000001 |
And Existing completeness in type
| 20000000000000001  |
| 20000000000000002  |
And New subtypes to add
| label     | pendingDocument | status | 
| CIN       | false           | IN     |
And New indexes in subtype
| code               | category | referenceValue |
| 10000000000000027  | OB       |                |
When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00098">


### ERROR 77
Scenario: Save a collect with unauthorized Index
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status | edocType          |
| CIN       | false           | IN     | 00000000000000001 |
And New indexes in type
| code               | category | referenceValue |
| 10000000000000002  | OB       |                |
When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00078">

### ERROR 77
Scenario: Save a collect with unauthorized Index
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status | edocType          |
| CIN       | false           | IN     | 00000000000000001 |
And New indexes in type
| code               | category | referenceValue |
| 10000000000000011  | ND       | MRZ            |
When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00079">
