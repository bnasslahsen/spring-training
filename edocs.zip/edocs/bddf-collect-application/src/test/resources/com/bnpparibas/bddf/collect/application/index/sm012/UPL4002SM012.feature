Feature: UPL4002SM012

Background:

Given An existing collect
| entityLabel | productLabel      | id                                   |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label           | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType |
| Avis imposition | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 3               | OB             | 00000000000000004 | Liste              |
And Existing completeness in type
| 20000000000000008 |




Scenario: CP pièce avec 2 titulaires.
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | ownerIndex | referenceValue |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | 1          | Jean           |
| e81d981b-3383-416f-81db-b2f11b21d59a | 10000000000000001 | OB       | 2          | Jeanine        |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl  | idPiece                              | idPieceJmc |
| Jean                      |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
And existing indexes_jmc in indexe <"e81d981b-3383-416f-81db-b2f11b21d59a">
| extractedValue            | statusControl  | idPiece                              | idPieceJmc|
| Jeanine                   |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"OK"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">
Then I expect statusControl <"OK"> in index <"e81d981b-3383-416f-81db-b2f11b21d59a">

Scenario: CNP pièce avec 2 titulaire ; 1 prénom incorrect 
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | ownerIndex  | referenceValue |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       |  1          | Jean           |
| e81d981b-3383-416f-81db-b2f11b21d59a | 10000000000000001 | OB       |  2          | Jeanine        |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl  | idPiece                              | idPieceJmc |
| Jean                      |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
And existing indexes_jmc in indexe <"e81d981b-3383-416f-81db-b2f11b21d59a">
| extractedValue              | statusControl  | idPiece                              | idPieceJmc |
| Alexandra                   |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"OK"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">
Then I expect statusControl <"KO_COHE"> in index <"e81d981b-3383-416f-81db-b2f11b21d59a">


Scenario: CP pièce avec 3 titulaires.
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | ownerIndex | referenceValue |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | 1          | Jean           |
| e81d981b-3383-416f-81db-b2f11b21d59a | 10000000000000001 | OB       | 2          | Jeanine        |
| 36e751ce-f24e-498c-82ab-c57ee3c010ce | 10000000000000001 | OB       | 3          | Jennifer       | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl  | idPiece                              | idPieceJmc |
| Jean                      |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
And existing indexes_jmc in indexe <"e81d981b-3383-416f-81db-b2f11b21d59a">
| extractedValue            | statusControl  | idPiece                              | idPieceJmc |
| Jeanine                   |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
And existing indexes_jmc in indexe <"36e751ce-f24e-498c-82ab-c57ee3c010ce">
| extractedValue            | statusControl  | idPiece                              | idPieceJmc |
| Jennifer                  |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"OK"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">
Then I expect statusControl <"OK"> in index <"e81d981b-3383-416f-81db-b2f11b21d59a">
Then I expect statusControl <"OK"> in index <"36e751ce-f24e-498c-82ab-c57ee3c010ce">



Scenario: CNP pièce avec 3 titulaires mais deux index
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | ownerIndex | referenceValue |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | 1          | Jean           |
| e81d981b-3383-416f-81db-b2f11b21d59a | 10000000000000001 | OB       | 2          | Jeanine        |
| 36e751ce-f24e-498c-82ab-c57ee3c010ce | 10000000000000001 | OB       | 3          | Jennifer       |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue            | statusControl  | idPiece                              | idPieceJmc |
| Jean                      |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
And existing indexes_jmc in indexe <"e81d981b-3383-416f-81db-b2f11b21d59a">
| extractedValue            | statusControl  | idPiece                              | idPieceJmc |
| Jeanine                   |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
And existing indexes_jmc in indexe <"36e751ce-f24e-498c-82ab-c57ee3c010ce">
| extractedValue            | statusControl  | idPiece                              | idPieceJmc |
| Jean                      |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"OK"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">
Then I expect statusControl <"OK"> in index <"e81d981b-3383-416f-81db-b2f11b21d59a">
Then I expect statusControl <"KO_COHE"> in index <"36e751ce-f24e-498c-82ab-c57ee3c010ce">



