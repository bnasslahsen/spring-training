Feature: UPL001017SM002

# Dernière mise a jour : 19/01/2018.
# V0.0 : Initialisation

########################################################## 2 #

Background:
Given Existing collects
| id                                   | entityLabel |  status    | journeyCode |
| a6b15173-a48f-4861-b67a-7283e30f3d4c | Retail      |    EC      | 100000      |
| a6b15173-a48f-4861-b67a-7283e30f3d4d | Retail      |    EC      | 100000      |

## collect 1
And Existing familiesManagmentActs in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND | DR |
And Existing owners in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| reference         | name |
| 01740005814157951 | Jean |
And An existing list of types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | familyId                             | familyCategory | edocType          |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 56b15173-a48f-4861-b67a-7283e30f3d4c | OB             | 00000000000000001 |
| 16b15173-a48f-4861-b67a-7283e30f3d5c | 56b15173-a48f-4861-b67a-7283e30f3d5c | OB             | 00000000000000001 |
And Existing pieces in type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> and collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   |
| 26b15173-a48f-4861-b67a-7283e30f3d4c |

## collect 2
And Existing familiesManagmentActs in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4d">
| OB | ND | DR |
And Existing owners in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4d">
| reference         | name |
| 01740005814157951 | Jean |
And An existing list of types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4d">
| id                                   | familyId                             | familyCategory | edocType          |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 56b15173-a48f-4861-b67a-7283e30f3d4c | OB             | 00000000000000001 |
And Existing pieces in type <"16b15173-a48f-4861-b67a-7283e30f3d4c"> and collect <"a6b15173-a48f-4861-b67a-7283e30f3d4d">
| id                                   |
| 26b15173-a48f-4861-b67a-7283e30f3d4c |




Scenario: delete a family inexistent in collect
#RG81
Given a family to delete <"56b15173-a48f-4861-b67a-7283e30f3d4e">
When I delete the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I return the error code : <"ERR-FUNC-UPD-00036">

Scenario: delete a family with existent pieces
#RG119
Given a family to delete <"56b15173-a48f-4861-b67a-7283e30f3d4c">
When I delete the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4d">
Then There is no exception
And types in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4d"> are <0> 

Scenario: delete a family from collect with many families
#RG119
Given a family to delete <"56b15173-a48f-4861-b67a-7283e30f3d4c">
When I delete the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then There is no exception
And types in the collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c"> are <1> 

