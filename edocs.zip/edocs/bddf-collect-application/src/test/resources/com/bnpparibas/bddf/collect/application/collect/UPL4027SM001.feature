Feature: UPL4027SM001

Background:
Given A new collect
| entityLabel | productLabel      | journeyCode |
| Retail      | Crédit immobilier | 100000      |
And Existing familiesManagmentActs
| OB | ND | DR |
And A new family
| label                    | category | propertyType |
| Justificatif de domicile | OB       | Fixe         |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
### RG244
#CP groupLabel set
Scenario: Save a collect with JmcFamily=address_proof and groupLabel set
And New types to add
| label                 | pendingDocument | status | controlRequired |       edocType           | digitalAllowed |
| Taxe Habitation       | false           | IN     |       3         |  00000000000000006       | true           |
And New indexes in type
| code               | category |  referenceValue | label  |  groupLabel  | indexable |
| 10000000000000002  | OB       | Nom             | Nom    |  Etat Civil  |   true    |
| 10000000000000004  | OB       | Prenom          | Prénom |  Etat Civil  |   true    |
When I add a collect
Then There is no exception

### RG243
#CP
Scenario: Save a collect with indexable indexes
And New types to add
| label                 | pendingDocument | status | controlRequired |       edocType           | digitalAllowed |
| Taxe Habitation       | false           | IN     |       3         |  00000000000000006       | true           |
And New indexes in type
| code               | category |  referenceValue | label  |  groupLabel  | indexable |
| 10000000000000002  | OB       | Nom             | Nom    |  Etat Civil  |   true    |
| 10000000000000004  | OB       | Prenom          | Prénom |  Etat Civil  |   true    |
When I add a collect
Then There is no exception

### RG243
#CP
Scenario: Save a collect with groupLabel set with ND boolean
And New types to add
| label                     | pendingDocument | status | controlRequired |       edocType           | digitalAllowed |
| Solicitation commerciale  | false           | IN     |       3         |  00000000000000021       | true           |
And New indexes in type
| code               | category | label            |  groupLabel  | indexable |
| 10000000000000019  | OB       | Présence date    |  test        |   true    |
When I add a collect
Then There is no exception

### RG243
#CNP
Scenario: Save a collect with ND non boolean (indexable false)
And New types to add
| label                 | pendingDocument | status | controlRequired |       edocType           | digitalAllowed |
| Taxe Habitation       | false           | IN     |       3         |  00000000000000006       | true           |
And New indexes in type
| code               | category | label  |  groupLabel  | indexable |
| 10000000000000014  | OB       | Nom    |  test        |  false    |
When I add a collect
Then I expect error <"ERR-FUNC-UPD-00092">


### RG243
##CNP
Scenario: Save a collect with ND non boolean (indexable true)
And New types to add
| label                 | pendingDocument | status | controlRequired |       edocType           | digitalAllowed |
| Taxe Habitation       | false           | IN     |       3         |  00000000000000006       | true           |
And New indexes in type
| code               | category | label            |  groupLabel  | indexable |  
| 10000000000000014  | OB       | Nom              |  Etat Civil  |  true     |  
When I add a collect
Then I expect error <"ERR-FUNC-UPD-00092">

### RG244
Scenario: Save a collect with indexes's subtypes
And New types to add
| label                 | pendingDocument | status | controlRequired |       edocType           | digitalAllowed |
| Taxe Habitation       | false           | IN     |       3         |  00000000000000006       | true           |
And New subTypes to add
| label                 | pendingDocument | status | 
| Taxe Habitation       | false           | IN     | 
And New indexes in subtype
| code               | category |  referenceValue | label  |  groupLabel  | indexable |
| 10000000000000002  | OB       | Nom             | Nom    |  Etat Civil  |   true    |
| 10000000000000004  | OB       | Prenom          | Prénom |  Etat Civil  |   true    |
When I add a collect
Then There is no exception
