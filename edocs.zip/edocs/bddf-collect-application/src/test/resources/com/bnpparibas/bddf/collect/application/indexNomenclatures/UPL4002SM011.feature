Feature: UPL4002SM011

Background:
Given Existing collects
| id                                   | entityLabel |  status    | journeyCode |
| a6b15173-a48f-4861-b67a-7283e30f3d4c | Retail      |            | 100000      |

## collect 1
And Existing familiesManagmentActs in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| OB | ND | DR |
And Existing owners in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| reference         | name |
| 01740005814157951 | Jean |
And An existing list of types in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
| id                                   | familyId                             | familyCategory | edocType          |
| 16b15173-a48f-4861-b67a-7283e30f3d4c | 56b15173-a48f-4861-b67a-7283e30f3d4c | OB             | 00000000000000001 |






### RG185
Scenario: Save a collect with an unknown gender
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And New indexes in type
| code               | category | referenceValue |
| 10000000000000001  | OB       | K              |

When I save the collect
Then I expect error code <"ERR-FUNC-UPD-00070">






#RG186
Scenario: add a family with a index not correct

Given a family to add
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | OB       |
And Owners references in family to save
| 01740005814157951 |
And Types in family to save
| label    | edocType          |
| Quitance | 00000000000000001 |
And New indexes in type for family
| code               | category | referenceValue |
| 10000000000000001  | OB       | G              |
When I register the family in collect <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I expect error code family <"ERR-FUNC-UPD-00070">


### RG185
Scenario: Save a collect with an known gender
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And New indexes in type
| code               | category | referenceValue |
| 10000000000000001  | OB       | M              |

When I save the collect
Then there is no exception


### RG185
Scenario: Save a collect with an unknown countries
Given A new collect country
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family country
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners country
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add country
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And New indexes in type country
| code               | category | referenceValue |
| 10000000000000007  | OB       | BRZ            |

When I save the collect country
Then I expect error code country <"ERR-FUNC-UPD-00070">


Scenario: Save a collect with an known countries
Given A new collect country
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family country
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners country
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add country
| label     | pendingDocument | status |
| CIN       | false           | IN     |
And New indexes in type country
| code               | category | referenceValue |
| 10000000000000007  | OB       | DNK            |

When I save the collect country
Then there is not exception country



#RG186
Scenario: add a family with a bad country

Given a family to add country
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | OB       |
And Owners references in family to save country
| 01740005814157951 |
And Types in family to save country
| label    | edocType          |
| Quitance | 00000000000000001 |
And New indexes in type for family country
| code               | category | referenceValue |
| 10000000000000007  | OB       | BRZ            |
When I register the family in collect country <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then I expect error code family country <"ERR-FUNC-UPD-00070">

#RG186
Scenario: add a family with a good country

Given a family to add goodcountry
| id                                   | category |
| 56b15173-a48f-4861-b67a-7283e30f3d4c | OB       |
And Owners references in family to save goodcountry
| 01740005814157951 |
And Types in family to save goodcountry
| label    | edocType          |
| Quitance | 00000000000000001 |
And New indexes in type for family goodcountry
| code               | category | referenceValue |
| 10000000000000007  | OB       | DNK            |
When I register the family in collect goodcountry <"a6b15173-a48f-4861-b67a-7283e30f3d4c">
Then there is no exception family goodcountry <"ERR-FUNC-UPD-00070">
