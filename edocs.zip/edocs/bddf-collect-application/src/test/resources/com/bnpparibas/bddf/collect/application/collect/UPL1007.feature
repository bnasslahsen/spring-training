Feature: UPL1007

########################################################## 1 #
Scenario: Case of authorized User
Given a collect
#    | entityLabel | productLabel  		| stepLabel   | journeyCode | piecesManagementAct 		| familiesManagementAct           | sendingApplicationCode	|
 	 | Retail      | Credit Immobilier  | Solvabilite | 100000      | DP,RC	             	    | OB,ND,DR			              |   AP00851				|
And owned by 
| reference          | name   | firstname | nature |
| 01740005814400000  | Durand | Jean      | 01     |
When I retrieve the collect with user <"01740005814400000">
Then I recive the collect

########################################################## 2 #
Scenario: Case of unauthorized User
Given a collect
#    | entityLabel | productLabel  		| stepLabel   | journeyCode | piecesManagementAct 		| familiesManagementAct           | sendingApplicationCode	|
 	 | Retail      | Credit Immobilier  | Solvabilite | 100000      | DP,RC	             	    | OB,ND,DR			              |   AP00851				|
And owned by 
| reference          | name   | firstname | nature |
| 01740005814400000  | Durand | Jean      | 01     |
When I retrieve the collect with user <"99999999999999999">
Then I recive an error: <"ERR-FUNC-UPD-00022">