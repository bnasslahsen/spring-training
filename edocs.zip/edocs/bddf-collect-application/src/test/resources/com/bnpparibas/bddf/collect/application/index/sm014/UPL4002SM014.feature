Feature: UPL4002SM014

Background:

Given An existing collect
| entityLabel | productLabel      | id                                   |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label     | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType | videoCodingDelay | 
| Quittance | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 3               | OB             | 00000000000000001 | Liste              |     Immediate    |
And Existing completeness in type
| 20000000000000001 |
| 20000000000000002 |



### RG207
#CP videocoding default
Scenario: Save a collect initializing indexes videoCodingDelay to "NotAllowed" --> default
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status | controlRequired |
| CIN       | false           | IN     |       3         |
And New indexes in type
| code               | category |  referenceValue | label  |
| 10000000000000001  | OB       | Nom             | Nom    |
| 10000000000000002  | OB       | Prenom          | Prénom |
When I save the collect
Then There is no exception
Then I expect videoCodingDelay to be equal to <"NotAllowed">
Then I expect videoCoding to be equal to <"false">

### RG207
#CP videoCodingDelay Differed
Scenario: Save a collect initializing videoCodingDelay to "Delayed"
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status | videoCodingDelay      | controlRequired |
| CIN       | false           | IN     |       Delayed         |       3         |
And New indexes in type
| code               | category |  referenceValue | label  |
| 10000000000000001  | OB       | Nom             | Nom    |
| 10000000000000002  | OB       | Prenom          | Prénom |
When I save the collect
Then There is no exception
Then I expect videoCodingDelay to be equal to <"Delayed">

### RG207
#CNP videoCodingDelay abc
Scenario: Save a collect initializing videoCodingDelay to "abc"
Given A new collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And A new family
| label                    | category |
| Justificatif de domicile | OB       |
And An new Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And New types to add
| label     | pendingDocument | status | videoCodingDelay | controlRequired |
| CIN       | false           | IN     |       abc        |       3         |
And New indexes in type
| code               | category |  referenceValue | label  |
| 10000000000000001  | OB       | Nom             | Nom    |
| 10000000000000002  | OB       | Prenom          | Prénom |
When I save the collect
Then There is exception CollectBusinessException with message containing <"ERR-FUNC-UPD-00003">
 
### RG207
#CP videocoding default
Scenario: Save a collect initializing videoCodingDelay to "NotAllowed" --> default

Given A new family to be add
| label                    | category |
| Justificatif de domicile | OB       |
And New types to add for new family
| label     | pendingDocument | status | controlRequired |
| CIN       | false           | IN     |        3        |
And New indexes in type for new family
| code               | category |  referenceValue | label  |
| 10000000000000001  | OB       | Nom             | Nom    |
| 10000000000000002  | OB       | Prenom          | Prénom |
When I add the family
Then There is no exception
Then I expect videoCodingDelay to be equal to <"NotAllowed">

### RG207
#CNP videoCodingDelay abc
Scenario: Save a collect initializing indexes videoCodingDelay to "abc"
Given A new family to be add
| label                    | category |
| Justificatif de domicile | OB       |
And New types to add for new family
| label     | pendingDocument | status | videoCodingDelay | controlRequired |
| CIN       | false           | IN     |       abc        |        3        |
And New indexes in type for new family
| code               | category |  referenceValue | label  |
| 10000000000000001  | OB       | Nom             | Nom    |
| 10000000000000002  | OB       | Prenom          | Prénom |
When I add the family
Then There is exception CollectBusinessException with message containing <"ERR-FUNC-UPD-00003">


# CNP AMI Index KO VideoCoding KO
Scenario: update piece AMI Index KO VideoCoding KO
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl | videoCoding  | ownerIndex |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | KO            |    false     |     1      |
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | KO            |    false     |     1      |
When I send to AMI
Then I expect indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111"> to be equal to <"KO">
Then I expect indexe <"8f8ee7cf-6f59-4338-8353-5735f1111112"> to be equal to <"KO">

# CP AMI Index KO VideoCoding OK
Scenario: update piece AMI Index KO VideoCoding OK
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl | videoCoding | ownerIndex |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | KO            |     true    |     1      |
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | KO            |     true    |     1      |
When I send to AMI
Then I expect indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111"> to be equal to <"OK">
Then I expect indexe <"8f8ee7cf-6f59-4338-8353-5735f1111112"> to be equal to <"OK">

# CP AMI Index KO and OK VideoCoding OK
Scenario: update piece AMI Index KO VideoCoding OK
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl | videoCoding | ownerIndex |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            |     true    |      1     |
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | KO            |     true    |      1     |
When I send to AMI
Then I expect indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111"> to be equal to <"OK">
Then I expect indexe <"8f8ee7cf-6f59-4338-8353-5735f1111112"> to be equal to <"OK">