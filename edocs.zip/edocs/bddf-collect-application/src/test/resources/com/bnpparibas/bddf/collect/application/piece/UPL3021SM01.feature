Feature: UPL3021SM01

# V0.1 : création des scénarios

########################################################## 1 #
Scenario: Deactivating a piece in the context database
Given a piece loaded by a customer in the context database
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel | state |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				|	TP			| 007	  |	ACTIF |		
When I Delete the piece <"a4af3040-6945-46be-940f-f3412233199b"> with channel <"007">
Then the piece is deactivated

########################################################## 2 #
Scenario: Deactivating a piece in the context database
Given a piece loaded by a employee in the context database
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel | state |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				|	TP			| 001	  |	ACTIF |		
When I Delete the piece <"a4af3040-6945-46be-940f-f3412233199b"> with channel <"007">
Then the piece is deactivated

########################################################## 3 #
Scenario: delete a piece by client and status VA - RG46 
Given a piece with status(VA) and delete piece by client
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel | state |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				|	VA			| 007	  | ACTIF |
When I Delete the piece <"a4af3040-6945-46be-940f-f3412233199b"> with channel <"007">
Then I receive an error : <"ERR-FUNC-UPD-00015">



########################################################## 4 #
#Scenario: delete a piece in collect closed - RG60
#Given an existing piece in collect closed
##|------------------------------------------------------------------------------ COLLECT ---------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------ TYPE ------------------------------------------|------------------------------------------PIECE---------------------------------------------------------------------|
#
##     | idCollect       								| status   | creationDate        			|endDate| entityLabel | productLabel       | stepLabel   | idJourney | sendingApplicationCode | id                                   | label             | digitalAllowed | controlRequired |pendingDocument |id                                   | label   	| ownerId        	| receivedFormat    | status		| channel |
#	  | a8fd3e39-b2c7-4932-b758-e6f36d2020c7 			| CL	   | 2017-05-02T18:25:34.985+02:00  | null	| Retail      | Credit Immobilier  | Solvabilite | 000256    |            AP00851     | 0b6a45c7-4eee-421b-b96d-9f391cddf711 | Avis d imposition |Oui             | Oui             |true            |a3af3040-6945-46be-940f-f3412233199b | page1.pdf	| 01740005814400000 | NUM			    |	TP		    | 001     |
#When I Delete the piece <"a4af3040-6945-46be-940f-f3412233199b"> with channel <"007">
#Then I receive an error : <"ERR-FUNC-UPD-00018">

########################################################## 5 #
#Scenario: delete a piece in collect abandoned  - RG60
#Given an existing piece in collect abandoned
##|------------------------------------------------------------------------------ COLLECT ---------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------ TYPE ------------------------------------------|------------------------------------------PIECE---------------------------------------------------------------------|
#
##     | idCollect       								| status   | creationDate        			|endDate| entityLabel | productLabel       | stepLabel   | idJourney | sendingApplicationCode | id                                   | label             | digitalAllowed | controlRequired |pendingDocument |id                                   | label   	| ownerId        	| receivedFormat    | status		| channel |
#	  | a8fd3e39-b2c7-4932-b758-e6f36d2020c7 			| AB	   | 2017-05-02T18:25:34.985+02:00  | null	| Retail      | Credit Immobilier  | Solvabilite | 000256    |            AP00851     | 0b6a45c7-4eee-421b-b96d-9f391cddf711 | Avis d imposition |Oui             | Oui             |true            |a3af3040-6945-46be-940f-f3412233199b | page1.pdf	| 01740005814400000 | NUM			    |	TP		    | 001     |
#When I Delete the piece <"a4af3040-6945-46be-940f-f3412233199b"> with channel <"007">
#Then I receive an error : <"ERR-FUNC-UPD-00018">


########################################################## 6 #
#Scenario: delete a piece an non existing collect - RG76
#Given a non existant collect 
##|------------------------------------------------------------------------------ COLLECT ---------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------ TYPE ------------------------------------------|------------------------------------------PIECE---------------------------------------------------------------------|
#
##     | idCollect       								| status   | creationDate        			|endDate| entityLabel | productLabel       | stepLabel   | idJourney | sendingApplicationCode | id                                   | label             | digitalAllowed |controlRequired |pendingDocument |id                                   | label   	| ownerId        	| receivedFormat    | status		| channel |
#	  | a8fd3e39-b2c7-4932-b758-e6f36d200000 			| EC	   | 2017-05-02T18:25:34.985+02:00  | null	| Retail      | Credit Immobilier  | Solvabilite | 000256    |            AP00851     | 0b6a45c7-4eee-421b-b96d-9f391cddf711 | Avis d imposition |Oui              Oui             |true            |a3af3040-6945-46be-940f-f3412233199b | page1.pdf	| 01740005814400000 | NUM			    |	TP		    | 001     |
#When I Delete the piece <"99993040-6945-46be-940f-f3412233199b"> with channel <"007">
#Then I receive an error : <"ERR-FUNC-UPD-00030">

########################################################## 7 #
Scenario: delete a piece an non existing type - RG80
Given a non existant type 
#|------------------------------------------------------------------------------ TYPE -----------------------------------------------|------------------------------------------PIECE---------------------------------------------------------------------|

#     | id                                   | label             | digitalAllowed | controlRequired |pendingDocument |id                                   | label   	| ownerId        	| receivedFormat    | status		| channel | state |
	  | 0b6a45c7-4eee-421b-b96d-9f391cddg000 | Avis d imposition |Oui             | Oui             |true            |a3af3040-6945-46be-940f-f3412233199b | page1.pdf	| 01740005814400000 | NUM			    |	TP		    | 001     | ACTIF |
When I Delete the piece <"55553040-6945-46be-940f-f3412233199b"> with channel <"007">
Then I receive an error : <"ERR-FUNC-UPD-00035">