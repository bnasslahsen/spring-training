Feature: UPL3019SM02

# V0.1 : création des scénarios
Background:
Given A collect
	 | id                                  		  | status 	| entityLabel | productLabel       | stepLabel   | journeyCode | sendingApplicationCode |
     | a8fd3e39-b2c7-4932-b758-e6f36d2020c7       | EC		| Retail      | Credit Immobilier  | Solvabilite | 000256   	 |       AP00851          |
And on a type
	 | id                                	| label             |pendingDocument | pendingDocumentLabel |
	 |0b6a45c7-4eee-421b-b96d-9f391cddf711	| Avis d imposition |     false      |						|
########################################################## 1 #
Scenario: delete an existing piece
Given An existing piece
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| PAP				|	VA			| 007	  |			
When i delete the piece <"a3af3040-6945-46be-940f-f3412233199b"> with channel <"001">
Then The piece is deleted

########################################################## 2 #
Scenario: delete a non existent piece - RG74
Given An existing piece
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| PAP				|	VA			| 007	  |
When I delete the piece <"aaaaaaaa-6945-46be-940f-f3412233199b">with id collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">and id type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> with channel <"001">
Then I return an error : <"ERR-FUNC-UPD-00028">


########################################################## 3 #
#Scenario: delete an existing piece with an non existing collect - RG76
#Given a piece with an non existing collect
#| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel |
#|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| PAP				|	VA			| 007	  |
#When I delete the piece <"a3af3040-6945-46be-940f-f3412233199b">with id collect <"99999999-b2c7-4932-b758-e6f36d2020c7">and id type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> with channel <"001">
#Then I return an error : <"ERR-FUNC-UPD-00030">

########################################################## 4 #
Scenario: delete an existing piece with an non existing type - RG80
Given a piece with an non existing type
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| PAP				|	VA			| 007	  |
When I delete the piece <"a3af3040-6945-46be-940f-f3412233199b">with id collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">and id type<"99999999-4eee-421b-b96d-9f391cddf711"> with channel <"001">
Then I return an error : <"ERR-FUNC-UPD-00035">

########################################################## 5 #
#Scenario: delete an existing piece in a collect closed - RG60
#Given a piece in a collect closed
#| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel |
#|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| PAP				|	VA			| 007	  |
#When I delete the piece <"a3af3040-6945-46be-940f-f3412233199b">with id collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">and id type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> with channel <"001">
#Then I return an error : <"ERR-FUNC-UPD-00018">

## RG154
Scenario: delete an existing piece with type status to RC
Given type id <"0b6a45c7-4eee-421b-b96d-9f391cddf711"> to <"RC"> 
Given An existing piece
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| PAP				|	TP			| 007	  |
When I delete the piece <"a3af3040-6945-46be-940f-f3412233199b">with id collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">and id type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> with channel <"001">
Then type id <"0b6a45c7-4eee-421b-b96d-9f391cddf711"> has status to <"IN">

Scenario: delete an existing piece via savePieces with type status to RC
Given type id <"0b6a45c7-4eee-421b-b96d-9f391cddf711"> to <"RC"> 
Given An existing piece
| id                                	| label   	| ownerId         	| receivedFormat    | status		| channel | 
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| PAP				        |	TP			  | 007	    | 
When I delete the piece <"a3af3040-6945-46be-940f-f3412233199b"> via savePieces with id collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">and id type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> with channel <"001">
Then type id <"0b6a45c7-4eee-421b-b96d-9f391cddf711"> has status to <"IN">

Scenario: delete an existing piece with type status to VA
Given type id <"0b6a45c7-4eee-421b-b96d-9f391cddf711"> to <"VA"> 
Given An existing piece
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| PAP				|	TP			| 007	  |
When I delete the piece <"a3af3040-6945-46be-940f-f3412233199b">with id collect <"a8fd3e39-b2c7-4932-b758-e6f36d2020c7">and id type<"0b6a45c7-4eee-421b-b96d-9f391cddf711"> with channel <"001">
Then type id <"0b6a45c7-4eee-421b-b96d-9f391cddf711"> has status to <"VA">

