Feature: UPL1009SM01

Background:

## Input common to all scenario
Given A collect to save
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And Owners in the collect to save
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And A family in the collect to save
| label                    | category |
| Justificatif de domicile | Fixe     |

## Existing repository
And An existing list of edoc-Type
| value             | jmcType       | gdnType  | reuseEligibility |
| 00000000000000001 | identity_card | 20090091 | true             |
| 00000000000000017 |               | 20090091 | true             |
| 00000000000000007 | payment       | 20090222 | false            |
And An existing list of reference documents
| ownerId           | edocType          | label               | referenceGdnId  |
| 01740005814157951 | 00000000000000001 | carteIdentite1.jpg  | GD0566255       |
| 01740005814157951 | 00000000000000001 | carteIdentite2.jpg  | GD0566257       |
| 01740005814157951 | 00000000000000017 | livretDeFamille.jpg | GD0465456       |


## Cas passant
Scenario: Save a collect with enable reuse = true and digital allowed = true
Given A list of types in the collect to save
| label                   | digitalAllowed | enableReuse | edocType          |
| Justificatif d'identité | true           | true        | 00000000000000001 |
| Livret de famille       | true           | true        | 00000000000000017 |
When I save the collect
Then There is no exepction
And The collect is created
And The type <"00000000000000001"> contains 2 piece(s) with a <"DF"> status
And The type <"00000000000000017"> contains 1 piece(s) with a <"DF"> status

##
Scenario: Save a collect with enable reuse = false and digital allowed = true
Given A list of types in the collect to save
| label                   | digitalAllowed | enableReuse | edocType          |
| Justificatif d'identité | true           | false       | 00000000000000001 |
| Livret de famille       | true           | false       | 00000000000000017 |
When I save the collect
Then There is no exepction
And The collect is created
And Types do not contain piece

## RG94
Scenario: Save a collect with enable reuse = true and digital allowed = false
Given A list of types in the collect to save
| label     | digitalAllowed | enableReuse | edocType          |
| Quittance | false          | true        | 00000000000000001 |
When I save the collect
Then I expect an error message <"ERR-FUNC-UPD-00047">

##
Scenario: Save a collect with enable reuse = false and digital allowed = false
Given A list of types in the collect to save
| label     | digitalAllowed | enableReuse | edocType          |
| Quittance | true           | false       | 00000000000000001 |
When I save the collect
Then There is no exepction
And The collect is created
And Types do not contain piece

## 
Scenario: Save a collect with enable reuse = true and digital allowed = true with subtypes
Given A list of types in the collect to save
| label                   | digitalAllowed | enableReuse | edocType          |
| Justificatif d'identité | true           | true        | 00000000000000001 |
And A list of subtypes
| label     |
| CNI       |
| Passeport |
When I save the collect
Then There is no exepction
And The collect is created
And Types do not contain piece 

## RG97
Scenario: Save a collect with enable reuse = true and digital allowed = true
Given A list of types in the collect to save
| label                   | digitalAllowed | enableReuse | edocType          |
| Justificatif d'identité | true           | true        | 00000000000000001 |
| Livret de famille       | true           | true        | 00000000000000017 |
And Category family is <"Liste">
When I save the collect
Then There is no exepction
And The collect is created
And The type <"00000000000000001"> contains 2 piece(s) with a <"DF"> status
And The type <"00000000000000017"> contains 1 piece(s) with a <"DF"> status


Scenario: Update a family from ND to OB
Given An existing collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And An existing owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing type
| label     | digitalAllowed | enableReuse | edocType          | familyCategory | id                                   | familyId                             |
| Quittance | true           | true        | 00000000000000001 | ND             | a8fd3e39-b2c7-4932-b758-e6f36d2020c7 | a8fd3e39-b2c7-4932-b758-e6f36d2020c6 |
When I update family category to <"OB">
Then There is no exepction
And The type <"00000000000000001"> contains 2 piece(s) with a <"DF"> status


Scenario: Update a family from ND to OB with subtypes
Given An existing collect
| entityLabel | productLabel      |
| Retail      | Crédit immobilier |
And An existing owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing type
| label     | digitalAllowed | enableReuse | edocType          | familyCategory | id                                   | familyId                             |
| Quittance | true           | true        | 00000000000000001 | ND             | a8fd3e39-b2c7-4932-b758-e6f36d2020c7 | a8fd3e39-b2c7-4932-b758-e6f36d2020c6 |
And A list of subtypes for family
| label     |
| CNI       |
| Passeport |
When I update family category to <"OB">
Then There is no exepction
And Types of the family do not contain piece

# RG126 Ne pas récupérer les pièces de référence pour une famille ND/DR
Scenario: Save a collect with enable reuse = true and family category DR
Given A list of types in the collect to save
| label                   | digitalAllowed | enableReuse | edocType          |
| Justificatif d'identité | true           | true        | 00000000000000001 |
| Livret de famille       | true           | true        | 00000000000000017 |
And Category family is <"DR">
When I save the collect
Then There is no exepction
And The collect is created
And The type <"00000000000000001"> contains 0 piece(s) with a <"DF"> status
And The type <"00000000000000017"> contains 0 piece(s) with a <"DF"> status
