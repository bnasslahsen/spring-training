Feature: UPL4007SM001

Background:

Given An existing collect
| entityLabel | productLabel      | id                                   | autoValidation |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | true           |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label     | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType | statusControl | completenessControl |
| Quittance | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 3               | OB             | 00000000000000001 | Liste              | OK            | OK                  |
| Quittance | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 3               | OB             | 00000000000000001 | Liste              | OK            | KO                  |

# Cas passant updatePiece
Scenario: update pieces auto-validating the type
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea"> of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb"> of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| identity_card_verso |

When I update pieces of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
Then I expect pieces status <"VA"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
And  I expect status <"VA_AUTO"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">

# AutoValidation à false
Scenario: update pieces with completenessControl set to KO
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea"> of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
| identity_card_recto |

When I update pieces of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
Then I expect pieces status <"DP"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
And  I expect status <"IN"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">

# Cas passant updateType
Scenario: update type auto-validating it
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea"> of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| identity_card_recto |

When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
Then I expect pieces status <"VA"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
And  I expect status <"VA_AUTO"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">

# updateType - AutoValidation à false
Scenario: update type with completenessControl set to KO
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea"> of type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
| identity_card_recto |

When I update a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
Then I expect pieces status <"DP"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
And  I expect status <"IN"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e8">
