Feature: UPL004002SM008

# V0.1 : création des scénarios
Background:
Given A collect
	 | id                                  		  | status 	| entityLabel | productLabel       | stepLabel   | journeyCode | sendingApplicationCode |
     | a8fd3e39-b2c7-4932-b758-e6f36d2020c7       | EC		| Retail      | Credit Immobilier  | Solvabilite | 000256      |       AP00851          |
And on a type
	 | id                                	| label             | pendingDocument | pendingDocumentLabel | statusControl | completenessControl |
	 |0b6a45c7-4eee-421b-b96d-9f391cddf711	| Avis d imposition |      false      |	 		 		   	|	KO          |  KO                 |
And existing pieces
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| PAP				|	VA			| 007	  |	
|b3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| PAP				|	VA			| 007	  |	
	 
########################################################## 1 #

#RG182
Scenario: delete an existing piece with indexes
Given existing indexes in type <"0b6a45c7-4eee-421b-b96d-9f391cddf711">
| id                                   | code              | category | statusControl | idPiece                              | idPieceJmc |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | KO            | a3af3040-6945-46be-940f-f3412233199b | 000000101  |
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | OK            | b3af3040-6945-46be-940f-f3412233199b | 000000101  |		
When i delete the piece <"a3af3040-6945-46be-940f-f3412233199b">
Then The piece is deleted

#RG182
Scenario: delete an existing piece with indexe status KO_MULT
Given existing indexes in type <"0b6a45c7-4eee-421b-b96d-9f391cddf711">
| id                                   | code              | category | statusControl | idPiece                              | idPieceJmc |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | KO_MULT       | a3af3040-6945-46be-940f-f3412233199b | 000000101  |
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | OK            | b3af3040-6945-46be-940f-f3412233199b | 000000101  |		
When i delete the piece <"a3af3040-6945-46be-940f-f3412233199b">
Then The piece is deleted

