Feature: UPL2024SM1
# V0.1 : création des scénarios


########################################################## 1 #
Scenario: save a piece correctly
Given a valid piece
When I save the piece
| id                                	| label   	| ownerId        	| receivedFormat    | channel | size |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				| 007	  |10000 |
Then I return the id of the piece


########################################################## 2 #
Scenario: save a piece with an excessive size
Given a piece with an excessive size
When I save the piece
| id                                	| label   	| ownerId        	| receivedFormat    | channel | size |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				| 007	  | 10001|
Then I return the error code : <"ERR-FUNC-UPD-00008"> 


########################################################## 3 #
Scenario: save a piece with an unauthorized format
Given a piece with an unauthorized format 
When I save the unauthorized format piece
| id                                	| label   	| ownerId        	| receivedFormat    | channel | size |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				| 007	  |10000 |
Then I return the error code : <"ERR-FUNC-UPD-00006"> 


########################################################## 4 #
Scenario: a valid piece but Type is not digital allowed
Given a valid piece associated to a no digital Allowed type
When I save the piece
| id                                	| label   	| ownerId        	| receivedFormat    | channel | size |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				| 007	  |10000 |
Then I return the error code : <"ERR-FUNC-UPD-00011"> 


########################################################## 5 #
Scenario: a valid piece but the maximum number of temporary pieces is reached 
Given a valid piece and a type with the maximum number of pieces reached
When I save the piece
| id                                	| label   	| ownerId        	| receivedFormat    | channel | size |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				| 007	  |10000 | 
Then I return the error code : <"ERR-FUNC-UPD-00010"> 


########################################################## 6 #
Scenario: a valid numeric piece with a type containing a paper piece
Given a valid numeric piece and a type with a paper
When I save the piece
| id                                	| label   	| ownerId        	| receivedFormat    | channel | size |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				| 007	  |10000 |
Then I return the id of the piece
And the paper piece is deleted


########################################################## 7 #
#Scenario: a valid piece but the collect is closed
#Given a valid piece and a closed collect
#When I save the piece
#Then I return the error code : <"ERR-FUNC-UPD-00018"> 


########################################################## 8 #
Scenario: a valid piece but the collect doesn't exist
Given a valid piece and a collect that doesn't exist
When I save the piece
| id                                	| label   	| ownerId        	| receivedFormat    | channel | size |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				| 007	  |10000 |
Then I return the error code : <"ERR-FUNC-UPD-00030"> 


########################################################## 9 #
Scenario: a valid piece but the type doesn't exist
Given a valid piece and a type that doesn't exist
When I save the piece
| id                                	| label   	| ownerId        	| receivedFormat    | channel | size |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				| 007	  |10000 |
Then I return the error code : <"ERR-FUNC-UPD-00035"> 


########################################################## 10 #
Scenario: a valid piece but the type contains a subtype
Given a valid piece and a type that contains a subtype
When I save the piece
| id                                	| label   	| ownerId        	| receivedFormat    | channel | size |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				| 007	  |10000 |
Then I return the error code : <"ERR-FUNC-UPD-00038"> 

########################################################## 11 #
Scenario: a valid piece for the type of a family ND
Given a valid piece and a type of a family ND
When I save the piece
| id                                	| label   	| ownerId        	| receivedFormat    | channel | size |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				| 007	  |10000 |
Then I return the error code : <"ERR-FUNC-UPD-00042"> 

########################################################## 12 #
Scenario: a valid piece numeric for the type with missing document
Given a valid numeric piece for the type with missing document
When I save the piece
| id                                	| label   	| ownerId        	| receivedFormat    | channel | size |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| NUM				| 007	  |10000 |
Then the type pendingDocument is <"true">


########################################################## 13 #
Scenario: a valid piece paper for the type with missing document
Given a valid piece paper for the type with missing document
When I save the piece
| id                                	| label   	| ownerId        	| receivedFormat    | status		| channel |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| PAP				|	VA			| 007	  |
Then the type pendingDocument is <"false">

########################################################## 14 #
Scenario: a paper piece and a type where paperAllowed to false
Given a paper piece and a type where paperAllowed to false
When I save the piece
| id                                	| label   	| ownerId        	| receivedFormat    | channel | size |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| PAP				| 007	  |10000 |
Then I return the error code : <"ERR-FUNC-UPD-00085"> 

########################################################## 15 #
Scenario: a paper piece and a type where paperAllowed to true
Given a paper piece and a type where paperAllowed to true
When I save the piece
| id                                	| label   	| ownerId        	| receivedFormat    | channel | size | status |
|a3af3040-6945-46be-940f-f3412233199b	| page1.pdf	| 01740005814400000	| PAP				| 007	  |10000 | VA |
Then I return the id of the piece
