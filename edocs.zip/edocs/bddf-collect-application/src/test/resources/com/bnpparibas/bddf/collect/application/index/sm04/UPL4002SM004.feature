Feature: UPL4002SM004

Background:

Given An existing collect
| entityLabel | productLabel      | id                                   |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label     | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType |
| Quittance | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 3               | OB             | 00000000000000001 | Liste              |
And Existing completeness in type
| 20000000000000001 |
| 20000000000000002 |

### RG160 - Scenario1 : 2 pieces in the same edocType
Scenario: update pieces with 2 pieces in the same edocType
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| identity_card_verso |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            | 
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | OK            | 

### RG160 - Scenario1 : 3 pieces in the same edocType
Scenario: update pieces with 3 pieces in the same edocType with unknow document ( recto + verso + image)
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| identity_card_verso |
| unknown |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            | 
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | OK            | 

When I update pieces
Then I expect CTRL_RECO <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">

### RG160 + RG163  - Scenario2 :  2 pieces in different edocTypes
Scenario: update pieces with 2 pieces in different edocTypes
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| passport |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            | 
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | OK            | 

When I update pieces
Then I expect CTRL_RECO <"KO_EXP"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
And I expect CTRL_EXTR <"KO"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
And I expect CTRL_COHE <"KO"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
Then I expect completenessControl <"identity_card_verso">

### RG161 + RG163
Scenario: update pieces with unknown document type
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| unknown |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            |   
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | OK            | 

### RG161 + RG163
Scenario: update pieces with  one unknown document type and one known document type (identity_card_recto + image)
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto | 
| unknown |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            |   
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | OK            | 

When I update pieces
Then I expect CTRL_RECO <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
And I expect CTRL_EXTR <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
And I expect CTRL_COHE <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">

### RG162 has been deleted

### RG164 + RG165 - scenario1 : piece with at least 1 unknown index
Scenario: update pieces with unknown index
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| identity_card_verso |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl  | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | KO_UNK         |
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | OK             |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal1                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111112">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal2                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect CTRL_EXTR <"KO"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
And I expect CTRL_COHE <"KO"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">

Scenario: update pieces with warning unknown index
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| identity_card_verso |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl  | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | FA       | WARNING_UNK         |
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | OK             |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal1                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111112">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal2                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect CTRL_EXTR <"WARNING"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
And I expect CTRL_COHE <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">


### RG164 + RG165 - scenario2 : piece with at least 1 duplicated index
Scenario: update pieces with duplicated index in the same piece edoc
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| identity_card_verso |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl  | 
| 8f8ee7cf-6f59-4338-8353-5735f1111114 | 10000000000000001 | OB       | KO_COHE        | 
| 8f8ee7cf-6f59-4338-8353-5735f1111115 | 10000000000000001 | OB       | OK             | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111114">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal1                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
| Pascal3                    |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000102  |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111115">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal2                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect CTRL_EXTR <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
And I expect CTRL_COHE <"KO"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">

Scenario: update pieces with duplicated index in the two piece edoc
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| identity_card_verso |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl  | 
| 8f8ee7cf-6f59-4338-8353-5735f1111114 | 10000000000000001 | OB       | KO_MULT        | 
| 8f8ee7cf-6f59-4338-8353-5735f1111115 | 10000000000000001 | OB       | OK             | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111114">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal1                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
| Pascal3                    |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 000000102  |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111115">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal2                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect CTRL_EXTR <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
And I expect CTRL_COHE <"KO"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
And I expect CTRL_EXTR <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
And I expect CTRL_COHE <"KO"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">

### RG164 - scenario3 : piece with at least 1 warning index and no Ko index 
Scenario: update pieces with warning extr index and no Ko index
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| identity_card_verso |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl  | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | FA       | WARNING_EXTR   | 
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | OK             | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal1                    |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111112">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal2                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect CTRL_EXTR <"WARNING"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
And I expect CTRL_COHE <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">

### RG166 - RG167 valid indexes
Scenario: update pieces with valid indexes
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| identity_card_verso |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            |
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | OK            | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal1                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111112">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| XXXXXXX                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect CTRL_RECO <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
And I expect CTRL_EXTR <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
And I expect CTRL_COHE <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">

### RG167 Warning index
Scenario: update pieces with WARNING_COHE indexes
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| identity_card_verso |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            |
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | FA       | WARNING_COHE  | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal1                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111112">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| XXXXXXX                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |

When I update pieces
Then I expect CTRL_RECO <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
And I expect CTRL_EXTR <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
And I expect CTRL_COHE <"WARNING"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">

### RG168 KO_COHE
Scenario: update pieces with KO_COHE index
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| identity_card_verso |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            | 
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | KO_COHE       |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal1                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111112">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| XXXXXXX                    |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect CTRL_RECO <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
And I expect CTRL_EXTR <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
And I expect CTRL_COHE <"KO"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">

### RG169 StatusControl piece to OK
Scenario: update pieces setting statusControl piece to OK
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| identity_card_verso |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            | 
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | WARNING_COHE  | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal1                    |  OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111112">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| XXXXXXX                    |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"OK"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">

### RG169 StatusControl piece to KO
Scenario: update pieces setting statusControl piece to KO
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| identity_card_verso |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | KO_COHE            | 
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | OK            | 
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111111">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| Pascal1                    |  KO            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
And existing indexes_jmc in indexe <"8f8ee7cf-6f59-4338-8353-5735f1111112">
| extractedValue             | statusControl  | idPiece                              | idPieceJmc|
| XXXXXXX                    |  Ok            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
When I update pieces
Then I expect statusControl <"KO"> in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">

### RG170 - Scenario1 : no missing documents
Scenario: update pieces with all documents of completeness
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
| identity_card_verso |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl | 
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            | 
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | OK            |

When I update pieces
Then I expect completenessControl <"OK">

### RG170 - Scenario2 : missing 1 document
Scenario: update pieces with 1 missing Jmc document
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |
And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
| identity_card_recto |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | statusControl |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            |
| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | OK            | 

When I update pieces
Then I expect completenessControl <"identity_card_verso">

### RG171 - Not possible in cucumber
#Scenario: update pieces while 1 piece with EC statusControl
#Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
#| id                                   | ownerId            | statusControl |
#| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | OK            |
#| 8f8ee7cf-6f59-4338-8353-5735fd8933eb | 01740005814157951  | EC1           |
#And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933ea">
#| identity_card_recto |
#And existing typeJmc in piece <"8f8ee7cf-6f59-4338-8353-5735fd8933eb">
#| identity_card_verso |
#And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
#| id                                   | code              | category | statusControl | idPiece                              | idPieceJmc |
#| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000001 | OB       | OK            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
#| 8f8ee7cf-6f59-4338-8353-5735f1111112 | 10000000000000002 | OB       | EC            | 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 000000101  |
#
#When I update pieces
#Then I expect statusControl <"EC"> for the type 
#And methode test <"EC">  
