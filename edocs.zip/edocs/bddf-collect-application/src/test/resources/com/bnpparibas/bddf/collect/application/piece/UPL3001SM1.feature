Feature: UPL3001SM1
# V0.1 : création des scénarios

Background:
Given in progress collect
	 | id                                  		  | status 	| entityLabel | productLabel       | stepLabel   | journeyCode | sendingApplicationCode |
     | a8fd3e39-b2c7-4932-b758-e6f36d2020c7       | EC		| Retail      | Credit Immobilier  | Solvabilite | 000256      |       AP00851          |
And containing a type
	 | id                                	| label             |pendingDocument | pendingDocumentLabel |
	 |0b6a45c7-4eee-421b-b96d-9f391cddf711	| Avis d imposition |     false      |						|

########################################################## 1 #
Scenario: search for existing piece on GDN
Given an existing piece
| id                                    | label     | ownerId           | receivedFormat    | status        | channel | idDocGdn	|
|a3af3040-6945-46be-940f-f3412233199b   | page1.pdf | 01740005814400000 | numérique         |   DP          | 007     | GDN8888		|                
When I search for the piece <"a3af3040-6945-46be-940f-f3412233199b">
Then I return the piece
########################################################## 2 #
Scenario: search for a nonexistent piece 
Given an existing piece
| id                                    | label     | ownerId           | receivedFormat    | status        | channel | idDocGdn	|
|a3af3040-6945-46be-940f-f3412233199b   | page1.pdf | 01740005814400000 | numérique         |   DP          | 007     | GDN8888		|
When I search for the piece <"aaaaaaaa-6945-46be-940f-f3412233199b">
Then I get the error code : <"ERR-FUNC-UPD-00028">