Feature: UPL004023SM002

Background:

Given An existing collect
| entityLabel | productLabel      | id                                   | autoValidation | journeyCode | controlIterationAllowed |
| Retail      | Crédit immobilier | 8f8ee7cf-6f59-4338-8353-5735fd8933e8 | true           |  000001     |            3            |
And An existing Owners
| reference         | firstname | nature |
| 01740005814157951 | Jean      | 01     |
And An existing types
| label           | pendingDocument | status | id                                   | familyId                             | controlRequired | familyCategory | edocType          | familyPropertyType |
| Avis imposition | false           | IN     | 8f8ee7cf-6f59-4338-8353-5735fd8933e7 | 8f8ee7cf-6f59-4338-8353-5735fd893322 | 3               | OB             | 00000000000000004 | Liste              |
And Existing completeness in type
| 20000000000000008 |



Scenario: Reindexation manuelle
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       | controlIterationAchieved |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |            1             |
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | ownerIndex | referenceValue | correctedValue | groupLabel | indexable |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000002 | OB       | 1          | Jean           | Jean           | group1     | true      |
| e81d981b-3383-416f-81db-b2f11b21d59a | 10000000000000004 | OB       | 1          | Doe            |                | group1     | true      |
And groupIndexesValidation in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> is <"true">
When I update CT a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
Then I expect statusControl <"OK_MAN"> in index <"8f8ee7cf-6f59-4338-8353-5735f1111111">
Then I expect statusControl <"OK_MAN"> in index <"e81d981b-3383-416f-81db-b2f11b21d59a">


Scenario: Reindexation manuelle ERR-FONC-UPD-00064
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       | controlIterationAchieved |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |            1             |   
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | ownerIndex | referenceValue | correctedValue | groupLabel | indexable |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000002 | OB       | 1          | Jean           | Jean           | group1     | true      |
| e81d981b-3383-416f-81db-b2f11b21d59a | 10000000000000004 | OB       | 1          | Doe            |                |            | true      |
And groupIndexesValidation in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> is <"false">
When I update CT a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
Then I expect error code <"ERR-FUNC-UPD-00064">



Scenario: Validation automatique suite à réindexation manuelle
Given existing pieces in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | ownerId            | status       | controlIterationAchieved |
| 8f8ee7cf-6f59-4338-8353-5735fd8933ea | 01740005814157951  | DP           |            1             | 
And existing indexes in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
| id                                   | code              | category | ownerIndex | referenceValue | correctedValue | groupLabel | indexable |
| 8f8ee7cf-6f59-4338-8353-5735f1111111 | 10000000000000002 | OB       | 1          | Jean           | Jean           | group1     | true      |
| e81d981b-3383-416f-81db-b2f11b21d59a | 10000000000000004 | OB       | 1          | Doe            |                | group1     | true      |
And groupIndexesValidation in type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7"> is <"true">
When I update CT a type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">
And  I expect status <"VA_AUTO"> for the type <"8f8ee7cf-6f59-4338-8353-5735fd8933e7">

