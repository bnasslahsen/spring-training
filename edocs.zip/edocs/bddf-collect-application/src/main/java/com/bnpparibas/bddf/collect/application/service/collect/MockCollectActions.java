package com.bnpparibas.bddf.collect.application.service.collect;

import java.io.IOException;
import java.io.InputStream;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.CollectDTO;
import com.bnpparibas.bddf.collect.application.dto.CollectDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.OwnerDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.type.FamilyCategory;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.config.SpringProfileConstants;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

@Profile(SpringProfileConstants.SPRING_PROFILE_MOCK)
@Primary
@Service
public class MockCollectActions implements CollectActions {
	private static final Logger LOG = LoggerFactory.getLogger(MockCollectActions.class);
	private static final String CLIENT_JOURNEY_CODES = "200001,200000,200,800,100,110000,110001,110";

	@Inject
	CollectValidator customValidator;

	@Inject
	private TypeValidator typeValidator;

	@Inject
	CustomMapper customMapper;

	@Inject
	private ResourceLoader resourceLoader;

	public MockCollectActions() {
		super();
	}

	@Override
	public List<CollectDTO> getAllManagedCollects(Context context) {
		return getCollects(CollectDetailsDTO.class).stream().map(c -> new CollectDTO(c.getId())).collect(Collectors.toList());
	}

	@Override
	public CollectAllDetailsDTO getCollect(UUID id, Context context) {
		final Optional<CollectAllDetailsDTO> collect = getCollects(CollectAllDetailsDTO.class).stream().filter(c -> c.getId().equals(id)).findFirst();
		return collect.isPresent() ? collect.get() : null;
	}

	@Override
	public Set<CollectDetailsDTO> getCollectsByOwners(List<String> references, List<String> journeyCodes, Context context) {
		return getCollects(CollectDetailsDTO.class).stream().filter(c -> {
			final List<String> refs = c.getOwners().stream().map(OwnerDTO::getReference).collect(Collectors.toList());
			refs.retainAll(references);
			return !refs.isEmpty() && c.getJourneyCode().equals(journeyCodes.get(0));
		}).collect(Collectors.toSet());
	}

	@Override
	public CollectDTO saveCollect(CollectAllDetailsDTO collectDTO, Context context) {

		final Collect collect = new Collect(null, null, Instant.now(), null, collectDTO.getEntityLabel(), collectDTO.getProductLabel(), collectDTO.getStepLabel(), collectDTO.getJourneyCode(), null, new HashSet<>(collectDTO.getPiecesManagementAct()),
				new HashSet<>(collectDTO.getFamiliesManagementAct()), new HashSet<>(collectDTO.getCollectManagementAct()), collectDTO.getSendingApplicationCode(), false, false, 0, false, 0);

		final List<Owner> owners = new ArrayList<>();
		collectDTO.getOwners().stream().map(o -> new Owner(o.getReference(), o.getName(), o.getFirstname(), o.getBirthDate(), Integer.valueOf(o.getNature()), o.getId(), o.getCommunicationTemplate())).forEach(owners::add);

		final Set<Type> types = new HashSet<>();
		collectDTO.getFamilies().forEach(f -> types.addAll(customMapper.convertFromFamilyDTO(f, false)));
		customValidator.validateCollect(collect);
		types.forEach(t -> typeValidator.validateType(t, null, collect, true));
		return new CollectDTO(UUID.randomUUID());
	}

	@Override
	public List<String> endCollect(UUID collectId, String status, Context context) {
		final List<String> alerts = new ArrayList<>();
		if (getCollects(CollectDTO.class).stream().noneMatch(c -> collectId.equals(c.getId()))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_NOT_FOUND, collectId.toString()));
		}

		final List<Type> types = getTypes(collectId);

		final Map<UUID, Set<Type>> typesByFamily = types.stream().collect(Collectors.groupingBy(Type::getFamilyId, LinkedHashMap::new, Collectors.toSet()));
		typesByFamily.forEach((k, typeList) -> {
			final Type family = types.stream().filter(t -> t.getFamilyId().equals(k)).findFirst().get();

			if (FamilyCategory.OB.name().equals(family.getFamilyCategory()) || FamilyCategory.IN.name().equals(family.getFamilyCategory())) {
				customValidator.validateFamily(collectId, family.getFamilyPropertyType(), typeList);
			} else if (FamilyCategory.DF.name().equals(family.getFamilyCategory())) {
				alerts.addAll(customValidator.validateFamilyWithAlert(family.getFamilyPropertyType(), typeList));
			}
		});
		return alerts;

	}

	private <T> List<T> getCollects(Class<T> type) {
		final Resource resource = resourceLoader.getResource("classpath:Collect.json");

		List<T> collecteDetailsDTO = new ArrayList<>();

		try {
			final InputStream collectFile = resource.getInputStream();
			final ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.findAndRegisterModules();
			objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			final JavaType t = objectMapper.getTypeFactory().constructCollectionType(List.class, type);
			collecteDetailsDTO = objectMapper.readValue(collectFile, t);

		} catch (final IOException e) {
			LOG.error(e.getMessage(), e);
		}
		return collecteDetailsDTO;

	}

	private List<Type> getTypes(UUID collectId) {
		final List<CollectAllDetailsDTO> collects = getCollects(CollectAllDetailsDTO.class);
		final Map<UUID, List<Type>> typesByCollect = new HashMap<>();
		collects.stream().forEach(c -> {
			final List<Type> typeList = new ArrayList<>();
			c.getFamilies().stream().forEach(f -> typeList.addAll(customMapper.convertFromFamilyDTO(f, false)));
			if (!typeList.isEmpty()) {
				typesByCollect.put(c.getId(), typeList);
			}
		});

		return typesByCollect.get(collectId);
	}

	@Override
	public void updateCollect(UUID collectId, CollectAllDetailsDTO collectDTO, Context context) {
		throw new UnsupportedOperationException();

	}

	@Override
	public Set<CollectDetailsDTO> getCollectsClient(Context context) {
		return getCollectsByOwners(Arrays.asList(context.getCustomerId()), Arrays.asList(CLIENT_JOURNEY_CODES.trim().split(",")), context);
	}

}
