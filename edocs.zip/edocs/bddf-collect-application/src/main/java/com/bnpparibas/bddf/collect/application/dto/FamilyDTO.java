package com.bnpparibas.bddf.collect.application.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;

import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * A DTO representing a Family
 */
@ApiModel
public class FamilyDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "Identifiant unique de la famille", required = true, readOnly = true, example = "8f8ee7cf-6f59-4338-8353-5735fd8933ea")
	private UUID id;

	@NotNull
	@ApiModelProperty(value = "Liste des références (minimum une référence) des propriétaires de la collecte dont la famille s'applique", required = true)
	private List<String> owners;

	@NotEmpty
	@NotNull
	@ApiModelProperty(value = "Nom de la famille", required = true)
	private String label;

	@NotEmpty
	@NotNull
	@ApiModelProperty(value = "Catégorie de la famille (à choisir parmi les actes de gestions autorisés)", required = true, allowableValues = "ND,DR,OB,DF,IN", example = "OB")
	private String category;

	@ApiModelProperty(value = "Commentaire de la catégorie de la famille. Obligatoire dans le cas d'une famille déja restituée (DR)")
	private String categoryComment;

	@NotEmpty
	@NotNull
	@ApiModelProperty(value = "Type de famille Liste (un seul type doit être validé) ou Fixe (tous les types doivent être validés)", required = true, allowableValues = "Liste,Fixe", example = "Liste")
	private String propertyType;

	@ApiModelProperty(value = "Code icon")
	private String iconCode;

	@ApiModelProperty(value = "Informations complémentaires.")
	private String additionalInformation;

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@Valid
	@ApiModelProperty(value = "Informations complémentaires Collaborateur.")
	private String additionalInformationCollab;

	@ApiModelProperty(value = "Position utilisé pour le tri")
	private int position;
	
	@ApiModelProperty(value = "la famille est bloquée car un évenement est en erreur")
	private boolean blocked;

	@ApiModelProperty(value = "Liste des actes de gestion autorisés pour les familles de documents parmi ND, DR, OB, DF et IN", required = true)
	private List<String> familiesManagementAct;

	@ApiModelProperty(value = "Liste des actes de gestion autorisés pour les pièces parmi DP, RC, VA et RF", required = true)
	private List<String> piecesManagementAct;

	@Valid
	@NotNull
	@ApiModelProperty(value = "Liste des types (minimum un type) de la famille", required = true)
	private List<TypeDTO> types;

	public FamilyDTO() {
		super();
	}

	public FamilyDTO(Type type, String channel) {
		this(type.getFamilyId(), new ArrayList<>(type.getFamilyOwners()), type.getFamilyLabel(), type.getFamilyCategory(), type.getFamilyCategoryComment(), type.getFamilyPropertyType(), type.getFamilyIconCode(), type.getFamilyAdditionalInformation(), null,
				type.getFamiliesManagementActFamily(), type.getFamilyPosition(), type.getPiecesManagementActFamily(), type.getFamilyAdditionalInformationCollab(), type.isFamilyBlocked(), channel);
	}

	public FamilyDTO(UUID id, List<String> owners, String label, String category, String categoryComment, String propertyType, String iconCode, String additionalInformation, List<TypeDTO> types, Set<String> familiesManagementActFamily, int familyPoisition,
			Set<String> piecesManagementActFamily, String additionalInformationCollab, boolean blocked, String channel) {
		super();
		final boolean isClient = Channel.isClient(channel);
		this.id = id;
		this.owners = owners.stream().sorted().collect(Collectors.toList());
		this.label = label;
		this.category = category;
		this.categoryComment = categoryComment;
		this.propertyType = propertyType;
		this.iconCode = iconCode;
		this.additionalInformation = additionalInformation;
		this.additionalInformationCollab = isClient ? null : getNotNullValue(additionalInformationCollab);
		this.position = familyPoisition;
		this.familiesManagementAct = Optional.ofNullable(familiesManagementActFamily).map(ArrayList<String>::new).orElse(new ArrayList<>());
		this.piecesManagementAct = Optional.ofNullable(piecesManagementActFamily).map(ArrayList<String>::new).orElse(new ArrayList<>());
		this.types = types;
		this.blocked = blocked;
	}

	private String getNotNullValue(String value) {
		return StringUtils.isEmpty(value) ? "" : value;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public List<String> getOwners() {
		return owners;
	}

	public void setOwners(List<String> owners) {
		this.owners = owners;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCategoryComment() {
		return categoryComment;
	}

	public void setCategoryComment(String categoryComment) {
		this.categoryComment = categoryComment;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public String getIconCode() {
		return iconCode;
	}

	public void setIconCode(String iconCode) {
		this.iconCode = iconCode;
	}

	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public List<TypeDTO> getTypes() {
		return types;
	}

	public void setTypes(List<TypeDTO> types) {
		this.types = types;
	}

	public List<String> getFamiliesManagementAct() {
		return familiesManagementAct;
	}

	public void setFamiliesManagementAct(List<String> familiesManagementAct) {
		this.familiesManagementAct = familiesManagementAct;
	}

	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("FamilyDTO [id=");
		builder.append(id);
		builder.append("]");
		return builder.toString();
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public List<String> getPiecesManagementAct() {
		return piecesManagementAct;
	}

	public void setPiecesManagementAct(List<String> piecesManagementAct) {
		this.piecesManagementAct = piecesManagementAct;
	}

	public String getAdditionalInformationCollab() {
		return additionalInformationCollab;
	}

	public void setAdditionalInformationCollab(String additionalInformationCollab) {
		this.additionalInformationCollab = additionalInformationCollab;
	}

	public boolean isBlocked() {
		return blocked;
	}

	public void setBlocked(boolean blocked) {
		this.blocked = blocked;
	}

}
