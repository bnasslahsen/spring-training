package com.bnpparibas.bddf.collect.application.dto;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel
public class UpdateDTO {

	@ApiModelProperty(value = "Date de mise à jour", readOnly = true, required = true)
	private ZonedDateTime updateDate;
	@ApiModelProperty(value = "Liste d'alerte(s)")
	private List<String> alerts;

	public UpdateDTO() {
		super();
	}

	public UpdateDTO(ZonedDateTime updateDate) {
		this.updateDate = updateDate;
	}

	public UpdateDTO(ZonedDateTime now, List<String> alerts) {
		this(now);
		this.alerts = alerts;
	}

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	public List<String> getAlerts() {
		return alerts;
	}

	public void setAlerts(List<String> alerts) {
		this.alerts = alerts;
	}

	public static UpdateDTO now() {
		return new UpdateDTO(ZonedDateTime.now());
	}

	public static UpdateDTO now(List<String> alerts) {
		return new UpdateDTO(ZonedDateTime.now(), alerts);
	}

	public ZonedDateTime getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(ZonedDateTime updateDate) {
		this.updateDate = updateDate;
	}

	@Override
	public String toString() {
		final int numberChar = 32;
		final StringBuilder builder = new StringBuilder(numberChar);
		builder.append("UpdateDTO [updateDate=");
		builder.append(updateDate);
		builder.append(", alerts=");
		builder.append(Optional.ofNullable(alerts).map(List::toArray).orElse(new Object[] {}));
		builder.append("]");
		return builder.toString();
	}

}
