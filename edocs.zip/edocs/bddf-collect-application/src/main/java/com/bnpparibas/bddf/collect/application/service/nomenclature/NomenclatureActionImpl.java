package com.bnpparibas.bddf.collect.application.service.nomenclature;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.domain.nomenclature.Nomenclature;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

/**
 *
 * Cette classe présente les Web Service Rest de la ressource Nomenclature
 * 
 */

@Service
@DDD.ApplicationService
public class NomenclatureActionImpl implements NomenclatureAction {

	@Autowired
	private NomenclatureService nomenclatureService;

	@Autowired
	private CustomMapper customMapper;

	@Override
	public List<NomenclatureDto> getNomemclature(Context context) {
		final List<Nomenclature> nomenclatures = nomenclatureService.findAll();
		return nomenclatures.stream().map(customMapper::toNomemclatureDto).collect(Collectors.toList());
	}

}
