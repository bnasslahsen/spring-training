package com.bnpparibas.bddf.collect.application.dto;

import java.io.Serializable;
import java.time.LocalDate;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * A DTO representing an Owner
 */
@ApiModel
public class OwnerDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	@NotNull
	@Size(max = 17, min = 17)
	@ApiModelProperty(value = "Identifiant unique de personne", required = true, example = "00004567890123456")
	private String reference;

	@NotEmpty
	@NotNull
	@ApiModelProperty(value = "Nom de la personne", required = true, example = "Dupond")
	private String name;

	@NotEmpty
	@NotNull
	@ApiModelProperty(value = "Prénom de la personne", required = true, example = "Jean")
	private String firstname;

	@ApiModelProperty(value = "Date de naissance de la personne")
	private LocalDate birthDate;

	@NotNull
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%02d")
	@Pattern(regexp = "01|02")
	@ApiModelProperty(value = "Nature de la personne", allowableValues = "01,02", required = true, example = "01")
	private String nature;

	@JsonIgnore
	private String id;

	@ApiModelProperty(value = "Template de communication")
	private String communicationTemplate;

	public OwnerDTO() {
		super();
	}

	public OwnerDTO(Owner owner) {
		this(owner.getReference(), owner.getName(), owner.getFirstname(), null != owner.getBirthDate() ? owner.getBirthDate() : null, String.format("%02d", owner.getNature()), owner.getId(), owner.getCommunicationTemplate());
	}

	public OwnerDTO(String reference, String name, String firstname, LocalDate birthdate, String nature, String id, String communicationTemplate) {
		super();
		this.reference = reference;
		this.name = name;
		this.firstname = firstname;
		this.birthDate = birthdate;
		this.nature = nature;
		this.id = id;
		this.communicationTemplate = communicationTemplate;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	@JsonIgnore
	public LocalDate getBirthDate() {
		return birthDate;
	}

	@JsonProperty
	public void setBirthDate(LocalDate birthDate) {
		this.birthDate = birthDate;
	}

	public String getNature() {
		return nature;
	}

	public void setNature(String nature) {
		this.nature = nature;
	}

	public String getCommunicationTemplate() {
		return communicationTemplate;
	}

	public void setCommunicationTemplate(String communicationTemplate) {
		this.communicationTemplate = communicationTemplate;
	}

	@Override
	public String toString() {
		final int number = 61;
		final StringBuilder builder = new StringBuilder(number);
		builder.append("OwnerDTO [reference=");
		builder.append(reference);
		builder.append(", name=");
		builder.append(name);
		builder.append(", firstname=");
		builder.append(firstname);
		builder.append(", birthDate=");
		builder.append(birthDate);
		builder.append(", nature=");
		builder.append(nature);
		builder.append("]");
		return builder.toString();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
