package com.bnpparibas.bddf.collect.application.dto;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * A DTO representing a collect
 */
@ApiModel(parent = CollectDetailsDTO.class)
public class CollectAllDetailsDTO extends CollectDetailsDTO {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "Liste des actes de gestion autorisés pour les familles de documents parmi ND,DR,OB,DF et IN", required = true)
	private List<String> familiesManagementAct;

	@ApiModelProperty(value = "Liste des formats de document autorisés", readOnly = true, required = true, example = "PDF")
	private List<String> allowedFile;

	@NotNull
	@ApiModelProperty(value = "Liste des actes de gestion autorisés pour les documents parmi VA,RC,RF et DP", required = true)
	private List<String> piecesManagementAct;

	@ApiModelProperty(value = "Liste des actes de gestion autorisés pour la colllecte parmi AB et CL", required = false)
	private List<String> collectManagementAct;

	@Valid
	@NotNull
	@ApiModelProperty(value = "Liste des familles de documents (minimum une famille)", required = true)
	private List<FamilyDTO> families;

	public CollectAllDetailsDTO() {
		super();
	}

	public CollectAllDetailsDTO(Collect collect) {
		super(collect);
		this.allowedFile = new ArrayList<>(collect.getAllowedFile());
		this.piecesManagementAct = new ArrayList<>(collect.getPiecesManagementAct());
		this.familiesManagementAct = new ArrayList<>(collect.getFamiliesManagementAct());
		this.collectManagementAct = collect.getCollectManagementActWithoutInit() != null ? new ArrayList<>(collect.getCollectManagementActWithoutInit()) : null;
	}

	public List<String> getAllowedFile() {
		return allowedFile;
	}

	public void setAllowedFile(List<String> allowedFile) {
		this.allowedFile = allowedFile;
	}

	public List<String> getPiecesManagementAct() {
		return piecesManagementAct;
	}

	public void setPiecesManagementAct(List<String> piecesManagementAct) {
		this.piecesManagementAct = piecesManagementAct;
	}

	public List<String> getFamiliesManagementAct() {
		return familiesManagementAct;
	}

	@JsonProperty
	public void setFamiliesManagementAct(List<String> familiesManagementAct) {
		this.familiesManagementAct = familiesManagementAct;
	}

	public List<FamilyDTO> getFamilies() {
		return families;
	}

	public void setFamilies(List<FamilyDTO> families) {
		this.families = families;
	}

	@JsonProperty
	public List<String> getCollectManagementAct() {
		return collectManagementAct;
	}

	public void setCollectManagementAct(List<String> collectManagementAct) {
		this.collectManagementAct = collectManagementAct;
	}

	@Override
	public String toString() {
		final int number = 31;
		final StringBuilder builder = new StringBuilder(number);
		builder.append("CollectAllDetailsDTO [getId()=");
		builder.append(getId());
		builder.append("]");
		return builder.toString();
	}

}
