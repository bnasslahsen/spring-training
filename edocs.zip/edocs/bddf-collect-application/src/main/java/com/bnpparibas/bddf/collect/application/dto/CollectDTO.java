package com.bnpparibas.bddf.collect.application.dto;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * A DTO representing a collect
 */
@ApiModel
public class CollectDTO {

	@NotNull
	@ApiModelProperty(value = "Identifiant unique de la collecte", readOnly = true, required = true, example = "8f8ee7cf-6f59-4338-8353-5735fd8933ea")
	private UUID id;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@ApiModelProperty(value = "Message d'alerte", readOnly = true, example = "Il existe au moins une collecte appartenant a un des titulaires [00004567890123456] pour le parcours 100001")
	private String alert;

	public CollectDTO(UUID id) {
		this.id = id;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getAlert() {
		return alert;
	}

	public void setAlert(String alert) {
		this.alert = alert;
	}

	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("CollectDTO [id=");
		builder.append(id);
		builder.append("]");
		return builder.toString();
	}

}