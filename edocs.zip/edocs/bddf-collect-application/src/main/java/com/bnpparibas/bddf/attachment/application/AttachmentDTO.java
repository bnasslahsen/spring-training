package com.bnpparibas.bddf.attachment.application;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.UUID;

public class AttachmentDTO {
	private UUID id;
	private Instant creationDate;
	private String userId;
	private String channel;
	private String sendingApplicationCode;
	private String fileName;
	private long fileSize;
	private String mimeType;
	private ByteBuffer file;

	public AttachmentDTO(UUID id, String userId, String sendingApplicationCode, String fileName, String mimeType, ByteBuffer file) {
		super();
		this.id = id;
		this.userId = userId;
		this.sendingApplicationCode = sendingApplicationCode;
		this.fileName = fileName;
		this.mimeType = mimeType;
		this.file = file;
	}

	public AttachmentDTO(String userId, String channel, String sendingApplicationCode, String fileName, String mimeType, long fileSize, ByteBuffer file) {
		super();
		this.userId = userId;
		this.channel = channel;
		this.sendingApplicationCode = sendingApplicationCode;
		this.fileName = fileName;
		this.mimeType = mimeType;
		this.fileSize = fileSize;
		this.file = file;
	}

	public AttachmentDTO(String fileName, String mimeType, ByteBuffer file) {
		super();
		this.fileName = fileName;
		this.mimeType = mimeType;
		this.file = file;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public Instant getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Instant creationDate) {
		this.creationDate = creationDate;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSendingApplicationCode() {
		return sendingApplicationCode;
	}

	public void setSendingApplicationCode(String sendingApplicationCode) {
		this.sendingApplicationCode = sendingApplicationCode;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getMimeType() {
		return mimeType;
	}

	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	public ByteBuffer getFile() {
		return file;
	}

	public void setFile(ByteBuffer file) {
		this.file = file;
	}

	public long getFileSize() {
		return fileSize;
	}

	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

}
