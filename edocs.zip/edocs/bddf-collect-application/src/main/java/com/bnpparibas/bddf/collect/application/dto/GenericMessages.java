package com.bnpparibas.bddf.collect.application.dto;

public enum GenericMessages {
	PLEASE_CONTACT("Veuillez contacter votre conseiller");

	private String label;

	GenericMessages(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}
}
