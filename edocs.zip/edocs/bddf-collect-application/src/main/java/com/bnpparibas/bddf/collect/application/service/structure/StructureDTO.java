package com.bnpparibas.bddf.collect.application.service.structure;

import java.util.ArrayList;
import java.util.List;


public class StructureDTO {
	 
		
	private String code;
	private String label;
	private List<EdocTypeDTO> types;

	public String getCode() {
		return code;
	}
	
	public List<EdocTypeDTO> getTypes() {
		if(types == null) {
			types = new ArrayList<>();
		}
		return types;
	}

	public void setTypes(List<EdocTypeDTO> edoctypesDTO) {
		this.types = edoctypesDTO;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public String getLabel() {
		return label;
	}
	
	public void setLabel(String label) {
		this.label = label;
	}
	
	
	
	

 
}
