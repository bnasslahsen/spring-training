package com.bnpparibas.bddf.collect.application.service.structure;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnp.schema.edoc_families.EdocFamilies.EdocFamily;
import com.bnp.schema.edoc_types_families.EdocFamiliesTypes.EdocFamilyTypes;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.domain.edoc.families.EdocFamiliesRepository;
import com.bnpparibas.bddf.collect.domain.edoc.families.types.EdocFamiliesTypesRepository;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@Service
@DDD.ApplicationService
public class StructureActionImpl implements StructureAction {

	@Autowired
	EdocFamiliesRepository edocFamiliesRepository;

	@Autowired
	EdocFamiliesTypesRepository edocFamiliesTypesRepository;

	@Autowired
	EdocTypeRepository edocTypeRepository;

	@Autowired
	CustomMapper customMapper;

	@Override
	public List<StructureDTO> getStructure(Context context) {
		final List<EdocFamily> edocFamilies = edocFamiliesRepository.findAll();
		final List<EdocFamilyTypes> edocFamilyTypes = edocFamiliesTypesRepository.findAll();
		final List<EdocType> edocTypes = edocTypeRepository.findAll();

		return customMapper.getStructureList(edocFamilies, edocFamilyTypes, edocTypes);
	}

}
