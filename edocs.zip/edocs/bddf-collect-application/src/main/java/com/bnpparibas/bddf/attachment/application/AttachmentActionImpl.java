package com.bnpparibas.bddf.attachment.application;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.attachment.domain.Attachment;
import com.bnpparibas.bddf.attachment.domain.AttachmentService;
import com.bnpparibas.bddf.rest.Context;

@Component
public class AttachmentActionImpl implements AttachmentAction {

	@Autowired
	private AttachmentService attachmentService;

	@Override
	public UUID addAttachment(AttachmentDTO attachmentDTO, Context context) {
		final Attachment attachment = new Attachment(attachmentDTO.getUserId(), attachmentDTO.getChannel(), attachmentDTO.getSendingApplicationCode(), attachmentDTO.getFileName(), attachmentDTO.getMimeType(), attachmentDTO.getFileSize());
		return attachmentService.addAttachment(attachment, attachmentDTO.getFile(), context);
	}

	@Override
	public String validateAttachment(UUID idAttachment, Context context) {
		return attachmentService.validateAttachment(idAttachment, context);
	}

	@Override
	public void deleteAttachment(UUID idAttachment, Context context) {
		attachmentService.deleteAttachment(idAttachment, context);

	}

	@Override
	public AttachmentDTO getAttachment(UUID idAttachment, Context context) {
		final Attachment attachment = attachmentService.getAttachment(idAttachment, context);
		return new AttachmentDTO(attachment.getFileName(), attachment.getMimeType(), attachment.getFile());
	}

}
