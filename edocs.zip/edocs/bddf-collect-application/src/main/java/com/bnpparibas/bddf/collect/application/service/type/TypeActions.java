package com.bnpparibas.bddf.collect.application.service.type;

import java.util.UUID;

import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.ApplicationService
public interface TypeActions {

	SubTypeDTO getType(UUID collectId, UUID typeId, Context context);

	boolean updateType(UUID idCollect, UUID idType, SubTypeDTO type, Context context) throws InterruptedException;

	UUID addType(UUID collectId, UUID familyId, TypeDTO typeDTO, Context context) throws InterruptedException;
	
	boolean deleteType(UUID idCollect, UUID idType, Context context);

}
