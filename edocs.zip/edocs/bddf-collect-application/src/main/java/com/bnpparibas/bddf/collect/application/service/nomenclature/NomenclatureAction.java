package com.bnpparibas.bddf.collect.application.service.nomenclature;

import java.util.List;

import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.ApplicationService
public interface NomenclatureAction {
	List<NomenclatureDto> getNomemclature(Context context);
}
