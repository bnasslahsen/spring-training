package com.bnpparibas.bddf.collect.application.service.structure;

import java.util.List;

import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.ApplicationService
public interface StructureAction {
	List<StructureDTO> getStructure(Context context);
}
