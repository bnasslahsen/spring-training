package com.bnpparibas.bddf.attachment.application;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel
public class ResponseAttachmentDTO {

	@ApiModelProperty(value = "Identifiant unique de fichier", example = "8f8ee7cf-6f59-4338-8353-5735fd8933ea")
	private String idAttachment;

	public ResponseAttachmentDTO(String idAttachment) {
		super();
		this.idAttachment = idAttachment;
	}

	public String getIdAttachment() {
		return idAttachment;
	}

	public void setIdAttachment(String idAttachment) {
		this.idAttachment = idAttachment;
	}

}
