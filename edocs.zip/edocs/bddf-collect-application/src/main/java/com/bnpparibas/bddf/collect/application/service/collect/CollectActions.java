package com.bnpparibas.bddf.collect.application.service.collect;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.CollectDTO;
import com.bnpparibas.bddf.collect.application.dto.CollectDetailsDTO;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.ApplicationService
public interface CollectActions {

	List<CollectDTO> getAllManagedCollects(Context context);

	CollectAllDetailsDTO getCollect(UUID id, Context context);

	Set<CollectDetailsDTO> getCollectsByOwners(List<String> references, List<String> journeyCodes, Context context);

	CollectDTO saveCollect(CollectAllDetailsDTO collect, Context context);

	List<String> endCollect(UUID collectId, String status, Context context);

	void updateCollect(UUID collectId, CollectAllDetailsDTO collectDTO, Context context);

	Set<CollectDetailsDTO> getCollectsClient(Context context);
}
