package com.bnpparibas.bddf.collect.application.service.family;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.security.CheckHabiltation;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.type.TypeService;
import com.bnpparibas.bddf.rest.Context;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

/**
 *
 * Cette classe présente les Web Service Rest de la ressource Family
 * 
 */

@Service
public class FamilyActionsImpl implements FamilyActions {

	private final TypeService typeService;
	private final CustomMapper customMapper;

	public FamilyActionsImpl(TypeService typeService, CustomMapper customMapper) {
		this.typeService = typeService;
		this.customMapper = customMapper;
	}

	@Override
	@CheckHabiltation(readOnly = false, paramNames = { "collectId", "families", "context" })
	public void updateFamilies(UUID colllectId, List<FamilyDTO> families, Context context) {
		typeService.updateFamilies(colllectId, families.stream().collect(Collectors.toMap(FamilyDTO::getId, f -> customMapper.toFamily(f))), context);
	}

	@Override
	@CheckHabiltation(readOnly = false, paramNames = { "collectId", "family", "context" })
	@HystrixCommand(commandKey = "addFamilyCmd", ignoreExceptions = { CollectBusinessException.class })
	public UUID addFamily(UUID colllectId, FamilyDTO family, Context context) throws InterruptedException {
		typeService.addFamily(colllectId, customMapper.convertFromFamilyDTO(family, false), context);
		return family.getId();
	}

	@Override
	@CheckHabiltation(readOnly = false, paramNames = { "collectId", "familyId", "context" })
	public void deleteFamily(UUID colllectId, UUID familyId, Context context) {
		typeService.deleteFamily(colllectId, familyId, context);
	}

}
