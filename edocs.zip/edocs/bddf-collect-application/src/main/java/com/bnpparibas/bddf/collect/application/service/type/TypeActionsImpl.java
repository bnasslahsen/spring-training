package com.bnpparibas.bddf.collect.application.service.type;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.security.CheckHabiltation;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeService;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.Sets;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

/**
 *
 * Cette classe présente les Web Service Rest de la ressource Type
 *
 */

@Service
public class TypeActionsImpl implements TypeActions {

	private final TypeService typeService;
	private final CustomMapper customMapper;

	public TypeActionsImpl(TypeService typeService, CustomMapper customMapper) {
		this.typeService = typeService;
		this.customMapper = customMapper;
	}

	@Override
	@CheckHabiltation(readOnly = true, paramNames = { "collectId", "typeId", "context" })
	public SubTypeDTO getType(UUID collectId, UUID typeId, Context context) {
		final boolean isClient = Channel.isClient(context.getCanal());
		final Type type = typeService.getType(collectId, typeId);
		SubTypeDTO typeDTO = null;
		if (type.isDisplayToClient() && isClient || !isClient) {
			final List<PieceDTO> pieces = type.getActivePieces().stream().map(p -> new PieceDTO(p, context.getCanal()))
					.sorted((p1, p2) -> Optional.ofNullable(p1.getUpdateDate()).orElse(p1.getAcquisitionDate()).compareTo(Optional.ofNullable(p2.getUpdateDate()).orElse(p2.getAcquisitionDate()))).collect(Collectors.toList());
			typeDTO = new SubTypeDTO(type, context.getCanal());
			typeDTO.setMaxSizeDoc(type.getMaxSizeDoc());
			typeDTO.setStatus(type.getStatus());
			typeDTO.setPieces(pieces);
			typeDTO.setEdocType(type.getEdocType());
			typeDTO.setEnableReuse(type.isEnableReuse());
		}
		return Optional.ofNullable(typeDTO).orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_CHANNEL, context.getCanal(), typeId.toString())));
	}

	@Override
	@CheckHabiltation(readOnly = false, paramNames = { "idCollect", "idType", "typeDTO", "context" })
	@HystrixCommand(commandKey = "updateTypeCmd", ignoreExceptions = { CollectBusinessException.class })
	public boolean updateType(UUID idCollect, UUID idType, SubTypeDTO typeDTO, Context context) throws InterruptedException {
		final Type type = new Type(typeDTO.getId(), null, null, null, null, null, null, null, null, null, typeDTO.getLabel(), typeDTO.getAdditionalInformation(), false, null, 0, 0, null, typeDTO.isPendingDocument(), typeDTO.getPendingDocumentLabel(),
				typeDTO.getStatus(), false, typeDTO.getStatusControl(), typeDTO.getPendingDocumentProfile(), typeDTO.isGroupIndexesValidation(), typeDTO.isDisplayCommentToClient(), typeDTO.getAdditionalInformationCollab(), null);
		final Set<Piece> pieces = new HashSet<>();
		if (Optional.ofNullable(typeDTO.getPieces()).isPresent()) {
			typeDTO.getPieces().forEach(p -> pieces.add(customMapper.convertFromPieceDTO(p)));
		}
		type.setPieces(pieces);
		final Set<Indexe> indexes = new HashSet<>();
		if (Optional.ofNullable(typeDTO.getIndexes()).isPresent()) {
			typeDTO.getIndexes().forEach(i -> indexes.add(customMapper.convertFromIndexDTO(i, true)));
		}
		type.setIndexes(indexes);

		typeService.updateType(idCollect, idType, type, context);

		return true;
	}

	@Override
	@CheckHabiltation(readOnly = false, paramNames = { "collectId", "familyId", "typeDTO", "context" })
	@HystrixCommand(commandKey = "addTypeCmd", ignoreExceptions = { CollectBusinessException.class })
	public UUID addType(UUID collectId, UUID familyId, TypeDTO typeDTO, Context context) throws InterruptedException {
		final List<Type> types = new ArrayList<>();
		final Type type = new Type(UUID.randomUUID(), null, familyId, null, null, null, null, null, null, null, typeDTO.getLabel(), typeDTO.getAdditionalInformation(), typeDTO.isDigitalAllowed(), typeDTO.getControlDocumentType(), 0,
				typeDTO.getControlRequired(), null, typeDTO.isPendingDocument(), typeDTO.getPendingDocumentLabel(), TypeStatus.IN.getLabel(), typeDTO.isPaperAllowed(), null, typeDTO.getPendingDocumentProfile(), typeDTO.isGroupIndexesValidation(),
				typeDTO.isDisplayCommentToClient(), typeDTO.getAdditionalInformationCollab(), null);
		type.setEdocType(typeDTO.getEdocType());
		type.setVideoCodingDelay(typeDTO.getVideoCodingDelay());
		type.setEnableReuse(typeDTO.isEnableReuse());
		type.setPosition(typeDTO.getPosition());
		if (typeDTO.getCompleteness() != null) {
			type.setCompleteness(Sets.newHashSet(typeDTO.getCompleteness()));
		}

		final Set<Indexe> indexes = new HashSet<>();
		if (Optional.ofNullable(typeDTO.getIndexes()).isPresent()) {
			typeDTO.getIndexes().forEach(i -> indexes.add(customMapper.convertFromIndexDTO(i, false)));
		}
		type.setIndexes(indexes);
		types.add(type);
		if (typeDTO.getSubTypes() != null) {
			typeDTO.getSubTypes().forEach(subTypeDTO -> {
				final Type subType = populateSubType(subTypeDTO, type, familyId);
				types.add(subType);
			});
		}
		typeService.addType(collectId, familyId, types, context);

		return type.getId();
	}

	private Type populateSubType(SubTypeDTO subTypeDTO, Type type, final UUID familyId) {
		final Type subType = new Type(UUID.randomUUID(), type.getId(), familyId, null, null, null, null, null, null, null, subTypeDTO.getLabel(), subTypeDTO.getAdditionalInformation(), type.isDigitalAllowed(), type.getControlDocumentType(), 0,
				type.getControlRequired(), null, subTypeDTO.isPendingDocument(), subTypeDTO.getPendingDocumentLabel(), TypeStatus.IN.getLabel(), type.isPaperAllowed(), null, type.getPendingDocumentProfile(), type.isGroupIndexesValidation(),
				type.isDisplayCommentToClient(), subTypeDTO.getAdditionalInformationCollab(), null);

		subType.setEnableReuse(type.isEnableReuse());
		subType.setPosition(subTypeDTO.getPosition());
		subType.setEdocType(type.getEdocType());
		subType.setVideoCodingDelay(type.getVideoCodingDelay());
		subType.setEnableReuse(type.isEnableReuse());

		if (subTypeDTO.getCompleteness() != null) {
			subType.setCompleteness(Sets.newHashSet(subTypeDTO.getCompleteness()));
		}
		final Set<Indexe> indexes = new HashSet<>();
		if (Optional.ofNullable(subTypeDTO.getIndexes()).isPresent()) {
			subTypeDTO.getIndexes().forEach(i -> indexes.add(customMapper.convertFromIndexDTO(i, false)));
		}
		subType.setIndexes(indexes);
		return subType;
	}

	@Override
	public boolean deleteType(UUID idCollect, UUID idType, Context context) {
		return typeService.deleteType(idCollect, idType, context);
	}

}
