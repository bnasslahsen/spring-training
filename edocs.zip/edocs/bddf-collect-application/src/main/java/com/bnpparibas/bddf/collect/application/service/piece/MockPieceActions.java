package com.bnpparibas.bddf.collect.application.service.piece;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDataDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDataMiniatureDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceRecivedFormat;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.config.SpringProfileConstants;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

@Profile(SpringProfileConstants.SPRING_PROFILE_MOCK)
@Primary
@Service
public class MockPieceActions implements PieceActions {

	private static final Logger LOG = LoggerFactory.getLogger(MockPieceActions.class);

	@Inject
	CollectValidator customValidator;

	@Inject
	PieceValidator pieceValidator;

	@Inject
	CustomMapper customMapper;

	@Inject
	private ResourceLoader resourceLoader;

	public MockPieceActions() {
		super();
	}

	private <T> List<T> getCollects(Class<T> type) {
		final Resource resource = resourceLoader.getResource("classpath:Collect.json");

		List<T> collecteDetailsDTO = new ArrayList<>();

		try {
			final InputStream collectFile = resource.getInputStream();
			final ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.findAndRegisterModules();
			objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			final JavaType t = objectMapper.getTypeFactory().constructCollectionType(List.class, type);
			collecteDetailsDTO = objectMapper.readValue(collectFile, t);

		} catch (final IOException e) {
			LOG.error(e.getMessage(), e);
		}
		return collecteDetailsDTO;

	}

	@Override
	public UUID addPiece(UUID collectId, UUID typeId, PieceDTO pieceDTO, ByteBuffer bytes, String contentType, Context context) {

		final Piece piece = customMapper.convertFromPieceDTO(pieceDTO);
		piece.setChannel(context.getCanal());
		final UUID pieceId = UUID.randomUUID();
		piece.setId(pieceId);
		if (piece.getReceivedFormat().equals(PieceRecivedFormat.NUM.name())) {
			piece.setStatus(PieceStatus.TP.getLabel());
		}

		piece.setAcquisitionDate(Instant.now());
		final CollectAllDetailsDTO collectDTO = getCollects(CollectAllDetailsDTO.class).stream().filter(c -> c.getId().equals(collectId)).findFirst()
				.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_NOT_FOUND, collectId.toString()))); // RG 76
		final Collect collect = new Collect(collectDTO.getId(), collectDTO.getCollectStatus(), collectDTO.getCreationDate().toInstant(), null, collectDTO.getEntityLabel(), collectDTO.getProductLabel(), null, collectDTO.getJourneyCode(),
				new HashSet<>(collectDTO.getAllowedFile()), new HashSet<>(collectDTO.getPiecesManagementAct()), new HashSet<>(collectDTO.getFamiliesManagementAct()), new HashSet<>(collectDTO.getCollectManagementAct()),
				collectDTO.getSendingApplicationCode(), false, false, 0, false, 0);
		final List<Type> typeByCollect = getTypes(collectId);
		if (typeByCollect.stream().anyMatch(t -> typeId.equals(t.getParentId()))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNAUTHORIZED, typeId.toString()));// RG 83
		}

		final List<Type> types = new ArrayList<>();
		collectDTO.getFamilies().forEach(f -> types.addAll(customMapper.convertFromFamilyDTO(f, false)));

		final int pieceNumber = 1;

		final Type type = types.stream().filter(t -> t.getId().equals(typeId)).findFirst()
				.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_NOT_FOUND, typeId.toString(), collectId.toString(), typeId.toString()))); // RG 80
		pieceValidator.validatePiece(piece, collect, type, contentType, "", pieceNumber);
		final List<Piece> pieces = getPieces(collectId);
		final boolean receivedFormatChanged = Optional.ofNullable(pieces.isEmpty() ? null : pieces.get(0)).map(p -> !p.getReceivedFormat().equals(piece.getReceivedFormat())).orElse(false);
		// RG 82
		if (!receivedFormatChanged && PieceRecivedFormat.PAP.name().equals(piece.getReceivedFormat()) && !pieces.isEmpty()) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_ONE_PIECE_AUTHORIZED, type.getId().toString()));
		}
		return piece.getId();
	}

	@Override
	public PieceDataDTO getPieceData(UUID collectId, UUID typeId, UUID pieceId, Context context) {
		final Piece piece = getPiece(collectId, pieceId).orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_NOT_FOUND, pieceId.toString(), collectId.toString(), typeId.toString(), pieceId.toString())));
		if (PieceStatus.TP.getLabel().equals(piece.getStatus()) && Channel.isClient(context.getCanal()) && !piece.getChannel().equals(context.getCanal())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_CHANNEL, context.getCanal(), piece.getLabel()));
		}
		PieceDataDTO pieceDTO = null;
		final int numberData = 1000;
		final ByteBuffer data = ByteBuffer.allocate(numberData);
		pieceDTO = new PieceDataDTO(piece, data, piece.getContentType(), context.getCanal());
		return pieceDTO;
	}

	@Override
	public boolean deletePiece(UUID collectId, UUID typeId, UUID pieceId, Context context) {

		final Piece piece = getPiece(collectId, pieceId).orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_NOT_FOUND, pieceId.toString(), collectId.toString(), typeId.toString(), pieceId.toString())));
		if (Channel.isClient(context.getCanal()) && !context.getCanal().equals(piece.getChannel())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_CHANNEL, piece.getLabel()));
		}
		return false;
	}

	@Override
	public void updatePieces(UUID collectId, UUID typeId, List<PieceDTO> piecesList, Context context) {

	}

	private Optional<Piece> getPiece(UUID collectId, UUID pieceId) {
		final List<CollectAllDetailsDTO> collects = getCollects(CollectAllDetailsDTO.class);
		final Map<UUID, List<Piece>> pieces = new HashMap<>();
		collects.stream().forEach(c -> {
			final List<Piece> pieceList = new ArrayList<>(customMapper.getAllPieceInCollectDTO(c.getFamilies()));
			if (!pieceList.isEmpty()) {
				pieces.put(c.getId(), pieceList);
			}
		});

		return pieces.get(collectId).stream().filter(p -> p.getId().equals(pieceId)).findFirst();
	}

	private List<Piece> getPieces(UUID collectId) {
		final List<CollectAllDetailsDTO> collects = getCollects(CollectAllDetailsDTO.class);
		final Map<UUID, List<Piece>> piecesByCollect = new HashMap<>();
		collects.stream().forEach(c -> {
			final List<Piece> pieceList = new ArrayList<>(customMapper.getAllPieceInCollectDTO(c.getFamilies()));
			if (!pieceList.isEmpty()) {
				piecesByCollect.put(c.getId(), pieceList);
			}
		});

		return piecesByCollect.get(collectId).stream().collect(Collectors.toList());
	}

	private List<Type> getTypes(UUID collectId) {
		final List<CollectAllDetailsDTO> collects = getCollects(CollectAllDetailsDTO.class);
		final Map<UUID, List<Type>> typesByCollect = new HashMap<>();
		collects.stream().forEach(c -> {
			final List<Type> typeList = new ArrayList<>();
			c.getFamilies().stream().forEach(f -> typeList.addAll(customMapper.convertFromFamilyDTO(f, false)));
			if (!typeList.isEmpty()) {
				typesByCollect.put(c.getId(), typeList);
			}
		});
		return typesByCollect.get(collectId);
	}

	@Override
	public PieceDataMiniatureDTO getThumbnail(UUID idCollect, UUID idType, UUID idPiece, Context context) {
		return null;
	}

}
