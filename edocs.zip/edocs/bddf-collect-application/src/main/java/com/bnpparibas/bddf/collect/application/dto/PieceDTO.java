package com.bnpparibas.bddf.collect.application.dto;

import java.io.Serializable;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;

import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.type.Profile;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * A DTO representing a Piece
 */

@ApiModel
public class PieceDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "Identifian unique du document", required = true, readOnly = true, example = "8f8ee7cf-6f59-4338-8353-5735fd8933ea")
	private UUID id;

	@NotNull(groups = { Collab.class, Client.class, Papier.class })
	@NotEmpty
	@ApiModelProperty(value = "Nom du document", required = true)
	private String label;

	@NotNull(groups = { Client.class })
	@ApiModelProperty(value = "Identifiant du client", readOnly = true)
	private String ownerId;

	@NotNull(groups = { Collab.class, Papier.class })
	@ApiModelProperty(value = "Identifiant du collaborateur", readOnly = true)
	private String employeeId;

	@ApiModelProperty(value = "Canal", readOnly = true, required = true, allowableValues = "001,004,007", example = "001")
	private String channel;

	@ApiModelProperty(value = "Date d'acquisition", readOnly = true, required = true)
	private ZonedDateTime acquisitionDate;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@ApiModelProperty(value = "Date de mise à jour", readOnly = true)
	private ZonedDateTime updateDate;

	@ApiModelProperty(value = "Taille du document")
	private long size;

	@NotNull(groups = { Collab.class, Client.class, Papier.class })
	@NotEmpty
	@ApiModelProperty(value = "Format de réception du document", readOnly = true, allowableValues = "NUM,PAP", example = "NUM")
	private String receivedFormat;

	@ApiModelProperty(value = "Statut du document", required = true, allowableValues = "TP,DP,DP_EC,VA,RC,RF,DP_err", example = "TP")
	private String status;

	@ApiModelProperty(value = "Raison de refus du document")
	private String rejectionReason;
	@ApiModelProperty(value = "Commentaire de refus du document")
	private String rejectionComment;
	@ApiModelProperty(value = "Profile du collaborateur qui refuse le document")
	private String rejectionProfile;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@ApiModelProperty(value = "Statut du controle du document", required = false)
	private String statusControl;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@ApiModelProperty(value = "Indicateur de reconnaissance")
	private String typeControl;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@ApiModelProperty(value = "Indicateur d'extraction des indexes")
	private String extractionControl;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@ApiModelProperty(value = "Indicateur de cohésion de données")
	private String coherenceControl;

	@ApiModelProperty(value = "Nombre d'itérations de contrôle automatique", required = false, readOnly = true)
	private int controlIterationAchieved;

	@ApiModelProperty(value = "Ordre d'ajout de la pièce", required = false, readOnly = true)
	private int position;
	
	@ApiModelProperty(value = "Afficher le commentaire de refus aux clients")
	private boolean displayCommentToClient;

	@JsonIgnore
	private List<String> typesJmc;

	public PieceDTO() {
		super();
	}

	public PieceDTO(Piece piece, String channel) {
		super();
		this.id = piece.getId();
		this.label = piece.getLabel();
		this.ownerId = piece.getOwnerId();
		this.employeeId = piece.getEmployeeId();
		this.channel = piece.getChannel();
		this.acquisitionDate = Optional.ofNullable(piece.getAcquisitionDate()).map(o -> ZonedDateTime.ofInstant(piece.getAcquisitionDate(), ZoneOffset.systemDefault())).orElse(null);
		this.updateDate = Optional.ofNullable(piece.getUpdateDate()).map(o -> ZonedDateTime.ofInstant(piece.getUpdateDate(), ZoneOffset.systemDefault())).orElse(null);
		this.size = piece.getSize();
		this.receivedFormat = piece.getReceivedFormat();
		this.status = piece.getStatus();
		this.typesJmc = piece.getTypesJmc();
		this.controlIterationAchieved = piece.getControlIterationAchieved();
		this.position = piece.getPosition();
		this.rejectionReason = piece.getRejectionReason();
		this.displayCommentToClient = piece.isDisplayCommentToClient();

		mapData(piece, channel);

	}

	private void mapData(Piece piece, String channel) {
		final boolean isClient = Channel.isClient(channel);
		if (StringUtils.isNotEmpty(piece.getRejectionComment()) && isClient && !piece.isDisplayCommentToClient() && Profile.BO.getLabel().equals(piece.getRejectionProfile())) {
			this.rejectionComment = GenericMessages.PLEASE_CONTACT.getLabel();
		} else {
			this.rejectionComment = piece.getRejectionComment();
		}
		this.rejectionProfile = isClient ? "" : piece.getRejectionProfile();
		this.statusControl = isClient ? null : getNotNullValue(piece.getStatusControl());
		this.coherenceControl = isClient ? null : getNotNullValue(piece.getCoherenceControl());
		this.extractionControl = isClient ? null : getNotNullValue(piece.getExtractionControl());
		this.typeControl = isClient ? null : getNotNullValue(piece.getTypeControl());
	}

	public List<String> getTypesJmc() {
		return typesJmc;
	}

	public void setTypesJmc(List<String> typesJmc) {
		this.typesJmc = typesJmc;
	}

	private String getNotNullValue(String value) {
		return StringUtils.isEmpty(value) ? "" : value;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public boolean isDisplayCommentToClient() {
		return displayCommentToClient;
	}

	public void setDisplayCommentToClient(boolean displayCommentToClient) {
		this.displayCommentToClient = displayCommentToClient;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public ZonedDateTime getAcquisitionDate() {
		return acquisitionDate;
	}

	public void setAcquisitionDate(ZonedDateTime acquisitionDate) {
		this.acquisitionDate = acquisitionDate;
	}

	public ZonedDateTime getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(ZonedDateTime updateDate) {
		this.updateDate = updateDate;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public String getReceivedFormat() {
		return receivedFormat;
	}

	public void setReceivedFormat(String receivedFormat) {
		this.receivedFormat = receivedFormat;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRejectionReason() {
		return rejectionReason;
	}

	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}

	public String getRejectionComment() {
		return rejectionComment;
	}

	public void setRejectionComment(String rejectionComment) {
		this.rejectionComment = rejectionComment;
	}

	public String getTypeControl() {
		return typeControl;
	}

	public void setTypeControl(String typeControl) {
		this.typeControl = typeControl;
	}

	public String getExtractionControl() {
		return extractionControl;
	}

	public void setExtractionControl(String extractionControl) {
		this.extractionControl = extractionControl;
	}

	public String getCoherenceControl() {
		return coherenceControl;
	}

	public void setCoherenceControl(String coherenceControl) {
		this.coherenceControl = coherenceControl;
	}

	public int getControlIterationAchieved() {
		return controlIterationAchieved;
	}

	public void setControlIterationAchieved(int controlIterationAchieved) {
		this.controlIterationAchieved = controlIterationAchieved;
	}

	public interface Collab {
	}

	public interface Client {
	}

	public interface Papier {

	}

	@Override
	public String toString() {
		final int number = 22;
		final StringBuilder builder = new StringBuilder(number);
		builder.append("PieceDTO [id=");
		builder.append(id);
		builder.append(", label=");
		builder.append(label);
		builder.append("]");
		return builder.toString();
	}

	public String getStatusControl() {
		return statusControl;
	}

	public void setStatusControl(String statusControl) {
		this.statusControl = statusControl;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public String getRejectionProfile() {
		return rejectionProfile;
	}

	public void setRejectionProfile(String rejectionProfile) {
		this.rejectionProfile = rejectionProfile;
	}

}
