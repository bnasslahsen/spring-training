package com.bnpparibas.bddf.attachment.application;

import java.util.UUID;

import com.bnpparibas.bddf.rest.Context;

public interface AttachmentAction {

	/**
	 * Add a file to the NAS
	 *
	 * @param attachmentDTO
	 * @return idAttachment
	 */
	UUID addAttachment(AttachmentDTO attachmentDTO, Context context);

	/**
	 * Send the temporary file to GDN and delete it in the NAS and the database
	 *
	 * @param idAttachment
	 * @param context
	 * @return idDocGDN
	 */
	String validateAttachment(UUID idAttachment, Context context);

	/**
	 * Delete file from NAS
	 *
	 * @param idAttachment
	 * @param context
	 */
	void deleteAttachment(UUID idAttachment, Context context);

	/**
	 * Get file from NAS
	 * 
	 * @param idAttachment
	 * @param context
	 * @return
	 */
	AttachmentDTO getAttachment(UUID idAttachment, Context context);

}
