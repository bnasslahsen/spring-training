package com.bnpparibas.bddf.collect.application.dto;

import java.io.Serializable;
import java.util.UUID;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * A DTO representing a Index
 */

@ApiModel
public class IndexDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "Identifiant unique du document", required = true, readOnly = true, example = "8f8ee7cf-6f59-4338-8353-5735fd8933ea")
	private UUID id;

	@NotNull
	@NotEmpty
	@ApiModelProperty(value = "Code de l'index", required = true)
	private String code;

	@ApiModelProperty(value = "Libellé de l'index")
	private String label;

	@NotNull(groups = { Collab.class, Client.class })
	@NotEmpty
	@ApiModelProperty(value = "Catégorie de l'index", required = true)
	private String category;

	@NotNull(groups = { Collab.class, Client.class })
	@ApiModelProperty(value = "Indexable", required = true)
	private boolean indexable;

	@ApiModelProperty(value = "Format de l'index")
	private String format;

	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	@ApiModelProperty(value = "Taille min de l'index")
	private Integer minSize;

	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	@ApiModelProperty(value = "Taille max de l'index")
	private Integer maxSize;

	@ApiModelProperty(value = "Valeur de référence")
	private String referenceValue;

	@ApiModelProperty(value = "Position de l'index")
	private int position;

	@ApiModelProperty(value = "Valeur extraite de JMC")
	private String extractedValue;

	@ApiModelProperty(value = "Valeur corrigée")
	private String correctedValue;

	@ApiModelProperty(value = "Résultat de control JMC", readOnly = true)
	private String statusControl;

	@ApiModelProperty(value = "Message de résultat de control JMC", readOnly = true)
	private String messageControl;

	@ApiModelProperty(value = "index du propriétaire de l'index si non renseigné mis à 1")
	private String ownerIndex;

	@ApiModelProperty(value = "Informations complémentaires")
	private String additionalInformation;

	@ApiModelProperty(value = "envoi à AMI")
	private boolean videoCoding;

	@ApiModelProperty(value = "libellé de groupe de l'index")
	private String groupLabel;

	public IndexDTO() {
		super();
		this.code = "";
		this.category = "";
		this.indexable = false;
		this.referenceValue = "";

	}

	public IndexDTO(Indexe index) {
		super();
		this.id = index.getId();
		this.code = index.getCode();
		this.label = index.getLabel();
		this.category = index.getCategory();
		this.indexable = index.isIndexable();
		this.referenceValue = index.getReferenceValue();
		this.position = index.getPosition();
		this.extractedValue = index.getExtractedValue();
		this.correctedValue = index.getCorrectedValue();
		this.statusControl = index.getStatusControl();
		this.messageControl = index.getMessageControl();
		this.ownerIndex = index.getOwnerIndex();
		this.format = index.getFormat();
		this.minSize = index.getMinSize();
		this.maxSize = index.getMaxSize();
		this.additionalInformation = index.getAdditionalInformation();
		this.videoCoding = index.isVideoCoding();
		this.groupLabel = index.getGroupLabel();
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public boolean isIndexable() {
		return indexable;
	}

	public void setIndexable(boolean indexable) {
		this.indexable = indexable;
	}

	public String getReferenceValue() {
		return referenceValue;
	}

	public void setReferenceValue(String referenceValue) {
		this.referenceValue = referenceValue;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public interface Collab {
	}

	public interface Client {
	}

	@Override
	public String toString() {
		final int number = 50;
		final StringBuilder builder = new StringBuilder(number);
		builder.append("IndexDTO [id=");
		builder.append(id);
		builder.append(", code=");
		builder.append(code);
		builder.append(", label=");
		builder.append(label);
		builder.append("]");
		return builder.toString();
	}

	public String getExtractedValue() {
		return extractedValue;
	}

	public void setExtractedValue(String extractedValue) {
		this.extractedValue = extractedValue;
	}

	public String getStatusControl() {
		return statusControl;
	}

	public void setStatusControl(String statusControl) {
		this.statusControl = statusControl;
	}

	public String getMessageControl() {
		return messageControl;
	}

	public void setMessageControl(String messageControl) {
		this.messageControl = messageControl;
	}

	public String getOwnerIndex() {
		return ownerIndex;
	}

	public void setOwnerIndex(String ownerIndex) {
		this.ownerIndex = ownerIndex;
	}

	public String getCorrectedValue() {
		return correctedValue;
	}

	public void setCorrectedValue(String correctedValue) {
		this.correctedValue = correctedValue;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public Integer getMinSize() {
		return minSize;
	}

	public Integer getMaxSize() {
		return maxSize;
	}

	public void setMinSize(Integer minSize) {
		this.minSize = minSize;
	}

	public void setMaxSize(Integer maxSize) {
		this.maxSize = maxSize;
	}

	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public boolean isVideoCoding() {
		return videoCoding;
	}

	public void setVideoCoding(boolean videoCoding) {
		this.videoCoding = videoCoding;
	}

	public String getGroupLabel() {
		return groupLabel;
	}

	public void setGroupLabel(String groupLabel) {
		this.groupLabel = groupLabel;
	}

}
