package com.bnpparibas.bddf.attachment.application;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel
public class ResponsePutAttachementDTO {

	@ApiModelProperty(value = "Identifiant unique de fichier dans GDN", example = "8f8ee7cf-6f59-4338-8353-5735fd8933ea")
	private String idGDN;

	public ResponsePutAttachementDTO(String idGDN) {
		super();
		this.idGDN = idGDN;
	}

	public String getIdGDN() {
		return idGDN;
	}

	public void setIdGDN(String idGDN) {
		this.idGDN = idGDN;
	}

}
