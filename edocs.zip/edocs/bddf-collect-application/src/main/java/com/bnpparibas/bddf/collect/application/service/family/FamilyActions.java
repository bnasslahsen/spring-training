package com.bnpparibas.bddf.collect.application.service.family;

import java.util.List;
import java.util.UUID;

import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.ApplicationService
public interface FamilyActions {

	void updateFamilies(UUID colllectId, List<FamilyDTO> families, Context context);

	UUID addFamily(UUID colllectId, FamilyDTO family, Context context) throws InterruptedException;

	void deleteFamily(UUID colllectId, UUID familyId, Context context);
}
