package com.bnpparibas.bddf.collect.application.service.piece;

import java.nio.ByteBuffer;
import java.util.List;
import java.util.UUID;

import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDataDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDataMiniatureDTO;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.ApplicationService
public interface PieceActions {

	UUID addPiece(UUID collectId, UUID typeId, PieceDTO pieceDTO, ByteBuffer bytes, String contentType, Context context) throws InterruptedException;

	void updatePieces(UUID collectId, UUID typeId, List<PieceDTO> piecesList, Context context) throws InterruptedException;

	boolean deletePiece(UUID collectId, UUID typeId, UUID pieceId, Context context);

	PieceDataDTO getPieceData(UUID collectId, UUID typeId, UUID pieceId, Context context);

	PieceDataMiniatureDTO getThumbnail(UUID collectId, UUID typeId, UUID pieceId, Context context);

}
