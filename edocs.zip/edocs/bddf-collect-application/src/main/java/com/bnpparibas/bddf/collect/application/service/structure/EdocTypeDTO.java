package com.bnpparibas.bddf.collect.application.service.structure;

public class EdocTypeDTO {
	private String code;
	private String label;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	
	
}
