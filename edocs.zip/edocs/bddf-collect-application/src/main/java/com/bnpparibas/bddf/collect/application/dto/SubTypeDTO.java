package com.bnpparibas.bddf.collect.application.dto;

import java.io.Serializable;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;

import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.type.Profile;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * A DTO representing a SubType
 */
@ApiModel
public class SubTypeDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "Identifiant unique du sous-type", required = true, readOnly = true, example = "8f8ee7cf-6f59-4338-8353-5735fd8933ea")
	private UUID id;

	@NotNull
	@NotEmpty
	@ApiModelProperty(value = "Nom du sous-type", required = true)
	private String label;

	@ApiModelProperty(value = "Informations complémentaires")
	private String additionalInformation;

	@Valid
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@ApiModelProperty(value = "Informations complémentaires Collaborateur.")
	private String additionalInformationCollab;

	@ApiModelProperty(value = "Boolean indiquant si le dépôt de documents au format numérique est autorisé", required = true, example = "true")
	private boolean digitalAllowed;

	@ApiModelProperty(value = "Boolean indiquant si le dépôt de documents au format papier est autorisé", required = true, example = "true")
	private boolean paperAllowed = true;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	@ApiModelProperty(value = "Taille maximale pour un document au format numérique", readOnly = true)
	private Long maxSizeDoc;

	@ApiModelProperty(value = "Position utilisé pour le tri")
	private int position;

	@ApiModelProperty(value = "Contrôle requis", required = true, example = "0", allowableValues = "0,1,2,3,4")
	private Integer controlRequired;

	@ApiModelProperty(value = "Date de contrôle du sous-type.", readOnly = true)
	private ZonedDateTime controlDate;

	@ApiModelProperty(value = "Indicateur de document manquant.", required = true)
	private boolean pendingDocument;

	@ApiModelProperty(value = "Commentaire obligatoire en cas d'indication de document manquant")
	private String pendingDocumentLabel;

	@ApiModelProperty(value = "Profil du collaborateur lors d'un document manquant")
	private String pendingDocumentProfile;

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private String edocType;

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private String status;

	@ApiModelProperty(value = "Boolean indiquant si le type est éligible à la réutilisation de pièce", required = false)
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private boolean enableReuse;

	@ApiModelProperty(value = "Statut de contrôle", readOnly = true)
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private String statusControl;

	@ApiModelProperty(value = "Indicateur completeness", readOnly = true)
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private String completenessControl;

	@ApiModelProperty(value = "Type de vidéocodage ou NotAllowed", readOnly = true)
	private String videoCodingDelay;

	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	@ApiModelProperty(value = "Réindexation simplifiée", readOnly = true)
	private boolean groupIndexesValidation;

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@ApiModelProperty(value = "Reconnaissance automatique des pièces non identifiées par JMC")
	private boolean autoRecognition;
	@Valid
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@ApiModelProperty(value = "Display To Client", readOnly = true, required = true)
	private Boolean displayToClient;

	@ApiModelProperty(value = "Afficher le commentaire de refus aux clients")
	private boolean displayCommentToClient;

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@ApiModelProperty(value = "Completeness")
	private List<String> completeness;

	@Valid
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@ApiModelProperty(value = "Liste des indexes du sous-type")
	private List<IndexDTO> indexes;

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@ApiModelProperty(value = "Liste des pièces du sous-type")
	private List<PieceDTO> pieces;

	public SubTypeDTO() {
		super();
	}

	public SubTypeDTO(Type type, String channel) {
		super();
		final boolean isClient = Channel.isClient(channel);
		this.id = type.getId();
		this.label = type.getLabel();
		this.additionalInformation = type.getAdditionalInformation();
		this.controlDate = null != type.getControlDate() ? ZonedDateTime.ofInstant(type.getControlDate(), ZoneOffset.systemDefault()) : null;

		this.pendingDocument = type.isPendingDocument();
		if (this.pendingDocument && isClient && !type.isDisplayCommentToClient() && Profile.BO.getLabel().equals(type.getPendingDocumentProfile())) {
			this.pendingDocumentLabel = GenericMessages.PLEASE_CONTACT.getLabel();
			this.pendingDocumentProfile = "";
		} else {
			this.pendingDocumentLabel = type.getPendingDocumentLabel();
			this.pendingDocumentProfile = type.getPendingDocumentProfile();
		}
		this.controlRequired = type.getControlRequired();
		this.digitalAllowed = type.isDigitalAllowed();
		this.paperAllowed = type.isPaperAllowed();
		this.indexes = Channel.isClient(channel) ? null : getNotNullIndexDTOList(toIndexDTO(type.getIndexes()));
		this.completeness = isClient ? null : getNotNullSetFromList(type.getCompleteness());
		this.statusControl = isClient ? null : getNotNullValue(type.getStatusControl());
		this.completenessControl = isClient ? null : getNotNullValue(type.getCompletenessControlLabel());
		this.displayToClient = type.isDisplayToClient();
		this.additionalInformationCollab = isClient ? null : getNotNullValue(type.getAdditionalInformationCollab());
		this.videoCodingDelay = type.getVideoCodingDelay();
		this.displayCommentToClient = type.isDisplayCommentToClient();
		this.position = type.getPosition();
	}

	private String getNotNullValue(String value) {
		return StringUtils.isEmpty(value) ? "" : value;
	}

	private List<IndexDTO> getNotNullIndexDTOList(List<IndexDTO> list) {
		return list != null ? new ArrayList<>(list) : new ArrayList<>();
	}

	private List<String> getNotNullSetFromList(Set<String> set) {
		return set != null ? new ArrayList<>(set) : new ArrayList<>();
	}

	private static List<IndexDTO> toIndexDTO(Set<Indexe> indexes) {
		return indexes.stream().map(IndexDTO::new).collect(Collectors.toList());
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public ZonedDateTime getControlDate() {
		return controlDate;
	}

	public void setControlDate(ZonedDateTime controlDate) {
		this.controlDate = controlDate;
	}

	public boolean isPendingDocument() {
		return pendingDocument;
	}

	public void setPendingDocument(boolean pendingDocument) {
		this.pendingDocument = pendingDocument;
	}

	public String getPendingDocumentLabel() {
		return pendingDocumentLabel;
	}

	public void setPendingDocumentLabel(String pendingDocumentLabel) {
		this.pendingDocumentLabel = pendingDocumentLabel;
	}

	public Long getMaxSizeDoc() {
		return maxSizeDoc;
	}

	public void setMaxSizeDoc(Long maxSizeDoc) {
		this.maxSizeDoc = maxSizeDoc;
	}

	public List<PieceDTO> getPieces() {
		return pieces;
	}

	public void setPieces(List<PieceDTO> pieces) {
		this.pieces = pieces;
	}

	public Integer getControlRequired() {
		return controlRequired;
	}

	public void setControlRequired(Integer controlRequired) {
		this.controlRequired = controlRequired;
	}

	public boolean isDigitalAllowed() {
		return digitalAllowed;
	}

	public void setDigitalAllowed(boolean digitalAllowed) {
		this.digitalAllowed = digitalAllowed;
	}

	public List<IndexDTO> getIndexes() {
		return indexes;
	}

	public void setIndexes(List<IndexDTO> indexes) {
		this.indexes = indexes;
	}

	public String getStatusControl() {
		return statusControl;
	}

	public void setStatusControl(String statusControl) {
		this.statusControl = statusControl;
	}

	@Override
	public String toString() {
		final int number = 24;
		final StringBuilder builder = new StringBuilder(number);
		builder.append("SubTypeDTO [id=");
		builder.append(id);
		builder.append(", label=");
		builder.append(label);
		builder.append("]");
		return builder.toString();
	}

	public List<String> getCompleteness() {
		return completeness;
	}

	public void setCompleteness(List<String> completeness) {
		this.completeness = completeness;
	}

	public String getCompletenessControl() {
		return completenessControl;
	}

	public void setCompletenessControl(String completenessControl) {
		this.completenessControl = completenessControl;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public String getEdocType() {
		return edocType;
	}

	public void setEdocType(String edocType) {
		this.edocType = edocType;
	}

	@JsonIgnore
	public boolean isEnableReuse() {
		return enableReuse;
	}

	@JsonProperty
	public void setEnableReuse(boolean enableReuse) {
		this.enableReuse = enableReuse;
	}

	public boolean isPaperAllowed() {
		return paperAllowed;
	}

	public void setPaperAllowed(boolean paperAllowed) {
		this.paperAllowed = paperAllowed;
	}

	public String getVideoCodingDelay() {
		return videoCodingDelay;
	}

	public void setVideoCodingDelay(String videoCodingDelay) {
		this.videoCodingDelay = videoCodingDelay;
	}

	public String getPendingDocumentProfile() {
		return pendingDocumentProfile;
	}

	public void setPendingDocumentProfile(String pendingDocumentProfile) {
		this.pendingDocumentProfile = pendingDocumentProfile;
	}

	public boolean isGroupIndexesValidation() {
		return groupIndexesValidation;
	}

	public void setGroupIndexesValidation(boolean groupIndexesValidation) {
		this.groupIndexesValidation = groupIndexesValidation;
	}

	public boolean isAutoRecognition() {
		return autoRecognition;
	}

	public void setAutoRecognition(boolean autoRecognition) {
		this.autoRecognition = autoRecognition;
	}

	public String getAdditionalInformationCollab() {
		return additionalInformationCollab;
	}

	public void setAdditionalInformationCollab(String additionalInformationCollab) {
		this.additionalInformationCollab = additionalInformationCollab;
	}

	public boolean isDisplayCommentToClient() {
		return displayCommentToClient;
	}

	public void setDisplayCommentToClient(boolean displayCommentToClient) {
		this.displayCommentToClient = displayCommentToClient;
	}

	public Boolean getDisplayToClient() {
		return displayToClient;
	}

	public void setDisplayToClient(Boolean displayToClient) {
		this.displayToClient = displayToClient;
	}

}
