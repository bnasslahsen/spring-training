package com.bnpparibas.bddf.collect.application.service.type;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.config.SpringProfileConstants;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

@Profile(SpringProfileConstants.SPRING_PROFILE_MOCK)
@Primary
@Service
public class MockTypeActions implements TypeActions {

	private static final Logger LOG = LoggerFactory.getLogger(MockTypeActions.class);

	@Inject
	CustomMapper customMapper;

	@Inject
	CollectValidator customValidator;

	@Inject
	private ResourceLoader resourceLoader;

	public MockTypeActions() {
		super();
	}

	private <T> List<T> getCollects(Class<T> type) {
		final Resource resource = resourceLoader.getResource("classpath:Collect.json");

		List<T> collecteDetailsDTO = new ArrayList<>();

		try {
			final InputStream collectFile = resource.getInputStream();
			final ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.findAndRegisterModules();
			objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			final JavaType t = objectMapper.getTypeFactory().constructCollectionType(List.class, type);
			collecteDetailsDTO = objectMapper.readValue(collectFile, t);

		} catch (final IOException e) {
			LOG.error(e.getMessage(), e);
		}
		return collecteDetailsDTO;

	}

	private Optional<Type> getType(UUID collectId, UUID typeId) {
		final List<CollectAllDetailsDTO> collects = getCollects(CollectAllDetailsDTO.class);
		final Map<UUID, List<Type>> typesByCollect = new HashMap<>();
		collects.stream().forEach(c -> {
			final List<Type> typeList = new ArrayList<>();
			c.getFamilies().stream().forEach(f -> typeList.addAll(customMapper.convertFromFamilyDTO(f, false)));
			if (!typeList.isEmpty()) {
				typesByCollect.put(c.getId(), typeList);
			}
		});

		return typesByCollect.get(collectId).stream().filter(t -> t.getId().equals(typeId)).findFirst();
	}

	private List<Piece> getPieces(UUID collectId) {
		final List<CollectAllDetailsDTO> collects = getCollects(CollectAllDetailsDTO.class);
		final Map<UUID, List<Piece>> piecesByCollect = new HashMap<>();
		collects.stream().forEach(c -> {
			final List<Piece> pieceList = new ArrayList<>(customMapper.getAllPieceInCollectDTO(c.getFamilies()));
			if (!pieceList.isEmpty()) {
				piecesByCollect.put(c.getId(), pieceList);
			}
		});

		return piecesByCollect.get(collectId).stream().collect(Collectors.toList());
	}

	@Override
	public SubTypeDTO getType(UUID collectId, UUID typeId, Context context) {
		Optional.ofNullable(getCollects(CollectAllDetailsDTO.class).stream().filter(c -> c.getId().equals(collectId)).findAny())
				.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_NOT_FOUND, collectId.toString())));
		final Type type = getType(collectId, typeId).orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_NOT_FOUND, typeId.toString(), collectId.toString(), typeId.toString())));
		final SubTypeDTO typeDTO = new SubTypeDTO(type, context.getCanal());
		final List<PieceDTO> pieces = new ArrayList<>();
		getPieces(collectId).stream().map(p -> new PieceDTO(p, context.getCanal())).forEach(pieces::add);
		typeDTO.setPieces(pieces);
		return typeDTO;
	}

	@Override
	public boolean updateType(UUID idCollect, UUID idType, SubTypeDTO typeDTO, Context context) {
		final Type updatedType = new Type(typeDTO.getId(), null, null, null, null, null, null, null, null, null, typeDTO.getLabel(), typeDTO.getAdditionalInformation(), false, null, 0, 0, null, typeDTO.isPendingDocument(),
				typeDTO.getPendingDocumentLabel(), false, null, false, false, typeDTO.getAdditionalInformationCollab(), null, true);
		final List<Piece> pieces = new ArrayList<>();
		if (Optional.ofNullable(typeDTO.getPieces()).isPresent()) {
			typeDTO.getPieces().forEach(p -> pieces.add(customMapper.convertFromPieceDTO(p)));
		}
		if (Channel.isClient(context.getCanal())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_CLIENT_CHANNEL)); // RG 72
		}
		final CollectAllDetailsDTO collect = getCollects(CollectAllDetailsDTO.class).stream().filter(c -> c.getId().equals(idCollect)).findAny()
				.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_NOT_FOUND, idCollect.toString())));
		if (CollectStatus.CL.name().equals(collect.getCollectStatus()) || CollectStatus.AB.name().equals(collect.getCollectStatus())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_CLOSED, collect.getCollectStatus(), idCollect.toString())); // RG 60
		}
		getType(idCollect, idType).orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_NOT_FOUND, idType.toString(), idCollect.toString(), idType.toString())));
		if (updatedType.isPendingDocument() && Optional.ofNullable(updatedType.getPendingDocumentLabel()).orElse("").isEmpty()) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_PENDING_COMMENT)); // RG 73
		}
		updateTypePart2(pieces);
		return true;
	}

	private void updateTypePart2(List<Piece> pieces) {
		pieces.stream().peek(p -> {
			if (PieceStatus.RF.getLabel().equals(p.getStatus())) {
				if (Optional.ofNullable(p.getRejectionReason()).orElse("").isEmpty()) {
					throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_REJECT_REASON, p.getLabel())); // RG 47
				} else if ("Autre".equals(p.getRejectionReason()) && Optional.ofNullable(p.getRejectionComment()).orElse("").isEmpty()) {
					throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_REJECT_COMMENT, p.getLabel())); // RG 49
				}
			}
		});
	}

	@Override
	public UUID addType(UUID collectId, UUID familyId, TypeDTO typeDTO, Context context) throws InterruptedException {
		return null;
	}

	@Override
	public boolean deleteType(UUID idCollect, UUID idType, Context context) {
		// TODO Auto-generated method stub
		return false;
	}

}
