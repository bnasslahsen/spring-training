package com.bnpparibas.bddf.collect.application.service.piece;

import java.nio.ByteBuffer;
import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDataDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDataMiniatureDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.security.CheckHabiltation;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceService;
import com.bnpparibas.bddf.rest.Context;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

/**
 *
 * Cette classe présente les Web Service Rest de la ressource Piece
 * 
 */

@Service
public class PieceActionsImpl implements PieceActions {

	private static final Logger LOG = LoggerFactory.getLogger(PieceActionsImpl.class);

	private final PieceService pieceService;
	private final CustomMapper customMapper;

	@Autowired
	private Environment environment;

	public PieceActionsImpl(PieceService pieceService, CustomMapper customMapper) {
		this.pieceService = pieceService;
		this.customMapper = customMapper;
	}

	@Override
	@CheckHabiltation(readOnly = false, paramNames = { "collectId", "typeId", "pieceDTO", "bytes", "contentType", "userId", "channel" })
	@HystrixCommand(commandKey = "addPieceCmd", ignoreExceptions = { CollectBusinessException.class })
	public UUID addPiece(UUID collectId, UUID typeId, PieceDTO pieceDTO, ByteBuffer bytes, String contentType, Context context) throws InterruptedException {
		final long startTimeActionsAddPiece = System.currentTimeMillis();
		final Piece piece = customMapper.convertFromPieceDTO(pieceDTO);
		piece.setChannel(context.getCanal());
		piece.setPosition(pieceDTO.getPosition());
		piece.setLabel(removeAccents(piece.getLabel()));
		final UUID id = pieceService.addPiece(collectId, typeId, piece, bytes, contentType, context);
		final long endTimeActionsAddPiece = System.currentTimeMillis();
		final long secondsActionsAddPiece = endTimeActionsAddPiece - startTimeActionsAddPiece;
		LoggerHelper.logForPerfTest(LOG, "Collecte : " + collectId + "Temps pour addPiece : " + secondsActionsAddPiece + " ms");
		return id;
	}

	@Override
	@CheckHabiltation(readOnly = true, paramNames = { "collectId", "typeId", "pieceId", "userId", "channel" })
	public PieceDataDTO getPieceData(UUID collectId, UUID typeId, UUID pieceId, Context context) {
		final long startTimeGetPiece = System.currentTimeMillis();
		final Pair<Piece, ByteBuffer> piece = pieceService.getPiece(collectId, typeId, pieceId, context);
		final long endTimeGetPiece = System.currentTimeMillis();
		final long secondsGetPiece = endTimeGetPiece - startTimeGetPiece;
		LoggerHelper.logForPerfTest(LOG, "Collecte : " + collectId + " Temps pour getPiece : " + secondsGetPiece + " ms");
		return new PieceDataDTO(piece.getLeft(), piece.getRight(), piece.getLeft().getContentType(), context.getCanal());
	}

	@Override
	@CheckHabiltation(readOnly = false, paramNames = { "collectId", "typeId", "pieceId", "context" })
	public boolean deletePiece(UUID collectId, UUID typeId, UUID pieceId, Context context) {
		final long startTimeDeletePiece = System.currentTimeMillis();
		final boolean isDeleted = pieceService.deletePiece(collectId, typeId, pieceId, context);
		final long endTimeDeletePiece = System.currentTimeMillis();
		final long secondsDeletePiece = endTimeDeletePiece - startTimeDeletePiece;
		LoggerHelper.logForPerfTest(LOG, "Collecte : " + collectId + " Temps pour deletePiece : " + secondsDeletePiece + " ms");
		return isDeleted;
	}

	@Override
	@CheckHabiltation(readOnly = false, paramNames = { "collectId", "typeId", "piecesList", "context" })
	@HystrixCommand(commandKey = "updatePiecesCmd", ignoreExceptions = { CollectBusinessException.class })
	public void updatePieces(UUID collectId, UUID typeId, List<PieceDTO> piecesList, Context context) throws InterruptedException {
		final long startTimeActionsSavePiece = System.currentTimeMillis();
		final Set<Piece> pieces = piecesList.stream().map(customMapper::convertFromPieceDTO).collect(Collectors.toSet());
		pieceService.updatePieces(collectId, typeId, pieces, context);
		final long endTimeActionsSavePiece = System.currentTimeMillis();
		final long secondsActionsSavePiece = endTimeActionsSavePiece - startTimeActionsSavePiece;
		LoggerHelper.logForPerfTest(LOG, "Collecte : " + collectId + " Temps pour savePiece : " + secondsActionsSavePiece + " ms");

	}

	@Override
	@CheckHabiltation(readOnly = true, paramNames = { "collectId", "typeId", "pieceId", "context" })
	public PieceDataMiniatureDTO getThumbnail(UUID collectId, UUID typeId, UUID pieceId, Context context) {
		return new PieceDataMiniatureDTO(pieceService.getThumbnail(collectId, typeId, pieceId, context.getCanal()));
	}
	
	public static String removeAccents(String text) {
		return text == null ? null : Normalizer.normalize(text, Form.NFD).replaceAll("[^\\p{ASCII}]", "");
	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

}
