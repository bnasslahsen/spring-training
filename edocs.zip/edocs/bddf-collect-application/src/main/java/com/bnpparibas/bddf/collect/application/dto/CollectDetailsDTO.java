package com.bnpparibas.bddf.collect.application.dto;

import java.io.Serializable;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.bnpparibas.bddf.collect.domain.collect.Collect;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * A DTO representing a collect
 */
@ApiModel
public class CollectDetailsDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "Identifiant unique de la collecte", required = true, readOnly = true, example = "8f8ee7cf-6f59-4338-8353-5735fd8933ea")
	private UUID id;

	@ApiModelProperty(value = "Statut de la collecte", required = true, readOnly = true, allowableValues = "EC,CL,AB", example = "EC")
	private String collectStatus;
	@ApiModelProperty(value = "Date de création de la collecte", required = true, readOnly = true)
	private ZonedDateTime creationDate;

	@ApiModelProperty(value = "Date de fin de la collecte (abandon ou clôture)", required = false, readOnly = true)
	private ZonedDateTime endDate;

	@ApiModelProperty(value = "Entité")
	private String entityLabel;

	@NotEmpty
	@NotNull
	@ApiModelProperty(value = "Offre produit", required = true)
	private String productLabel;

	@ApiModelProperty(value = "Libélé étape")
	private String stepLabel;

	@NotEmpty
	@NotNull
	@ApiModelProperty(value = "Code parcours", required = true)
	private String journeyCode;

	@NotEmpty
	@NotNull
	@ApiModelProperty(value = "Code de l'application appelante", required = true, example = "APXXXXX")
	private String sendingApplicationCode;

	@ApiModelProperty(value = "Projet", required = false)
	private String project;

	@ApiModelProperty(value = "Auto-validation", required = false)
	private boolean autoValidation;

	@ApiModelProperty(value = "Auto-acceptation", required = false)
	private boolean autoAcceptationAllowed;

	@ApiModelProperty(value = "Nombre d'itérations permis", required = false)
	private int controlIterationAllowed;

	@ApiModelProperty(value = "Délais de clôture", required = false)
	private int autoClosingDelay = -1;

	@ApiModelProperty(value = "Envoyer une notification au client", required = false)
	private boolean notifyOwners;

	@Valid
	@NotNull
	@ApiModelProperty(value = "Liste des propriétaires de la collecte", required = true)
	private List<OwnerDTO> owners;

	public CollectDetailsDTO() {
		super();
	}

	public CollectDetailsDTO(Collect collect) {
		this(collect.getId(), collect.getStatus(), ZonedDateTime.ofInstant(collect.getCreationDate(), ZoneId.systemDefault()), collect.getEndDate() != null ? ZonedDateTime.ofInstant(collect.getEndDate(), ZoneOffset.systemDefault()) : null,
				collect.getEntityLabel(), collect.getProductLabel(), collect.getStepLabel(), collect.getJourneyCode(), collect.getSendingApplicationCode(), collect.isAutoValidation(), collect.isAutoAcceptationAllowed(),
				collect.getControlIterationAllowed(), collect.getAutoClosingDelay(), collect.isNotifyOwners());
		this.project = collect.getProject();
	}

	public CollectDetailsDTO(UUID id, String collectStatus, ZonedDateTime creationDate, ZonedDateTime endDate, String entityLabel, String productLabel, String stepLabel, String journeyCode, String sendingApplicationCode, boolean autoValidation,
			boolean autoAcceptationAllowed, int controlIterationAllowed, int autoClosingDelay, boolean notifyOwners) {
		super();
		this.id = id;
		this.collectStatus = collectStatus;
		this.creationDate = creationDate;
		this.endDate = endDate;
		this.entityLabel = entityLabel;
		this.productLabel = productLabel;
		this.stepLabel = stepLabel;
		this.journeyCode = journeyCode;
		this.sendingApplicationCode = sendingApplicationCode;
		this.autoValidation = autoValidation;
		this.autoAcceptationAllowed = autoAcceptationAllowed;
		this.controlIterationAllowed = controlIterationAllowed;
		this.autoClosingDelay = autoClosingDelay;
		this.notifyOwners = notifyOwners;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getCollectStatus() {
		return collectStatus;
	}

	public void setCollectStatus(String collectStatus) {
		this.collectStatus = collectStatus;
	}

	public ZonedDateTime getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(ZonedDateTime creationDate) {
		this.creationDate = creationDate;
	}

	public ZonedDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(ZonedDateTime endDate) {
		this.endDate = endDate;
	}

	public String getEntityLabel() {
		return entityLabel;
	}

	public void setEntityLabel(String entityLabel) {
		this.entityLabel = entityLabel;
	}

	public String getProductLabel() {
		return productLabel;
	}

	public void setProductLabel(String productLabel) {
		this.productLabel = productLabel;
	}

	public String getStepLabel() {
		return stepLabel;
	}

	public void setStepLabel(String stepLabel) {
		this.stepLabel = stepLabel;
	}

	public String getJourneyCode() {
		return journeyCode;
	}

	public void setJourneyCode(String journeyCode) {
		this.journeyCode = journeyCode;
	}

	public String getSendingApplicationCode() {
		return sendingApplicationCode;
	}

	public void setSendingApplicationCode(String sendingApplicationCode) {
		this.sendingApplicationCode = sendingApplicationCode;
	}

	public List<OwnerDTO> getOwners() {
		return owners;
	}

	public void setOwners(List<OwnerDTO> owners) {
		this.owners = owners;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public boolean isAutoValidation() {
		return autoValidation;
	}

	public void setAutoValidation(boolean autoValidation) {
		this.autoValidation = autoValidation;
	}

	public boolean isAutoAcceptationAllowed() {
		return autoAcceptationAllowed;
	}

	public void setAutoAcceptationAllowed(boolean autoAcceptationAllowed) {
		this.autoAcceptationAllowed = autoAcceptationAllowed;
	}

	public int getControlIterationAllowed() {
		return controlIterationAllowed;
	}

	public void setControlIterationAllowed(int controlIterationAllowed) {
		this.controlIterationAllowed = controlIterationAllowed;
	}

	public int getAutoClosingDelay() {
		return autoClosingDelay;
	}

	public void setAutoClosingDelay(int autoClosingDelay) {
		this.autoClosingDelay = autoClosingDelay;
	}

	public boolean isNotifyOwners() {
		return notifyOwners;
	}

	public void setNotifyOwners(boolean notifyOwners) {
		this.notifyOwners = notifyOwners;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		return equalsPart2(obj);
	}

	private boolean equalsPart2(Object obj) {
		final CollectDetailsDTO other = (CollectDetailsDTO) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		final int number = 23;
		final StringBuilder builder = new StringBuilder(number);
		builder.append("CollectDetailsDTO [id=");
		builder.append(id);
		builder.append("]");
		return builder.toString();
	}

}
