package com.bnpparibas.bddf.collect.application.service.nomenclature;

public class NomenclatureDto {
	 
		
	private String code;
	private String value;
	private String label;
	
	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}
	
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}
	
	public String getLabel() {
		return label;
	}
	
	public void setLabel(String label) {
		this.label = label;
	}
	
	
	
	

 
}
