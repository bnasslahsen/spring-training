package com.bnpparibas.bddf.collect.application.service.collect;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.bnpparibas.bddf.collect.application.dto.CollectAllDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.CollectDTO;
import com.bnpparibas.bddf.collect.application.dto.CollectDetailsDTO;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.OwnerDTO;
import com.bnpparibas.bddf.collect.application.mapper.CustomMapper;
import com.bnpparibas.bddf.collect.application.security.CheckHabiltation;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectService;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.errors.TechnicalException;
import com.bnpparibas.bddf.rest.Context;

/**
 *
 * Cette classe présente les Web Service Rest de la ressource Collect
 *
 */

@Service
@DDD.ApplicationService
public class CollectActionsImpl implements CollectActions {

	private static final Logger LOG = LoggerFactory.getLogger(CollectActionsImpl.class);

	private final CollectService collectService;
	private final CustomMapper customMapper;

	@Autowired
	private Environment environment;

	public CollectActionsImpl(CollectService collectService, CustomMapper familyMapper) {
		this.collectService = collectService;
		this.customMapper = familyMapper;
	}

	@Override
	@CheckHabiltation(readOnly = true, paramNames = { "id", "context" })
	public CollectAllDetailsDTO getCollect(UUID id, Context context) {
		try {
			final long startTimeActionsGetCollect = System.currentTimeMillis();
			final Collect collect = collectService.getCollect(id);

			final List<OwnerDTO> ownersDTO = collect.getOwners().stream().sorted(Comparator.comparing(Owner::getName)).map(OwnerDTO::new).collect(Collectors.toList());
			final List<FamilyDTO> familiesDTO = customMapper.convertToFamilyDTO(collect.getTypes(), context.getCanal());

			final CollectAllDetailsDTO collectDetailsDTO = new CollectAllDetailsDTO(collect);
			collectDetailsDTO.setFamilies(familiesDTO);

			collectDetailsDTO.setOwners(ownersDTO);
			final long endTimeActionsGetCollect = System.currentTimeMillis();
			final long secondsActionsGetCollect = endTimeActionsGetCollect - startTimeActionsGetCollect;
			LoggerHelper.logForPerfTest(LOG, "Collecte : " + id + "Temps pour actions getCollect : " + secondsActionsGetCollect + " ms");
			return collectDetailsDTO;
		} catch (final Exception ex) {
			throw new TechnicalException(CollectErrorConstants.ERR_COL_TECH, ex);
		}

	}

	@Override
	public List<CollectDTO> getAllManagedCollects(Context context) {
		return collectService.getAllManagedCollects().stream().map(CollectDTO::new).collect(Collectors.toList());
	}

	@Override
	public Set<CollectDetailsDTO> getCollectsByOwners(List<String> references, List<String> journeyCodes, Context context) {
		final Set<Collect> collects = collectService.getCollectsByOwners(new HashSet<>(references), journeyCodes);

		final Set<CollectDetailsDTO> collectsDTO = new HashSet<>();
		collects.forEach(collect -> {
			final CollectDetailsDTO collectDetailsDTO = new CollectDetailsDTO(collect);
			collectDetailsDTO.setOwners(collect.getOwners().stream().map(OwnerDTO::new).collect(Collectors.toList()));
			collectsDTO.add(collectDetailsDTO);
		});
		return collectsDTO;
	}

	@Override
	public Set<CollectDetailsDTO> getCollectsClient(Context context) {
		final String journeyCodes = Optional.ofNullable(environment).map(s -> s.getProperty("param.getcollects-client-journey-codes")).orElse("");
		return getCollectsByOwners(Arrays.asList(context.getCustomerId()), Arrays.asList(journeyCodes.trim().split(",")), context);
	}

	@Override
	public CollectDTO saveCollect(CollectAllDetailsDTO collectDTO, Context context) {

		final long startTimeSaveCollect = System.currentTimeMillis();

		final Collect collect = mapDTOToCollect(collectDTO);

		final UUID collectId = collectService.addCollect(collect, context);
		final CollectDTO newCollect = new CollectDTO(collectId);
		final long endTimeSaveCollect = System.currentTimeMillis();
		final long secondsSaveCollect = endTimeSaveCollect - startTimeSaveCollect;
		LoggerHelper.logForPerfTest(LOG, "Collecte : " + collectId + " Temps pour saveCollect : " + secondsSaveCollect + " ms");
		return newCollect;
	}

	private Collect mapDTOToCollect(CollectAllDetailsDTO collectDTO) {
		final Collect collect = new Collect(null, null, null, null, collectDTO.getEntityLabel(), collectDTO.getProductLabel(), collectDTO.getStepLabel(), collectDTO.getJourneyCode(), customMapper.toSet(collectDTO.getAllowedFile()),
				customMapper.toSet(collectDTO.getPiecesManagementAct()), customMapper.toSet(collectDTO.getFamiliesManagementAct()), customMapper.toSetElseNull(collectDTO.getCollectManagementAct()), collectDTO.getSendingApplicationCode(),
				collectDTO.isAutoValidation(), collectDTO.isAutoAcceptationAllowed(), collectDTO.getAutoClosingDelay(), collectDTO.isNotifyOwners(), collectDTO.getControlIterationAllowed());
		collect.setProject(collectDTO.getProject());
		collect.setControlIterationAllowed(collectDTO.getControlIterationAllowed());
		collect.setOwners(collectDTO.getOwners().stream().map(o -> new Owner(o.getReference(), o.getName(), o.getFirstname(), o.getBirthDate(), Integer.valueOf(o.getNature()), o.getId(), o.getCommunicationTemplate())).collect(Collectors.toSet()));
		collect.setTypes(collectDTO.getFamilies().stream().map(f -> customMapper.convertFromFamilyDTO(f, false)).flatMap(Collection::stream).collect(Collectors.toSet()));
		collect.getTypes().stream().flatMap(type -> type.getIndexes().stream()).forEach(Indexe::initControls);
		return collect;
	}

	@Override
	@CheckHabiltation(readOnly = false, paramNames = { "collectId", "status", "context" })
	public List<String> endCollect(UUID collectId, String status, Context context) {
		return new ArrayList<>(collectService.endCollect(collectId, status, context));
	}

	@Override
	@CheckHabiltation(readOnly = false, paramNames = { "collectDTO", "collectDTO", "context" })
	public void updateCollect(UUID collectId, CollectAllDetailsDTO collectDTO, Context context) {
		final Collect updatedCollect = new Collect(collectDTO.getId(), collectDTO.getCollectStatus(), null, null, collectDTO.getEntityLabel(), collectDTO.getProductLabel(), collectDTO.getStepLabel(), collectDTO.getJourneyCode(), null,
				customMapper.toSet(collectDTO.getPiecesManagementAct()), customMapper.toSet(collectDTO.getFamiliesManagementAct()), customMapper.toSet(collectDTO.getCollectManagementAct()), collectDTO.getSendingApplicationCode(),
				collectDTO.isAutoValidation(), collectDTO.isAutoAcceptationAllowed(), collectDTO.getAutoClosingDelay(), collectDTO.isNotifyOwners(), collectDTO.getControlIterationAllowed());

		updatedCollect.setProject(collectDTO.getProject());
		if (CollectionUtils.isNotEmpty(collectDTO.getOwners())) {
			updatedCollect
					.setOwners(collectDTO.getOwners().stream().map(o -> new Owner(o.getReference(), o.getName(), o.getFirstname(), o.getBirthDate(), Integer.valueOf(o.getNature()), o.getId(), o.getCommunicationTemplate())).collect(Collectors.toSet()));
		}
		if (CollectionUtils.isNotEmpty(collectDTO.getFamilies())) {

			updatedCollect.setTypes(collectDTO.getFamilies().stream().map(f -> customMapper.convertFromFamilyDTO(f, false)).flatMap(Collection::stream).collect(Collectors.toSet()));
		}

		collectService.updateCollect(updatedCollect, collectId, context);

	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

}
