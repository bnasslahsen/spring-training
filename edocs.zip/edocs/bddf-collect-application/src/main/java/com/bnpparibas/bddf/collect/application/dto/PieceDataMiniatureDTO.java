package com.bnpparibas.bddf.collect.application.dto;

import java.io.Serializable;
import java.nio.ByteBuffer;

public class PieceDataMiniatureDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	private ByteBuffer content;

	public PieceDataMiniatureDTO() {
		super();
	}

	public PieceDataMiniatureDTO(ByteBuffer content) {
		this.content = content;
	}

	public ByteBuffer getContent() {
		return content;
	}

	public void setContent(ByteBuffer content) {
		this.content = content;
	}

}
