package com.bnpparibas.bddf.collect.application.security;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditEvent;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectService;
import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.ConnectedManager;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableMap;

@Aspect
public class SecurityInterceptor {

	@Inject
	private CollectService collectService;

	@Inject
	private CollectEventHandler collectEventHandler;

	@Inject
	private AuditGenerator auditGenerator;

	@Inject
	private EdocTypeRepository edocTypeRepository;

	static final Map<String, AuditValue> MY_MAP;

	static {
		MY_MAP = ImmutableMap.<String, AuditValue> builder().put("updateType", AuditValue.ERROR_UPDATE_TYPE).put("updateFamilies", AuditValue.ERROR_UPDATE_FAMILY).put("savePieces", AuditValue.ERROR_VALIDATE_TYPE)
				.put("deletePiece", AuditValue.ERROR_DELETE_PIECE).put("addPiece", AuditValue.ERROR_ADD_PIECE_NUM).build();
	}

	public SecurityInterceptor() {
		super();
	}

	@Before("execution(* com.bnpparibas.bddf.collect.application.service..*.*(..))")
	public void doChannelCheck(JoinPoint joinPoint) {
		final Object[] signatureArgs = joinPoint.getArgs();
		final Context context = (Context) signatureArgs[(signatureArgs.length) - 1];
		if (Arrays.stream(Channel.values()).map(Channel::getValue).noneMatch(c -> c.equals(context.getCanal()))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DATA_VALUE, "channel", context.getCanal()));
		}
	}

	@Before("execution(* com.bnpparibas.bddf.collect.exposition.web.rest.collab..*.*(..))")
	public void doChannelCheckCollab(JoinPoint joinPoint) {
		final String channel = ConnectedManager.get().getCanal();
		if (!Channel.isCollab(channel)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_CHANNEL_UNAUTHORIZED, channel));
		}
	}

	@Before("execution(* com.bnpparibas.bddf.collect.exposition.web.rest.client..*.*(..))")
	public void doChannelCheckClient(JoinPoint joinPoint) {
		final String channel = ConnectedManager.get().getCanal();
		if (!Channel.isClient(channel)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_CHANNEL_UNAUTHORIZED, channel));
		}
	}

	@Before("@annotation(com.bnpparibas.bddf.collect.application.security.CheckHabiltation) && @annotation(checkHabiltationAnnotation)")
	public void doHabilitationCheck(JoinPoint joinPoint, CheckHabiltation checkHabiltationAnnotation) {

		final Object[] signatureArgs = joinPoint.getArgs();

		final UUID idCollect = (UUID) signatureArgs[0];
		final Context context = (Context) signatureArgs[(signatureArgs.length) - 1];

		final Collect collect = collectService.getOnlyCollectById(idCollect);
		if (collect == null) {
			sendAudit(idCollect, context);
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_NOT_FOUND, idCollect.toString()));
		}

		final UUID idType = "idType".equals(checkHabiltationAnnotation.paramNames()[1]) ? (UUID) signatureArgs[1] : null;
		final String methodName = joinPoint.getSignature().getName();
		checkCollect(checkHabiltationAnnotation.readOnly(), collect, context, signatureArgs, idType, methodName);

		if (Channel.isClient(context.getCanal())) {
			final List<String> references = collect.getOwners().stream().map(Owner::getReference).collect(Collectors.toList());
			checkCollectHabilitation(collect, context, references, signatureArgs, idType, methodName);
		}
	}

	private AuditEvent buildAudit(final Object[] signatureArgs, final Collect collect, Context context, final UUID idType, final String methodName) {
		AuditEvent auditEvent = null;

		if ("endCollect".equals(methodName)) {
			final String status = (String) signatureArgs[1];
			if (CollectStatus.CL.name().equals(status)) {
				auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_CLOTURE_COLLECTE)
						// Collecte
						.setIdCollect(collect.getId()).setJourneyCode(collect.getJourneyCode());
			} else if (CollectStatus.AB.name().equals(status)) {
				auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_ABANDON_COLLECTE)
						// Collecte
						.setIdCollect(collect.getId()).setJourneyCode(collect.getJourneyCode());
			}

		} else {
			auditEvent = checkMethodName(signatureArgs, collect, context, idType, methodName);

		}
		return auditEvent;
	}

	private AuditEvent checkMethodName(Object[] signatureArgs, Collect collect, Context context, UUID idType, String methodName) {
		AuditEvent event = null;
		switch (methodName) {
		case "updateType":

			event = updateType(collect, context, idType);
			break;
		case "updateFamilies":
			event = auditGenerator.newAudit(context, AuditValue.ERROR_UPDATE_FAMILY, "")
					// Collecte
					.setIdCollect(collect.getId()).setJourneyCode(collect.getJourneyCode());
			break;
		case "addFamily":
			final String labelFamily = ((FamilyDTO) (signatureArgs[1])).getLabel();
			event = auditGenerator.newAudit(context, AuditValue.ERROR_ADD_FAMILY, labelFamily)
					// Collecte
					.setIdCollect(collect.getId()).setJourneyCode(collect.getJourneyCode());
			break;
		case "savePieces":
			event = auditGenerator.newAudit(context, AuditValue.ERROR_VALIDATE_TYPE, Optional.ofNullable(idType).map(Object::toString).orElse(""), collect.getTypes().stream().filter(t -> t.getId().equals(idType)).map(Type::getLabel).findAny().orElse(""))
					// Collecte
					.setIdCollect(collect.getId()).setJourneyCode(collect.getJourneyCode());
			break;
		case "deletePiece":
			event = auditGenerator.newAudit(context, AuditValue.ERROR_DELETE_PIECE, "", "", "")
					// Collecte
					.setIdCollect(collect.getId()).setJourneyCode(collect.getJourneyCode());
			break;
		case "addPiece":
			event = addPiece(signatureArgs, collect, context);
			break;
		default:
			// empty
			break;
		}
		return event;
	}

	private AuditEvent addPiece(Object[] signatureArgs, Collect collect, Context context) {
		final int numberArgs = 2;
		final PieceDTO pieceDTO = (PieceDTO) signatureArgs[numberArgs];
		AuditEvent event;
		if (("PAP").equals(pieceDTO.getReceivedFormat())) {
			event = auditGenerator.newAudit(context, AuditValue.ERROR_VALIDATE_TYPE, "", "")
					// Collecte
					.setIdCollect(collect.getId()).setJourneyCode(collect.getJourneyCode());
		} else {
			event = auditGenerator.newAudit(context, AuditValue.ERROR_ADD_PIECE_NUM, "", "")
					// Collecte
					.setIdCollect(collect.getId()).setJourneyCode(collect.getJourneyCode());

		}
		return event;
	}

	private AuditEvent updateType(Collect collect, Context context, UUID idType) {
		final Optional<Type> type = collect.getTypes().stream().filter(t -> t.getId().equals(idType)).findAny();
		return auditGenerator.newAudit(context, AuditValue.ERROR_UPDATE_TYPE, collect.getTypes().stream().filter(t -> t.getId().equals(idType)).map(Type::getLabel).findAny().orElse(""))
				// Collecte
				.setIdCollect(collect.getId()).setJourneyCode(collect.getJourneyCode())
				// Type
				.setIdType(idType).setEdocType(type.map(Type::getEdocType).orElse(null)).setTypeLabel(type.map(Type::getEdocType).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(null));
	}

	private void sendAudit(UUID idCollect, Context context) {
		final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.READ_COLLECT_ERROR, idCollect.toString())
				// Collecte
				.setIdCollect(idCollect);
		collectEventHandler.sendAuditEvent(auditEvent);
	}

	@AfterThrowing(pointcut = "execution(* com.bnpparibas.bddf.collect.application.service..*.*(..))", throwing = "e")
	public void onActionError(JoinPoint joinPoint, Throwable e) {
		if (e instanceof CollectBusinessException) {
			Optional.ofNullable(((CollectBusinessException) e).getAuditEvent()).ifPresent(event -> {
				event.setCodeError(e.getMessage());
				collectEventHandler.sendAuditEvent(event);
			});
		}

	}

	private void checkCollect(boolean readOnly, Collect collect, Context context, final Object[] signatureArgs, UUID typeId, String methodName) {
		if (readOnly) {
			if (Channel.isClient(context.getCanal()) && CollectStatus.AB.name().equals(collect.getStatus())) {
				throw new CollectBusinessException(buildAudit(signatureArgs, collect, context, typeId, methodName), new Builder(CollectErrorConstants.ERR_COL_COLLECT_ABANDONED, collect.getId().toString(), collect.getEndDate().toString())); // RG
			}
		} else {
			if (CollectStatus.CL.name().equals(collect.getStatus()) || CollectStatus.AB.name().equals(collect.getStatus())) {
				throw new CollectBusinessException(buildAudit(signatureArgs, collect, context, typeId, methodName), new Builder(CollectErrorConstants.ERR_COL_COLLECT_CLOSED, collect.getStatus(), collect.getId().toString())); // RG 60
			}

		}

	}

	private void checkCollectHabilitation(Collect collect, Context context, List<String> references, final Object[] signatureArgs, UUID typeId, String methodName) {
		if (!references.contains(context.getCustomerId())) {
			throw new CollectBusinessException(buildAudit(signatureArgs, collect, context, typeId, methodName), new Builder(CollectErrorConstants.ERR_HABLITATION_NOT_AUTHORIZED, context.getCustomerId(), collect.getId().toString()));
		}
	}

}