package com.bnpparibas.bddf.collect.application.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * Register the habilitation aspect ****
 *
 * @author FAB
 *
 */
@Configuration
@EnableAspectJAutoProxy
public class SecurityInterceptorConfiguration {

	public SecurityInterceptorConfiguration() {
		super();
	}

	@Bean
	public SecurityInterceptor securityInterceptor() {
		return new SecurityInterceptor();
	}

}
