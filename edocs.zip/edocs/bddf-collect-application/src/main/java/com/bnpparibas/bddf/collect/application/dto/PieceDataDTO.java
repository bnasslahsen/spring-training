package com.bnpparibas.bddf.collect.application.dto;

import java.nio.ByteBuffer;

import com.bnpparibas.bddf.collect.domain.piece.Piece;

import io.swagger.annotations.ApiModel;

@ApiModel
public class PieceDataDTO extends PieceDTO {

	private static final long serialVersionUID = 1L;

	private ByteBuffer content;

	private String contentType;

	public PieceDataDTO() {
		super();
	}

	public PieceDataDTO(Piece piece, ByteBuffer content, String contentType, String channel) {
		super(piece, channel);
		this.content = content;
		this.contentType = contentType;
	}

	public ByteBuffer getContent() {
		return content;
	}

	public void setContent(ByteBuffer content) {
		this.content = content;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	@Override
	public String toString() {
		final int number = 48;
		final StringBuilder builder = new StringBuilder(number);
		builder.append("PieceDataDTO [getId()=");
		builder.append(getId());
		builder.append(", getLabel()=");
		builder.append(getLabel());
		builder.append(", getSize()=");
		builder.append(getSize());
		builder.append("]");
		return builder.toString();
	}

}
