package com.bnpparibas.bddf.collect.application.security;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface CheckHabiltation {
	boolean readOnly();

	String[] paramNames() default "";
}