package com.bnpparibas.bddf.collect.application.mapper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnp.schema.edoc_families.EdocFamilies.EdocFamily;
import com.bnp.schema.edoc_types_families.EdocFamiliesTypes.EdocFamilyTypes;
import com.bnpparibas.bddf.collect.application.dto.FamilyDTO;
import com.bnpparibas.bddf.collect.application.dto.IndexDTO;
import com.bnpparibas.bddf.collect.application.dto.PieceDTO;
import com.bnpparibas.bddf.collect.application.dto.SubTypeDTO;
import com.bnpparibas.bddf.collect.application.dto.TypeDTO;
import com.bnpparibas.bddf.collect.application.service.nomenclature.NomenclatureDto;
import com.bnpparibas.bddf.collect.application.service.structure.EdocTypeDTO;
import com.bnpparibas.bddf.collect.application.service.structure.StructureDTO;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.nomenclature.Nomenclature;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

/**
 *
 * Cette classe fait le mapping entre les objets métiers et les objets DTO
 *
 */

@Component
public class CustomMapper {
	private static final Logger LOG = LoggerFactory.getLogger(CustomMapper.class);

	public Piece convertFromPieceDTO(PieceDTO pieceDTO) {
		final Piece piece = new Piece(null, pieceDTO.getLabel(), null, null, null, null, pieceDTO.getSize(), pieceDTO.getReceivedFormat(), null, null, pieceDTO.getRejectionReason(), pieceDTO.getRejectionComment(), pieceDTO.getTypeControl(),
				pieceDTO.getRejectionProfile(), pieceDTO.isDisplayCommentToClient());
		Optional.ofNullable(pieceDTO.getId()).ifPresent(piece::setId);
		Optional.ofNullable(pieceDTO.getStatus()).ifPresent(piece::setStatus);
		Optional.ofNullable(pieceDTO.getChannel()).ifPresent(piece::setChannel);
		Optional.ofNullable(pieceDTO.getOwnerId()).ifPresent(piece::setOwnerId);
		Optional.ofNullable(pieceDTO.getEmployeeId()).ifPresent(piece::setEmployeeId);
		Optional.ofNullable(pieceDTO.getAcquisitionDate()).ifPresent(acquisitionDate -> piece.setAcquisitionDate(acquisitionDate.toInstant()));
		Optional.ofNullable(pieceDTO.getUpdateDate()).ifPresent(updateDate -> piece.setUpdateDate(updateDate.toInstant()));
		Optional.ofNullable(pieceDTO.getTypesJmc()).ifPresent(typeJmc -> piece.setTypesJmc(typeJmc));
		return piece;
	}

	public Indexe convertFromIndexDTO(IndexDTO indexDTO, boolean keepId) {
		final Indexe index = new Indexe(null, indexDTO.getCode(), indexDTO.getLabel(), indexDTO.getCategory(), indexDTO.isIndexable(), indexDTO.getReferenceValue(), null, indexDTO.getCorrectedValue(), null, indexDTO.getPosition(), null, null,
				indexDTO.getOwnerIndex(), indexDTO.getAdditionalInformation(), indexDTO.isVideoCoding(), indexDTO.getGroupLabel());
		final UUID indexId = keepId ? indexDTO.getId() : UUID.randomUUID();
		index.setId(indexId);
		return index;
	}

	public Set<Piece> getAllPieceInCollectDTO(List<FamilyDTO> families) {
		return families.stream().filter(f -> null != f.getTypes()).map(FamilyDTO::getTypes).flatMap(List::stream).map(t -> Optional.ofNullable(t.getSubTypes())
				// type containg subtypes
				// get all subtype
				.map(subTypes -> subTypes.stream()
						// map sutypes to List<Piece>
						.map(st -> mapPieces(st.getPieces(), st.getId()))
						// collect in one list
						.flatMap(List::stream).collect(Collectors.toList()))
				// type without subtype
				.orElse(mapPieces(t.getPieces(), t.getId())))
				// Collect Stream<List<Piece>> into List<Piece>
				.flatMap(List::stream).collect(Collectors.toSet());
	}

	private List<Piece> mapPieces(List<PieceDTO> piecesToMap, UUID id) {
		LOG.debug("mapPieces with id {}", id);
		final List<Piece> pieces = new ArrayList<>();
		if (null != piecesToMap) {
			piecesToMap.forEach(p -> {
				final Piece piece = convertFromPieceDTO(p);
				piece.setId(p.getId());
				piece.setAcquisitionDate(p.getAcquisitionDate().toInstant());
				Optional.ofNullable(p.getUpdateDate()).ifPresent(updateDate -> piece.setUpdateDate(updateDate.toInstant()));
				piece.setStatus(p.getStatus());
				piece.setSize(p.getSize());
				pieces.add(piece);
			});
		}
		return pieces;
	}

	public Set<Type> convertFromFamilyDTO(FamilyDTO f, boolean keepId) {
		final Set<Type> types = new HashSet<>();
		final UUID familyId = keepId ? f.getId() : UUID.randomUUID();
		f.setId(familyId);
		if (f.getTypes() != null) {
			f.getTypes().forEach(t -> {
				final UUID typeId = UUID.randomUUID();
				final Type type = populateType(f, keepId, familyId, t, typeId);
				types.add(type);
				if (t.getSubTypes() != null) {
					t.getSubTypes().forEach(st -> {
						final UUID subTypeId = UUID.randomUUID();
						final Type subType = populateSubType(f, familyId, t, typeId, st, subTypeId);
						types.add(subType);
					});
				}

			});
		}
		return types;
	}

	private Type populateSubType(FamilyDTO f, final UUID familyId, TypeDTO t, final UUID typeId, SubTypeDTO st, final UUID subTypeId) {
		final Type subType = new Type(subTypeId, typeId, familyId, Optional.ofNullable(f.getOwners()).map(HashSet<String>::new).orElse(new HashSet<>()), f.getLabel(), f.getCategory(), f.getCategoryComment(), f.getPropertyType(), f.getIconCode(),
				f.getAdditionalInformation(), st.getLabel(), st.getAdditionalInformation(), t.isDigitalAllowed(), t.getControlDocumentType(), t.getMaxSizeDoc(), Optional.ofNullable(t.getControlRequired()).orElse(0), null, false, null, t.isPaperAllowed(),
				t.getPendingDocumentProfile(), t.isGroupIndexesValidation(), t.isDisplayCommentToClient(), f.getAdditionalInformationCollab(), t.getAdditionalInformationCollab(), Optional.ofNullable(t.isDisplayToClient()).orElse(true));
		subType.setEdocType(t.getEdocType());
		subType.setEnableReuse(t.isEnableReuse());
		subType.setStatus(t.getStatus());
		subType.setFamiliesManagementActFamily(toSet(f.getFamiliesManagementAct()));
		subType.setPiecesManagementActFamily(toSet(f.getPiecesManagementAct()));
		subType.setVideoCodingDelay(t.getVideoCodingDelay());
		if (st.getIndexes() != null && !st.getIndexes().isEmpty()) {
			subType.setIndexes(st.getIndexes().stream().map(ind -> convertFromIndexDTO(ind, false)).collect(Collectors.toSet()));
		}
		if (st.getCompleteness() != null) {
			subType.setCompleteness(Sets.newHashSet(st.getCompleteness()));
		}
		subType.setCompletenessControl(st.getCompletenessControl());
		subType.setStatusControl(st.getStatusControl());
		subType.setAdditionalInformationCollab(st.getAdditionalInformationCollab());
		return subType;
	}

	private Type populateType(FamilyDTO f, boolean keepId, final UUID familyId, TypeDTO t, final UUID typeId) {
		final Type type = new Type(typeId, null, familyId, Optional.ofNullable(f.getOwners()).map(HashSet<String>::new).orElse(new HashSet<>()), f.getLabel(), f.getCategory(), f.getCategoryComment(), f.getPropertyType(), f.getIconCode(),
				f.getAdditionalInformation(), t.getLabel(), t.getAdditionalInformation(), t.isDigitalAllowed(), t.getControlDocumentType(), t.getMaxSizeDoc(), Optional.ofNullable(t.getControlRequired()).orElse(0), null,
				keepId ? t.isPendingDocument() : false, keepId ? t.getPendingDocumentLabel() : null, t.isPaperAllowed(), t.getPendingDocumentProfile(), t.isGroupIndexesValidation(), t.isDisplayCommentToClient(), t.getAdditionalInformationCollab(),
				f.getAdditionalInformationCollab(), Optional.ofNullable(t.isDisplayToClient()).orElse(true));
		type.setEdocType(t.getEdocType());
		type.setEnableReuse(t.isEnableReuse());
		type.setDisplayToClient(Optional.ofNullable(t.isDisplayToClient()).orElse(true));
		type.setStatus(t.getStatus());
		type.setFamiliesManagementActFamily(toSet(f.getFamiliesManagementAct()));
		type.setPiecesManagementActFamily(toSet(f.getPiecesManagementAct()));
		type.setPosition(t.getPosition());
		type.setFamilyPosition(f.getPosition());
		type.setFamilyAdditionalInformationCollab(f.getAdditionalInformationCollab());
		type.setVideoCodingDelay(t.getVideoCodingDelay());
		type.setVideoCodingDelay(t.getVideoCodingDelay());
		if (t.getIndexes() != null) {
			type.setIndexes(t.getIndexes().stream().map(ind -> convertFromIndexDTO(ind, false)).collect(Collectors.toSet()));
		}
		if (t.getCompleteness() != null) {
			type.setCompleteness(Sets.newHashSet(t.getCompleteness()));
		}
		return type;
	}

	public List<FamilyDTO> convertToFamilyDTO(Set<Type> types, String channel) {
		if (CollectionUtils.isNotEmpty(types)) {

			final Set<String> refs = types.stream().map(Type::getFamilyOwners).flatMap(Collection::stream).collect(Collectors.toSet());
			final List<FamilyDTO> familiesDTO = new ArrayList<>();
			final Map<UUID, Map<UUID, List<Type>>> typeByFamille = types.stream().collect(Collectors.groupingBy(Type::getFamilyId, groupingByWithNullKeys(Type::getParentId)));
			typeByFamille.forEach((familyId, typesMap) -> {
				final UUID idFirstType = typesMap.keySet().iterator().next();
				final FamilyDTO familyDTO = new FamilyDTO(typesMap.get(idFirstType).get(0), channel);
				List<TypeDTO> typesList = new ArrayList<>();
				final Map<UUID, List<SubTypeDTO>> mapSousTypes = new HashMap<>();

				// --------------------------------------------------------
				typesMap(typesMap, typesList, mapSousTypes, channel);

				typesList.forEach(type -> type.setSubTypes(mapSousTypes.get(type.getId())));
				typesList = typeToAdd(typesList, channel);
				if (!typesList.isEmpty()) {
					familyDTO.setTypes(typesList.stream().sorted(typeComparator()).collect(Collectors.toList()));
					familiesDTO.add(familyDTO);
				}

			});
			return refs.stream().map(r -> familiesDTO.stream().filter(f -> f.getOwners().stream().anyMatch(ow -> r.equals(ow)))).flatMap(Function.identity()).distinct().sorted(familyComparator()).collect(Collectors.toList());
		}
		return new ArrayList<>();
	}

	private List<TypeDTO> typeToAdd(List<TypeDTO> types, String channel) {
		final boolean isClient = Channel.isClient(channel);
		final List<TypeDTO> typesList = new ArrayList<>();
		types.stream().forEach(type -> {
			if (type.isDisplayToClient() && isClient || !isClient) {
				typesList.add(type);
			}
		});
		return typesList;
	}

	private void typesMap(Map<UUID, List<Type>> typesMap, List<TypeDTO> typesList, Map<UUID, List<SubTypeDTO>> mapSousTypes, String channel) {
		typesMap.forEach((idParent, list) -> {

			if (idParent == null) {

				mapWithIdParrntNull(typesList, list, channel);
			} else {
				// On parcours une liste de sous type
				mapWithIdParentNotNull(mapSousTypes, idParent, list, channel);
			}

		});
	}

	private Comparator<FamilyDTO> familyComparator() {
		return (f1, f2) -> {
			int out;
			if (f1.getPosition() != f2.getPosition()) {
				out = Integer.compare(f1.getPosition(), f2.getPosition());
			} else if (f1.getOwners().size() != f2.getOwners().size()) {
				out = Integer.compare(f1.getOwners().size(), f2.getOwners().size());
			} else {
				if (f1.getOwners().size() == 1 && f2.getOwners().size() == 1 && !f1.getOwners().get(0).equals(f2.getOwners().get(0))) {
					out = f1.getOwners().get(0).compareTo(f2.getOwners().get(0));
				} else {
					out = f1.getLabel().compareTo(f2.getLabel());
				}
			}
			return out;
		};
	}

	private Comparator<TypeDTO> typeComparator() {
		return (t1, t2) -> {
			int out;
			if (t1.getPosition() == t2.getPosition()) {
				out = t1.getLabel().compareTo(t2.getLabel());

			} else {
				out = Integer.compare(t1.getPosition(), t2.getPosition());
			}
			return out;
		};
	}

	private void mapWithIdParentNotNull(Map<UUID, List<SubTypeDTO>> mapSousTypes, UUID idParent, List<Type> list, String channel) {
		// On parcours une liste de sous type
		final List<SubTypeDTO> subTypesList = new ArrayList<>();
		list.forEach(type -> {
			final SubTypeDTO st = new SubTypeDTO(type, channel);
			st.setStatus(type.getStatus());
			st.setEdocType(type.getEdocType());
			st.setEnableReuse(type.isEnableReuse());
			final List<PieceDTO> subTypePiecesList = new ArrayList<>();
			final Set<Piece> piecesList = type.getActivePieces();
			if (piecesList != null) {
				piecesList.forEach(piece -> {
					final PieceDTO pieceDTO = new PieceDTO(piece, channel);
					subTypePiecesList.add(pieceDTO);
				});

				st.setPieces(
						subTypePiecesList.stream().sorted((p1, p2) -> Optional.ofNullable(p1.getUpdateDate()).orElse(p1.getAcquisitionDate()).compareTo(Optional.ofNullable(p2.getUpdateDate()).orElse(p2.getAcquisitionDate()))).collect(Collectors.toList()));
			}
			setCollabSubType(channel, type, st);
			subTypesList.add(st);
		});
		mapSousTypes.put(idParent, subTypesList.stream().sorted(Comparator.comparing(SubTypeDTO::getLabel)).collect(Collectors.toList()));
	}

	private void setCollabSubType(String channel, Type type, final SubTypeDTO st) {
		if (!Channel.isClient(channel)) {
			final List<IndexDTO> typeIndexesList = new ArrayList<>();
			final Set<Indexe> indexesList = type.getIndexes();
			if (indexesList != null) {
				indexesList.forEach(index -> {
					final IndexDTO indexeDTO = new IndexDTO(index);
					typeIndexesList.add(indexeDTO);
				});
				st.setIndexes(typeIndexesList.stream().sorted((p1, p2) -> p1.getCode().compareTo(Optional.ofNullable(p2.getCode()).orElse(p2.getCode()))).collect(Collectors.toList()));
			}
			st.setCompleteness(Lists.newArrayList(Optional.ofNullable(type.getCompleteness()).orElse(new HashSet<>())));
			st.setCompletenessControl(type.getCompletenessControlLabel());
			st.setStatusControl(type.getStatusControl());
		}
	}

	private void mapWithIdParrntNull(List<TypeDTO> typesList, List<Type> list, String channel) {
		// On parcours une liste de type
		list.forEach(type -> {
			final TypeDTO t = new TypeDTO(type, channel);
			t.setEdocType(type.getEdocType());
			t.setStatus(type.getStatus());
			t.setPosition(type.getPosition());
			final List<PieceDTO> typePiecesList = new ArrayList<>();
			final Set<Piece> piecesList = type.getActivePieces();
			if (piecesList != null) {
				piecesList.forEach(piece -> {
					final PieceDTO pieceDTO = new PieceDTO(piece, channel);
					typePiecesList.add(pieceDTO);
				});
				t.setPieces(
						typePiecesList.stream().sorted((p1, p2) -> Optional.ofNullable(p1.getUpdateDate()).orElse(p1.getAcquisitionDate()).compareTo(Optional.ofNullable(p2.getUpdateDate()).orElse(p2.getAcquisitionDate()))).collect(Collectors.toList()));
			}
			setCollabType(channel, type, t);
			typesList.add(t);
		});
	}

	private void setCollabType(String channel, Type type, final TypeDTO t) {
		if (!Channel.isClient(channel)) {
			final List<IndexDTO> typeIndexesList = new ArrayList<>();
			final Set<Indexe> indexesList = type.getIndexes();
			if (indexesList != null) {
				indexesList.forEach(index -> {
					final IndexDTO indexeDTO = new IndexDTO(index);
					typeIndexesList.add(indexeDTO);
				});
				t.setIndexes(typeIndexesList.stream().sorted((p1, p2) -> p1.getCode().compareTo(Optional.ofNullable(p2.getCode()).orElse(p2.getCode()))).collect(Collectors.toList()));
			}
			t.setCompleteness(Lists.newArrayList(Optional.ofNullable(type.getCompleteness()).orElse(new HashSet<>())));
		}
	}

	/* Like Collectors.groupingBy, but accepts null keys. */
	public static <T, A> Collector<T, ?, Map<A, List<T>>> groupingByWithNullKeys(Function<? super T, ? extends A> classifier) {
		return Collectors.toMap(classifier, Collections::singletonList, (List<T> oldList, List<T> newEl) -> {
			final List<T> newList = new ArrayList<>(oldList.size() + 1);
			newList.addAll(oldList);
			newList.addAll(newEl);
			return newList;
		});
	}

	public Type toFamily(FamilyDTO f) {
		final Type t = new Type();
		t.setFamilyId(f.getId());
		t.setFamilyCategory(f.getCategory());
		t.setFamilyCategoryComment(f.getCategoryComment());
		t.setFamiliesManagementActFamily(toSet(f.getFamiliesManagementAct()));
		t.setPiecesManagementActFamily(toSet(f.getPiecesManagementAct()));
		t.setAdditionalInformationCollab(f.getAdditionalInformationCollab());
		return t;
	}

	public <T> Set<T> toSet(List<T> list) {
		return Optional.ofNullable(list).map(HashSet<T>::new).orElse(new HashSet<T>());
	}

	public <T> Set<T> toSetElseNull(List<T> list) {
		return Optional.ofNullable(list).map(HashSet<T>::new).orElse(null);
	}

	public NomenclatureDto toNomemclatureDto(Nomenclature nm) {
		final NomenclatureDto dto = new NomenclatureDto();
		dto.setCode(nm.getEdoc());
		dto.setValue(nm.getCode());
		dto.setLabel(nm.getLabel());

		return dto;
	}

	public Nomenclature toNomemclature(NomenclatureDto dto) {
		final Nomenclature nomenclature = new Nomenclature();
		nomenclature.setEdoc(dto.getCode());
		nomenclature.setCode(dto.getValue());
		nomenclature.setLabel(dto.getLabel());

		return nomenclature;
	}

	public List<StructureDTO> getStructureList(List<EdocFamily> edocFamilies, List<EdocFamilyTypes> edocFamilyTypes, List<EdocType> edocTypes) {
		final List<StructureDTO> structuresDTO = new ArrayList<>();
		edocFamilyTypes.forEach(edocFamilyTypesL -> {
			final StructureDTO structureDTO = new StructureDTO();
			final String familyCode = edocFamilyTypesL.getFamilyCode();
			final Optional<String> familyLabelOpt = edocFamilies.stream().filter(edocFamily -> edocFamily.getCode().equals(familyCode)).findAny().map(EdocFamily::getLabel);
			if (familyLabelOpt.isPresent()) {
				final String familyLabel = familyLabelOpt.get();
				structureDTO.setCode(familyCode);
				structureDTO.setLabel(familyLabel);
				edocFamilyTypesL.getEdocTypes().getCode().forEach(edocCodeL -> {
					populateStructureDTO(edocTypes, structureDTO, edocCodeL);
				});
				structuresDTO.add(structureDTO);
			} else {
				LOG.error("familyCode : " + familyCode + " from edoc-families-types.xml not found in edoc-families.xml");
			}
		});
		return structuresDTO;
	}

	private void populateStructureDTO(List<EdocType> edocTypes, StructureDTO structureDTO, String edocCodeL) {
		final String edocCode = edocCodeL;
		final Optional<String> edocLabelOpt = edocTypes.stream().filter(edocTypeL -> edocTypeL.getValue().equals(edocCode)).findAny().map(EdocType::getLabel);
		if (edocLabelOpt.isPresent()) {
			final String edocLabel = edocLabelOpt.get();

			final EdocTypeDTO edocTypeDTO = new EdocTypeDTO();
			edocTypeDTO.setCode(edocCode);
			edocTypeDTO.setLabel(edocLabel);

			structureDTO.getTypes().add(edocTypeDTO);

		} else {
			LOG.error("edoctypeCode : " + edocCode + " from edoc-families-types.xml not found in edoctype.xml");
		}
	}

}
