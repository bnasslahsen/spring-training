package com.bnpparibas.bddf.collect.domain.collect;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.collect.params.PiecesStatusActionsImpl;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.ladrad.LadRadValidator;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureServiceImpl;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceRecivedFormat;
import com.bnpparibas.bddf.collect.domain.piece.PieceServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadService;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;

public class PieceServiceTest extends AbstractServiceTest {

	private PieceServiceImpl pieceService;
	private PieceGdnServiceImpl pieceGdnService;
	private AuditGenerator auditGenerator;
	private EdocTypeRepository edocTypeRepository;
	private PieceAutomaticControlUtils pieceAutomaticControlUtils;
	private DocReferenceServiceImpl docReferenceService = new DocReferenceServiceImpl();

	@Override
	public void prepareDatas() throws Exception {
		pieceGdnRepository = mock(PieceGdnRepository.class);
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		final Environment environment = mock(Environment.class);
		final TypeLadRadService typeLadRadService = mock(TypeLadRadService.class);
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		final NomenclatureService nomenclatureService = mock(NomenclatureServiceImpl.class);
		final TypeValidator typeValidator = new TypeValidator();
		final CollectValidator customValidator = new CollectValidator();
		final PieceValidator pieceValidator = new PieceValidator();
		final PiecesStatusActionsRepository piecesStatusActionsRepository = new PiecesStatusActionsImpl();
		pieceValidator.setPieceStatusRepository(piecesStatusActionsRepository);

		edocTypeRepository = new EdocTypesRepositoryImpl();
		final LadRadValidator ladRadValidator = new LadRadValidator();
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(false);
		final TypeAutomaticControlServiceImpl typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, typeValidator, nomenclatureService, new EdocIndexRepositoryImpl(), featureManager, pieceRepository,
				pieceGdnRepository, ladRadValidator, edocTypeRepository, typeRepository, docReferenceService, new TypeAutomaticControlUtils());
		typeAutomaticControlService.setCollectRepository(collectRepository);
		pieceGdnService = new PieceGdnServiceImpl(collectRepository, typeRepository, pieceRepository, pieceGdnRepository, collectEventHandler, auditGenerator, edocTypeRepository, nomenclatureService);
		pieceGdnService.setDocReferenceService(docReferenceService);
		pieceGdnService.setFeatureManager(featureManager);
		pieceAutomaticControlUtils = new PieceAutomaticControlUtils(pieceGdnService, typeAutomaticControlService);
		pieceService = new PieceServiceImpl(collectRepository, typeRepository, pieceRepository, customValidator, collectEventHandler, pieceGdnService, auditGenerator, environment, typeAutomaticControlService, featureManager, pieceAutomaticControlUtils);
		pieceService.setBlackListJmcFormat("");
		final EdocTypeRepository edocTypeRepository = mock(EdocTypeRepository.class);
		pieceService.setEdocTypeRepository(edocTypeRepository);
		pieceService.setPieceValidator(pieceValidator);
		when(pieceGdnRepository.savePiece(any(), any(), any(), any(), any(), any())).thenReturn("idDocGdn");
	}

	@Test
	public void addPieceFailsOnSizeMaxLimitTest() throws InterruptedException {
		final Piece p = pieceRepository.getPiece(collectId, typeOBListeId, pieceId);
		p.setSize(1000001);
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_SIZE_MAX);
		pieceService.addPiece(collectId, typeOBListeId, p, null, "application/pdf", new Context("123456", Channel.SPIRIT.getValue(), "001"));
	}

	@Test
	public void addPieceFailsOnMaxPiecesTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_NUMBER);
		pieceService.addPiece(collectId, typeWith5PiecesId, pieceToAdd, null, "application/pdf", new Context("123456", Channel.SPIRIT.getValue(), "001"));
	}

	@Test
	public void addPieceTest() throws InterruptedException {
		pieceService.addPiece(collectId, typeOBListeId, pieceToAdd, ByteBuffer.allocate(1000), "application/pdf", new Context("123456", Channel.SPIRIT.getValue(), "001"));
		final ArgumentCaptor<UUID> argument = ArgumentCaptor.forClass(UUID.class);
		verify(pieceRepository).addPieceData(argument.capture(), any(), any(), any());
		verify(pieceRepository, times(1)).addPieceData(any(), any(), any(), any());
		assertThat(argument.getValue()).isEqualTo(pieceToAdd.getId());
		assertThat("NOT_SENT").isEqualTo(pieceToAdd.getStatusSentToGdn());
	}

	@Test
	public void addPieceFailsOnWrongReceivedFormatTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_DATA_VALUE);
		pieceToAdd.setReceivedFormat("toto");
		pieceService.addPiece(collectId, typeOBListeId, pieceToAdd, ByteBuffer.allocate(1000), "application/pdf", new Context("123456", Channel.SPIRIT.getValue(), "001"));
	}

	@Test
	public void addPieceFailsOnUnauthorizedFamilyCategoryTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_CATEGORY_TYPE_UNAUTHORIZED);
		typeRepository.findOne(collectId, typeOBListeId).setFamilyCategory(FamiliesManagmentAct.ND.name());
		pieceService.addPiece(collectId, typeOBListeId, pieceToAdd, ByteBuffer.allocate(1000), "application/pdf", new Context("123456", Channel.SPIRIT.getValue(), "001"));
	}

	@Test
	public void addPaperPieceOnTypeContainingNumPiecesTest() throws InterruptedException {
		final Set<Piece> pieces = typeRepository.findOne(collectId, typeOBListeId).getPieces();
		pieceService.addPiece(collectId, typeOBListeId, paperPiece, null, "application/pdf", new Context("123456", Channel.SPIRIT.getValue(), "001"));
		pieces.stream().filter(p -> p.getReceivedFormat().equals("NUM")).forEach(p -> assertThat(p.getState()).isEqualTo(PieceStates.INACTIF.name()));
		assertThat(typeRepository.findOne(collectId, typeOBListeId).getStatus()).isEqualTo(TypeStatus.VA.getLabel());
	}

	@Test
	public void addPaperPieceOnSubtypeContainingNumPiecesTest() throws InterruptedException {
		final Set<Piece> pieces = typeRepository.findOne(collectWithSubTypeId, subTypeWSTID).getPieces();
		pieceService.addPiece(collectWithSubTypeId, subTypeWSTID, paperPiece, null, "application/pdf", new Context("123456", Channel.SPIRIT.getValue(), "001"));
		pieces.stream().filter(p -> p.getReceivedFormat().equals("NUM")).forEach(p -> assertThat(p.getState()).isEqualTo(PieceStates.INACTIF.name()));
	}

	@Test
	public void addPieceOnParentTypeFailsTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_TYPE_UNAUTHORIZED);
		pieceService.addPiece(collectWithSubTypeId, typeWSTID, pieceToAdd, null, "application/pdf", new Context("123456", Channel.SPIRIT.getValue(), "001"));
	}

	@Test
	public void addPieceFailsOnSizeMinLimitTest() throws InterruptedException {
		// Piece p = pieceRepository.findPieceById(pieceId);
		pieceToAdd.setSize(9);
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_SIZE_MIN);
		pieceService.addPiece(collectId, typeOBListeId, pieceToAdd, null, "application/pdf", new Context("123456", Channel.SPIRIT.getValue(), "001"));
	}

	@Test
	public void addPieceFailsOnUnallowedFormatTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_FORMAT);
		pieceService.addPiece(collectId, typeOBListeId, pieceToAdd, null, "application/xxx", new Context("123456", Channel.SPIRIT.getValue(), "001"));
	}

	@Test
	public void addPiecDocAllowedFormatTest() throws InterruptedException {
		pieceService.addPiece(collectId, typeOBListeId, pieceToAdd, null, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", new Context("123456", Channel.SPIRIT.getValue(), "001"));
		final ArgumentCaptor<UUID> argument = ArgumentCaptor.forClass(UUID.class);
		verify(pieceRepository).addPieceData(argument.capture(), any(), any(), any());
		verify(pieceRepository, times(1)).addPieceData(any(), any(), any(), any());
		assertThat(argument.getValue()).isEqualTo(pieceToAdd.getId());
	}

	@Test
	public void addPiecExcelAllowedFormatTest() throws InterruptedException {
		pieceService.addPiece(collectId, typeOBListeId, pieceToAdd, null, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", new Context("123456", Channel.SPIRIT.getValue(), "001"));
		final ArgumentCaptor<UUID> argument = ArgumentCaptor.forClass(UUID.class);
		verify(pieceRepository).addPieceData(argument.capture(), any(), any(), any());
		verify(pieceRepository, times(1)).addPieceData(any(), any(), any(), any());
		assertThat(argument.getValue()).isEqualTo(pieceToAdd.getId());
	}

	@Test
	public void addPieceFailsOnDigitalNotAllowedTest() throws InterruptedException {
		typeRepository.findOne(collectId, typeOBListeId).setDigitalAllowed(false);
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_TYPE_DIGITAL_NOT_ALLOWED);
		pieceService.addPiece(collectId, typeOBListeId, pieceToAdd, null, "application/pdf", new Context("123456", Channel.SPIRIT.getValue(), "001"));
	}

	@Test
	public void addPieceFailsOnReceivedFormatTest() throws InterruptedException {
		paperPiece.setStatus(PieceStatus.TP.getLabel());
		paperPiece.setReceivedFormat(PieceRecivedFormat.PAP.name());
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_UNAUTHORIZED);
		pieceService.addPiece(collectId, typeOBListeId, paperPiece, null, "application/pdf", new Context("123456", Channel.SPIRIT.getValue(), "001"));
	}

	@Test
	public void addPieceFailsOnRejectReasonTest() throws InterruptedException {
		paperPiece.setStatus(PieceStatus.RF.getLabel());
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_REJECT_REASON);
		pieceService.addPiece(collectId, typeOBListeId, paperPiece, null, "application/pdf", new Context("123456", Channel.SPIRIT.getValue(), "001"));
	}

	@Test
	public void addPieceFailsOnRejectCommentTest() throws InterruptedException {
		paperPiece.setStatus(PieceStatus.RF.getLabel());
		paperPiece.setRejectionReason("Autre");
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_REJECT_COMMENT);
		pieceService.addPiece(collectId, typeOBListeId, paperPiece, null, "application/pdf", new Context("123456", Channel.SPIRIT.getValue(), "001"));
	}

	@Test
	public void addPieceFailsOnUnauthorizedChannelTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_CHANNEL_UNAUTHORIZED);
		pieceService.addPiece(collectId, typeOBListeId, paperPiece, null, "application/pdf", new Context("123456", Channel.CLIENT_007.getValue(), "004"));
	}

	@Test
	public void addPieceFailsOnUnauthorizedPaperPieceDeleteTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_CHANNEL_UNAUTHORIZED);
		pieceService.addPiece(collectId, typeOBListeWithAPaperPieceId, pieceToAdd, null, "application/pdf", new Context("123456", Channel.CLIENT_007.getValue(), "004"));
	}

	@Test
	public void addPieceFailsOnSeveralPaperPieceAddedTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_ONE_PIECE_AUTHORIZED);
		pieceService.addPiece(collectId, typeOBListeWithAPaperPieceId, paperPiece, null, "application/pdf", new Context("123456", Channel.SPIRIT.getValue(), "001"));
	}

	@Test
	public void GetThumbnailTest() {
		assertThat(pieceService.getThumbnail(collectId, typeOBListeId, pieceId, channel)).isNotNull();
	}

	public void GetPieceTest() {
		assertThat(pieceService.getPiece(collectId, typeOBListeId, pieceId, new Context("123456", Channel.SPIRIT.getValue(), "001")).getLeft()).isEqualTo(pieceRepository.getPiece(collectId, typeOBListeId, pieceId));
	}

	@Test
	public void DeletePieceSpiritTest() {
		pieceRepository.getPiece(collectId, typeOBListeId, pieceId).setStatus(PieceStatus.TP.getLabel());
		pieceService.deletePiece(collectId, typeOBListeId, pieceId, new Context("123456", Channel.SPIRIT.getValue(), "001"));
		assertThat(pieceRepository.getPiece(collectId, typeOBListeId, pieceId).getState()).isEqualTo(PieceStates.INACTIF.name());
	}

	@Test
	public void DeletePieceNonePiece() {
		pieceService.deletePiece(collectId, validateRcTypeId, RcpieceId, new Context("123456", Channel.SPIRIT.getValue(), "001"));
		assertThat(validateRcType.getStatus()).isEqualTo(TypeStatus.IN.getLabel());
	}

	@Test
	public void DeletePieceBelTest() {
		pieceRepository.getPiece(collectId, typeOBListeId, pieceId).setStatus(PieceStatus.TP.getLabel());
		pieceRepository.getPiece(collectId, typeOBListeId, pieceId).setChannel(Channel.CLIENT_007.getValue());
		pieceService.deletePiece(collectId, typeOBListeId, pieceId, new Context("123456", Channel.CLIENT_007.getValue(), "004"));
		assertThat(pieceRepository.getPiece(collectId, typeOBListeId, pieceId).getState()).isEqualTo(PieceStates.INACTIF.name());
	}

	@Test
	public void savePiecesTest() throws InterruptedException {
		typeRepository.findOne(collectId, typeOBListeId).getPieces().forEach(p -> p.setStatus(PieceStatus.TP.getLabel()));
		final Set<Piece> updatedPieces = typeRepository.findOne(collectId, typeOBListeId).getPieces().stream().map(p -> new Piece(p.getId(), p.getLabel(), p.getOwnerId(), p.getEmployeeId(), p.getChannel(), p.getAcquisitionDate(), p.getSize(),
				p.getReceivedFormat(), PieceStatus.DP.getLabel(), p.getIdDocGdn(), p.getRejectionReason(), p.getRejectionComment(), null, null, false)).collect(Collectors.toSet());
		typeRepository.findOne(collectId, typeOBListeId).getPieces().forEach(p -> p.setStatusSentToGdn("DONE"));
		pieceService.updatePieces(collectId, typeOBListeId, updatedPieces, new Context("123456", Channel.SPIRIT.getValue(), "001"));
		typeRepository.findOne(collectId, typeOBListeId).getPieces().forEach(p -> {
			assertThat(p.getStatus()).isEqualTo(PieceStatus.DP.getLabel());
			assertThat(p.getStatusSentToGdn()).isEqualTo("DONE");
		});
	}

	@Test
	public void savePiecesFailsOnGdnErrorTest() throws InterruptedException {

		when(pieceGdnRepository.savePiece(any(), any(), any(), any(), any(), any())).thenReturn(("Erreur - GDN indisponible"));
		typeRepository.findOne(collectId, typeOBListeId).getPieces().forEach(p -> p.setStatus(PieceStatus.TP.getLabel()));
		final Set<Piece> updatedPieces = typeRepository.findOne(collectId, typeOBListeId).getPieces().stream().map(p -> new Piece(p.getId(), p.getLabel(), p.getOwnerId(), p.getEmployeeId(), p.getChannel(), p.getAcquisitionDate(), p.getSize(),
				p.getReceivedFormat(), PieceStatus.DP.getLabel(), p.getIdDocGdn(), p.getRejectionReason(), p.getRejectionComment(), null, null, false)).collect(Collectors.toSet());
		pieceService.updatePieces(collectId, typeOBListeId, updatedPieces, new Context("123456", Channel.SPIRIT.getValue(), "001"));

	}

	@Test
	public void savePiecesWithOnePieceDeletedTest() throws InterruptedException {
		final List<Piece> pieces = new ArrayList<>(typeRepository.findOne(collectId, typeOBListeId).getPieces());
		final Piece p = pieces.get(0);
		final Set<Piece> toSave = new HashSet<>();
		toSave.add(pieces.get(1));
		pieceService.updatePieces(collectId, typeOBListeId, toSave, new Context("123456", Channel.SPIRIT.getValue(), "001"));
		assertThat(p.getState()).isEqualTo(PieceStates.INACTIF.name());
	}

	// Soumission d’une pièce DF et suppression d’une pièce DF via le putPieces
	@Test
	public void savePiecesDfAndDeletePiecesDfTest() throws InterruptedException {
		final List<Piece> pieces = new ArrayList<>(typeRepository.findOne(collectId, typeWithDFId).getPieces());
		final Piece piece1 = pieces.get(0);
		final Piece piece2 = pieces.get(1);
		final Set<Piece> toSave = new HashSet<>();
		piece2.setStatus(PieceStatus.DP.getLabel());
		toSave.add(piece2);
		pieceService.updatePieces(collectId, typeWithDFId, toSave, new Context("123456", Channel.SPIRIT.getValue(), "001"));
		assertThat(piece1.getState()).isEqualTo(PieceStates.INACTIF.name());
		typeRepository.findOne(collectId, typeWithDFId).getPieces().stream().filter(p -> toSave.contains(p)).forEach(p -> assertThat(PieceStatus.DP.getLabel().equals(p.getStatus()) && StringUtils.isNotEmpty(p.getReferenceGdnId())));
	}

	@Test
	public void savePiecesFailsOnDpToTpTest() throws InterruptedException {
		final Set<Piece> piecesRepo = typeRepository.findOne(collectId, typeOBListeId).getPieces();
		final Set<Piece> pieces = piecesRepo.stream().map(p -> new Piece(p.getId(), p.getLabel(), p.getOwnerId(), p.getEmployeeId(), p.getChannel(), p.getAcquisitionDate(), p.getSize(), p.getReceivedFormat(), p.getStatus(), p.getIdDocGdn(),
				p.getRejectionReason(), p.getRejectionComment(), null, null, false)).collect(Collectors.toSet());
		pieces.iterator().next().setStatus(PieceStatus.TP.getLabel());
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_UNAUTHORIZED_ACTION);
		pieceService.updatePieces(collectId, typeOBListeId, pieces, new Context("123456", Channel.CLIENT_007.getValue(), "004"));
	}

	@Test
	public void savePiecesFailsOnTpToVaTest() throws InterruptedException {
		final List<Piece> piecesRepo = new ArrayList<>(typeRepository.findOne(collectId, typeOBListeId).getPieces());
		piecesRepo.get(0).setStatus(PieceStatus.TP.getLabel());
		final Set<Piece> pieces = piecesRepo.stream().map(p -> new Piece(p.getId(), p.getLabel(), p.getOwnerId(), p.getEmployeeId(), p.getChannel(), p.getAcquisitionDate(), p.getSize(), p.getReceivedFormat(), p.getStatus(), p.getIdDocGdn(),
				p.getRejectionReason(), p.getRejectionComment(), null, null, false)).collect(Collectors.toSet());
		pieces.iterator().next().setStatus(PieceStatus.VA.getLabel());
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_UNAUTHORIZED_ACTION);
		pieceService.updatePieces(collectId, typeOBListeId, pieces, new Context("123456", Channel.CLIENT_007.getValue(), "004"));
	}

	@Test
	public void savePiecesFailsOnVaToDpTest() throws InterruptedException {
		final List<Piece> piecesRepo = new ArrayList<>(typeRepository.findOne(collectId, typeOBListeId).getPieces());
		piecesRepo.get(0).setStatus(PieceStatus.VA.getLabel());
		final Set<Piece> pieces = piecesRepo.stream().map(p -> new Piece(p.getId(), p.getLabel(), p.getOwnerId(), p.getEmployeeId(), p.getChannel(), p.getAcquisitionDate(), p.getSize(), p.getReceivedFormat(), p.getStatus(), p.getIdDocGdn(),
				p.getRejectionReason(), p.getRejectionComment(), null, null, false)).collect(Collectors.toSet());
		pieces.iterator().next().setStatus(PieceStatus.DP.getLabel());
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_UNAUTHORIZED_ACTION);
		pieceService.updatePieces(collectId, typeOBListeId, pieces, new Context("123456", Channel.CLIENT_007.getValue(), "004"));
	}

	@Test
	public void savePiecesFailsOnRcToTpTest() throws InterruptedException {
		final List<Piece> piecesRepo = new ArrayList<>(typeRepository.findOne(collectId, typeOBListeId).getPieces());
		piecesRepo.get(0).setStatus(PieceStatus.RC.getLabel());
		final Set<Piece> pieces = piecesRepo.stream().map(p -> new Piece(p.getId(), p.getLabel(), p.getOwnerId(), p.getEmployeeId(), p.getChannel(), p.getAcquisitionDate(), p.getSize(), p.getReceivedFormat(), p.getStatus(), p.getIdDocGdn(),
				p.getRejectionReason(), p.getRejectionComment(), null, null, false)).collect(Collectors.toSet());
		pieces.iterator().next().setStatus(PieceStatus.TP.getLabel());
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_UNAUTHORIZED_ACTION);
		pieceService.updatePieces(collectId, typeOBListeId, pieces, new Context("123456", Channel.CLIENT_007.getValue(), "004"));
	}

	@Test
	public void savePiecesFailsOnDpToVaTest() throws InterruptedException {
		final List<Piece> piecesRepo = new ArrayList<>(typeRepository.findOne(collectId, typeOBListeId).getPieces());
		final Set<Piece> pieces = piecesRepo.stream().map(p -> new Piece(p.getId(), p.getLabel(), p.getOwnerId(), p.getEmployeeId(), p.getChannel(), p.getAcquisitionDate(), p.getSize(), p.getReceivedFormat(), p.getStatus(), p.getIdDocGdn(),
				p.getRejectionReason(), p.getRejectionComment(), null, null, false)).collect(Collectors.toSet());
		pieces.iterator().next().setStatus(PieceStatus.VA.getLabel());
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_UNAUTHORIZED_ACTION);
		pieceService.updatePieces(collectId, typeOBListeId, pieces, new Context("123456", Channel.CLIENT_007.getValue(), "004"));
	}

	@Test
	public void savePiecesFailsOnUnkownActionTest() throws InterruptedException {
		final List<Piece> piecesRepo = new ArrayList<>(typeRepository.findOne(collectId, typeOBListeId).getPieces());
		final Set<Piece> pieces = piecesRepo.stream().map(p -> new Piece(p.getId(), p.getLabel(), p.getOwnerId(), p.getEmployeeId(), p.getChannel(), p.getAcquisitionDate(), p.getSize(), p.getReceivedFormat(), p.getStatus(), p.getIdDocGdn(),
				p.getRejectionReason(), p.getRejectionComment(), null, null, false)).collect(Collectors.toSet());
		pieces.iterator().next().setStatus("TOTO");
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_UNKNOWN_ACTION);
		pieceService.updatePieces(collectId, typeOBListeId, pieces, new Context("123456", Channel.CLIENT_007.getValue(), "004"));
	}

	@Test
	public void savePiecesFailsOnTooMuchPiecesSentTest() throws InterruptedException {
		final Set<Piece> pieces = new HashSet<>();
		final Piece p0 = new Piece();
		p0.setId(UUID.randomUUID());
		pieces.add(p0);
		final Piece p1 = new Piece();
		p1.setId(UUID.randomUUID());
		pieces.add(p1);
		final Piece p2 = new Piece();
		p2.setId(UUID.randomUUID());
		pieces.add(p2);
		final Piece p3 = new Piece();
		p3.setId(UUID.randomUUID());
		pieces.add(p3);
		final Piece p4 = new Piece();
		p4.setId(UUID.randomUUID());
		pieces.add(p4);
		final Piece p5 = new Piece();
		p5.setId(UUID.randomUUID());
		pieces.add(p5);
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_NUMBER);
		pieceService.updatePieces(collectId, typeOBListeId, pieces, new Context("123456", Channel.CLIENT_007.getValue(), "004"));
	}

	@Test
	public void savePieceFailsOnUnauthorizedDeleteTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_DELETE_UNAUTHORIZED);
		pieceService.updatePieces(collectId, typeOBListeId, new HashSet<>(), new Context("123456", Channel.CLIENT_007.getValue(), "004"));
	}

	@Test
	public void savePieceFailsOnUnauthorizedUpdateOnValidatedTypeTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_TYPE_UPDATE_UNAUTHORIZED);
		final Piece piece = new Piece(UUID.randomUUID(), "page1.jpg", null, null, null, null, 1000, "NUM", "TP", null, null, null, "", null, false);
		pieceService.addPiece(collectId, validateTypeId, piece, ByteBuffer.allocate(1000), "JPEG", new Context("123456", "001", "001"));
	}

	@Test
	public void addPieceFailsWhenTypesWithOtherThanDFPiecesTest() throws InterruptedException {
		final Piece piece = new Piece(UUID.randomUUID(), "page1.jpg", null, null, null, null, 1000, "NUM", "TP", null, null, null, "", null, false);
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_CATEGORY_TYPE_LISTE);
		pieceService.addPiece(collectId, typeWithDFId, piece, ByteBuffer.allocate(1000), "JPEG", new Context("123456", "001", "001"));
	}

	// RG110 : Cas de soumission d’une pièce DF depuis un canal client
	@Test
	public void savePiecesFailsOnClientChannelTest() throws InterruptedException {
		final Set<Piece> updatedPieces = typeRepository.findOne(collectId, typeWithDFId).getPieces().stream().map(p -> new Piece(p.getId(), p.getLabel(), p.getOwnerId(), p.getEmployeeId(), p.getChannel(), p.getAcquisitionDate(), p.getSize(),
				p.getReceivedFormat(), PieceStatus.DP.getLabel(), p.getIdDocGdn(), p.getRejectionReason(), p.getRejectionComment(), null, null, false)).collect(Collectors.toSet());
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_UNAUTHORIZED_ACTION);
		pieceService.updatePieces(collectId, typeWithDFId, updatedPieces, new Context("123456", Channel.CLIENT_007.getValue(), "004"));
	}

	// RG40 : Si action requise impossible par rapport au statut de la pièce d'un type donné (DF -> VA)
	@Test
	public void savePiecesFailsOnDfToVaTest() throws InterruptedException {
		final Set<Piece> updatedPieces = typeRepository.findOne(collectId, typeWithDFId).getPieces().stream().map(p -> new Piece(p.getId(), p.getLabel(), p.getOwnerId(), p.getEmployeeId(), p.getChannel(), p.getAcquisitionDate(), p.getSize(),
				p.getReceivedFormat(), PieceStatus.VA.getLabel(), p.getIdDocGdn(), p.getRejectionReason(), p.getRejectionComment(), null, null, false)).collect(Collectors.toSet());
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_UNAUTHORIZED_ACTION);
		pieceService.updatePieces(collectId, typeWithDFId, updatedPieces, new Context("123456", Channel.SPIRIT.getValue(), "001"));
	}

	@Test
	public void savePiecesEventTest() throws InterruptedException {
		typeRepository.findOne(collectId, typeOBListeId).getPieces().forEach(p -> p.setStatus(PieceStatus.TP.getLabel()));
		final Set<Piece> updatedPieces = typeRepository.findOne(collectId, typeOBListeId).getPieces().stream().map(p -> new Piece(p.getId(), p.getLabel(), p.getOwnerId(), p.getEmployeeId(), p.getChannel(), p.getAcquisitionDate(), p.getSize(),
				p.getReceivedFormat(), PieceStatus.DP.getLabel(), p.getIdDocGdn(), p.getRejectionReason(), p.getRejectionComment(), null, null, false)).collect(Collectors.toSet());
		pieceService.updatePieces(collectId, typeOBListeId, updatedPieces, new Context("123456", Channel.SPIRIT.getValue(), "001"));
		verify(collectEventHandler, times(2)).sendGdnPieceEvent(any(), any(), any());
	}

}
