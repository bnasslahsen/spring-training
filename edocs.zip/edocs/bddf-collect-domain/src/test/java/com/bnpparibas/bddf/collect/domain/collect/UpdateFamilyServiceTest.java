package com.bnpparibas.bddf.collect.domain.collect;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.event.collect.UpdatedCollect;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureServiceImpl;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceRepository;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.type.FamilyRepository;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadService;
import com.bnpparibas.bddf.collect.domain.type.TypeServiceImpl;
import com.bnpparibas.bddf.rest.Context;

public class UpdateFamilyServiceTest extends AbstractServiceTest {

	private TypeServiceImpl typeService;
	private AuditGenerator auditGenerator;

	@Override
	public void prepareDatas() {
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		final CollectValidator customValidator = new CollectValidator();
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		final TypeLadRadService typeLadRadService = mock(TypeLadRadService.class);
		final FamilyRepository familyRepository = mock(FamilyRepository.class);
		final PieceValidator pieceValidator = new PieceValidator();
		final PiecesStatusActionsRepository piecesStatusActionsRepository = mock(PiecesStatusActionsRepository.class);
		pieceValidator.setPieceStatusRepository(piecesStatusActionsRepository);

		final Environment environment = mock(Environment.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		final FeatureManager featureManager = mock(FeatureManager.class);

		when(featureManager.isActive(any())).thenReturn(false);
		final TypeAutomaticControlServiceImpl typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, null, null, new EdocIndexRepositoryImpl(), featureManager, pieceRepository, pieceGdnRepository, null,
				null, typeRepository, docReferenceService, new TypeAutomaticControlUtils());

		// service
		typeService = new TypeServiceImpl(collectRepository, typeRepository, customValidator, collectEventHandler, auditGenerator, docReferenceService, typeAutomaticControlService, familyRepository);
		typeService.setFeatureManager(featureManager);
		final EdocTypeRepository edocTypeRepository = mock(EdocTypeRepository.class);
		typeService.setEdocTypeRepository(edocTypeRepository);
		final EdocTypesRepositoryImpl edocTypesRepositoryImpl = new EdocTypesRepositoryImpl();
		typeService.setEdocTypeRepository(edocTypesRepositoryImpl);
		final DocReferenceRepository docReferenceRepository = mock(DocReferenceRepository.class);
		typeService.setDocReferenceRepository(docReferenceRepository);
		final NomenclatureService nomenclatureService = mock(NomenclatureServiceImpl.class);
		typeService.setNomenclatureService(nomenclatureService);
		typeService.setEnvironment(environment);
		typeService.setDocReferenceService(mock(DocReferenceService.class));
		typeService.setPieceValidator(pieceValidator);
	}

	@Test
	public void updatedFamilyEventTest() {
		updateFamilies(collectId, typeRepository.findOne(collectId, typeOBListeId), FamiliesManagmentAct.DR.name(), "un commentaire", null);

		final ArgumentCaptor<UpdatedCollect> argument = ArgumentCaptor.forClass(UpdatedCollect.class);
		verify(collectEventHandler).sendUpdatedCollectEvent(argument.capture());
		verify(collectEventHandler, times(1)).sendUpdatedCollectEvent(any());
		// assertThat("un commentaire").isEqualTo(argument.getValue().getCollect().getTypes().iterator().next().getFamilyCategoryComment());
	}

	@Test
	public void updateFamiliesNdTest() {
		updateFamilies(collectId, typeRepository.findOne(collectId, typeOBListeId), FamiliesManagmentAct.ND.name(), null, null);
		assertThat(typeRepository.findOne(collectId, typeOBListeId).getFamilyCategory()).isEqualTo(FamiliesManagmentAct.ND.name());
	}

	@Test
	public void updateFamiliesFailsOnUnkownCategoryTest() {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_FAMILY_CATEGORY);
		updateFamilies(collectId, typeRepository.findOne(collectId, typeOBListeId), "toto", null, null);
	}

	@Test
	public void updateFamiliesFailsOnFamilyNotFoundTest() {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_FAMILY_NOT_FOUND);
		updateFamilies(collectId, typeRepository.findOne(collectId, typeOBListeId), FamiliesManagmentAct.ND.name(), null, UUID.randomUUID());
	}

	@Test
	public void updateFamiliesDrFailsTest() {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_FAMILY_CATEGORY_COMMENT);
		updateFamilies(collectId, typeRepository.findOne(collectId, typeOBListeId), FamiliesManagmentAct.DR.name(), null, null);
	}

	@Test
	public void updateFamiliesDrTest() {
		updateFamilies(collectId, typeRepository.findOne(collectId, typeOBListeId), FamiliesManagmentAct.DR.name(), "commentaire", null);
		assertThat(typeRepository.findOne(collectId, typeOBListeId).getFamilyCategory()).isEqualTo(FamiliesManagmentAct.DR.name());
	}

	private void updateFamilies(UUID collectId, Type type, String category, String comment, UUID familyId) {
		final Type t = new Type(type.getId(), type.getParentId(), Optional.ofNullable(familyId).orElse(type.getFamilyId()), type.getFamilyOwners(), type.getFamilyLabel(), category, comment, type.getFamilyPropertyType(), type.getFamilyIconCode(),
				type.getFamilyAdditionalInformation(), type.getLabel(), type.getAdditionalInformation(), type.isDigitalAllowed(), type.getControlDocumentType(), type.getMaxSizeDoc(), type.getControlRequired(), type.getControlDate(),
				type.isPendingDocument(), type.getPendingDocumentLabel(), false, null, false, false, null, null, true);
		t.setEdocType(type.getEdocType());
		t.setPieces(type.getPieces());
		t.setFamiliesManagementActFamily(type.getFamiliesManagementActFamily());

		final Map<UUID, List<Type>> families0 = collectRepository.findOne(collectId).getTypes().stream().collect(Collectors.groupingBy(Type::getFamilyId));
		final Map<UUID, Type> families = new HashMap<>();
		families0.forEach((id, types) -> families.put(id, types.get(0)));
		families.put(t.getFamilyId(), t);
		typeService.updateFamilies(collectId, families, new Context("123456", Channel.SPIRIT.getValue()));
		assertThat(typeRepository.findOne(collectId, type.getId()).getFamilyCategory()).isEqualTo(category);

	}

	@Test
	public void updateFamiliesStatusINTest() {
		updateFamilies(collectId, typeRepository.findOne(collectId, typeOBListeId), FamiliesManagmentAct.DR.name(), "commentaire", null);
		assertTrue(typeRepository.findByCollect(collectId).stream().map(Type::getStatus).map("IN"::equals).allMatch(Boolean.TRUE::equals));

	}

	@Test
	public void updateFamiliesFromOBToFATest() {
		updateFamilies(collectId, typeRepository.findOne(collectId, typeOBListeId), FamiliesManagmentAct.FA.name(), null, null);
		assertThat(typeRepository.findOne(collectId, typeOBListeId).getFamilyCategory()).isEqualTo(FamiliesManagmentAct.FA.name());
		typeRepository.findOne(collectWithFacultativeFamilyId, typeWithfacultativeFamilyID).getPieces().forEach(p -> assertThat(p.getState().equals(PieceStates.ACTIF.getLabel())));
	}

	@Test
	public void updateFamiliesFromFAToNDTest() {
		updateFamilies(collectWithFacultativeFamilyId, typeRepository.findOne(collectWithFacultativeFamilyId, typeWithfacultativeFamilyID), FamiliesManagmentAct.ND.name(), null, null);
		assertThat(typeRepository.findOne(collectWithFacultativeFamilyId, typeWithfacultativeFamilyID).getFamilyCategory()).isEqualTo(FamiliesManagmentAct.ND.name());
		typeRepository.findOne(collectWithFacultativeFamilyId, typeWithfacultativeFamilyID).getPieces().forEach(p -> assertThat(p.getState().equals(PieceStates.INACTIF.getLabel())));
	}

	@Test
	public void updateFamiliesFromFAToDRTest() {
		updateFamilies(collectWithFacultativeFamilyId, typeRepository.findOne(collectWithFacultativeFamilyId, typeWithfacultativeFamilyID), FamiliesManagmentAct.DR.name(), "comment DR", null);
		assertThat(typeRepository.findOne(collectWithFacultativeFamilyId, typeWithfacultativeFamilyID).getFamilyCategory()).isEqualTo(FamiliesManagmentAct.DR.name());
		typeRepository.findOne(collectWithFacultativeFamilyId, typeWithfacultativeFamilyID).getPieces().forEach(p -> assertThat(p.getState().equals(PieceStates.INACTIF.getLabel())));
	}

	@Test
	public void updateFamiliesFromNDToOBTest() {

		updateFamilies(collectWithSubTypePieceId, typeRepository.findOne(collectWithSubTypePieceId, typeSubPieceId), FamiliesManagmentAct.OB.name(), "comment OB", null);
		assertThat(typeRepository.findOne(collectWithSubTypePieceId, typeSubPieceId).getFamilyCategory()).isEqualTo(FamiliesManagmentAct.OB.name());
		typeRepository.findOne(collectWithSubTypePieceId, typeSubPieceId).getPieces().forEach(p -> assertThat(p.getState().equals(PieceStates.INACTIF.getLabel())));

	}

	@Test
	public void updateFamiliesWitActManagmentInFamilyTest() {
		updateFamilies(collectWithoutActMangmentId, typeRepository.findOne(collectWithoutActMangmentId, typeWithActManagmentInFamilyID), FamiliesManagmentAct.DR.name(), "comment DR", null);
		assertThat(typeRepository.findOne(collectWithoutActMangmentId, typeWithActManagmentInFamilyID).getFamilyCategory()).isEqualTo(FamiliesManagmentAct.DR.name());
		typeRepository.findOne(collectWithoutActMangmentId, typeWithActManagmentInFamilyID).getPieces().forEach(p -> assertThat(p.getState().equals(PieceStates.INACTIF.getLabel())));
	}

	@Test
	public void updateFamiliesWitActManagmentInFamilyAndCategoryNotAuthorizedTest() {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_FAMILY_CATEGORY);
		updateFamilies(collectWithoutActMangmentId, typeRepository.findOne(collectWithoutActMangmentId, typeWithActManagmentInFamilyID), "XX", null, null);
	}

}
