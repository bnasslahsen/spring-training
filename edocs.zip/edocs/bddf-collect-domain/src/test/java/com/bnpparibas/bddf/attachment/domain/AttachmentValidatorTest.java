package com.bnpparibas.bddf.attachment.domain;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.rest.Context;

public class AttachmentValidatorTest {

	private AttachmentValidator attachmentValidator = new AttachmentValidator();

	@Rule
	public final ExpectedException exception = ExpectedException.none();

	@Before
	public void before() {
		attachmentValidator.setAuthorizedFormat("PDF,PDF/A,PNG,JPEG,GIF,TIFF,XLS,DOC");
	}

	@Test
	public void allowedFileFailsTest() {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_ATTACHMENT_ALLOWED_FILES);
		final Attachment attachment = new Attachment("1234567", "004", "AP12247", "test.pdf", "XXXX", 1000);
		attachmentValidator.validate(attachment);
	}

	@Test
	public void errorSendingApplicationCodeTest() {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_ATTACHMENT_SENDING_APPLICATION_CODE);
		final Attachment attachment = new Attachment("1234567", "004", "AC122247", "test.pdf", "pdf", 1000);
		attachmentValidator.validate(attachment);
	}

	@Test
	public void errorMaxFileSizeTest() {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_ATTACHMENT_MAX_SIZE);
		final Attachment attachment = new Attachment("1234567", "004", "AP12247", "test.png", "png", 100000000000L);
		attachmentValidator.validate(attachment);
	}

	@Test
	public void unauthorizedChannelTest() {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_ATTACHMENT_INCORRECT_CHANNEL);
		final Attachment attachment = new Attachment("1234567", "009", "AP12247", "test.png", "png", 10);
		attachmentValidator.validate(attachment);
	}

	@Test
	public void unauthorizedUSerIDTest() {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_ATTACHMENT_USER_ID_NOT_ALLOWED);
		final Attachment attachment = new Attachment("1234567", "009", "AP12247", "test.png", "png", 10);
		attachmentValidator.checkCanModify(attachment, new Context("1234568", "001"));
	}

}
