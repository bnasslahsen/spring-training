package com.bnpparibas.bddf.collect.domain.ladrad;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.net.URI;
import java.net.URISyntaxException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.domain.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.PageDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.PieceDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusFolderDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusPieceDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceControls;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceIndicators;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.StatusDocument;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.StatusFolder;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.StatusPiece;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.TypeControls;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.type.AmiServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.ControlRequired;
import com.bnpparibas.bddf.collect.domain.type.FamilyCategory;
import com.bnpparibas.bddf.collect.domain.type.IndexStatus;
import com.bnpparibas.bddf.collect.domain.type.LadRadRepository;
import com.bnpparibas.bddf.collect.domain.type.PropertyType;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.collect.domain.type.VideoCodingDelay;
import com.google.common.collect.ImmutableSet;

public class TypeLadRadServiceAmi {
	private LadRadRepository ladRadRepository;
	private EdocIndexRepository edocIndexRepository;
	private FeatureManager featureManagerLadRad;
	private TypeRepository typeRepository;
	private EdocTypeRepository edocTypeRepository;
	private TypeLadRadServiceImpl typeLadRadService;

	private StatusFolderDTO statusFolderDTO;
	private StatusDocumentDTO statusDocumentDTO;
	private StatusPieceDTO statusPieceDTO;
	private String pieceJMCData;
	private Type type;
	private Piece piece;
	private String folderJMC;
	private URI uri;
	private UUID collectId;
	private UUID typeID;
	private LadRadValidator ladRadValidator;
	private TypeValidator typeValidator;
	private StatusDocumentDTO statusDocumentDTO2;
	private TypeLadRadServiceImpl typeLadRadServiceAmi;
	private AmiServiceImpl amiService;

	@Before
	public void setUp() throws URISyntaxException {
		initData();
		initMocks();
		prepareMocks();
	}

	public void initData() throws URISyntaxException {
		uri = new URI("test");
		collectId = UUID.fromString("11b27725-a4b4-445b-b8ba-9f3558533ae0");
		typeID = UUID.fromString("00b27725-a4b4-445b-b8ba-9f3558533ae0");
		type = new Type(typeID, null, null, null, "Médicale", FamilyCategory.OB.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null, false, null, new Random().nextLong(), 0, null, false, null, false, null, false,
				false, null, null, true);
		type.setControlRequired(ControlRequired.CONTROL_JMC.getCode());
		type.setEdocType("00000000000000001");
		type.setCompleteness(ImmutableSet.of("20000000000000001"));
		piece = new Piece(UUID.fromString("8998b043-d75d-43c8-8172-1d90ab13a2fb"), "avis_impot1.doc", null, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "TP", "GD4564687876768", null, null, null, null, false);
		final Set<Piece> lisPieces = new HashSet<>();
		lisPieces.add(piece);

		type.setPieces(lisPieces);
		final Indexe idxJMCName = new Indexe(null, "10000000000000002", null, "OB", true, "CERYHIER", null, "A", null, 2, null, null, "1", "", false, null);
		final Indexe idxJMCFirstName = new Indexe(null, "10000000000000003", null, "OB", true, "CORLNNE", null, "A", null, 2, null, null, "1", "", false, null);
		final Indexe idxJMCFacultatif = new Indexe(null, "10000000000000004", null, "FA", true, "CERYHIER", null, "A", null, 2, null, null, "1", "", false, null);
		type.setIndexes(ImmutableSet.of(idxJMCName, idxJMCFirstName, idxJMCFacultatif));

		statusFolderDTO = new StatusFolderDTO();
		statusFolderDTO.setExternalRef("00b27725-a4b4-445b-b8ba-9f3558533ae0");
		statusFolderDTO.setStatus(StatusFolder.ANALYSIS_SUCCESS.getLabel());
		folderJMC = "";
		statusPieceDTO = new StatusPieceDTO();
		statusPieceDTO.setStatus(StatusPiece.ANALYSIS_SUCCESS.getLabel());
		statusDocumentDTO = new StatusDocumentDTO();
		statusDocumentDTO.setExternalRef("00c27725-a4b4-445b-b8ba-9f3558533be0");
		statusDocumentDTO.setStatus(StatusDocument.ANALYSIS_SUCCESS.getLabel());
		statusDocumentDTO2 = new StatusDocumentDTO();
		statusDocumentDTO2.setExternalRef("00c27725-a4b4-445b-b8ba-9f3558533be0");
		statusDocumentDTO2.setStatus(StatusDocument.ANALYSIS_SUCCESS.getLabel());
		final PageDTO pageJMC = new PageDTO();
		final PieceDTO pieceJMC = new PieceDTO();
		pieceJMC.setStatus(StatusPiece.ANALYSIS_SUCCESS.getLabel());
		pieceJMC.setType("identity_card_recto");
		pieceJMC.setReference("WSQQMJCkKD");
		final List<PieceDTO> pieces = new ArrayList<>();
		pieces.add(pieceJMC);
		pageJMC.setPieces(pieces);
		final List<PageDTO> pages = new ArrayList<>();
		pages.add(pageJMC);
		statusDocumentDTO.setPages(pages);

	}

	public void initMocks() {
		typeLadRadService = new TypeLadRadServiceImpl();
		ladRadValidator = new LadRadValidator();
		typeValidator = new TypeValidator();
		typeRepository = mock(TypeRepository.class);
		ladRadRepository = mock(LadRadRepository.class);
		edocIndexRepository = new EdocIndexRepositoryImpl();
		featureManagerLadRad = mock(FeatureManager.class);
		when(featureManagerLadRad.isActive(any())).thenReturn(true);
		edocTypeRepository = new EdocTypesRepositoryImpl();
		typeLadRadService.setEdocTypeRepository(edocTypeRepository);
		typeLadRadService.setTypeRepository(typeRepository);
		typeLadRadService.setLadRadRepository(ladRadRepository);
		typeLadRadService.setEdocIndexRepository(edocIndexRepository);
		typeLadRadService.setLadRadValidator(ladRadValidator);

		final Environment env = mock(Environment.class);
		final NomenclatureService nomenclatureService = mock(NomenclatureService.class);
		doAnswer(Invocation -> {
			return "0";
		}).when(env).getProperty(any());
		final TypeAutomaticControlUtils typeAutomaticControlUtils = spy(new TypeAutomaticControlUtils());
		typeAutomaticControlUtils.setEdocIndexRepository(edocIndexRepository);
		typeAutomaticControlUtils.setEdocTypeRepository(edocTypeRepository);
		typeAutomaticControlUtils.setLadRadValidator(ladRadValidator);
		typeAutomaticControlUtils.setNomenclatureService(nomenclatureService);
		typeAutomaticControlUtils.setTypeValidator(typeValidator);
		typeAutomaticControlUtils.setEnvironment(env);
		typeAutomaticControlUtils.setLadRadRepository(ladRadRepository);
		typeLadRadService.setEnv(env);
		typeLadRadService.setTypeAutomaticControlUtils(typeAutomaticControlUtils);
		typeLadRadService.setEdocTypeRepository(edocTypeRepository);
		typeLadRadService.setLadRadValidator(ladRadValidator);
		typeLadRadServiceAmi = spy(typeLadRadService);
		typeLadRadService.setTypeAutomaticControlUtils(typeAutomaticControlUtils);
		amiService = new AmiServiceImpl();
		amiService.setEnv(env);
		amiService.setTypeAutomaticControlUtils(typeAutomaticControlUtils);
		amiService.setEdocTypeRepository(edocTypeRepository);
		amiService.setLadRadValidator(ladRadValidator);
		amiService.setLadRadRepository(ladRadRepository);
		amiService.setEdocIndexRepository(edocIndexRepository);
		amiService.setEdocTypeRepository(edocTypeRepository);
		typeAutomaticControlUtils.setTypeLadRadService(typeLadRadServiceAmi);
		doReturn(true).when(typeAutomaticControlUtils).getSuccess(any(), any());
	}

	public void prepareMocks() throws URISyntaxException {
		when(ladRadRepository.getStatusFolder(eq("11b27725-a4b4-445b-b8ba-9f3558533ae0-1"), any())).thenReturn(statusFolderDTO);
		doNothing().when(ladRadRepository).injectRefDataFolder(any(), any(), any());

		doAnswer(invocation -> {
			return folderJMC;
		}).when(ladRadRepository).getFolder(any(), any());

		when(ladRadRepository.uploadDocument(any(), any(), any(), any())).thenReturn(uri);
		doNothing().when(ladRadRepository).analyseFolder(any(), any());

		when(ladRadRepository.getStatusDocument(eq(piece.getId().toString() + "-1"), any())).thenReturn(statusDocumentDTO);

		doAnswer(invocation -> {
			return statusDocumentDTO;
		}).when(ladRadRepository).getStatusDocument(any(), any());

		when(ladRadRepository.getStatusPiece(eq("WSQQMJCkKD"), any())).thenReturn(statusPieceDTO);
		when(ladRadRepository.createPiece(any(), any(), any())).thenReturn(new URI("piece/111"));
		doNothing().when(ladRadRepository).forcePieceType(any(), any(), any());

		when(typeRepository.findOne(any(), eq(typeID))).thenReturn(type);

		doNothing().when(typeRepository).updateType(any(), any());
	}

	@Test
	public void testSendAMIFirstIterationImmediate() {
		pieceJMCData = "{\"fields\":{\"name\":{\"kind\":\"extracted\",\"value\":\"CERYHIER\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"firstname\":{\"kind\":\"extracted\",\"value\":\"CORLNNE\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"gender\":{\"kind\":\"extracted\",\"value\":\"F\",\"mandatory\":\"yes\",\"data_type\":[\"M\",\"F\"],\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"birth_date\":{\"kind\":\"extracted\",\"value\":\"1965-12-06\",\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"value\":{\"level\":90,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"nationality\":{\"kind\":\"extracted\",\"value\":\"FRA\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"piece_number\":{\"kind\":\"extracted\",\"value\":\"940992310285\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":30,\"message\":null,\"status\":\"NOT_VALID\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"issue_date\":{\"kind\":\"extracted\",\"value\":\"1994-09-01\",\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"expiration_date\":{\"kind\":\"computed\",\"value\":\"2004-09-30\",\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":0,\"message\":\"no_more_valid_expired\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}}},\"validity_controls\":{\"back\":{\"MRZ_OVERALL\":\"KO\",\"BIRTHDAY\":\"OK\",\"DOCUMENT_NUMBER\":\"KO\"},\"front\":{\"identity_is_adult\":\"OK\",\"identity_not_expired\":\"KO\"}},\"conformity_controls\":{\"dossier_name\":\"OK\",\"dossier_firstname\":\"OK\",\"dossier_birth_date\":\"OK\",\"dossier_gender\":\"OK\",\"dossier_issue_date_identity\":\"OK\",\"dossier_expiration_date\":\"OK\",\"identity_diff_mrz_body_name\":\"OK\",\"identity_diff_mrz_body_firstname\":\"OK\",\"identity_diff_mrz_body_gender\":\"OK\",\"identity_diff_mrz_body_piece_number\":\"OK\",\"identity_diff_mrz_body_birth_date\":\"OK\"},\"type\":\"identity_card_recto\",\"document_family\":\"identity\",\"document_type\":\"identity_card\",\"mandatory\":null,\"data_type\":null,\"business_status\":null,\"fraud_controls\":{\"fraud_initials_not_conform\":\"WARNING\",\"fraud_initials_char_size\":\"WARNING\",\"fraud_initials_area_size\":\"OK\",\"fraud_initials_chars_count\":\"OK\",\"fraud_blacklist\":\"OK\",\"fraud_document_creator\":\"NOT_APPLICABLE_WARNING\"},\"images\":{\"image_original\":{\"selected\":0,\"href\":\"/images/piece/5URarpbSM7\"},\"image_warped\":{\"selected\":0,\"href\":\"/images/piece/1Z6KgDfVkW\"},\"image_cropped\":{\"selected\":0,\"href\":\"/images/piece/qPRIknpWg6\"},\"image_id_photo\":{\"selected\":0,\"href\":\"/images/piece/18rilq0zb9\"},\"image_id_signature\":{\"selected\":0,\"href\":\"/images/piece/1DoxaQg9gl\"}},\"links\":{\"data\":{\"href\":\"/pieces/WSQQMJCkKD\"},\"image_original\":{\"href\":\"/pieceImages/WSQQMJCkKD/original\"},\"image\":{\"href\":\"/pieceImages/WSQQMJCkKD\"},\"image_crop\":{\"href\":\"/pieceImages/WSQQMJCkKD/crop\"},\"status\":{\"href\":\"/pieces/WSQQMJCkKD/status\"},\"rawdata\":{\"href\":\"/pieces/WSQQMJCkKD/rawdata\"},\"document\":{\"href\":\"/documents/cVTahwr5Na/status\"},\"page\":{\"href\":\"/pages/ko3YabFK5e/status\"},\"update\":{\"href\":\"/pieces/WSQQMJCkKD/update\"},\"deactivate\":{\"href\":\"/pieces/WSQQMJCkKD/deactivate\"},\"force_piece_type\":{\"href\":\"/pieces/WSQQMJCkKD/forcePieceType\"},\"photo\":{\"href\":\"/pieces/WSQQMJCkKD/photo\"},\"signature\":{\"href\":\"/pieces/WSQQMJCkKD/signature\"}}}";
		when(ladRadRepository.getPiece(any(), any())).thenReturn(pieceJMCData);
		type.setStatusControl(TypeControls.KO.getLabel());
		type.setVideoCodingDelay(VideoCodingDelay.IMMEDIATE.getCode());
		type.setCompletenessControl(TypeControls.OK.getLabel());
		type.getActivePieces().forEach(piece -> {
			piece.setStatusControl(PieceControls.KO.getLabel());
		});
		type.getIndexes().forEach(index -> {
			index.setStatusControl(IndexStatus.KO.getCode());
			index.setIndexable(false);
			index.setVideoCoding(true);
		});

		amiService.sendAMIFirstIteration(collectId, type, "");
		type.getIndexes().stream().filter(idx -> idx.getCategory().equals("OB")).forEach(idx -> assertThat(idx.getStatusControl()).isEqualTo(IndexStatus.OK.name()));
	}

	@Test
	public void testSendAMISecondIterationBypass() {
		pieceJMCData = "{\"fields\":{\"name\":{\"kind\":\"extracted\",\"value\":\"CERYHIER\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"firstname\":{\"kind\":\"extracted\",\"value\":\"CORLNNE\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"gender\":{\"kind\":\"extracted\",\"value\":\"F\",\"mandatory\":\"yes\",\"data_type\":[\"M\",\"F\"],\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"birth_date\":{\"kind\":\"extracted\",\"value\":\"1965-12-06\",\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"value\":{\"level\":90,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"nationality\":{\"kind\":\"extracted\",\"value\":\"FRA\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"piece_number\":{\"kind\":\"extracted\",\"value\":\"940992310285\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":30,\"message\":null,\"status\":\"NOT_VALID\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"issue_date\":{\"kind\":\"extracted\",\"value\":\"1994-09-01\",\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"expiration_date\":{\"kind\":\"computed\",\"value\":\"2004-09-30\",\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":0,\"message\":\"no_more_valid_expired\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}}},\"validity_controls\":{\"back\":{\"MRZ_OVERALL\":\"KO\",\"BIRTHDAY\":\"OK\",\"DOCUMENT_NUMBER\":\"KO\"},\"front\":{\"identity_is_adult\":\"OK\",\"identity_not_expired\":\"KO\"}},\"conformity_controls\":{\"dossier_name\":\"OK\",\"dossier_firstname\":\"OK\",\"dossier_birth_date\":\"OK\",\"dossier_gender\":\"OK\",\"dossier_issue_date_identity\":\"OK\",\"dossier_expiration_date\":\"OK\",\"identity_diff_mrz_body_name\":\"OK\",\"identity_diff_mrz_body_firstname\":\"OK\",\"identity_diff_mrz_body_gender\":\"OK\",\"identity_diff_mrz_body_piece_number\":\"OK\",\"identity_diff_mrz_body_birth_date\":\"OK\"},\"type\":\"identity_card_recto\",\"document_family\":\"identity\",\"document_type\":\"identity_card\",\"mandatory\":null,\"data_type\":null,\"business_status\":null,\"fraud_controls\":{\"fraud_initials_not_conform\":\"WARNING\",\"fraud_initials_char_size\":\"WARNING\",\"fraud_initials_area_size\":\"OK\",\"fraud_initials_chars_count\":\"OK\",\"fraud_blacklist\":\"OK\",\"fraud_document_creator\":\"NOT_APPLICABLE_WARNING\"},\"images\":{\"image_original\":{\"selected\":0,\"href\":\"/images/piece/5URarpbSM7\"},\"image_warped\":{\"selected\":0,\"href\":\"/images/piece/1Z6KgDfVkW\"},\"image_cropped\":{\"selected\":0,\"href\":\"/images/piece/qPRIknpWg6\"},\"image_id_photo\":{\"selected\":0,\"href\":\"/images/piece/18rilq0zb9\"},\"image_id_signature\":{\"selected\":0,\"href\":\"/images/piece/1DoxaQg9gl\"}},\"links\":{\"data\":{\"href\":\"/pieces/WSQQMJCkKD\"},\"image_original\":{\"href\":\"/pieceImages/WSQQMJCkKD/original\"},\"image\":{\"href\":\"/pieceImages/WSQQMJCkKD\"},\"image_crop\":{\"href\":\"/pieceImages/WSQQMJCkKD/crop\"},\"status\":{\"href\":\"/pieces/WSQQMJCkKD/status\"},\"rawdata\":{\"href\":\"/pieces/WSQQMJCkKD/rawdata\"},\"document\":{\"href\":\"/documents/cVTahwr5Na/status\"},\"page\":{\"href\":\"/pages/ko3YabFK5e/status\"},\"update\":{\"href\":\"/pieces/WSQQMJCkKD/update\"},\"deactivate\":{\"href\":\"/pieces/WSQQMJCkKD/deactivate\"},\"force_piece_type\":{\"href\":\"/pieces/WSQQMJCkKD/forcePieceType\"},\"photo\":{\"href\":\"/pieces/WSQQMJCkKD/photo\"},\"signature\":{\"href\":\"/pieces/WSQQMJCkKD/signature\"}}}";
		when(ladRadRepository.getPiece(any(), any())).thenReturn(pieceJMCData);
		type.setStatusControl(TypeControls.KO.getLabel());
		type.setVideoCodingDelay(VideoCodingDelay.IMMEDIATE.getCode());
		type.setCompletenessControl("identity_card_recto");
		type.getActivePieces().forEach(piece -> {
			piece.setStatusControl(PieceControls.KO.getLabel());
			piece.setTypeControl(PieceIndicators.OK_MAN.getLabel());
		});
		type.getIndexes().forEach(index -> {
			index.setStatusControl(IndexStatus.KO.getCode());
			index.setIndexable(false);
			index.setVideoCoding(true);
		});

		amiService.sendAMISecondIteration(collectId, type, true, "");
		type.getIndexes().stream().filter(idx -> idx.getCategory().equals("OB")).forEach(idx -> assertThat(idx.getStatusControl()).isEqualTo(IndexStatus.OK.name()));
	}

	@Test
	public void testSendAMISecondIterationNoBypassVideoCoding() {
		pieceJMCData = "{\"fields\":{\"name\":{\"kind\":\"extracted\",\"value\":\"CERYHIER\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"firstname\":{\"kind\":\"extracted\",\"value\":\"CORLNNE\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"gender\":{\"kind\":\"extracted\",\"value\":\"F\",\"mandatory\":\"yes\",\"data_type\":[\"M\",\"F\"],\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"birth_date\":{\"kind\":\"extracted\",\"value\":\"1965-12-06\",\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"value\":{\"level\":90,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"nationality\":{\"kind\":\"extracted\",\"value\":\"FRA\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"piece_number\":{\"kind\":\"extracted\",\"value\":\"940992310285\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":30,\"message\":null,\"status\":\"NOT_VALID\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"issue_date\":{\"kind\":\"extracted\",\"value\":\"1994-09-01\",\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"expiration_date\":{\"kind\":\"computed\",\"value\":\"2004-09-30\",\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":0,\"message\":\"no_more_valid_expired\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}}},\"validity_controls\":{\"back\":{\"MRZ_OVERALL\":\"KO\",\"BIRTHDAY\":\"OK\",\"DOCUMENT_NUMBER\":\"KO\"},\"front\":{\"identity_is_adult\":\"OK\",\"identity_not_expired\":\"KO\"}},\"conformity_controls\":{\"dossier_name\":\"OK\",\"dossier_firstname\":\"OK\",\"dossier_birth_date\":\"OK\",\"dossier_gender\":\"OK\",\"dossier_issue_date_identity\":\"OK\",\"dossier_expiration_date\":\"OK\",\"identity_diff_mrz_body_name\":\"OK\",\"identity_diff_mrz_body_firstname\":\"OK\",\"identity_diff_mrz_body_gender\":\"OK\",\"identity_diff_mrz_body_piece_number\":\"OK\",\"identity_diff_mrz_body_birth_date\":\"OK\"},\"type\":\"identity_card_recto\",\"document_family\":\"identity\",\"document_type\":\"identity_card\",\"mandatory\":null,\"data_type\":null,\"business_status\":null,\"fraud_controls\":{\"fraud_initials_not_conform\":\"WARNING\",\"fraud_initials_char_size\":\"WARNING\",\"fraud_initials_area_size\":\"OK\",\"fraud_initials_chars_count\":\"OK\",\"fraud_blacklist\":\"OK\",\"fraud_document_creator\":\"NOT_APPLICABLE_WARNING\"},\"images\":{\"image_original\":{\"selected\":0,\"href\":\"/images/piece/5URarpbSM7\"},\"image_warped\":{\"selected\":0,\"href\":\"/images/piece/1Z6KgDfVkW\"},\"image_cropped\":{\"selected\":0,\"href\":\"/images/piece/qPRIknpWg6\"},\"image_id_photo\":{\"selected\":0,\"href\":\"/images/piece/18rilq0zb9\"},\"image_id_signature\":{\"selected\":0,\"href\":\"/images/piece/1DoxaQg9gl\"}},\"links\":{\"data\":{\"href\":\"/pieces/WSQQMJCkKD\"},\"image_original\":{\"href\":\"/pieceImages/WSQQMJCkKD/original\"},\"image\":{\"href\":\"/pieceImages/WSQQMJCkKD\"},\"image_crop\":{\"href\":\"/pieceImages/WSQQMJCkKD/crop\"},\"status\":{\"href\":\"/pieces/WSQQMJCkKD/status\"},\"rawdata\":{\"href\":\"/pieces/WSQQMJCkKD/rawdata\"},\"document\":{\"href\":\"/documents/cVTahwr5Na/status\"},\"page\":{\"href\":\"/pages/ko3YabFK5e/status\"},\"update\":{\"href\":\"/pieces/WSQQMJCkKD/update\"},\"deactivate\":{\"href\":\"/pieces/WSQQMJCkKD/deactivate\"},\"force_piece_type\":{\"href\":\"/pieces/WSQQMJCkKD/forcePieceType\"},\"photo\":{\"href\":\"/pieces/WSQQMJCkKD/photo\"},\"signature\":{\"href\":\"/pieces/WSQQMJCkKD/signature\"}}}";
		when(ladRadRepository.getPiece(any(), any())).thenReturn(pieceJMCData);
		type.setStatusControl(TypeControls.KO.getLabel());
		type.setCompletenessControl(TypeControls.OK.name());
		type.setVideoCodingDelay(VideoCodingDelay.IMMEDIATE.getCode());
		type.getActivePieces().forEach(piece -> {
			piece.setStatusControl(PieceControls.KO.getLabel());
			piece.setTypeControl(PieceIndicators.OK.getLabel());
		});
		type.getIndexes().forEach(index -> {
			index.setStatusControl(IndexStatus.KO.getCode());
			index.setIndexable(false);
			index.setVideoCoding(true);
		});

		amiService.sendAMISecondIteration(collectId, type, false, "");
		type.getIndexes().stream().filter(idx -> idx.getCategory().equals("OB")).forEach(idx -> assertThat(idx.getStatusControl()).isEqualTo(IndexStatus.OK.name()));
	}

	@Test
	public void testSendAMISecondIterationNoBypassVideoTyping() {
		pieceJMCData = "{\"fields\":{\"name\":{\"kind\":\"extracted\",\"value\":\"CERYHIER\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"firstname\":{\"kind\":\"extracted\",\"value\":\"CORLNNE\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"gender\":{\"kind\":\"extracted\",\"value\":\"F\",\"mandatory\":\"yes\",\"data_type\":[\"M\",\"F\"],\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"birth_date\":{\"kind\":\"extracted\",\"value\":\"1965-12-06\",\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"value\":{\"level\":90,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"nationality\":{\"kind\":\"extracted\",\"value\":\"FRA\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"piece_number\":{\"kind\":\"extracted\",\"value\":\"940992310285\",\"mandatory\":\"yes\",\"data_type\":\"string\",\"controls\":{\"conformity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":30,\"message\":null,\"status\":\"NOT_VALID\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"issue_date\":{\"kind\":\"extracted\",\"value\":\"1994-09-01\",\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":null,\"message\":null,\"status\":\"NOT_CONTROLLED\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}},\"expiration_date\":{\"kind\":\"computed\",\"value\":\"2004-09-30\",\"mandatory\":\"yes\",\"data_type\":\"date\",\"controls\":{\"conformity\":{\"level\":100,\"message\":null,\"status\":\"VALID\"},\"validity\":{\"level\":0,\"message\":\"no_more_valid_expired\",\"status\":\"NOT_VALID\"},\"value\":{\"level\":50,\"message\":null,\"status\":\"VALID\"}},\"status\":\"NOT_VALID\",\"coords\":{\"top_left\":{\"x\":null,\"y\":null},\"bottom_right\":{\"x\":null,\"y\":null}}}},\"validity_controls\":{\"back\":{\"MRZ_OVERALL\":\"KO\",\"BIRTHDAY\":\"OK\",\"DOCUMENT_NUMBER\":\"KO\"},\"front\":{\"identity_is_adult\":\"OK\",\"identity_not_expired\":\"KO\"}},\"conformity_controls\":{\"dossier_name\":\"OK\",\"dossier_firstname\":\"OK\",\"dossier_birth_date\":\"OK\",\"dossier_gender\":\"OK\",\"dossier_issue_date_identity\":\"OK\",\"dossier_expiration_date\":\"OK\",\"identity_diff_mrz_body_name\":\"OK\",\"identity_diff_mrz_body_firstname\":\"OK\",\"identity_diff_mrz_body_gender\":\"OK\",\"identity_diff_mrz_body_piece_number\":\"OK\",\"identity_diff_mrz_body_birth_date\":\"OK\"},\"type\":\"identity_card_recto\",\"document_family\":\"identity\",\"document_type\":\"identity_card\",\"mandatory\":null,\"data_type\":null,\"business_status\":null,\"fraud_controls\":{\"fraud_initials_not_conform\":\"WARNING\",\"fraud_initials_char_size\":\"WARNING\",\"fraud_initials_area_size\":\"OK\",\"fraud_initials_chars_count\":\"OK\",\"fraud_blacklist\":\"OK\",\"fraud_document_creator\":\"NOT_APPLICABLE_WARNING\"},\"images\":{\"image_original\":{\"selected\":0,\"href\":\"/images/piece/5URarpbSM7\"},\"image_warped\":{\"selected\":0,\"href\":\"/images/piece/1Z6KgDfVkW\"},\"image_cropped\":{\"selected\":0,\"href\":\"/images/piece/qPRIknpWg6\"},\"image_id_photo\":{\"selected\":0,\"href\":\"/images/piece/18rilq0zb9\"},\"image_id_signature\":{\"selected\":0,\"href\":\"/images/piece/1DoxaQg9gl\"}},\"links\":{\"data\":{\"href\":\"/pieces/WSQQMJCkKD\"},\"image_original\":{\"href\":\"/pieceImages/WSQQMJCkKD/original\"},\"image\":{\"href\":\"/pieceImages/WSQQMJCkKD\"},\"image_crop\":{\"href\":\"/pieceImages/WSQQMJCkKD/crop\"},\"status\":{\"href\":\"/pieces/WSQQMJCkKD/status\"},\"rawdata\":{\"href\":\"/pieces/WSQQMJCkKD/rawdata\"},\"document\":{\"href\":\"/documents/cVTahwr5Na/status\"},\"page\":{\"href\":\"/pages/ko3YabFK5e/status\"},\"update\":{\"href\":\"/pieces/WSQQMJCkKD/update\"},\"deactivate\":{\"href\":\"/pieces/WSQQMJCkKD/deactivate\"},\"force_piece_type\":{\"href\":\"/pieces/WSQQMJCkKD/forcePieceType\"},\"photo\":{\"href\":\"/pieces/WSQQMJCkKD/photo\"},\"signature\":{\"href\":\"/pieces/WSQQMJCkKD/signature\"}}}";
		when(ladRadRepository.getPiece(any(), any())).thenReturn(pieceJMCData);
		type.setStatusControl(TypeControls.KO.getLabel());
		type.setCompletenessControl("identity_card_recto");
		type.setVideoCodingDelay(VideoCodingDelay.IMMEDIATE.getCode());
		type.getActivePieces().forEach(piece -> {
			piece.setStatusControl(PieceControls.KO.getLabel());
			piece.setTypeControl(PieceIndicators.KO.getLabel());
		});
		type.getIndexes().forEach(index -> {
			index.setStatusControl(IndexStatus.KO.getCode());
			index.setIndexable(false);
			index.setVideoCoding(true);
		});

		amiService.sendAMISecondIteration(collectId, type, false, "");
		type.getIndexes().stream().filter(idx -> idx.getCategory().equals("OB")).forEach(idx -> assertThat(idx.getStatusControl()).isEqualTo(IndexStatus.OK.name()));
	}
}
