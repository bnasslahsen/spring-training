package com.bnpparibas.bddf.collect.domain.collect;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import org.junit.Test;
import org.springframework.context.MessageSource;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.collect.params.GdnParamRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.ladrad.LadRadValidator;
import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.GdnParamRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceRepository;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.type.ControlRequired;
import com.bnpparibas.bddf.collect.domain.type.FamilyRepository;
import com.bnpparibas.bddf.collect.domain.type.LadRadRepository;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadService;
import com.bnpparibas.bddf.collect.domain.type.TypeServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;

public class FamilyServiceTest extends AbstractServiceTest {

	private TypeServiceImpl typeService;
	private AuditGenerator auditGenerator;

	private TypeValidator typeValidator;
	private CollectValidator customValidator;
	private FeatureManager featureManager;

	@Override
	public void prepareDatas() {
		injectServices();

	}

	void injectServices() {
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		customValidator = new CollectValidator();
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		final TypeLadRadService typeLadRadService = mock(TypeLadRadService.class);
		final LadRadRepository ladRadRepository = mock(LadRadRepository.class);
		final FamilyRepository familyRepository = mock(FamilyRepository.class);
		final TypeAutomaticControlUtils typeAutomaticControlUtils = new TypeAutomaticControlUtils(ladRadRepository, new LadRadValidator(), typeRepository, typeValidator, typeLadRadService, collectRepository, collectEventHandler,
				new EdocTypesRepositoryImpl(), nomenclatureService, new EdocIndexRepositoryImpl(), docReferenceService, featureManager);
		// service
		featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(false);
		final TypeAutomaticControlServiceImpl typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, typeValidator, null, new EdocIndexRepositoryImpl(), featureManager, pieceRepository, pieceGdnRepository,
				null, null, typeRepository, docReferenceService, typeAutomaticControlUtils);

		typeService = new TypeServiceImpl(collectRepository, typeRepository, customValidator, collectEventHandler, auditGenerator, docReferenceService, typeAutomaticControlService, familyRepository);
		final EdocTypeRepository edocTypeRepository = mock(EdocTypeRepository.class);

		typeService.setEdocTypeRepository(edocTypeRepository);
		typeService.setFeatureManager(featureManager);
		final EdocTypesRepositoryImpl edocTypesRepositoryImpl = new EdocTypesRepositoryImpl();
		typeService.setEdocTypeRepository(edocTypesRepositoryImpl);
		final DocReferenceRepository docReferenceRepository = mock(DocReferenceRepository.class);
		typeService.setDocReferenceRepository(docReferenceRepository);
		final GdnParamRepository gdnParamRepository = new GdnParamRepositoryImpl();
		typeService.setGdnParamRepository(gdnParamRepository);
		final EdocIndexRepository edocIndexRepository = new EdocIndexRepositoryImpl();
		typeService.setEdocIndexRepository(edocIndexRepository);
		typeService.setNomenclatureService(nomenclatureService);
		typeValidator = spy(new TypeValidator());
		typeService.setTypeValidator(typeValidator);
	}

	@Test
	public void addFamilyIsOk() throws InterruptedException {
		addFamily(collectIdEdocType, familyTypeOBToAdd, FamiliesManagmentAct.OB.name(), "un commentaire", null);
		final Type type = typeRepository.findOne(collectIdEdocType, familyTypeOBIDToAdd);
		assertThat(type).isEqualTo(typeRepository.findOne(collectIdEdocType, familyTypeOBIDToAdd));
	}

	@Test
	public void addFamilyWithEdocTypeIsOk() throws InterruptedException {
		when(featureManager.isActive(any())).thenReturn(true);
		typeService.setFeatureManager(featureManager);
		familyTypeOBToAdd.setEdocType("00000000000000002");
		familyTypeOBToAdd.setDigitalAllowed(true);
		addFamily(collectIdEdocType, familyTypeOBToAdd, FamiliesManagmentAct.OB.name(), "un commentaire", null);
		final Type type = typeRepository.findOne(collectIdEdocType, familyTypeOBIDToAdd);
		assertThat(type).isEqualTo(typeRepository.findOne(collectIdEdocType, familyTypeOBIDToAdd));
	}

	@Test
	public void addFamilyAdressProofGroupLabelOk() throws InterruptedException {
		when(featureManager.isActive(any())).thenReturn(true);
		typeService.setFeatureManager(featureManager);
		familyTypeOBToAdd.setEdocType("00000000000000006");
		familyTypeOBToAdd.setDigitalAllowed(true);
		final Indexe indexe = new Indexe();
		indexe.setId(UUID.randomUUID());
		indexe.setCategory("OB");
		indexe.setReferenceValue("Nom");
		indexe.setCode("10000000000000002");
		indexe.setLabel("Nom");
		indexe.setGroupLabel("Etat Civil");
		indexe.setIndexable(true);
		familyTypeOBToAdd.getIndexes().add(indexe);
		addFamily(collectIdEdocType, familyTypeOBToAdd, FamiliesManagmentAct.OB.name(), "un commentaire", null);
		final Type type = typeRepository.findOne(collectIdEdocType, familyTypeOBIDToAdd);
		assertThat(type).isEqualTo(typeRepository.findOne(collectIdEdocType, familyTypeOBIDToAdd));
	}

	@Test
	public void addFamilyWithMissingTypeEdoc() throws InterruptedException {

		when(featureManager.isActive(any())).thenReturn(true);
		typeService.setFeatureManager(featureManager);
		familyTypeOBToAdd.setDigitalAllowed(true);
		familyTypeOBToAdd.setEdocType("");
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_TYPE_EDOC_MANDATORY);
		addFamily(collectIdEdocType, familyTypeOBToAdd, FamiliesManagmentAct.OB.name(), "un commentaire", null);

	}

	@Test
	public void addFamilyWithUnkownTypeEdocAndDigitalIsAllowed() throws InterruptedException {
		when(featureManager.isActive(any())).thenReturn(true);
		typeService.setFeatureManager(featureManager);
		familyTypeOBToAdd.setEdocType("XXXXX");
		familyTypeOBToAdd.setDigitalAllowed(true);
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_TYPE_EDOC_UNKOWN);
		addFamily(collectIdEdocType, familyTypeOBToAdd, FamiliesManagmentAct.OB.name(), "un commentaire", null);
	}

	@Test
	public void addFamilyWithUnknowNomenclature() {
		Exception exception = null;
		when(featureManager.isActive(any())).thenReturn(true);
		typeService.setFeatureManager(featureManager);
		familyTypeOBToAdd.setEdocType("00000000000000001");
		familyTypeOBToAdd.setDigitalAllowed(true);
		familyTypeOBToAdd.setControlRequired(ControlRequired.CONTROL_JMC.getCode());

		familyTypeOBToAdd.setIndexes(prepareSetUpIndexesUnknownNomenclature());

		try {
			addFamily(collectIdEdocType, familyTypeOBToAdd, FamiliesManagmentAct.OB.name(), "un commentaire", null);
		} catch (final Exception e) {
			exception = e;
		}
		assertThat(exception).isNotNull();
		assertThat(exception.getMessage()).contains("0070");

	}

	@Test
	public void addFamilyWithNomenclatureOk() {
		Exception exception = null;
		when(featureManager.isActive(any())).thenReturn(true);
		typeService.setFeatureManager(featureManager);
		familyTypeOBToAdd.setEdocType("00000000000000001");
		familyTypeOBToAdd.setDigitalAllowed(true);

		familyTypeOBToAdd.setIndexes(prepareSetUpIndexesItsAllGood());

		try {
			addFamily(collectIdEdocType, familyTypeOBToAdd, FamiliesManagmentAct.OB.name(), "un commentaire", null);
		} catch (final Exception e) {
			exception = e;
		}
		assertThat(exception).isNull();

	}

	private Set<Indexe> prepareSetUpIndexesUnknownNomenclature() {
		final Set<Indexe> indexes = new HashSet<>();
		final Indexe index = new Indexe();
		index.setReferenceValue("M");
		index.setId(UUID.randomUUID());
		index.setCode("10000000000000001");
		index.setCategory("OB");

		indexes.add(index);

		return indexes;
	}

	private Set<Indexe> prepareSetUpIndexesItsAllGood() {
		final Set<Indexe> indexes = new HashSet<>();
		final Indexe index = new Indexe();
		index.setReferenceValue("F");
		index.setId(UUID.randomUUID());
		index.setCode("10000000000000001");
		index.setCategory("OB");

		indexes.add(index);

		return indexes;
	}

	private void addFamily(UUID collectId, Type type, String category, String comment, UUID familyId) throws InterruptedException {
		final Set<Type> family = new HashSet<>();
		family.add(type);
		typeService.addFamily(collectId, family, new Context("123456", Channel.SPIRIT.getValue()));

	}

	@Test
	public void deleteFamilyInexistentInCollectIsOk() {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_FAMILY_NOT_FOUND);
		typeService.deleteFamily(collectIdEdocType, familyTypeOBIDToAdd, new Context("123456", Channel.SPIRIT.getValue()));

	}

	@Test
	public void deleteFamilyIsOk() {
		typeService.deleteFamily(collectIdEdocType, familyWithEdocTypeId, new Context("123456", Channel.SPIRIT.getValue()));
		final Collect collect = collectRepository.findOne(collectIdEdocType);
		assertThat(collect.getTypes().size()).isEqualTo(1);
	}

	@Test
	public void deleteFamilyWithCollectManyFamilyIsOk() {
		Collect collect = collectRepository.findOne(collectId);
		assertThat(collect.getTypes().size()).isEqualTo(9);
		typeService.deleteFamily(collectId, familyOBId, new Context("123456", Channel.SPIRIT.getValue()));
		collect = collectRepository.findOne(collectId);
		assertThat(collect.getTypes().size()).isEqualTo(9);
	}

}
