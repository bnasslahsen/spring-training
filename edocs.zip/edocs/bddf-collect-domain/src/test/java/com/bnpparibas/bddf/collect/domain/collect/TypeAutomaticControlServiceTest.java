package com.bnpparibas.bddf.collect.domain.collect;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.net.URISyntaxException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditEventService;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.index.IndexeJmc;
import com.bnpparibas.bddf.collect.domain.ladrad.LadRadValidator;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceControls;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceIndicators;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.TypeControls;
import com.bnpparibas.bddf.collect.domain.nomenclature.Nomenclature;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.type.ControlRequired;
import com.bnpparibas.bddf.collect.domain.type.FamilyCategory;
import com.bnpparibas.bddf.collect.domain.type.IndexCategory;
import com.bnpparibas.bddf.collect.domain.type.IndexStatus;
import com.bnpparibas.bddf.collect.domain.type.LadRadRepository;
import com.bnpparibas.bddf.collect.domain.type.PropertyType;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.errors.TechnicalException;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableSet;

public class TypeAutomaticControlServiceTest {

	private LadRadRepository ladRadRepository;
	private EdocIndexRepository edocIndexRepository;
	private FeatureManager featureManagerLadRad;
	private TypeRepository typeRepository;
	private EdocTypeRepository edocTypeRepository;
	private TypeLadRadServiceImpl typeLadRadService;
	private TypeAutomaticControlServiceImpl typeAutomaticControlService;
	private LadRadValidator ladRadValidator;
	private CollectRepository collectRepository;
	private TypeValidator typeValidator;
	private CollectEventHandler collectEventHandler;
	private PieceRepository pieceRepository;
	private Collect collect;
	private Type type;
	private Piece piece;
	private Piece piece2;
	private TypeAutomaticControlUtils typeAutomaticControlUtils;

	@Before
	public void setUp() throws URISyntaxException {
		initMocks();
		initData();
	}

	public void initData() throws URISyntaxException {
		type = new Type(UUID.fromString("8998b043-d75d-43c8-8172-1d90ab13a2fb"), null, null, null, "Médicale", FamilyCategory.OB.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null, false, null,
				new Random().nextLong(), 0, null, false, null, false, null, false, false, null, null, true);
		type.setControlRequired(ControlRequired.CONTROL_JMC.getCode());
		type.setEdocType("00000000000000001");
		type.setCompleteness(ImmutableSet.of("20000000000000001"));
		piece = new Piece(UUID.fromString("8998b043-d75d-43c8-8172-1d90ab13a2fb"), "avis_impot1.doc", null, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "TP", "GD4564687876768", null, null, null, null, false);
		piece2 = new Piece(UUID.fromString("8998b043-d75d-43c8-8172-1d91ab13a2fb"), "avis_impot1.doc", null, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "DP", "GD4564687876768", null, null, null, null, false);
		final Set<Piece> lisPieces = new HashSet<>();
		lisPieces.add(piece);
		type.setPieces(lisPieces);
		collect = new Collect(UUID.randomUUID(), "EC", Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", ImmutableSet.of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIF", "TIFF"), ImmutableSet.of("DP"),
				ImmutableSet.of("OB", "ND", "DR", "DF"), null, "AP001", false, true, 0, false, 0);
		collect.setControlIterationAllowed(2);
		final List<IndexeJmc> indexesJmc = new ArrayList<>();
		indexesJmc.add(new IndexeJmc("usual_name", "CORLNNE", "OK", UUID.fromString("8998b043-d75d-43c8-8172-1d90ab13a2fb"), "1"));
		final Indexe idxJMCName = new Indexe(null, "10000000000000002", null, "OB", true, "CERYHIER", null, "A", null, 2, null, null, "1", "", false, null);
		idxJMCName.setIndexesJmc(indexesJmc);
		final Indexe idxJMCFirstName = new Indexe(null, "10000000000000003", null, "OB", true, "CORLNNE", null, "A", null, 2, null, null, "1", "", false, null);
		idxJMCFirstName.setIndexesJmc(indexesJmc);
		final Indexe idxJMCFacultatif = new Indexe(null, "10000000000000004", null, "FA", true, "CERYHIER", null, "A", null, 2, null, null, "1", "", false, null);
		idxJMCFacultatif.setIndexesJmc(indexesJmc);
		type.setIndexes(ImmutableSet.of(idxJMCName, idxJMCFirstName, idxJMCFacultatif));

	}

	public void initMocks() {
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		collectEventHandler = mock(CollectEventHandler.class);
		ladRadValidator = new LadRadValidator();
		typeValidator = new TypeValidator();
		typeRepository = mock(TypeRepository.class);
		ladRadRepository = mock(LadRadRepository.class);
		edocIndexRepository = new EdocIndexRepositoryImpl();
		featureManagerLadRad = mock(FeatureManager.class);
		collectRepository = mock(CollectRepository.class);
		pieceRepository = mock(PieceRepository.class);
		when(featureManagerLadRad.isActive(any())).thenReturn(true);
		edocTypeRepository = new EdocTypesRepositoryImpl();
		typeLadRadService = mock(TypeLadRadServiceImpl.class);
		final Environment environment = mock(Environment.class);
		when(environment.getProperty("param.logForPerf")).thenReturn("false");
		when(environment.getProperty("param.controlIterationAllowed", Integer.class, 2)).thenReturn(2);

		final NomenclatureService nomenclatureService = mock(NomenclatureService.class);
		doAnswer(invocation -> {
			final List<Nomenclature> nomenclatures = new ArrayList<>();
			final Nomenclature nomenclatureF = new Nomenclature();
			nomenclatureF.setCode("F");
			nomenclatureF.setEdoc("10000000000000001");
			nomenclatureF.setJmc("F");
			nomenclatureF.setLabel("Féminin");

			final Nomenclature nomenclatureH = new Nomenclature();
			nomenclatureH.setCode("M");
			nomenclatureH.setEdoc("10000000000000001");
			nomenclatureH.setJmc("M");
			nomenclatureH.setLabel("Masculin");

			final Nomenclature nomenclatureARG = new Nomenclature();
			nomenclatureARG.setCode("ARG");
			nomenclatureARG.setEdoc("10000000000000007");
			nomenclatureARG.setJmc("ARG");
			nomenclatureARG.setLabel("Argentine");

			nomenclatures.add(nomenclatureF);
			nomenclatures.add(nomenclatureH);
			nomenclatures.add(nomenclatureARG);
			return nomenclatures;
		}).when(nomenclatureService).findAll();

		typeValidator.setEnv(environment);
		typeAutomaticControlUtils = spy(new TypeAutomaticControlUtils(ladRadRepository, ladRadValidator, typeRepository, typeValidator, typeLadRadService, collectRepository, collectEventHandler, edocTypeRepository, nomenclatureService, edocIndexRepository,
				docReferenceService, featureManagerLadRad));

		doReturn(true).when(typeAutomaticControlUtils).getSuccess(any(), any());
		doReturn(new StatusDocumentDTO()).when(typeAutomaticControlUtils).verifyStatusDocument(any(), any(), any(), any(), any());
		doReturn(new HashMap<>()).when(typeAutomaticControlUtils).verifyStatusDocuments(any(), any(), any(), any());

		typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, typeValidator, nomenclatureService, new EdocIndexRepositoryImpl(), featureManagerLadRad, pieceRepository, null, ladRadValidator,
				edocTypeRepository, typeRepository, docReferenceService, typeAutomaticControlUtils);
		typeAutomaticControlService.setEnvironment(environment);
		typeAutomaticControlService.setCollectRepository(collectRepository);

		final AuditEventService auditEventService = mock(AuditEventService.class);
		doNothing().when(auditEventService).sendAuditEventLadRAD(any(), any(), any(), any(), any(), any());
		doNothing().when(auditEventService).sendAuditEventLadRADFirstIteration(any(), any(), any(), any(), any(), any(), any(), any());
		doNothing().when(auditEventService).sendAuditEventLadRADSecondIteration(any(), any(), any(), any(), any(), any(), any());
		when(auditEventService.sendAuditEventForcedRecognition(any(), any(), any(), any(), any())).thenReturn(true);
		typeAutomaticControlUtils.setAuditEventService(auditEventService);
		typeAutomaticControlService.setAuditEventService(auditEventService);

	}

	@Test
	public void updateIndexesAndDeleteAll() {
		doNothing().when(ladRadRepository).deleteDocument(any(), any());
		doNothing().when(ladRadRepository).deleteFolder(any(), any());
		when(collectRepository.findOnlyCollect(any())).thenReturn(collect);
		type.setStatusControl("OK");
		type.setControlDocumentType("test");
		piece.setStatus(PieceStatus.DP.getLabel());
		typeAutomaticControlService.updateIndexesOnDeletePieces(collect, type, type.getPieces(), new Context("", ""), true);
		assertThat(type.getStatusControl()).isNull();
		assertThat(type.getCompletenessControl()).isNull();

	}

	@Test
	public void updateIndexesAndDeleteOne() {
		doNothing().when(ladRadRepository).deleteDocument(any(), any());
		doNothing().when(ladRadRepository).deleteFolder(any(), any());
		when(collectRepository.findOnlyCollect(any())).thenReturn(collect);
		final StatusDocumentDTO sd = new StatusDocumentDTO();
		sd.setReference("");
		type.setStatusControl("KO");
		type.setControlDocumentType("test");
		piece.setStatus(PieceStatus.DP.getLabel());
		piece.setStatusControl("OK");
		piece2.setStatusControl("KO");
		piece2.setTypeControl(PieceIndicators.KO_UNK.name());
		piece2.setState(PieceStates.INACTIF.getLabel());
		piece.setTypesJmc(Arrays.asList("identity_card_recto"));
		type.getPieces().add(piece2);
		type.getIndexes().forEach(indexe -> indexe.setIndexesJmc(new ArrayList<>(Arrays.asList(new IndexeJmc("", indexe.getReferenceValue(), "OK", piece.getId(), "abc")))));
		typeAutomaticControlService.updateIndexesOnDeletePieces(collect, type, new HashSet<Piece>(Arrays.asList(piece2)), new Context("1", "001"), true);
		assertThat(type.getStatusControl()).isEqualTo("OK");

	}

	@Test
	public void whenDeletePieceShouldTypeVAAUTO() {
		doNothing().when(ladRadRepository).deleteDocument(any(), any());
		doNothing().when(ladRadRepository).deleteFolder(any(), any());
		collect.setAutoValidation(true);
		when(collectRepository.findOnlyCollect(any())).thenReturn(collect);
		final StatusDocumentDTO sd = new StatusDocumentDTO();
		sd.setReference("");
		type.setStatusControl("KO");
		type.setControlDocumentType("test");
		piece.setStatus(PieceStatus.DP.getLabel());
		piece.setStatusControl("OK");
		piece2.setStatusControl("KO");
		piece2.setTypeControl(PieceIndicators.KO_UNK.name());
		piece2.setState(PieceStates.INACTIF.getLabel());
		piece.setTypesJmc(Arrays.asList("identity_card_recto"));
		type.getPieces().add(piece2);
		type.getIndexes().forEach(indexe -> indexe.setIndexesJmc(new ArrayList<>(Arrays.asList(new IndexeJmc("", indexe.getReferenceValue(), "OK", piece.getId(), "abc")))));
		typeAutomaticControlService.updateIndexesOnDeletePieces(collect, type, new HashSet<Piece>(Arrays.asList(piece2)), new Context("1", "001"), true);
		assertThat(type.getStatus()).isEqualTo("VA_AUTO");

	}

	@Test
	public void controlfirstIterationWhenJMCIsFailed() {
		doNothing().when(typeLadRadService).createFolderIfNotExists(any(), any(), any(), any(), any());
		doThrow(new TechnicalException("")).when(typeAutomaticControlUtils).verifyStatusDocument(any(), any(), any(), any(), any());
		doThrow(new TechnicalException("")).when(typeAutomaticControlUtils).verifyStatusDocuments(any(), any(), any(), any());
		when(collectRepository.findOnlyCollect(any())).thenReturn(collect);
		when(typeRepository.findOne(any(), any())).thenReturn(type);
		doNothing().when(collectEventHandler).sendAutomaticControlEvent(any(), any(), any());
		doNothing().when(pieceRepository).deletePiece(any());
		piece.setStatus(PieceStatus.DP.getLabel());
		typeAutomaticControlService.controlFirstIteration(collect.getId(), new Context("1", "001"), "000001", type, collect);
		assertThat(type.getStatusControl()).isEqualTo(TypeControls.ERR.name());
		type.getPieces().stream().forEach(piece -> assertThat(piece.getStatusControl()).isEqualTo(PieceControls.ERR.name()));
		type.getPieces().stream().forEach(pieceErr -> assertThat(pieceErr.getTypeControl()).isEqualTo(PieceIndicators.KO_UNK.name()));
		type.getIndexes().stream().filter(idx -> idx.getCategory().equals(IndexCategory.OB.name())).forEach(index1 -> assertThat(index1.getStatusControl()).isEqualTo(IndexStatus.KO_UNK.name()));

	}

	@Test
	public void controlfirstIterationIsOK() {
		doNothing().when(typeLadRadService).createFolderIfNotExists(any(), any(), any(), any(), any());
		when(collectRepository.findOnlyCollect(any())).thenReturn(collect);
		when(typeRepository.findOne(any(), any())).thenReturn(type);
		when(ladRadRepository.uploadDocument(any(), any(), any(), any())).thenReturn(null);
		doNothing().when(collectEventHandler).sendAutomaticControlEvent(any(), any(), any());
		doNothing().when(pieceRepository).deletePiece(any());
		piece.setStatus(PieceStatus.DP.getLabel());
		piece.setStatusControl("");
		piece.setState(PieceStates.ACTIF.name());
		piece.setTypesJmc(Arrays.asList("identity_card_recto"));
		type.getIndexes().forEach(indexe -> indexe.setIndexesJmc(new ArrayList<>(Arrays.asList(new IndexeJmc("", indexe.getReferenceValue(), "OK", piece.getId(), "abc")))));
		typeAutomaticControlService.controlFirstIteration(collect.getId(), new Context("1", "001"), "000001", type, collect);
		assertThat(type.getStatusControl()).isEqualTo(TypeControls.OK.name());
		type.getPieces().stream().forEach(piece -> assertThat(piece.getStatusControl()).isEqualTo(PieceControls.OK.name()));
		type.getPieces().stream().forEach(pieceErr -> assertThat(pieceErr.getTypeControl()).isEqualTo(PieceIndicators.OK.name()));

	}

	@Test
	public void controlSecondIterationIsOK() {
		doNothing().when(typeLadRadService).createFolderIfNotExists(any(), any(), any(), any(), any());
		when(collectRepository.findOnlyCollect(any())).thenReturn(collect);
		when(typeRepository.findOne(any(), any())).thenReturn(type);
		doNothing().when(collectEventHandler).sendAutomaticControlEvent(any(), any(), any());
		doNothing().when(pieceRepository).deletePiece(any());
		piece.setStatus(PieceStatus.DP.getLabel());
		piece.setStatusControl("");
		piece.setState(PieceStates.ACTIF.name());
		piece.setControlIterationAchieved(1);
		piece.setTypesJmc(Arrays.asList("identity_card_recto"));
		piece.setTypeControl(PieceControls.OK.name());
		type.getIndexes().forEach(indexe -> indexe.setIndexesJmc(new ArrayList<>(Arrays.asList(new IndexeJmc("", indexe.getReferenceValue(), "OK", piece.getId(), "abc")))));
		typeAutomaticControlService.controlSecondIteration(collect, type, type, new Context("1", "001", "001"));
		assertThat(type.getStatusControl()).isEqualTo(TypeControls.OK.name());
		type.getPieces().stream().forEach(piece -> assertThat(piece.getStatusControl()).isEqualTo(PieceControls.OK.name()));
	}

	@Test
	public void controlSecondIterationAutoAcceptationOk() {
		doNothing().when(typeLadRadService).createFolderIfNotExists(any(), any(), any(), any(), any());
		when(collectRepository.findOnlyCollect(any())).thenReturn(collect);
		when(typeRepository.findOne(any(), any())).thenReturn(type);
		doNothing().when(collectEventHandler).sendAutomaticControlEvent(any(), any(), any());
		doNothing().when(pieceRepository).deletePiece(any());
		piece.setStatus(PieceStatus.DP.getLabel());
		piece.setStatusControl("");
		piece.setState(PieceStates.ACTIF.name());
		piece.setControlIterationAchieved(1);
		piece.setTypesJmc(Arrays.asList("passeport"));
		piece.setTypeControl(PieceControls.OK.name());
		type.getIndexes().forEach(indexe -> indexe.setIndexesJmc(new ArrayList<>(Arrays.asList(new IndexeJmc("", indexe.getReferenceValue(), "KO", piece.getId(), "abc")))));
		typeAutomaticControlService.controlSecondIteration(collect, type, type, new Context("1", "001", "001"));
		assertThat(type.getStatus()).isEqualTo(TypeStatus.RC_AUTO.getLabel());
		type.getPieces().stream().forEach(piece -> assertThat(piece.getStatus()).isEqualTo(PieceStatus.RC.getLabel()));
	}

}
