package com.bnpparibas.bddf.collect.domain.collect;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.ExpectedException;

import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.nomenclature.Nomenclature;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.type.ControlRequired;
import com.bnpparibas.bddf.collect.domain.type.FamilyCategory;
import com.bnpparibas.bddf.collect.domain.type.FamilyRepository;
import com.bnpparibas.bddf.collect.domain.type.PropertyType;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.google.common.collect.ImmutableSet;

public abstract class AbstractServiceTest {

	protected static final Set<String> AUTHORIZED_FORMATS = ImmutableSet.of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIF", "TIFF", "XLS", "DOC");
	protected static final Set<String> ALL_FAMILIES_MANAGMENT_ACT = Arrays.stream(FamiliesManagmentAct.values()).map(FamiliesManagmentAct::name).collect(Collectors.toSet());
	protected static final Set<String> ALL_PIECES_MANAGMENT_ACT = Arrays.stream(PiecesManagmentAct.values()).map(PiecesManagmentAct::name).collect(Collectors.toSet());

	protected UUID collectId;
	protected UUID collectIdEdocType;
	protected String ownerReference;
	protected Owner owner;
	protected UUID typeOBListeId;
	protected UUID typeOBListeWithAPaperPieceId;
	protected UUID pieceId;
	protected String channel;
	protected Piece paperPiece;
	protected Piece pieceToAdd;
	protected UUID collectWithSubTypeId;
	protected UUID typeWSTID;
	protected UUID typeWith5PiecesId;
	protected UUID subTypeWSTID;
	protected UUID familyTypeOBIDToAdd;
	protected Type familyTypeOBToAdd;
	protected UUID typeWithfacultativeFamilyID;
	protected Type typeWithFacultativeFamily;
	protected UUID collectWithFacultativeFamilyId;
	protected UUID collectWithoutActMangmentId;
	protected UUID typeWithActManagmentInFamilyID;
	protected Type typeWithActManagmentInFamily;
	protected UUID familyWithEdocTypeId;
	protected UUID familyOBId;

	@Rule
	public final ExpectedException exception = ExpectedException.none();

	// Mock repo
	protected CollectRepository collectRepository;
	protected TypeRepository typeRepository;
	protected FamilyRepository familyRepository;
	protected PieceRepository pieceRepository;
	protected PieceGdnRepository pieceGdnRepository;
	protected CollectEventHandler collectEventHandler;
	protected NomenclatureService nomenclatureService;

	// Mock database
	protected Set<Collect> collects;
	protected List<Owner> owners;
	protected Map<UUID, List<String>> ownerByCollect;
	protected UUID validateTypeId;
	protected UUID validateRcTypeId;
	protected UUID typeWithDFId;
	protected UUID typeWithEdocTypeId;
	protected UUID subTypeWithEdocTypeId;
	protected UUID collectWithSubTypePieceId;
	protected Collect collectWithSubTypePiece;
	protected UUID typeSubPieceId;
	protected UUID subTypePieceId;
	protected Type typeNDListe;
	protected UUID RcpieceId;
	protected Type validateRcType;

	private void addCollect(Collect collectAdded) {
		collectAdded.setOwners(collectAdded.getOwners());
		collectAdded.setTypes(collectAdded.getTypes());
		collects.add(collectAdded);
		owners.addAll(collectAdded.getOwners());
		// ownerByCollect.put(collectAdded.getId(), ownersAdded.stream().map(Owner::getReference).collect(Collectors.toList()));
		// when(typeRepository.findByCollect(collectAdded.getId())).thenReturn(typesAdded);
	}

	public void setUp() {
		collectRepository = mock(CollectRepository.class);
		typeRepository = mock(TypeRepository.class);
		collectEventHandler = mock(CollectEventHandler.class);
		pieceRepository = mock(PieceRepository.class);
		pieceGdnRepository = mock(PieceGdnRepository.class);
		familyRepository = mock(FamilyRepository.class);
		nomenclatureService = mock(NomenclatureService.class);

		//////////////////////////////////////////////////
		// COLLECTS

		collects = new HashSet<>();

		doAnswer(invocation -> {
			final Object[] arguments = invocation.getArguments();
			final Collect collectAdded = (Collect) arguments[0];
			addCollect(collectAdded);
			return null;
		}).when(collectRepository).add(any());

		//////////////////////////////////////////////////
		// OWNERS

		owners = new ArrayList<>();
		ownerByCollect = new HashMap<>();

		// owners.forEach(o -> when(ownerRepository.findOne(o.getReference())).thenReturn(o));

		//////////////////////////////////////////////////
		// TYPES

		//////////////////////////////////////////////////
		// PIECES

		///// PREPARE DATAS

		// owner
		ownerReference = "123456789";
		owner = new Owner(ownerReference, "Jean", "Dupond", LocalDate.now(), 1, "1234567", null);

		// type 1
		typeOBListeId = UUID.randomUUID();
		familyOBId = UUID.randomUUID();
		final Type typeOBListe1 = new Type(typeOBListeId, null, familyOBId, ImmutableSet.of(ownerReference), "Médicale", FamilyCategory.OB.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null, true, null, 1000000,
				0, null, false, null, true, null, false, false, null, null, true);

		// type with paperPiece
		typeOBListeWithAPaperPieceId = UUID.randomUUID();
		final Type typeOBListeWithAPaperPiece = new Type(typeOBListeWithAPaperPieceId, null, UUID.randomUUID(), ImmutableSet.of(ownerReference), "Médicale", FamilyCategory.OB.name(), null, PropertyType.LISTE.getLabel(), null,
				"info compl famille assurance", null, null, true, null, 1000000, 0, null, false, null, true, null, false, false, null, null, true);

		typeWith5PiecesId = UUID.randomUUID();
		final Type typeWith5Pieces = new Type(typeWith5PiecesId, null, UUID.randomUUID(), ImmutableSet.of(ownerReference), "Médicale", FamilyCategory.OB.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null, true,
				null, 1000000, 0, null, false, null, false, null, false, false, null, null, true);

		validateTypeId = UUID.randomUUID();
		final Type validateType = new Type(validateTypeId, null, UUID.randomUUID(), ImmutableSet.of(ownerReference), "Médicale", FamilyCategory.OB.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null, true, null,
				1000000, 0, null, false, null, TypeStatus.VA.getLabel(), true, "", null, false, false, null, null);

		typeWithDFId = UUID.randomUUID();

		validateRcTypeId = UUID.randomUUID();

		validateRcType = new Type(validateRcTypeId, null, UUID.randomUUID(), ImmutableSet.of(ownerReference), "Médicale", FamilyCategory.OB.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null, true, null, 1000000,
				0, null, false, null, TypeStatus.RC.getLabel(), true, "", null, false, false, null, null);
		validateRcType.setControlRequired(ControlRequired.CONTROL_JMC.getCode());
		typeWithDFId = UUID.randomUUID();

		final Type typeWithDF = new Type(typeWithDFId, null, typeOBListe1.getFamilyId(), ImmutableSet.of(ownerReference), "Médicale", FamilyCategory.OB.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null, true,
				null, 1000000, 0, null, false, null, TypeStatus.IN.getLabel(), true, "", null, false, false, null, null);

		typeWithEdocTypeId = UUID.randomUUID();
		familyWithEdocTypeId = UUID.randomUUID();
		final Type typeWithEdocType = new Type(typeWithEdocTypeId, null, familyWithEdocTypeId, ImmutableSet.of(ownerReference), "Médicale", FamilyCategory.OB.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null,
				true, null, 1000000, 0, null, false, null, TypeStatus.IN.getLabel(), true, "", null, false, false, null, null);
		typeWithEdocType.setEdocType("00000000000000001");
		typeWithEdocType.setEnableReuse(true);

		subTypeWithEdocTypeId = UUID.randomUUID();
		final Type typeWithEdocTypeAndSubType = new Type(UUID.randomUUID(), null, UUID.randomUUID(), ImmutableSet.of(ownerReference), "Médicale", FamilyCategory.OB.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null,
				null, true, null, 1000000, 0, null, false, null, TypeStatus.IN.getLabel(), true, "", null, false, false, null, null);
		final Type subTypeWithEdocType = new Type(subTypeWithEdocTypeId, typeWithEdocTypeAndSubType.getId(), typeWithEdocTypeAndSubType.getFamilyId(), ImmutableSet.of(ownerReference), "Médicale", FamilyCategory.OB.name(), null,
				PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null, true, null, 1000000, 0, null, false, null, TypeStatus.IN.getLabel(), true, "", null, false, false, null, null);
		subTypeWithEdocType.setEdocType("00000000000000001");
		subTypeWithEdocType.setEnableReuse(true);

		// Family to add to an existant collect
		familyTypeOBIDToAdd = UUID.randomUUID();
		familyTypeOBToAdd = new Type(typeOBListeId, null, UUID.randomUUID(), ImmutableSet.of(ownerReference), "Médicale", FamilyCategory.OB.name(), null, PropertyType.FIXE.getLabel(), null, "info compl famille assurance", null, null, true, null, 1000000,
				0, null, false, null, false, null, false, false, null, null, true);
		familyTypeOBToAdd.setEdocType("00000000000000001");

		// FacultatifFamily
		typeWithfacultativeFamilyID = UUID.randomUUID();
		typeWithFacultativeFamily = new Type(typeWithfacultativeFamilyID, null, UUID.randomUUID(), ImmutableSet.of(ownerReference), "Médicale", FamilyCategory.FA.name(), null, PropertyType.FIXE.getLabel(), null, "info compl famille assurance", null, null,
				true, null, 1000000, 0, null, false, null, false, null, false, false, null, null, true);
		typeWithFacultativeFamily.setEdocType("00000000000000001");
		// type with act managment declared in family
		typeWithActManagmentInFamilyID = UUID.randomUUID();
		typeWithActManagmentInFamily = new Type(typeWithActManagmentInFamilyID, null, UUID.randomUUID(), ImmutableSet.of(ownerReference), "Médicale", FamilyCategory.FA.name(), null, PropertyType.FIXE.getLabel(), null, "info compl famille assurance", null,
				null, true, null, 1000000, 0, null, false, null, false, null, false, false, null, null, true);
		typeWithActManagmentInFamily.setFamiliesManagementActFamily(ALL_FAMILIES_MANAGMENT_ACT);
		typeWithFacultativeFamily.setEdocType("00000000000000001");

		// collect
		collectId = UUID.randomUUID();
		final Collect ecCollect = new Collect(collectId, CollectStatus.EC.name(), Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", AUTHORIZED_FORMATS, ALL_PIECES_MANAGMENT_ACT, ALL_FAMILIES_MANAGMENT_ACT, null, "AP001", false,
				false, 0, false, 0);
		ecCollect.setOwners(new HashSet<>(Arrays.asList(owner)));
		ecCollect.setTypes(new HashSet<>(Arrays.asList(typeOBListe1, typeOBListeWithAPaperPiece, typeWith5Pieces, validateType, typeWithDF, typeWithEdocType, typeWithEdocTypeAndSubType, subTypeWithEdocType, familyTypeOBToAdd, validateRcType)));
		collectRepository.add(ecCollect);

		collectIdEdocType = UUID.randomUUID();
		final Collect ecCollectEdocType = new Collect(collectIdEdocType, CollectStatus.EC.name(), Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", AUTHORIZED_FORMATS, ALL_PIECES_MANAGMENT_ACT, ALL_FAMILIES_MANAGMENT_ACT, null,
				"AP001", false, false, 0, false, 0);
		ecCollectEdocType.setOwners(new HashSet<>(Arrays.asList(owner)));
		ecCollectEdocType.setTypes(new HashSet<>(Arrays.asList(typeWithEdocType)));
		collectRepository.add(ecCollectEdocType);

		// collect with facultative family
		collectWithFacultativeFamilyId = UUID.randomUUID();
		final Collect collectWithFacultativeFamily = new Collect(collectWithFacultativeFamilyId, CollectStatus.EC.name(), Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", AUTHORIZED_FORMATS, ALL_PIECES_MANAGMENT_ACT,
				ALL_FAMILIES_MANAGMENT_ACT, null, "AP001", false, false, 0, false, 0);
		collectWithFacultativeFamily.setOwners(new HashSet<>(Arrays.asList(owner)));
		collectWithFacultativeFamily.setTypes(new HashSet<>(Arrays.asList(typeWithFacultativeFamily)));
		collectRepository.add(collectWithFacultativeFamily);

		// collect without act family managment
		collectWithoutActMangmentId = UUID.randomUUID();
		final Collect collectWithoutActManagment = new Collect(collectWithoutActMangmentId, CollectStatus.EC.name(), Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", AUTHORIZED_FORMATS, ALL_PIECES_MANAGMENT_ACT, null, null,
				"AP001", false, false, 0, false, 0);
		collectWithoutActManagment.setOwners(new HashSet<>(Arrays.asList(owner)));
		collectWithoutActManagment.setTypes(new HashSet<>(Arrays.asList(typeWithActManagmentInFamily)));
		collectRepository.add(collectWithoutActManagment);

		// pieces
		pieceId = UUID.randomUUID();
		final Piece piece1 = new Piece(pieceId, "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "DP", "GD4564687876768", null, null, null, null, false);
		final Piece piece2 = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "DP", "GD4564687876768", null, null, null, null, false);
		typeOBListe1.setPieces(new HashSet<>(Arrays.asList(piece1, piece2)));

		final Piece pieceDF1 = new Piece(pieceId, "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "DF", "GD4564687876768", null, null, null, null, false);
		final Piece pieceDF2 = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "DF", "GD4564687876768", null, null, null, null, false);
		typeWithDF.setPieces(new HashSet<>(Arrays.asList(pieceDF1, pieceDF2)));

		final Piece piece3 = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "PAP", "VA", "GD4564687876768", null, null, null, null, false);
		typeOBListeWithAPaperPiece.setPieces(new HashSet<>(Arrays.asList(piece3)));
		typeWithFacultativeFamily.setPieces(new HashSet<>(Arrays.asList(piece3)));

		final Piece pieceDP = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "DP", "GD4564687876768", null, null, null, null, false);
		typeWithEdocType.setPieces(new HashSet<>(Arrays.asList(pieceDP)));
		final Piece pieceDP2 = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "DP", "GD4564687876768", null, null, null, null, false);
		subTypeWithEdocType.setPieces(new HashSet<>(Arrays.asList(pieceDP2)));

		final Piece piece51 = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "TP", "GD4564687876768", null, null, null, null, false);
		final Piece piece52 = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "TP", "GD4564687876768", null, null, null, null, false);
		final Piece piece53 = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "TP", "GD4564687876768", null, null, null, null, false);
		final Piece piece54 = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "TP", "GD4564687876768", null, null, null, null, false);
		final Piece piece55 = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "TP", "GD4564687876768", null, null, null, null, false);
		typeWith5Pieces.setPieces(new HashSet<>(Arrays.asList(piece51, piece52, piece53, piece54, piece55)));

		final Piece validatedPiece = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "VA", "GD4564687876768", null, null, null, null, false);
		final Set<Piece> piecesValidated = new HashSet<>();
		piecesValidated.add(validatedPiece);
		validateType.setPieces(piecesValidated);

		RcpieceId = UUID.randomUUID();

		final Piece validatedRcPiece = new Piece(RcpieceId, "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "RC", "GD4564687876768", null, null, "KO", null, false);
		final Set<Piece> piecesValidatedRc = new HashSet<>();
		piecesValidatedRc.add(validatedRcPiece);
		validateRcType.setPieces(piecesValidatedRc);

		// Collect with subType
		collectWithSubTypeId = UUID.randomUUID();
		final Collect collectWithSubType = new Collect(collectWithSubTypeId, CollectStatus.EC.name(), Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", AUTHORIZED_FORMATS, ALL_PIECES_MANAGMENT_ACT, ALL_FAMILIES_MANAGMENT_ACT,
				null, "AP001", false, false, 0, false, 0);

		final UUID familyId = UUID.randomUUID();
		typeWSTID = UUID.randomUUID();
		subTypeWSTID = UUID.randomUUID();
		final Type typeOBListeCWST = new Type(typeWSTID, null, familyId, ImmutableSet.of(ownerReference), "Médicale", FamilyCategory.OB.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null, false, null,
				new Random().nextLong(), 0, null, false, null, false, null, false, false, null, null, true);
		final Type subTypeOBListeCWST = new Type(subTypeWSTID, typeWSTID, familyId, ImmutableSet.of(ownerReference), "Radio", FamilyCategory.OB.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null, false, null,
				new Random().nextLong(), 0, null, false, null, true, null, false, false, null, null, true);
		collectWithSubType.setOwners(new HashSet<>(Arrays.asList(owner)));
		collectWithSubType.setTypes(new HashSet<>(Arrays.asList(typeOBListeCWST, subTypeOBListeCWST)));

		final Piece piece4 = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), new Random().nextLong(), "NUM", "DP", "GD4564687876768", null, null, null, null, false);
		subTypeOBListeCWST.setPieces(new HashSet<>(Arrays.asList(piece4)));

		paperPiece = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 0, "PAP", "VA", "GD4564687876768", null, null, null, null, false);
		pieceToAdd = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "TP", "GD4564687876768", null, null, null, null, false);
		addCollect(collectWithSubType);

		// COllect SubTypePiece
		collectWithSubTypePieceId = UUID.randomUUID();
		collectWithSubTypePiece = new Collect(collectWithSubTypePieceId, CollectStatus.EC.name(), Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", AUTHORIZED_FORMATS, ALL_PIECES_MANAGMENT_ACT, ALL_FAMILIES_MANAGMENT_ACT, null,
				"AP001", false, false, 0, false, 0);

		final UUID familyIdTypePiece = UUID.randomUUID();
		typeSubPieceId = UUID.randomUUID();
		subTypePieceId = UUID.randomUUID();
		typeNDListe = new Type(typeSubPieceId, null, familyIdTypePiece, ImmutableSet.of(ownerReference), "Médicale", FamilyCategory.ND.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null, false, null,
				new Random().nextLong(), 0, null, false, null, false, null, false, false, null, null, true);
		final Type subTypeListePIece = new Type(subTypePieceId, typeSubPieceId, familyIdTypePiece, ImmutableSet.of(ownerReference), "Radio", FamilyCategory.ND.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null,
				false, null, new Random().nextLong(), 0, null, false, null, false, null, false, false, null, null, true);
		collectWithSubTypePiece.setOwners(new HashSet<>(Arrays.asList(owner)));
		collectWithSubTypePiece.setTypes(new HashSet<>(Arrays.asList(typeNDListe, subTypeListePIece)));

		final Piece pieceND = new Piece(UUID.randomUUID(), "avis_impot1.doc", ownerReference, "123456", Channel.SPIRIT.getValue(), Instant.now(), new Random().nextLong(), "NUM", "DP", "GD4564687876768", null, null, null, null, false);
		subTypeListePIece.setPieces(new HashSet<>(Arrays.asList(pieceND)));

		addCollect(collectWithSubTypePiece);

	}

	@Before
	public void before() throws Exception {
		setUp();
		prepareDatas();
		prepareMock();
	}

	protected void prepareMock() {

		collects.forEach(c -> when(collectRepository.findOne(c.getId())).thenReturn(c));
		collects.forEach(c -> when(collectRepository.findOnlyCollect(c.getId())).thenReturn(c));

		collects.forEach(c -> c.getTypes().forEach(t -> t.getPieces().forEach(p -> {
			if (p.getStatus().equals(PieceStatus.DP.getLabel())) {
				when(pieceGdnRepository.getPieceData(eq(p.getId()), any(), any())).thenReturn(ByteBuffer.allocate(1000));
			}
			when(pieceRepository.getPiece(c.getId(), t.getId(), p.getId())).thenReturn(p);
			when(pieceRepository.getPieceFromNas(p.getId())).thenReturn(ByteBuffer.allocate(1000));
			when(pieceRepository.getThumbnail(p.getId())).thenReturn(ByteBuffer.allocate(1000));
		})));
		collects.forEach(c -> c.getTypes().forEach(t -> when(typeRepository.findOne(c.getId(), t.getId())).thenReturn(t)));
		collects.forEach(c -> c.getTypes().forEach(t -> when(typeRepository.findOneWithInactivePieces(c.getId(), t.getId())).thenReturn(t)));
		when(collectRepository.findAll()).thenReturn(collects.stream().map(Collect::getId).collect(Collectors.toSet()));
		doNothing().when(typeRepository).updateType(any(), any());
		doNothing().when(typeRepository).addTypes(any(), any());
		doNothing().when(familyRepository).add(any(), any());
		doNothing().when(pieceRepository).addPieceData(any(), any(), any(), any());
		doAnswer(invocation -> {
			final UUID id = invocation.getArgument(0);
			return collects.stream().filter(c -> c.getId().equals(id)).findAny().map(Collect::getTypes).orElse(new HashSet<>());
		}).when(typeRepository).findByCollect(any());
		doAnswer(invocation -> {
			final UUID collectId = invocation.getArgument(0);
			final UUID typetId = invocation.getArgument(1);
			collects.stream().filter(c -> c.getId().equals(collectId)).findAny().get().setTypes(collects.stream().filter(c -> c.getId().equals(collectId)).findAny().map(Collect::getTypes).orElse(new HashSet<>())
					//
					.stream().filter(t -> !t.getId().equals(typetId)).collect(Collectors.toSet())

			);
			return null;
		}).when(familyRepository).delete(any());

		doAnswer(invocation -> {
			final List<Nomenclature> nomenclatures = new ArrayList<>();
			final Nomenclature nomenclatureF = new Nomenclature();
			nomenclatureF.setCode("F");
			nomenclatureF.setEdoc("10000000000000001");
			nomenclatureF.setJmc("F");
			nomenclatureF.setLabel("Féminin");

			final Nomenclature nomenclatureH = new Nomenclature();
			nomenclatureH.setCode("MEdoc");
			nomenclatureH.setEdoc("10000000000000001");
			nomenclatureH.setJmc("M");
			nomenclatureH.setLabel("Masculin");

			final Nomenclature nomenclatureARG = new Nomenclature();
			nomenclatureARG.setCode("ARGEdoc");
			nomenclatureARG.setEdoc("10000000000000007");
			nomenclatureARG.setJmc("ARG");
			nomenclatureARG.setLabel("Argentine");

			nomenclatures.add(nomenclatureF);
			nomenclatures.add(nomenclatureH);
			nomenclatures.add(nomenclatureARG);
			return nomenclatures;
		}).when(nomenclatureService).findAll();
	}

	/**
	 * Implement this method: add a collect with addCollect method, add piece in pieces, and put references in pieceByCollect
	 *
	 * @throws Exception
	 *             TODO fill parameter description
	 */
	public abstract void prepareDatas() throws Exception;

}
