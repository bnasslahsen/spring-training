package com.bnpparibas.bddf.collect.domain.ladrad;

import static org.assertj.core.api.Assertions.assertThat;

import java.net.URISyntaxException;
import java.time.Instant;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;

import com.bnp.schema.edoc.index.Indexes.EdocIndex;
import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.index.IndexeJmc;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceIndicators;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.TypeControls;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.type.ControlRequired;
import com.bnpparibas.bddf.collect.domain.type.FamilyCategory;
import com.bnpparibas.bddf.collect.domain.type.IndexStatus;
import com.bnpparibas.bddf.collect.domain.type.PropertyType;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.google.common.collect.ImmutableSet;

public class LadRadValidatorTest {

	private Type type;
	private Piece piece;
	private UUID typeID;
	private LadRadValidator ladRadValidator;
	private List<EdocType> edocTypes;
	private List<EdocIndex> edocIndexes;
	private UUID typeIDOwners;
	private Type typeOwners;
	private Piece pieceOwners;

	@Before
	public void setUp() throws URISyntaxException {
		initData();
		initData2IndexOwners();
	}

	private void initData2IndexOwners() {
		typeIDOwners = UUID.randomUUID();
		typeOwners = new Type(typeIDOwners, null, null, null, "Facture EDF", FamilyCategory.OB.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null, false, null, new Random().nextLong(), 0, null, false, null, false,
				null, false, false, null, null, true);
		typeOwners.setControlRequired(ControlRequired.CONTROL_JMC.getCode());
		typeOwners.setEdocType("00000000000000030");
		typeOwners.setCompleteness(ImmutableSet.of("20000000000000036"));
		pieceOwners = new Piece(UUID.randomUUID(), "factEDF.pdf", null, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "TP", "GD4564687876768", null, null, "", null, false);
		final Set<Piece> lisPieces = new HashSet<>();
		lisPieces.add(pieceOwners);
		typeOwners.setPieces(lisPieces);
		edocTypes = (new EdocTypesRepositoryImpl()).findAll();
		edocIndexes = (new EdocIndexRepositoryImpl()).findAll();
		ladRadValidator = new LadRadValidator();
	}

	public void initData() throws URISyntaxException {
		typeID = UUID.fromString("00b27725-a4b4-445b-b8ba-9f3558533ae0");
		type = new Type(typeID, null, null, null, "Médicale", FamilyCategory.OB.name(), null, PropertyType.LISTE.getLabel(), null, "info compl famille assurance", null, null, false, null, new Random().nextLong(), 0, null, false, null, false, null, false,
				false, null, null, true);
		type.setControlRequired(ControlRequired.CONTROL_JMC.getCode());
		type.setEdocType("00000000000000001");
		type.setCompleteness(ImmutableSet.of("20000000000000001"));
		piece = new Piece(UUID.randomUUID(), "avis_impot1.doc", null, "123456", Channel.SPIRIT.getValue(), Instant.now(), 5000, "NUM", "TP", "GD4564687876768", null, null, "", null, false);
		final Set<Piece> lisPieces = new HashSet<>();
		lisPieces.add(piece);
		type.setPieces(lisPieces);
		edocTypes = (new EdocTypesRepositoryImpl()).findAll();
		edocIndexes = (new EdocIndexRepositoryImpl()).findAll();
		ladRadValidator = new LadRadValidator();
	}

	@Test
	public void updatePiecesWithTwoPiecesInTheSameEdocTypeShouldToBeOK() {
		piece.setTypesJmc(Arrays.asList("identity_card_recto"));
		ladRadValidator.calculateIndicatorsPieces(piece, type, edocTypes, edocIndexes);
		assertThat(piece.getTypeControl()).isEqualTo(PieceIndicators.OK.name());

	}

	@Test
	public void updatePiecesWithTwoPiecesInDifferentEdocTypeShouldToBeKO_EXP() {
		piece.setTypesJmc(Arrays.asList("passport"));
		ladRadValidator.calculateIndicatorsPieces(piece, type, edocTypes, edocIndexes);
		assertThat(piece.getTypeControl()).isEqualTo(PieceIndicators.KO_EXP.name());
		assertThat(piece.getCoherenceControl()).isEqualTo(PieceIndicators.KO.name());
		assertThat(piece.getExtractionControl()).isEqualTo(PieceIndicators.KO.name());

	}

	@Test
	public void updatePiecesWithUnknownDocumentTypeShouldToBeKO_EXP() {
		piece.setTypesJmc(Arrays.asList("unknown"));
		ladRadValidator.calculateIndicatorsPieces(piece, type, edocTypes, edocIndexes);
		assertThat(piece.getTypeControl()).isEqualTo(PieceIndicators.KO_UNK.name());
		assertThat(piece.getCoherenceControl()).isEqualTo(PieceIndicators.KO.name());
		assertThat(piece.getExtractionControl()).isEqualTo(PieceIndicators.KO.name());

	}

	@Test
	public void updatePiecesWithUnknownIndexShouldToBeOK() {
		piece.setTypesJmc(Arrays.asList("identity_card_recto"));
		final Indexe idxName = new Indexe(UUID.randomUUID(), "10000000000000002", null, "OB", true, "CERYHIER", null, null, "A", 2, null, null, "1", "", false, null);
		idxName.setStatusControl(IndexStatus.KO_UNK.name());
		final Indexe idxFirstName = new Indexe(UUID.randomUUID(), "10000000000000003", null, "OB", true, "CORLNNE", null, null, "A", 2, null, null, "1", "", false, null);
		idxFirstName.setStatusControl(IndexStatus.OK.name());
		idxFirstName.setIndexesJmc(Arrays.asList(new IndexeJmc("usual_name", "Dahm", "OK", piece.getId(), "34fr2e")));
		type.setIndexes(ImmutableSet.of(idxName, idxFirstName));
		ladRadValidator.calculateIndicatorsPieces(piece, type, edocTypes, edocIndexes);
		assertThat(piece.getTypeControl()).isEqualTo(PieceIndicators.OK.name());
		assertThat(piece.getCoherenceControl()).isEqualTo(PieceIndicators.OK.name());
		assertThat(piece.getExtractionControl()).isEqualTo(PieceIndicators.OK.name());

	}

	@Test
	public void updatePiecesWithDuplicatedIndexInTheSamePieceEdocShouldToBeKOCohe() {
		piece.setTypesJmc(Arrays.asList("identity_card_recto"));
		final Indexe idxName = new Indexe(UUID.randomUUID(), "10000000000000002", null, "OB", true, "CERYHIER", null, null, "A", 2, null, null, "1", "", false, null);
		idxName.setStatusControl(IndexStatus.KO_COHE.name());
		idxName.setIndexesJmc(Arrays.asList(new IndexeJmc("name", "Dahm", "OK", piece.getId(), "34fr2e"), new IndexeJmc("name", "Dahm", "OK", piece.getId(), "34fr2e")));
		final Indexe idxFirstName = new Indexe(UUID.randomUUID(), "10000000000000003", null, "OB", true, "CORLNNE", null, null, "A", 2, null, null, "1", "", false, null);
		idxFirstName.setStatusControl(IndexStatus.OK.name());
		idxFirstName.setIndexesJmc(Arrays.asList(new IndexeJmc("usual_name", "Dahm", "OK", piece.getId(), "34fr2e")));
		type.setIndexes(ImmutableSet.of(idxName, idxFirstName));
		ladRadValidator.calculateIndicatorsPieces(piece, type, edocTypes, edocIndexes);
		assertThat(piece.getTypeControl()).isEqualTo(PieceIndicators.OK.name());
		assertThat(piece.getCoherenceControl()).isEqualTo(PieceIndicators.KO.name());
		assertThat(piece.getExtractionControl()).isEqualTo(PieceIndicators.OK.name());

	}

	@Test
	public void updatePiecesWithDuplicatedIndexInTheTwoPieceEdocShouldToBeKOMult() {
		final UUID pieceid2 = UUID.randomUUID();
		piece.setTypesJmc(Arrays.asList("identity_card_recto"));
		final Indexe idxName = new Indexe(UUID.randomUUID(), "10000000000000002", null, "OB", true, "CERYHIER", null, null, "A", 2, null, null, "1", "", false, null);
		idxName.setStatusControl(IndexStatus.KO_MULT.name());
		idxName.setIndexesJmc(Arrays.asList(new IndexeJmc("name", "Dahm", "OK", piece.getId(), "34fr2e"), new IndexeJmc("name", "Dahm", "KO", UUID.randomUUID(), "34fr2e")));
		final Indexe idxFirstName = new Indexe(UUID.randomUUID(), "10000000000000003", null, "OB", true, "CORLNNE", null, null, "A", 2, null, null, "1", "", false, null);
		idxFirstName.setStatusControl(IndexStatus.OK.name());
		idxFirstName.setIndexesJmc(Arrays.asList(new IndexeJmc("usual_name", "Dahm", "OK", piece.getId(), "34fr2e")));
		type.setIndexes(ImmutableSet.of(idxName, idxFirstName));
		ladRadValidator.calculateIndicatorsPieces(piece, type, edocTypes, edocIndexes);
		assertThat(piece.getTypeControl()).isEqualTo(PieceIndicators.OK.name());
		assertThat(piece.getCoherenceControl()).isEqualTo(PieceIndicators.KO.name());
		assertThat(piece.getExtractionControl()).isEqualTo(PieceIndicators.OK.name());

	}

	@Test
	public void updatePiecesWithWarningExtrIndexAndNoKoIndexEdocShouldToBeExtrWarning() {
		piece.setTypesJmc(Arrays.asList("identity_card_recto"));
		final Indexe idxName = new Indexe(UUID.randomUUID(), "10000000000000002", null, "OB", true, "CERYHIER", null, null, "A", 2, null, null, "1", "", false, null);
		idxName.setStatusControl(IndexStatus.OK.name());
		idxName.setIndexesJmc(Arrays.asList(new IndexeJmc("name", "Dahm", "OK", piece.getId(), "34fr2e"), new IndexeJmc("name", "Dahm", "OK", UUID.randomUUID(), "34fr2e")));
		final Indexe idxFirstName = new Indexe(UUID.randomUUID(), "10000000000000003", null, "FA", true, "CORLNNE", null, null, "A", 2, null, null, "1", "", false, null);
		idxFirstName.setStatusControl(IndexStatus.WARNING_EXTR.name());
		idxFirstName.setIndexesJmc(Arrays.asList(new IndexeJmc("usual_name", "Dahm", "KO", piece.getId(), "34fr2e")));
		type.setIndexes(ImmutableSet.of(idxName, idxFirstName));
		ladRadValidator.calculateIndicatorsPieces(piece, type, edocTypes, edocIndexes);
		assertThat(piece.getTypeControl()).isEqualTo(PieceIndicators.OK.name());
		assertThat(piece.getCoherenceControl()).isEqualTo(PieceIndicators.OK.name());
		assertThat(piece.getExtractionControl()).isEqualTo(PieceIndicators.WARNING.name());

	}

	@Test
	public void updatePiecesWithValidIndexeToBeOK() {
		piece.setTypesJmc(Arrays.asList("identity_card_recto"));
		final Indexe idxName = new Indexe(UUID.randomUUID(), "10000000000000002", null, "OB", true, "CERYHIER", null, null, "A", 2, null, null, "1", "", false, null);
		idxName.setStatusControl(IndexStatus.OK.name());
		idxName.setIndexesJmc(Arrays.asList(new IndexeJmc("name", "Dahm", "OK", piece.getId(), "34fr2e"), new IndexeJmc("name", "Dahm", "OK", UUID.randomUUID(), "34fr2e")));
		final Indexe idxFirstName = new Indexe(UUID.randomUUID(), "10000000000000003", null, "FA", true, "CORLNNE", null, null, "A", 2, null, null, "1", "", false, null);
		idxFirstName.setStatusControl(IndexStatus.OK.name());
		idxFirstName.setIndexesJmc(Arrays.asList(new IndexeJmc("usual_name", "Dahm", "KO", piece.getId(), "34fr2e")));
		type.setIndexes(ImmutableSet.of(idxName, idxFirstName));
		ladRadValidator.calculateIndicatorsPieces(piece, type, edocTypes, edocIndexes);
		assertThat(piece.getTypeControl()).isEqualTo(PieceIndicators.OK.name());
		assertThat(piece.getCoherenceControl()).isEqualTo(PieceIndicators.OK.name());
		assertThat(piece.getExtractionControl()).isEqualTo(PieceIndicators.OK.name());

	}

	@Test
	public void updatePiecesWithWARNING_COHEindexesShouldToBeWarningCohe() {
		piece.setTypesJmc(Arrays.asList("identity_card_recto"));
		final Indexe idxName = new Indexe(UUID.randomUUID(), "10000000000000002", null, "OB", true, "CERYHIER", null, null, "A", 2, null, null, "1", "", false, null);
		idxName.setStatusControl(IndexStatus.OK.name());
		idxName.setIndexesJmc(Arrays.asList(new IndexeJmc("name", "Dahm", "OK", piece.getId(), "34fr2e"), new IndexeJmc("name", "Dahm", "OK", UUID.randomUUID(), "34fr2e")));
		final Indexe idxFirstName = new Indexe(UUID.randomUUID(), "10000000000000003", null, "FA", true, "CORLNNE", null, null, "A", 2, null, null, "1", "", false, null);
		idxFirstName.setStatusControl(IndexStatus.WARNING_COHE.name());
		idxFirstName.setIndexesJmc(Arrays.asList(new IndexeJmc("usual_name", "Dahm", "KO", piece.getId(), "34fr2e")));
		type.setIndexes(ImmutableSet.of(idxName, idxFirstName));
		ladRadValidator.calculateIndicatorsPieces(piece, type, edocTypes, edocIndexes);
		assertThat(piece.getTypeControl()).isEqualTo(PieceIndicators.OK.name());
		assertThat(piece.getCoherenceControl()).isEqualTo(PieceIndicators.WARNING.name());
		assertThat(piece.getExtractionControl()).isEqualTo(PieceIndicators.OK.name());

	}

	@Test
	public void updatePiecesWithKO_COHEindexesShouldToBeKoCohe() {
		piece.setTypesJmc(Arrays.asList("identity_card_recto"));
		final Indexe idxName = new Indexe(UUID.randomUUID(), "10000000000000002", null, "OB", true, "CERYHIER", null, null, "A", 2, null, null, "1", "", false, null);
		idxName.setStatusControl(IndexStatus.OK.name());
		idxName.setIndexesJmc(Arrays.asList(new IndexeJmc("name", "Dahm", "OK", piece.getId(), "34fr2e"), new IndexeJmc("name", "Dahm", "OK", UUID.randomUUID(), "34fr2e")));
		final Indexe idxFirstName = new Indexe(UUID.randomUUID(), "10000000000000003", null, "OB", true, "CORLNNE", null, null, "A", 2, null, null, "1", "", false, null);
		idxFirstName.setStatusControl(IndexStatus.KO_COHE.name());
		idxFirstName.setIndexesJmc(Arrays.asList(new IndexeJmc("usual_name", "Dahm", "KO", piece.getId(), "34fr2e")));
		type.setIndexes(ImmutableSet.of(idxName, idxFirstName));
		ladRadValidator.calculateIndicatorsPieces(piece, type, edocTypes, edocIndexes);
		assertThat(piece.getTypeControl()).isEqualTo(PieceIndicators.OK.name());
		assertThat(piece.getCoherenceControl()).isEqualTo(PieceIndicators.KO.name());
		assertThat(piece.getExtractionControl()).isEqualTo(PieceIndicators.OK.name());

	}

	@Test
	public void updatePiecesWithAllDocumentsOfCompletenessShouldToOK() {
		piece.setTypesJmc(Arrays.asList("identity_card_recto"));
		final Indexe idxName = new Indexe(UUID.randomUUID(), "10000000000000002", null, "OB", true, "CERYHIER", null, null, "A", 2, null, null, "1", "", false, null);
		idxName.setStatusControl(IndexStatus.OK.name());
		idxName.setIndexesJmc(Arrays.asList(new IndexeJmc("name", "Dahm", "OK", piece.getId(), "34fr2e"), new IndexeJmc("name", "Dahm", "OK", UUID.randomUUID(), "34fr2e")));
		final Indexe idxFirstName = new Indexe(UUID.randomUUID(), "10000000000000003", null, "OB", true, "CORLNNE", null, null, "A", 2, null, null, "1", "", false, null);
		idxFirstName.setStatusControl(IndexStatus.OK.name());
		idxFirstName.setIndexesJmc(Arrays.asList(new IndexeJmc("usual_name", "Dahm", "OK", piece.getId(), "34fr2e")));
		type.setIndexes(ImmutableSet.of(idxName, idxFirstName));
		type.setControlRequired(ControlRequired.CONTROL_JMC.getCode());
		ladRadValidator.calculateIndicatorsType(type, edocTypes);
		assertThat(type.getStatusControl()).isEqualTo(TypeControls.OK.name());
		assertThat(type.getCompletenessControl()).isEqualTo(TypeControls.OK.name());

	}

	@Test
	public void updatePiecesWithOneMissingJmcDocumentShouldToOK() {
		piece.setTypesJmc(Arrays.asList("passport"));
		piece.setStatusControl(PieceIndicators.KO.name());
		final Indexe idxName = new Indexe(UUID.randomUUID(), "10000000000000002", null, "OB", true, "CERYHIER", null, null, "A", 2, null, null, "1", "", false, null);
		idxName.setStatusControl(IndexStatus.OK.name());
		idxName.setIndexesJmc(Arrays.asList(new IndexeJmc("name", "Dahm", "OK", piece.getId(), "34fr2e"), new IndexeJmc("name", "Dahm", "OK", UUID.randomUUID(), "34fr2e")));
		final Indexe idxFirstName = new Indexe(UUID.randomUUID(), "10000000000000003", null, "OB", true, "CORLNNE", null, null, "A", 2, null, null, "1", "", false, null);
		idxFirstName.setStatusControl(IndexStatus.OK.name());
		idxFirstName.setIndexesJmc(Arrays.asList(new IndexeJmc("usual_name", "Dahm", "OK", piece.getId(), "34fr2e")));
		type.setIndexes(ImmutableSet.of(idxName, idxFirstName));
		type.setControlRequired(ControlRequired.CONTROL_JMC.getCode());

		ladRadValidator.calculateIndicatorsType(type, edocTypes);
		assertThat(type.getStatusControl()).isEqualTo(TypeControls.KO.name());
		assertThat(type.getCompletenessControl()).isEqualTo("identity_card_recto");

	}

	@Test
	public void updatePiecesWithTwoOwnersShouldBeOk() {
		pieceOwners.setTypesJmc(Arrays.asList("invoice"));
		final Indexe idxName = new Indexe(UUID.randomUUID(), "10000000000000002", null, "OB", true, "CERYHIER", null, null, "A", 2, null, null, "1", "", false, null);
		idxName.setStatusControl(IndexStatus.OK.name());
		idxName.setIndexesJmc(Arrays.asList(new IndexeJmc("name", "CERYHIER", "OK", pieceOwners.getId(), "34fr2e")));
		final Indexe idxFirstName = new Indexe(UUID.randomUUID(), "10000000000000003", null, "OB", true, "CORINNE", null, null, "A", 2, null, null, "1", "", false, null);
		idxFirstName.setStatusControl(IndexStatus.OK.name());
		idxFirstName.setIndexesJmc(Arrays.asList(new IndexeJmc("usual_name", "CORINNE", "OK", pieceOwners.getId(), "34fr2e")));
		final Indexe idxNameOwners2 = new Indexe(UUID.randomUUID(), "10000000000000002", null, "OB", true, "CERYHIER", null, null, "A", 2, null, null, "2", "", false, null);
		idxNameOwners2.setStatusControl(IndexStatus.OK.name());
		idxNameOwners2.setIndexesJmc(Arrays.asList(new IndexeJmc("name", "CERYHIER", "OK", pieceOwners.getId(), "34fr2e")));
		final Indexe idxFirstNameOwners2 = new Indexe(UUID.randomUUID(), "10000000000000003", null, "OB", true, "JEAN", null, null, "A", 2, null, null, "2", "", false, null);
		idxFirstNameOwners2.setStatusControl(IndexStatus.OK.name());
		idxFirstNameOwners2.setIndexesJmc(Arrays.asList(new IndexeJmc("usual_name", "JEAN", "OK", pieceOwners.getId(), "34fr2e")));
		typeOwners.setIndexes(ImmutableSet.of(idxName, idxFirstName, idxNameOwners2, idxFirstNameOwners2));
		typeOwners.setControlRequired(ControlRequired.CONTROL_JMC.getCode());
		ladRadValidator.calculateIndicatorsType(typeOwners, edocTypes);
		assertThat(typeOwners.getStatusControl()).isEqualTo(TypeControls.OK.name());
		assertThat(typeOwners.getCompletenessControl()).isEqualTo(TypeControls.OK.name());

	}

	@Test
	public void updatePiecesWithTwoOwnersKO() {
		pieceOwners.setTypesJmc(Arrays.asList("invoice"));
		pieceOwners.setStatusControl("KO");
		final Indexe idxName = new Indexe(UUID.randomUUID(), "10000000000000002", null, "OB", true, "CERYHIER", null, null, "A", 2, null, null, "1", "", false, null);
		idxName.setStatusControl(IndexStatus.OK.name());
		idxName.setIndexesJmc(Arrays.asList(new IndexeJmc("name", "CERYHIER", "OK", pieceOwners.getId(), "34fr2e")));
		final Indexe idxFirstName = new Indexe(UUID.randomUUID(), "10000000000000003", null, "OB", true, "CORINNE", null, null, "A", 2, null, null, "1", "", false, null);
		idxFirstName.setStatusControl(IndexStatus.OK.name());
		idxFirstName.setIndexesJmc(Arrays.asList(new IndexeJmc("usual_name", "CORINNE", "KO", pieceOwners.getId(), "34fr2e")));
		final Indexe idxNameOwners2 = new Indexe(UUID.randomUUID(), "10000000000000002", null, "OB", true, "CERYHIER", null, null, "A", 2, null, null, "2", "", false, null);
		idxNameOwners2.setStatusControl(IndexStatus.OK.name());
		idxNameOwners2.setIndexesJmc(Arrays.asList(new IndexeJmc("name", "CERYHIER", "OK", pieceOwners.getId(), "34fr2e")));
		final Indexe idxFirstNameOwners2 = new Indexe(UUID.randomUUID(), "10000000000000003", null, "OB", true, "JEAN", null, null, "A", 2, null, null, "2", "", false, null);
		idxFirstNameOwners2.setStatusControl(IndexStatus.OK.name());
		idxFirstNameOwners2.setIndexesJmc(Arrays.asList(new IndexeJmc("usual_name", "JEAN", "OK", pieceOwners.getId(), "34fr2e")));
		typeOwners.setIndexes(ImmutableSet.of(idxName, idxFirstName, idxNameOwners2, idxFirstNameOwners2));
		typeOwners.setControlRequired(ControlRequired.CONTROL_JMC.getCode());
		ladRadValidator.calculateIndicatorsType(typeOwners, edocTypes);
		assertThat(typeOwners.getStatusControl()).isEqualTo(TypeControls.KO.name());
		assertThat(typeOwners.getCompletenessControl()).isEqualTo(TypeControls.OK.name());

	}

}
