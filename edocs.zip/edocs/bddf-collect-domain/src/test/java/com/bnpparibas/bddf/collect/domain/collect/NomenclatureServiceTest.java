package com.bnpparibas.bddf.collect.domain.collect;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.beans.HasPropertyWithValue.hasProperty;
import static org.junit.Assert.assertThat;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.junit.Test;

import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.nomenclature.Nomenclature;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;

public class NomenclatureServiceTest extends AbstractServiceTest {
	
	@Override
	public void prepareDatas() throws Exception {
		
		
	}
	@Test
	public void testOnConvertNomenclature() {
		final TypeValidator typeValidator = new TypeValidator();
		final Set<Indexe> indexes = new HashSet<>();

		Indexe index = new Indexe();
		index.setExtractedValue("M");
		index.setId(UUID.randomUUID());
		index.setCode("10000000000000001");

		indexes.add(index);

		index = new Indexe();
		index.setId(UUID.randomUUID());
		index.setExtractedValue("F");
		index.setCode("10000000000000001");

		indexes.add(index);

		index = new Indexe();
		index.setId(UUID.randomUUID());
		index.setExtractedValue("ARG");
		index.setCode("10000000000000007");

		indexes.add(index);

		final List<Nomenclature> nomenclatures = nomenclatureService.findAll();

		typeValidator.convertTypesExtractedIndexToEdoc(indexes, nomenclatures);

		assertThat(indexes, containsInAnyOrder(hasProperty("extractedValue", is("MEdoc")), hasProperty("extractedValue", is("F")), hasProperty("extractedValue", is("ARGEdoc"))));

	}

	
}
