package com.bnpparibas.bddf.collect.domain.collect;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.junit.Test;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditEventService;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.collect.params.PiecesStatusActionsImpl;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceIndicators;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureServiceImpl;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceRecivedFormat;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceRepository;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.type.ControlRequired;
import com.bnpparibas.bddf.collect.domain.type.FamilyRepository;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlUtils;
import com.bnpparibas.bddf.collect.domain.type.TypeLadRadService;
import com.bnpparibas.bddf.collect.domain.type.TypeServiceImpl;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.rest.Context;

public class TypeServiceTest extends AbstractServiceTest {

	private TypeServiceImpl typeService;
	private AuditGenerator auditGenerator;

	@Override
	public void prepareDatas() {
		final MessageSource messageSource = mock(MessageSource.class);
		auditGenerator = new AuditGenerator(messageSource);
		final CollectValidator customValidator = new CollectValidator();
		final PiecesStatusActionsImpl statusActionsImpl = new PiecesStatusActionsImpl();
		final DocReferenceService docReferenceService = mock(DocReferenceService.class);
		final FamilyRepository familyRepository = mock(FamilyRepository.class);
		final PieceValidator pieceValidator = new PieceValidator();
		pieceValidator.setPieceStatusRepository(statusActionsImpl);

		final Environment environment = mock(Environment.class);
		final TypeLadRadService typeLadRadService = mock(TypeLadRadService.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(false);
		final TypeAutomaticControlServiceImpl typeAutomaticControlService = new TypeAutomaticControlServiceImpl(typeLadRadService, collectEventHandler, null, null, new EdocIndexRepositoryImpl(), featureManager, pieceRepository, pieceGdnRepository, null,
				null, typeRepository, docReferenceService, new TypeAutomaticControlUtils());
		typeAutomaticControlService.setCollectRepository(collectRepository);
		// service
		typeService = new TypeServiceImpl(collectRepository, typeRepository, customValidator, collectEventHandler, auditGenerator, docReferenceService, typeAutomaticControlService, familyRepository);
		final EdocTypeRepository edocTypeRepository = mock(EdocTypeRepository.class);
		typeService.setEdocTypeRepository(edocTypeRepository);
		typeService.setPieceValidator(pieceValidator);
		typeService.setFeatureManager(featureManager);
		typeService.setTypeValidator(new TypeValidator());

		final EdocTypesRepositoryImpl edocTypesRepositoryImpl = new EdocTypesRepositoryImpl();
		typeService.setEdocTypeRepository(edocTypesRepositoryImpl);
		final EdocIndexRepositoryImpl edocIndexRepositoryImpl = new EdocIndexRepositoryImpl();
		typeService.setEdocIndexRepository(edocIndexRepositoryImpl);
		final NomenclatureServiceImpl nomenclatureServiceImpl = mock(NomenclatureServiceImpl.class);
		typeService.setNomenclatureService(nomenclatureServiceImpl);

		final DocReferenceRepository docReferenceRepository = mock(DocReferenceRepository.class);
		typeService.setDocReferenceRepository(docReferenceRepository);
		typeService.setEnvironment(environment);
		typeService.setDocReferenceService(mock(DocReferenceService.class));

		final AuditEventService auditEventService = mock(AuditEventService.class);
		doNothing().when(auditEventService).sendAuditEventLadRAD(any(), any(), any(), any(), any(), any());
		doNothing().when(auditEventService).sendAuditEventLadRADFirstIteration(any(), any(), any(), any(), any(), any(), any(), any());
		doNothing().when(auditEventService).sendAuditEventLadRADSecondIteration(any(), any(), any(), any(), any(), any(), any());
		when(auditEventService.sendAuditEventForcedRecognition(any(), any(), any(), any(), any())).thenReturn(true);
		typeService.setAuditEventService(auditEventService);
	}

	@Test
	public void getTypeTest() {
		final Type type = typeService.getType(collectId, typeOBListeId);
		assertThat(type).isEqualTo(typeRepository.findOne(collectId, typeOBListeId));
	}

	@Test
	public void updateTypeTest() throws InterruptedException {
		final Type type = updateType(collectId, typeRepository.findOne(collectId, typeOBListeId), Channel.SPIRIT.getValue(), false, null, PieceStatus.VA.getLabel(), null, null, null, null, null);
		type.getPieces().forEach(p -> assertThat(p.getStatus().equals(PieceStatus.VA.getLabel())));
	}

	@Test
	public void updateTypeWithRefusedPiecesTest() throws InterruptedException {
		final Type type = updateType(collectId, typeRepository.findOne(collectId, typeOBListeId), Channel.SPIRIT.getValue(), false, null, PieceStatus.RF.getLabel(), "commentaire", null, null, null, null);
		type.getPieces().forEach(p -> assertThat(p.getStatus().equals(PieceStatus.VA.getLabel())));
	}

	@Test
	public void updateTypeWithOnePieceDeletedTest() throws InterruptedException {
		final Type type = updateTypeWithOnlyOnePiece(collectId, typeRepository.findOne(collectId, typeOBListeId), Channel.SPIRIT.getValue(), false, null, PieceStatus.VA.getLabel());
		type.getPieces().forEach(p -> assertThat(Arrays.asList(PieceStatus.VA.getLabel(), "SU").contains(p.getStatus())));
	}

	@Test
	public void updateSubTypeTest() throws InterruptedException {
		final Type type = updateType(collectWithSubTypeId, typeRepository.findOne(collectWithSubTypeId, subTypeWSTID), Channel.SPIRIT.getValue(), false, null, PieceStatus.VA.getLabel(), null, null, null, null, null);
		type.getPieces().forEach(p -> assertThat(p.getStatus().equals(PieceStatus.VA.getLabel())));
	}

	@Test
	public void updateTypeFailsOnRefusedReasonPieceTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_REJECT_REASON);
		updateType(collectId, typeRepository.findOne(collectId, typeOBListeId), Channel.SPIRIT.getValue(), false, null, PieceStatus.RF.getLabel(), null, null, null, null, null);
	}

	@Test
	public void updateTypeFailsOnUnkownPieceStatusTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_UNKNOWN_ACTION);
		updateType(collectId, typeRepository.findOne(collectId, typeOBListeId), Channel.SPIRIT.getValue(), false, null, "toto", null, null, null, null, null);
	}

	@Test
	public void updateTypeFailsOnUnauthorizedPieceStatusTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_UNAUTHORIZED_ACTION);
		updateType(collectId, typeRepository.findOne(collectId, typeOBListeId), Channel.SPIRIT.getValue(), false, null, PieceStatus.TP.getLabel(), null, null, null, null, null);
	}

	@Test
	public void updateTypeFailsOnRefusedCommentPieceTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_PIECE_REJECT_COMMENT);
		updateType(collectId, typeRepository.findOne(collectId, typeOBListeId), Channel.SPIRIT.getValue(), false, null, PieceStatus.RF.getLabel(), "Autre", null, null, null, null);
	}

	@Test
	public void updateTypeFailsOnPendingDocumentLabelMissingTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_TYPE_PENDING_COMMENT);
		updateType(collectId, typeRepository.findOne(collectId, typeOBListeId), Channel.SPIRIT.getValue(), true, null, PieceStatus.VA.getLabel(), null, null, null, null, null);
	}

	private Type updateType(UUID collectId, Type type, String channel, boolean pendingDocument, String pendingDocumentLabel, String statusPieces, String rejectionReason, String status, String rejectionComment, String rejectionProfile,
			String pendingDocumentProfile) throws InterruptedException {
		final Type t = new Type(type.getId(), type.getParentId(), type.getFamilyId(), type.getFamilyOwners(), type.getFamilyLabel(), type.getFamilyCategory(), type.getFamilyCategoryComment(), type.getFamilyPropertyType(), type.getFamilyIconCode(),
				type.getFamilyAdditionalInformation(), type.getLabel(), type.getAdditionalInformation(), type.isDigitalAllowed(), type.getControlDocumentType(), type.getMaxSizeDoc(), type.getControlRequired(), type.getControlDate(), pendingDocument,
				pendingDocumentLabel, status, true, type.getStatusControl(), pendingDocumentProfile, false, false, null, null);
		t.setEdocType(type.getEdocType());
		final Set<Piece> piecesUpdated = typeRepository.findOne(collectId, type.getId()).getPieces().stream().map(p -> new Piece(p.getId(), p.getLabel(), p.getOwnerId(), p.getEmployeeId(), p.getChannel(), p.getAcquisitionDate(), p.getSize(),
				p.getReceivedFormat(), statusPieces, p.getIdDocGdn(), rejectionReason, rejectionComment, p.getTypeControl(), rejectionProfile, false)).collect(Collectors.toSet());
		t.setPieces(piecesUpdated);

		typeService.updateType(collectId, t.getId(), t, new Context("123456", channel));
		return typeRepository.findOne(collectId, type.getId());
	}

	private Type updateType2(UUID collectId, Type type, String channel, boolean pendingDocument, String pendingDocumentLabel, String statusPieces, String rejectionReason, String status, String rejectionComment, String rejectionProfile,
			String pendingDocumentProfile) throws InterruptedException {
		final Type t = new Type(type.getId(), type.getParentId(), type.getFamilyId(), type.getFamilyOwners(), type.getFamilyLabel(), type.getFamilyCategory(), type.getFamilyCategoryComment(), type.getFamilyPropertyType(), type.getFamilyIconCode(),
				type.getFamilyAdditionalInformation(), type.getLabel(), type.getAdditionalInformation(), type.isDigitalAllowed(), type.getControlDocumentType(), type.getMaxSizeDoc(), type.getControlRequired(), type.getControlDate(), pendingDocument,
				pendingDocumentLabel, status, true, type.getStatusControl(), pendingDocumentProfile, false, false, null, null);
		t.setEdocType(type.getEdocType());
		final Set<Piece> piecesUpdated = typeRepository.findOne(collectId, type.getId()).getPieces().stream().map(p -> new Piece(p.getId(), p.getLabel(), p.getOwnerId(), p.getEmployeeId(), p.getChannel(), p.getAcquisitionDate(), p.getSize(),
				PieceRecivedFormat.NUM.name(), statusPieces, p.getIdDocGdn(), rejectionReason, rejectionComment, p.getTypeControl(), rejectionProfile, false)).collect(Collectors.toSet());
		t.setPieces(piecesUpdated);
		t.setControlRequired(ControlRequired.CONTROL_JMC.getCode());
		t.getActivePieces().forEach(piece -> piece.setTypeControl(PieceIndicators.OK_MAN.getLabel()));

		typeService.updateType(collectId, t.getId(), t, new Context("123456", channel));
		return typeRepository.findOne(collectId, type.getId());
	}

	private Type updateTypeWithOnlyOnePiece(UUID collectId, Type type, String channel, boolean pendingDocument, String pendingDocumentLabel, String statusPieces) throws InterruptedException {
		final Type t = new Type(type.getId(), type.getParentId(), type.getFamilyId(), type.getFamilyOwners(), type.getFamilyLabel(), type.getFamilyCategory(), type.getFamilyCategoryComment(), type.getFamilyPropertyType(), type.getFamilyIconCode(),
				type.getFamilyAdditionalInformation(), type.getLabel(), type.getAdditionalInformation(), type.isDigitalAllowed(), type.getControlDocumentType(), type.getMaxSizeDoc(), type.getControlRequired(), type.getControlDate(), pendingDocument,
				pendingDocumentLabel, false, null, false, false, null, null, true);
		t.setEdocType(type.getEdocType());
		// List<Piece> piecesUpdated = Arrays.asList(pieceRepository.findPieceByCollect(collectId).stream()
		// .map(p -> new Piece(p.getId(), p.getLabel(), p.getOwnerId(), p.getEmployeeId(), p.getChannel(), p.getAcquisitionDate(), p.getSize(), p.getReceivedFormat(), statusPieces, p.getIdDocGdn(), p.getRejectionReason(), p.getRejectionComment()))
		// .findAny().orElse(null));

		typeService.updateType(collectId, t.getId(), t, new Context("123456", channel));
		return typeRepository.findOne(collectId, type.getId());
	}

	@Test
	public void updateTypeFailsOnVaStatusAndNotVaPiecesTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_TYPE_STATUS_NOT_ALLOWED);
		updateType(collectId, typeRepository.findOne(collectId, typeOBListeId), "001", false, null, PieceStatus.RC.getLabel(), null, TypeStatus.VA.getLabel(), null, null, null);
	}

	@Test
	public void updateTypeFailsOnVaStatusAndPendingDocumentTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_TYPE_STATUS_NOT_ALLOWED);
		updateType(collectId, typeRepository.findOne(collectId, typeOBListeId), "001", true, "Pending document", PieceStatus.VA.getLabel(), null, TypeStatus.VA.getLabel(), null, null, null);
	}

	@Test
	public void updateTypeFailsOnRcStatusAndNotRcOrVaPiecesTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_TYPE_STATUS_NOT_ALLOWED);
		updateType(collectId, typeRepository.findOne(collectId, typeOBListeId), "001", false, null, PieceStatus.DP.getLabel(), null, TypeStatus.RC.getLabel(), null, null, null);
	}

	@Test
	public void updateTypeFailsOnTypeControlTest() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_UNKNOWN_PIECE);
		updateType(collectId, typeRepository.findOne(collectId, validateRcTypeId), "001", false, null, PieceStatus.VA.getLabel(), null, PieceStatus.VA.getLabel(), null, null, null);
	}

	@Test
	public void updateTypeTestRejectionProfileBO() throws InterruptedException {
		final Type type = updateType(collectId, typeRepository.findOne(collectId, typeOBListeId), Channel.SPIRIT.getValue(), false, null, PieceStatus.RF.getLabel(), "Autre", TypeStatus.IN.getLabel(), "faux", "BO", null);
		type.getPieces().forEach(piece -> assertThat(piece.getRejectionProfile()).isEqualTo("BO"));
	}

	@Test
	public void updateTypeTestPendingDocumentProfile() throws InterruptedException {
		final Type type = updateType(collectId, typeRepository.findOne(collectId, typeOBListeId), Channel.SPIRIT.getValue(), true, "document manquant", PieceStatus.RC.getLabel(), null, TypeStatus.IN.getLabel(), null, null, "BO");
		assertThat(type.getPendingDocumentProfile()).isEqualTo("BO");
	}

	@Test
	public void updateTypeTestDevalidationRF() throws InterruptedException {
		final Type upType = typeRepository.findOne(collectId, typeOBListeId);
		upType.setStatus(PieceStatus.VA.getLabel());
		final Type type = updateType(collectId, upType, Channel.SPIRIT.getValue(), false, null, PieceStatus.RF.getLabel(), "Autre", TypeStatus.IN.getLabel(), "faux", "BO", null);
		assertThat(type.getStatus()).isEqualTo(TypeStatus.IN.getLabel());
	}

	@Test
	public void updateFailedTypeTestDevalidationRF() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_TYPE_UPDATE_UNAUTHORIZED);
		final Type upType = typeRepository.findOne(collectId, typeOBListeId);
		upType.setStatus(PieceStatus.VA.getLabel());
		final Type type = updateType(collectId, upType, Channel.SPIRIT.getValue(), false, null, PieceStatus.RF.getLabel(), "Autre", TypeStatus.IN.getLabel(), "faux", "FO", null);
		assertThat(type.getStatus()).isEqualTo(TypeStatus.VA.getLabel());
	}

	@Test
	public void updateTypeTestDevalidationPendingDocument() throws InterruptedException {
		final Type upType = typeRepository.findOne(collectId, typeOBListeId);
		upType.setStatus(PieceStatus.VA.getLabel());
		final Type type = updateType(collectId, upType, Channel.SPIRIT.getValue(), true, "document manquant", PieceStatus.RC.getLabel(), null, TypeStatus.IN.getLabel(), null, null, "BO");
		assertThat(type.getStatus()).isEqualTo(TypeStatus.IN.getLabel());
	}

	@Test
	public void updateTypeRG00178IsOK() throws InterruptedException {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_UNAUTHORIZED_OK_MAN);
		final Type upType = typeRepository.findOne(collectId, typeOBListeId);
		upType.setStatus(TypeStatus.IN.getLabel());
		upType.setControlRequired(ControlRequired.CONTROL_JMC.getCode());
		upType.getActivePieces().forEach(piece -> piece.setTypeControl(PieceIndicators.OK.getLabel()));
		final Type type = updateType2(collectId, upType, Channel.SPIRIT.getValue(), false, "", PieceStatus.DP.getLabel(), null, TypeStatus.IN.getLabel(), null, null, "FO");
		assertThat(type.getStatus()).isEqualTo(TypeStatus.IN.getLabel());
	}

	// @Test
	// public void updateTypeRG00177IsOK() throws InterruptedException {
	// exception.expect(CollectBusinessException.class);
	// exception.expectMessage(CollectErrorConstants.ERR_UNKNOWN_PIECE);
	// final Type upType = typeRepository.findOne(collectId, typeOBListeId);
	// upType.setStatus(TypeStatus.VA.getLabel());
	// upType.setControlRequired(ControlRequired.CONTROL_JMC.getCode());
	// upType.getActivePieces().forEach(piece -> piece.setTypeControl(PieceIndicators.KO.getLabel()));
	// final Type type = updateType2(collectId, upType, Channel.SPIRIT.getValue(), true, "document manquant", PieceStatus.RC.getLabel(), null, TypeStatus.VA.getLabel(), null, null, "BO");
	// assertThat(type.getStatus()).isEqualTo(TypeStatus.IN.getLabel());
	// }

	@Test
	public void addTypeTest() throws InterruptedException {
		final Type type = addType(collectId, typeRepository.findOne(collectId, typeOBListeId), Channel.SPIRIT.getValue());
		assertThat(type.getStatus()).isEqualTo(TypeStatus.IN.getLabel());
	}

	private Type addType(UUID collectId, Type type, String channel) throws InterruptedException {
		final Type newType = new Type(UUID.randomUUID(), type.getParentId(), type.getFamilyId(), type.getFamilyOwners(), type.getFamilyLabel(), type.getFamilyCategory(), type.getFamilyCategoryComment(), type.getFamilyPropertyType(),
				type.getFamilyIconCode(), type.getFamilyAdditionalInformation(), type.getLabel(), type.getAdditionalInformation(), type.isDigitalAllowed(), type.getControlDocumentType(), type.getMaxSizeDoc(), type.getControlRequired(),
				type.getControlDate(), false, "", TypeStatus.IN.getLabel(), true, type.getStatusControl(), "", false, false, null, null);
		newType.setEdocType("00000000000000001");

		typeService.addType(collectId, type.getFamilyId(), Arrays.asList(newType), new Context("123456", channel));
		return newType;
	}

}
