package com.bnpparibas.bddf.collect.domain.collect.params;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Repository;

import com.bnp.schema.edoc.index.Indexes;
import com.bnp.schema.edoc.index.Indexes.EdocIndex;
import com.bnp.schema.edoc.index.ObjectFactory;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.errors.TechnicalException;

@DDD.RepositoryImpl
@Repository
public class EdocIndexRepositoryImpl implements EdocIndexRepository {

	private List<EdocIndex> edocIndexes;

	public EdocIndexRepositoryImpl() {
		init();
	}

	private void init() {
		try {
			final InputStream inputStream = new ClassPathResource("edocIndex.xml").getInputStream();
			final Unmarshaller unmarshaller = JAXBContext.newInstance(ObjectFactory.class).createUnmarshaller();
			edocIndexes = ((Indexes) unmarshaller.unmarshal(inputStream)).getEdocIndex();
		} catch (final JAXBException | IOException e) {

			throw new TechnicalException(CollectErrorConstants.ERR_COL_TECH, e);
		}
	}

	@Override
	public List<EdocIndex> findAll() {
		return edocIndexes;
	}

	@Override
	public EdocIndex byValue(String value) {
		return edocIndexes.stream().filter(t -> t.getCode().equals(value)).findAny().orElse(null);
	}

}
