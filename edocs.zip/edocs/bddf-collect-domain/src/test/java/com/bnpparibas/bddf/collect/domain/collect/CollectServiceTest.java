package com.bnpparibas.bddf.collect.domain.collect;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.time.LocalDate;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.assertj.core.util.Sets;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringRunner;
import org.togglz.core.manager.FeatureManager;

import com.bnp.schema.edoc.type.Types;
import com.bnp.schema.edoc.type.Types.EdocType.PiecesEdoc;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocIndexRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.collect.params.EdocTypesRepositoryImpl;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.event.collect.UpdatedCollect;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.nomenclature.Nomenclature;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.param.GdnParamRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReference;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceRepository;
import com.bnpparibas.bddf.collect.domain.type.ControlRequired;
import com.bnpparibas.bddf.collect.domain.type.FamilyCategory;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.collect.domain.type.VideoCodingDelay;
import com.bnpparibas.bddf.rest.Context;
import com.google.common.collect.ImmutableSet;

@RunWith(SpringRunner.class)
public class CollectServiceTest {

	@Rule
	public final ExpectedException exception = ExpectedException.none();

	CollectServiceImpl collectService;

	private CollectRepository collectRepository;

	private TypeRepository typeRepository;
	private GdnParamRepository gdnParamRepository;
	private AuditGenerator auditGenerator;
	private PieceRepository pieceRepository;
	private CollectEventHandler collectEventHandler;
	private DocReferenceRepository docReferenceRepository;

	private List<Collect> collects;
	private List<Owner> owners;
	private List<Type> types;
	private List<Type> typesWithSubTypes;
	private List<Piece> pieces;
	private List<DocReference> references;
	private List<Indexe> indexes;
	private Type typeWithFacultatitveFamily;
	private Type typeWithActManagment;

	private NomenclatureService nomenclatureService;

	@Before
	public void setUp() {
		collectRepository = mock(CollectRepository.class);
		typeRepository = mock(TypeRepository.class);
		pieceRepository = mock(PieceRepository.class);
		collectEventHandler = mock(CollectEventHandler.class);
		gdnParamRepository = mock(GdnParamRepository.class);
		docReferenceRepository = mock(DocReferenceRepository.class);

		final Environment environment = mock(Environment.class);
		when(environment.getProperty("purge.collect-ab.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-ab.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.collect-cl.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.collect-cl.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-tp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-tp.ttl.day")).thenReturn("1");
		when(environment.getProperty("purge.piece-dp.ttl.month")).thenReturn("0");
		when(environment.getProperty("purge.piece-dp.ttl.day")).thenReturn("1");
		when(environment.getProperty("param.controlIterationAllowed", Integer.class, 2)).thenReturn(2);
		final MessageSource messageSource = mock(MessageSource.class);

		auditGenerator = new AuditGenerator(messageSource);

		setUpNomenclature();

		final CollectValidator customValidator = new CollectValidator();
		customValidator.setEnvironment(environment);
		final FeatureManager featureManager = mock(FeatureManager.class);
		when(featureManager.isActive(any())).thenReturn(false);
		final TypeValidator typeValidator = new TypeValidator();

		collectService = new CollectServiceImpl(collectRepository, typeRepository, gdnParamRepository, customValidator, collectEventHandler, auditGenerator, environment, typeValidator, new EdocTypesRepositoryImpl(), new EdocIndexRepositoryImpl());

		collectService.setDocReferenceRepository(docReferenceRepository);
		collectService.setNomenclatureService(nomenclatureService);

		final Types.EdocType.PiecesEdoc piecesEdoc = new PiecesEdoc();
		final Types.EdocType.PiecesEdoc.Piece pieceNumber1IDCard = new Types.EdocType.PiecesEdoc.Piece();
		pieceNumber1IDCard.setPieceCode("20000000000000001");
		pieceNumber1IDCard.setPieceDefault(true);
		pieceNumber1IDCard.setPieceLabel("Pièce identité recto");
		pieceNumber1IDCard.setPieceJmc("identity_card_recto");

		final Types.EdocType.PiecesEdoc.Piece pieceNumber2IDCard = new Types.EdocType.PiecesEdoc.Piece();
		pieceNumber2IDCard.setPieceCode("20000000000000002");
		pieceNumber2IDCard.setPieceDefault(true);
		pieceNumber2IDCard.setPieceLabel("Pièce identité verso");
		pieceNumber2IDCard.setPieceJmc("identity_card_verso");

		piecesEdoc.getPiece().add(pieceNumber1IDCard);
		piecesEdoc.getPiece().add(pieceNumber2IDCard);

		collectService.setAuthorizedFormat("PDF,PDF/A,PNG,JPEG,GIF,TIF,TIFF,JPG");

		collectService.setFeatureManager(featureManager);
		collects = new ArrayList<>();
		collects.add(new Collect(UUID.randomUUID(), "EC", Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", ImmutableSet.of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIF", "TIFF"), ImmutableSet.of("DP"),
				ImmutableSet.of("OB", "ND", "DR", "DF"), null, "AP001", false, false, 0, false, 0));
		collects.add(new Collect(UUID.randomUUID(), "EC", Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", ImmutableSet.of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIF", "TIFF"), ImmutableSet.of("VA"),
				ImmutableSet.of("OB", "ND", "DR", "DF"), null, "AP001", false, false, 0, false, 0));
		collects.add(new Collect(UUID.randomUUID(), "EC", Instant.now(), null, "Retail", "Crédit immobiliter", "Solvabilité", "100001", ImmutableSet.of("PDF", "PDF/A", "PNG", "JPEG", "GIF", "TIF", "TIFF"), ImmutableSet.of("DP"),
				ImmutableSet.of("OB", "ND", "DR", "DF"), null, "AP001", false, false, 0, false, 0));

		owners = new ArrayList<>();
		owners.add(new Owner("01740005814400000", "SETAH", "Alex", null, 1, "1234567", null));
		owners.add(new Owner("01740005814500000", "SETAH", "Alice", null, 1, "1234567", null));

		references = new ArrayList<>();
		DocReference ref = new DocReference();
		ref.setOwnerId("01740005814400000");
		ref.setEdocType("00000000000000017");
		ref.setLabel("piece.jpg");
		references.add(ref);
		ref = new DocReference();
		ref.setOwnerId("01740005814400000");
		ref.setEdocType("00000000000000001");
		ref.setLabel("piece2.jpg");
		references.add(ref);

		types = new ArrayList<>();
		types.add(new Type(UUID.randomUUID(), null, UUID.randomUUID(), new HashSet<>(Arrays.asList("01740005814400000")), "Médicale", "DF", null, "Fixe", null, "info compl famille assurance", null, null, true, null, new Random().nextLong(), 0, null, false,
				null, false, null, false, false, null, null, true));
		types.add(new Type(UUID.randomUUID(), null, UUID.randomUUID(), new HashSet<>(Arrays.asList("01740005814400000")), "Médicale", "DR", "Client non concerné par le document", "Fixe", null, "info compl famille assurance", null, null, false, null,
				new Random().nextLong(), 0, null, false, null, false, null, false, false, null, null, true));
		types.add(new Type(UUID.randomUUID(), null, UUID.randomUUID(), new HashSet<>(Arrays.asList("01740005814400000")), "Justificatif d'identité", "OB", null, "Fixe", null, "info compl famille Justificatif d'identité", "Carte d'identité1",
				"Veuiller fournir le recto et verso de votre carte d'identité", true, null, 1000000, 0, null, false, null, false, null, false, false, null, null, true));

		types.add(new Type(UUID.randomUUID(), null, UUID.randomUUID(), new HashSet<>(Arrays.asList("01740005814400000")), "Justificatif d'identité", "OB", null, "Fixe", null, "info compl famille assurance", null, null, true, null, new Random().nextLong(),
				0, null, false, null, false, null, false, false, null, null, true));
		types.add(new Type(UUID.randomUUID(), null, types.get(3).getId(), new HashSet<>(Arrays.asList("01740005814400000")), "Justificatif d'identité", "OB", null, "Fixe", null, "info compl famille Justificatif d'identité", "Carte d'identité2",
				"Veuiller fournir le recto et verso de votre carte d'identité", true, null, 1000000, 0, null, false, null, false, null, false, false, null, null, true));

		typeWithFacultatitveFamily = new Type(UUID.randomUUID(), null, types.get(3).getId(), new HashSet<>(Arrays.asList("01740005814400000")), "Justificatif d'identité", FamilyCategory.FA.name(), null, "Fixe", null,
				"info compl famille Justificatif d'identité", "Carte d'identité2", "Veuiller fournir le recto et verso de votre carte d'identité", true, null, 1000000, 0, null, false, null, false, null, false, false, null, null, true);
		typeWithActManagment = new Type(UUID.randomUUID(), null, types.get(3).getId(), new HashSet<>(Arrays.asList("01740005814400000")), "Justificatif d'identité", FamilyCategory.OB.name(), null, "Fixe", null, "info compl famille Justificatif d'identité",
				"Carte d'identité2", "Veuiller fournir le recto et verso de votre carte d'identité", true, null, 1000000, 0, null, false, null, false, null, false, false, null, null, true);
		pieces = new ArrayList<>();

		pieces.add(new Piece(UUID.randomUUID(), "avis_impot1.doc", "01740005814500000", null, "001", Instant.now(), 500000, "NUM", "VA", null, null, null, null, null, false));
		types.get(1).setPieces(new HashSet<>(Arrays.asList(pieces.get(0))));

		pieces.add(new Piece(UUID.randomUUID(), "avis_impot2.doc", "01740005814500000", null, "001", Instant.now(), new Random().nextLong(), "Numérique", "VA", null, null, null, null, null, false));
		types.get(2).setPieces(new HashSet<>(Arrays.asList(pieces.get(1))));

		pieces.add(new Piece(UUID.randomUUID(), "avis_impot1.doc", "01740005814500000", null, "001", Instant.now(), 500000, "NUM", "VA", null, null, null, null, null, false));
		types.get(3).setPieces(new HashSet<>(Arrays.asList(pieces.get(2))));

		pieces.add(new Piece(UUID.randomUUID(), "avis_impot2.doc", "01740005814500000", null, "001", Instant.now(), new Random().nextLong(), "NUM", "VA", null, null, null, null, null, false));
		types.get(4).setPieces(new HashSet<>(Arrays.asList(pieces.get(3))));

		final UUID familyId = UUID.randomUUID();
		final Type parentType = new Type(UUID.randomUUID(), null, familyId, new HashSet<>(Arrays.asList("01740005814400000")), "Justificatif d'identité", "OB", null, "Fixe", null, "info compl famille assurance", null, null, true, null,
				new Random().nextLong(), 0, null, false, null, false, null, false, false, null, null, true);
		parentType.setEdocType("00000000000000017");
		parentType.setControlRequired(0);
		parentType.setDigitalAllowed(true);
		parentType.setEnableReuse(true);
		final Type subType1 = new Type(UUID.randomUUID(), parentType.getId(), familyId, new HashSet<>(Arrays.asList("01740005814400000")), "Justificatif d'identité 1", "OB", null, "Fixe", null, "info compl famille assurance", null, null, true, null,
				new Random().nextLong(), 0, null, false, null, false, null, false, false, null, null, true);
		subType1.setEdocType("00000000000000017");
		final Type subType2 = new Type(UUID.randomUUID(), parentType.getId(), familyId, new HashSet<>(Arrays.asList("01740005814400000")), "Justificatif d'identité 2", "OB", null, "Fixe", null, "info compl famille assurance", null, null, true, null,
				new Random().nextLong(), 0, null, false, null, false, null, false, false, null, null, true);
		subType2.setEdocType("00000000000000017");
		typesWithSubTypes = Arrays.asList(parentType, subType1, subType2);

		indexes = new ArrayList<>();

		final Indexe index = new Indexe(UUID.randomUUID(), "10000000000000001", "Civilité", "OB", true, "F", null, null, null, 1, null, null, null, "", false, null);
		indexes.add(index);

		doAnswer(invocation -> {
			final String ownerId = invocation.getArgument(0);
			final String eType = invocation.getArgument(1);
			return references.stream().filter(r -> r.getOwnerId().equals(ownerId) && r.getEdocType().equals(eType)).collect(Collectors.toList());
		}).when(docReferenceRepository).getByOwnersAndType(any(), any());

		doAnswer(invocation -> {
			final String ownerIds = invocation.getArgument(0);
			final List<String> eTypes = invocation.getArgument(1);
			return references.stream().filter(r -> ownerIds.equals(r.getOwnerId()) && eTypes.contains(r.getEdocType())).collect(Collectors.toList());
		}).when(docReferenceRepository).getByOwnersAndTypes(any(), any());

	}

	private void setUpNomenclature() {
		nomenclatureService = mock(NomenclatureService.class);
		doAnswer(invocation -> {
			final List<Nomenclature> nomenclatures = new ArrayList<>();
			final Nomenclature nomenclatureF = new Nomenclature();
			nomenclatureF.setCode("F");
			nomenclatureF.setEdoc("10000000000000001");
			nomenclatureF.setJmc("F");
			nomenclatureF.setLabel("Féminin");

			final Nomenclature nomenclatureH = new Nomenclature();
			nomenclatureH.setCode("M");
			nomenclatureH.setEdoc("10000000000000001");
			nomenclatureH.setJmc("M");
			nomenclatureH.setLabel("Masculin");

			final Nomenclature nomenclatureARG = new Nomenclature();
			nomenclatureARG.setCode("ARG");
			nomenclatureARG.setEdoc("10000000000000007");
			nomenclatureARG.setJmc("ARG");
			nomenclatureARG.setLabel("Argentine");

			nomenclatures.add(nomenclatureF);
			nomenclatures.add(nomenclatureH);
			nomenclatures.add(nomenclatureARG);
			return nomenclatures;
		}).when(nomenclatureService).findAll();

	}

	protected static Map<String, Long> gdnParam() {
		return Collections.unmodifiableMap(Stream.of(new SimpleEntry<String, Long>("20090343", (long) 10485760), new SimpleEntry<String, Long>("20090091", (long) 10485760)).collect(Collectors.toMap((e) -> e.getKey(), (e) -> e.getValue())));
	}

	@Test
	public void getTypesByCollectIdTest() {
		when(typeRepository.findByCollect(collects.get(0).getId())).thenReturn(new HashSet<>(Arrays.asList(types.get(0), types.get(1))));
		assertThat(collectService.getTypesByCollectId(collects.get(0).getId())).hasSize(2);
		assertThat(collectService.getTypesByCollectId(collects.get(0).getId())).containsOnlyOnce(types.get(0));
	}

	@Test
	public void getCollectTest() {
		when(collectRepository.findOne(collects.get(0).getId())).thenReturn(collects.get(0));
		assertThat(collectService.getCollect(collects.get(0).getId())).isEqualToComparingFieldByField(collects.get(0));
	}

	@Test
	public void getCollectsByOwnersTest() {
		when(collectRepository.findByOwners(ImmutableSet.of("01740005814400000"), Arrays.asList("100001"))).thenReturn(Sets.newLinkedHashSet(collects.get(0), collects.get(2)));
		when(collectRepository.findByOwners(ImmutableSet.of("01740005814500000"), Arrays.asList("100001"))).thenReturn(Sets.newLinkedHashSet(collects.get(1), collects.get(2)));
		when(collectRepository.findByOwners(ImmutableSet.of("01740005814400000", "01740005814500000"), Arrays.asList("100001"))).thenReturn(Sets.newLinkedHashSet(collects.get(0), collects.get(1), collects.get(2)));

		assertEquals(collectService.getCollectsByOwners(ImmutableSet.of("01740005814400000"), Arrays.asList("100001")).size(), 2);
		assertEquals(collectService.getCollectsByOwners(ImmutableSet.of("01740005814500000"), Arrays.asList("100001")).size(), 2);
		assertEquals(collectService.getCollectsByOwners(ImmutableSet.of("01740005814400000", "01740005814500000"), Arrays.asList("100001")).size(), 3);
	}

	@Test
	public void addCollectTestFailsOnFamilyCategoryComment() {
		types.get(1).setFamilyCategoryComment("");
		collects.get(0).setTypes(new HashSet<>(types));
		collects.get(0).setOwners(new HashSet<>(owners));
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_FAMILY_CATEGORY_COMMENT);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
	}

	@Test
	public void addCollectTestFailsOnDataConsistensy() {
		collects.get(0).setTypes(new HashSet<>(types));
		collects.get(0).setOwners(new HashSet<>(Arrays.asList(owners.get(1))));
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_DATA_CONSISTENCY);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
	}

	@Test
	public void addCollectTestFailsOnDataMultiValue() {
		types.get(2).setFamilyPropertyType("Liste");
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(new HashSet<>(types));
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_DATA_MULTI_VALUE);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
	}

	@Test
	public void addCollectTestFailsOnUnkonwnPiecesManagementAct() {
		collects.get(0).setPiecesManagementAct(ImmutableSet.of("DP", "XX"));
		collects.get(0).setOwners(ImmutableSet.of(owners.get(1)));
		collects.get(0).setTypes(new HashSet<>(types));
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_DATA_VALUE);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
	}

	@Test
	public void addCollectTestFailsOnUnkonwnFamiliesManagementAct() {
		collects.get(0).setFamiliesManagementAct(ImmutableSet.of("OB", "ND", "DR", "XX"));
		collects.get(0).setOwners(ImmutableSet.of(owners.get(1)));
		collects.get(0).setTypes(new HashSet<>(types));
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_DATA_VALUE);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
	}

	@Test
	public void addCollectTestFailsOnUnkonwnFamilyCategory() {
		types.get(2).setFamilyCategory("XX");
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(new HashSet<>(types));
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_DATA_VALUE);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
	}

	@Test
	public void addCollectTestFailsOnUnkonwnPecesManagementActsFamily() {
		types.get(2).setPiecesManagementActFamily(ImmutableSet.of("DP", "XX"));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(new HashSet<>(types));
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_DATA_VALUE);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
	}

	@Test
	public void addCollectTestFailsOnUnkonwnEdocType() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("XX");
		types.get(2).setDigitalAllowed(true);
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(new HashSet<>(Arrays.asList(types.get(2))));
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_TYPE_EDOC_UNKOWN);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
	}

	// @Test
	public void addCollectTestFailsOnEmptyEdocTypeWithControlRequired() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("");
		types.get(2).setControlRequired(1);
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(new HashSet<>(types));
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_TYPE_EDOC_MANDATORY);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
	}

	@Test
	public void addCollectTestFailsOnEmptyJmcTypeWithControlRequiredAndDigitalAllowed() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000022");
		types.get(2).setControlRequired(1);
		types.get(2).setDigitalAllowed(true);
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_TYPE_JMC_MANDATORY);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
	}

	@Test
	public void addCollectTestOnEmptyJmcTypeWithControlRequiredAndDigitalNotAllowed() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000017");
		types.get(2).setControlRequired(1);
		types.get(2).setDigitalAllowed(false);
		types.get(2).setPaperAllowed(true);
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		final UUID id = collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
		assertThat(id).isNotNull();
	}

	@Test
	public void addCollectTestOnUnauthorizedIndex() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000020");
		types.get(2).setControlRequired(3);
		types.get(2).setDigitalAllowed(true);
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		final Set<Indexe> indexesc = new HashSet<>();
		indexesc.add(indexes.get(0));
		types.get(2).setIndexes(indexesc);
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_UNAUTHORIZED_INDEX);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
	}

	@Test
	public void addCollectTestOnMissingReferenceIndex() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000001");
		types.get(2).setControlRequired(3);
		types.get(2).setDigitalAllowed(true);
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		final Set<Indexe> indexesc = new HashSet<>();
		indexesc.addAll(prepareSetUpIndexesMissingReference());
		types.get(2).setIndexes(indexesc);
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_INDEX_MISSING_REFERENCE);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
	}

	@Test
	public void addCollectTestOnUnauthorizedReferenceIndex() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000001");
		types.get(2).setControlRequired(3);
		types.get(2).setDigitalAllowed(true);
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		final Set<Indexe> indexesc = new HashSet<>();
		indexesc.addAll(prepareSetUpIndexesUnauthorizedReference());
		types.get(2).setIndexes(indexesc);
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_INDEX_UNAUTHORIZED_REFERENCE);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
	}

	@Test
	public void addCollectTestOnEmptyJmcTypeWithControlNotRequiredAndDigitalAllowed() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000017");
		types.get(2).setControlRequired(0);
		types.get(2).setDigitalAllowed(true);
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		final UUID id = collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
		assertThat(id).isNotNull();
	}

	@Test
	public void closeCollectTest() {
		when(collectRepository.findOne(collects.get(0).getId())).thenReturn(collects.get(0));
		when(pieceRepository.getPieceFromNas(any())).thenReturn(ByteBuffer.allocate(1000));
		Mockito.doNothing().when(collectRepository).endCollect(collects.get(0));
		when(typeRepository.findByCollect(collects.get(0).getId())).thenReturn(ImmutableSet.of(types.get(4), types.get(3)));
		Mockito.doNothing().when(collectEventHandler).sendUpdatedCollectEvent(any());
		collectService.endCollect(collects.get(0).getId(), "CL", new Context("132456", "001", "001"));
		assertThat(collects.get(0).getStatus()).isEqualTo(CollectStatus.CL.name());

	}

	@Test
	public void closeCollectFailsonPendingDocumentTest() {
		types.get(4).setPendingDocument(true);
		collects.get(0).setTypes(ImmutableSet.of(types.get(4), types.get(3)));
		when(collectRepository.findOne(collects.get(0).getId())).thenReturn(collects.get(0));
		Mockito.doNothing().when(collectEventHandler).sendUpdatedCollectEvent(any());
		Mockito.doNothing().when(collectRepository).endCollect(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_INVALID);
		collectService.endCollect(collects.get(0).getId(), "CL", new Context("132456", "001", "001"));
	}

	@Test
	public void closeCollectFailsOnMissingPieceTest() {
		types.get(4).setPieces(new HashSet<>());
		collects.get(0).setTypes(ImmutableSet.of(types.get(4), types.get(3)));
		when(collectRepository.findOne(collects.get(0).getId())).thenReturn(collects.get(0));
		Mockito.doNothing().when(collectEventHandler).sendUpdatedCollectEvent(any());
		Mockito.doNothing().when(collectRepository).endCollect(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_INVALID);
		collectService.endCollect(collects.get(0).getId(), "CL", new Context("132456", "001", "001"));
	}

	@Test
	public void closeCollectFailsOnPieceStatusTest() {
		pieces.get(3).setStatus("DP");
		collects.get(0).setTypes(ImmutableSet.of(types.get(4), types.get(3)));
		when(collectRepository.findOne(collects.get(0).getId())).thenReturn(collects.get(0));
		Mockito.doNothing().when(collectEventHandler).sendUpdatedCollectEvent(any());
		Mockito.doNothing().when(collectRepository).endCollect(collects.get(0));
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_INVALID);
		collectService.endCollect(collects.get(0).getId(), "CL", new Context("132456", "001", "001"));
	}

	@Test
	public void closeCollectAlertOnPieceStatusTest() {
		types.get(3).setFamilyCategory("DF");
		Mockito.doNothing().when(collectEventHandler).sendUpdatedCollectEvent(any());
		when(pieceRepository.getPieceFromNas(any())).thenReturn(ByteBuffer.allocate(1000));
		types.get(4).setFamilyCategory("DF");
		pieces.get(3).setStatus("DP");
		collects.get(0).setTypes(ImmutableSet.of(types.get(4), types.get(3)));
		when(collectRepository.findOne(collects.get(0).getId())).thenReturn(collects.get(0));
		Mockito.doNothing().when(collectRepository).endCollect(collects.get(0));
		final List<String> alerts = collectService.endCollect(collects.get(0).getId(), "CL", new Context("132456", "001", "001"));
		assertThat(alerts).hasSize(1);
		assertThat(alerts.get(0)).isEqualTo("Des pages du document " + types.get(4).getLabel() + " sont en attente de collecte");
		assertThat(collects.get(0).getStatus()).isEqualTo(CollectStatus.CL.name());
	}

	@Test
	public void closeCollectAlertOnMissingPieceTest() {
		Mockito.doNothing().when(collectEventHandler).sendUpdatedCollectEvent(any(UpdatedCollect.class));
		when(pieceRepository.getPieceFromNas(any())).thenReturn(ByteBuffer.allocate(1000));
		types.get(3).setFamilyCategory("DF");
		types.get(4).setFamilyCategory("DF");
		types.get(4).setPieces(new HashSet<>());
		collects.get(0).setTypes(ImmutableSet.of(types.get(4), types.get(3)));
		when(collectRepository.findOne(collects.get(0).getId())).thenReturn(collects.get(0));
		Mockito.doNothing().when(collectRepository).endCollect(collects.get(0));
		final List<String> alerts = collectService.endCollect(collects.get(0).getId(), "CL", new Context("132456", "001", "001"));
		assertThat(alerts).hasSize(1);
		assertThat(alerts.get(0)).isEqualTo("Des pages du document " + types.get(4).getLabel() + " sont en attente de collecte");
		assertThat(collects.get(0).getStatus()).isEqualTo(CollectStatus.CL.name());
	}

	@Test
	public void closeCollectAlertOnMissingAndOnPieceStatutTest() {
		Mockito.doNothing().when(collectEventHandler).sendUpdatedCollectEvent(any());
		when(pieceRepository.getPieceFromNas(any())).thenReturn(ByteBuffer.allocate(1000));
		types.get(3).setFamilyCategory("DF");
		types.get(4).setFamilyCategory("DF");
		pieces.get(2).setStatus("DP");
		types.get(4).setPieces(new HashSet<>());
		collects.get(0).setTypes(ImmutableSet.of(types.get(4), types.get(3)));
		when(collectRepository.findOne(collects.get(0).getId())).thenReturn(collects.get(0));
		Mockito.doNothing().when(collectRepository).endCollect(collects.get(0));
		final List<String> alerts = collectService.endCollect(collects.get(0).getId(), "CL", new Context("132456", "001", "001"));
		assertThat(alerts).hasSize(2);
		assertThat(alerts.get(0)).isEqualTo("Des pages du document " + types.get(4).getLabel() + " sont en attente de collecte");
		assertThat(alerts.get(1)).isEqualTo("Des pages du document " + types.get(3).getLabel() + " sont en attente de collecte");
		assertThat(collects.get(0).getStatus()).isEqualTo(CollectStatus.CL.name());
	}

	@Test
	public void abondonCollectTest() {
		collects.get(0).setTypes(new HashSet<>(types));
		collects.get(0).setOwners(new HashSet<>(owners));
		when(collectRepository.findOne(collects.get(0).getId())).thenReturn(collects.get(0));
		Mockito.doNothing().when(collectRepository).endCollect(collects.get(0));
		when(typeRepository.findByCollect(collects.get(0).getId())).thenReturn(ImmutableSet.of(types.get(4), types.get(3)));
		Mockito.doNothing().when(collectEventHandler).sendUpdatedCollectEvent(any());
		collectService.endCollect(collects.get(0).getId(), "AB", new Context("132456", "001", "001"));
		assertThat(collects.get(0).getStatus()).isEqualTo(CollectStatus.AB.name());
	}

	@Test
	public void addCollectWithEnableReuseAndDigitalAllowed() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000017");
		types.get(2).setControlRequired(0);
		types.get(2).setDigitalAllowed(true);
		types.get(2).setEnableReuse(true);
		types.get(2).getPieces().clear();
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
		final ArgumentCaptor<Collect> collectSaved = ArgumentCaptor.forClass(Collect.class);
		verify(collectRepository).add(collectSaved.capture());
		final List<Piece> pieces = collectSaved.getValue().getTypes().stream().map(Type::getPieces).flatMap(Collection::stream).collect(Collectors.toList());
		assertThat(pieces.size()).isEqualTo(1);
		assertThat(pieces.get(0).getStatus()).isEqualTo(PieceStatus.DF.getLabel());
		assertTrue(collectSaved.getValue().getTypes().stream().map(Type::getStatus).allMatch(TypeStatus.IN.getLabel()::equals));
	}

	@Test
	public void addCollectTestOnBadNomenclature() {
		Exception exception = null;
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000017");
		types.get(2).setControlRequired(ControlRequired.CONTROL_JMC.getCode());
		types.get(2).setDigitalAllowed(false);
		types.get(2).setPaperAllowed(true);
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		types.get(2).setIndexes(prepareSetUpIndexesUnknownNomenclature());

		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		try {
			collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
		} catch (final Exception e) {
			exception = e;
		}
		assertThat(exception).isNotNull();
		assertThat(exception.getMessage()).contains("0070");
	}

	@Test
	public void addCollectTestGoodNomenclature() {
		Exception exception = null;
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000017");
		types.get(2).setControlRequired(1);
		types.get(2).setDigitalAllowed(true);
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		types.get(2).setIndexes(prepareSetUpIndexesItsAllGood());

		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		Mockito.doNothing().when(collectRepository).add(collects.get(0));
		try {
			collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
		} catch (final Exception e) {
			exception = e;
		}
		assertThat(exception).isNull();

	}

	private Set<Indexe> prepareSetUpIndexesUnknownNomenclature() {
		final Set<Indexe> indexes = new HashSet<>();
		final Indexe index = new Indexe();
		index.setReferenceValue("G");
		index.setId(UUID.randomUUID());
		index.setCode("10000000000000001");
		index.setCategory("OB");

		indexes.add(index);

		return indexes;
	}

	private Set<Indexe> prepareSetUpIndexesItsAllGood() {
		final Set<Indexe> indexes = new HashSet<>();
		final Indexe index = new Indexe();
		index.setReferenceValue("F");
		index.setId(UUID.randomUUID());
		index.setCode("10000000000000001");
		index.setCategory("OB");

		indexes.add(index);

		return indexes;
	}

	private Set<Indexe> prepareSetUpIndexesMissingReference() {
		final Set<Indexe> indexes = new HashSet<>();
		final Indexe index = new Indexe();
		index.setReferenceValue("");
		index.setId(UUID.randomUUID());
		index.setCode("10000000000000002");
		index.setCategory("OB");
		indexes.add(index);
		return indexes;
	}

	private Set<Indexe> prepareSetUpIndexesUnauthorizedReference() {
		final Set<Indexe> indexes = new HashSet<>();
		final Indexe index = new Indexe();
		index.setReferenceValue("MRZ");
		index.setId(UUID.randomUUID());
		index.setCode("10000000000000011");
		index.setCategory("OB");
		indexes.add(index);
		return indexes;
	}

	@Test
	public void addCollectWithEnableReuseFalseAndDigitalAllowed() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000017");
		types.get(2).setControlRequired(0);
		types.get(2).setDigitalAllowed(true);
		types.get(2).setEnableReuse(false);
		types.get(2).getPieces().clear();
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
		final ArgumentCaptor<Collect> collectSaved = ArgumentCaptor.forClass(Collect.class);
		verify(collectRepository).add(collectSaved.capture());
		final List<Piece> pieces = collectSaved.getValue().getTypes().stream().map(Type::getPieces).flatMap(Collection::stream).collect(Collectors.toList());
		assertThat(pieces.size()).isEqualTo(0);
	}

	@Test
	public void addCollectWithEnableReuseAndDigitalNotAllowed() {
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_REUSE_FORBIDEN);
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000017");
		types.get(2).setControlRequired(0);
		types.get(2).setDigitalAllowed(false);
		types.get(2).setEnableReuse(true);
		types.get(2).getPieces().clear();
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
	}

	@Test
	public void addCollectWithEnableReuseAndSubTypes() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		collects.get(0).setTypes(new HashSet<>(typesWithSubTypes));
		collects.get(0).setOwners(new HashSet<>(owners));
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
		final ArgumentCaptor<Collect> collectSaved = ArgumentCaptor.forClass(Collect.class);
		verify(collectRepository).add(collectSaved.capture());
		final List<Piece> pieces = collectSaved.getValue().getTypes().stream().map(Type::getPieces).flatMap(Collection::stream).collect(Collectors.toList());
		assertThat(pieces.size()).isEqualTo(0);
	}

	@Test
	public void addCollectWithEnableReuseAndDigitalAllowedList() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		collects.get(0).setOwners(new HashSet<>(owners));
		typesWithSubTypes.stream().forEach(t -> {
			t.setParentId(null);
			t.setFamilyPropertyType("Liste");
			t.setEnableReuse(true);
			t.setDigitalAllowed(true);
		});
		typesWithSubTypes.get(0).setEdocType("00000000000000017");
		typesWithSubTypes.get(1).setEdocType("00000000000000001");
		typesWithSubTypes.get(2).setEdocType("00000000000000002");
		collects.get(0).setTypes(new HashSet<>(typesWithSubTypes));
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
		final ArgumentCaptor<Collect> collectSaved = ArgumentCaptor.forClass(Collect.class);
		verify(collectRepository).add(collectSaved.capture());
		final List<Piece> pieces = collectSaved.getValue().getTypes().stream().map(Type::getPieces).flatMap(Collection::stream).collect(Collectors.toList());
		assertThat(pieces.size()).isEqualTo(2);
	}

	@Test
	public void abondonCollectWithFacultativeFamilyTest() {
		collects.get(0).setTypes(new HashSet<>(Arrays.asList(typeWithFacultatitveFamily)));
		collects.get(0).setOwners(new HashSet<>(owners));
		when(collectRepository.findOne(collects.get(0).getId())).thenReturn(collects.get(0));
		Mockito.doNothing().when(collectRepository).endCollect(collects.get(0));
		when(typeRepository.findByCollect(collects.get(0).getId())).thenReturn(ImmutableSet.of(types.get(4), types.get(3)));
		Mockito.doNothing().when(collectEventHandler).sendUpdatedCollectEvent(any());
		collectService.endCollect(collects.get(0).getId(), "AB", new Context("132456", "001", "001"));
		assertThat(collects.get(0).getStatus()).isEqualTo(CollectStatus.AB.name());
	}

	@Test
	public void addCollectWithActManagmentDeclaredInFamily() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setFamiliesManagementAct(null);
		typeWithActManagment.setFamiliesManagementActFamily(ImmutableSet.of("OB", "ND", "DR", "DF"));
		typeWithActManagment.setEdocType("00000000000000001");
		collects.get(0).setTypes(new HashSet<>(Arrays.asList(typeWithActManagment)));
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
		final ArgumentCaptor<Collect> collectSaved = ArgumentCaptor.forClass(Collect.class);
		verify(collectRepository).add(collectSaved.capture());
	}

	@Test
	public void addCollectWithNullCompleteness() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000001");
		types.get(2).setControlRequired(3);
		types.get(2).setDigitalAllowed(false);
		types.get(2).setPaperAllowed(true);
		types.get(2).getPieces().clear();
		final Set<Indexe> indexesc = new HashSet<>();
		indexesc.add(indexes.get(0));
		types.get(2).setIndexes(indexesc);
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
		collects.get(0).getTypes().forEach(t -> {
			assertThat(t.getVideoCodingDelay()).isEqualTo(VideoCodingDelay.NOT_ALLOWED.getCode());
		});
	}

	@Test
	public void addCollectWithImmediateVideoCodingDelay() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000001");
		types.get(2).setControlRequired(3);
		types.get(2).setDigitalAllowed(false);
		types.get(2).setPaperAllowed(true);
		types.get(2).setVideoCodingDelay(VideoCodingDelay.IMMEDIATE.getCode());
		;
		types.get(2).getPieces().clear();
		final Set<Indexe> indexesc = new HashSet<>();
		indexesc.add(indexes.get(0));
		types.get(2).setIndexes(indexesc);
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		collectService.addCollect(collects.get(0), new Context("132456", "001"));
		collects.get(0).getTypes().forEach(t -> {
			assertThat(t.getVideoCodingDelay()).isEqualTo(VideoCodingDelay.IMMEDIATE.getCode());
		});
	}

	@Test
	public void addCollectWithDelayedVideoCodingDelay() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000001");
		types.get(2).setControlRequired(3);
		types.get(2).setDigitalAllowed(false);
		types.get(2).setPaperAllowed(true);
		types.get(2).setVideoCodingDelay(VideoCodingDelay.DELAYED.getCode());
		;
		types.get(2).getPieces().clear();
		final Set<Indexe> indexesc = new HashSet<>();
		indexesc.add(indexes.get(0));
		types.get(2).setIndexes(indexesc);
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		collectService.addCollect(collects.get(0), new Context("132456", "001"));
		collects.get(0).getTypes().forEach(t -> {
			assertThat(t.getVideoCodingDelay()).isEqualTo(VideoCodingDelay.DELAYED.getCode());
		});
	}

	@Test
	public void addCollectWithNullVideoCodingDelay() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		types.get(2).setEdocType("00000000000000001");
		types.get(2).setControlRequired(3);
		types.get(2).setDigitalAllowed(true);
		types.get(2).getPieces().clear();
		final Set<Indexe> indexesc = new HashSet<>();
		indexesc.add(indexes.get(0));
		types.get(2).setIndexes(indexesc);
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		collectService.addCollect(collects.get(0), new Context("132456", "001"));
		collects.get(0).getTypes().forEach(t -> {
			assertThat(t.getVideoCodingDelay()).isNotEmpty();
		});
	}

	@Test
	public void addCollectWithCompletenessAndTypeNotMatching() {
		when(collectService.getFeatureManager().isActive(any())).thenReturn(true);
		exception.expect(CollectBusinessException.class);
		exception.expectMessage(CollectErrorConstants.ERR_COL_TYPE_UNKNOWN_COMPLETENESS);
		types.get(2).setEdocType("00000000000000001");
		types.get(2).setControlRequired(3);
		types.get(2).setDigitalAllowed(false);
		types.get(2).setPaperAllowed(true);
		types.get(2).getPieces().clear();

		final Set<String> completeness = new HashSet();
		completeness.add("20000000000000003");

		types.get(2).setCompleteness(completeness);
		final Set<Indexe> indexesc = new HashSet<>();
		indexesc.add(indexes.get(0));
		types.get(2).setIndexes(indexesc);
		final Set<Type> typesc = new HashSet<>();
		typesc.add(types.get(2));
		collects.get(0).setOwners(new HashSet<>(owners));
		collects.get(0).setTypes(typesc);
		try {
			collectService.addCollect(collects.get(0), new Context("132456", "001", "001"));
		} catch (final Exception e) {
			throw e;
		}

	}

	@Test
	public void updateCollectChangeDoNothing() {

		final Collect collect = collects.get(0);
		final Collect updatedCollect = new Collect(collect);

		updatedCollect.setTypes(new HashSet<>(Arrays.asList(typeWithFacultatitveFamily)));
		collect.setTypes(new HashSet<>(Arrays.asList(typeWithFacultatitveFamily)));

		updatedCollect.setOwners(new HashSet<>(owners));
		collect.setOwners(new HashSet<>(owners));
		updatedCollect.setEntityLabel("test");
		when(collectRepository.findOne(collect.getId())).thenReturn(collects.get(0));
		Mockito.doNothing().when(collectRepository).updateCollect(collects.get(0));
		when(typeRepository.findByCollect(collects.get(0).getId())).thenReturn(ImmutableSet.of(types.get(4), types.get(3)));
		Mockito.doNothing().when(collectEventHandler).sendUpdatedCollectEvent(any());
		collectService.updateCollect(updatedCollect, collect.getId(), new Context("1", "001", "001"));
		assertThat(collects.get(0).getEntityLabel()).isNotEqualTo("test");

	}

	@Test
	public void updateCollectAddOwner() {

		final Collect collect = collects.get(0);
		final Collect updatedCollect = new Collect(collect);

		updatedCollect.setTypes(new HashSet<>(Arrays.asList(typeWithFacultatitveFamily)));
		collect.setTypes(new HashSet<>(Arrays.asList(typeWithFacultatitveFamily)));

		final List ownersPlus1 = new ArrayList<>(owners);
		ownersPlus1.add(new Owner("01940010452800009", "Jean", "Dupont", LocalDate.now(), 1, "123457", null));

		updatedCollect.setOwners(new HashSet<>(ownersPlus1));
		collect.setOwners(new HashSet<>(owners));
		when(collectRepository.findOne(collect.getId())).thenReturn(collects.get(0));
		Mockito.doNothing().when(collectRepository).updateCollect(collects.get(0));
		when(typeRepository.findByCollect(collects.get(0).getId())).thenReturn(ImmutableSet.of(types.get(4), types.get(3)));
		Mockito.doNothing().when(collectEventHandler).sendUpdatedCollectEvent(any());
		collectService.updateCollect(updatedCollect, collect.getId(), new Context("1", "001", "001"));
		assertThat(collects.get(0).getOwners().size()).isEqualTo(3);

	}

}
