package com.bnpparibas.bddf.attachment.domain;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.UUID;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditEvent;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.rest.Context;

@RunWith(MockitoJUnitRunner.class)
public class AttachmentServiceTest {

	@Rule
	public final ExpectedException exception = ExpectedException.none();

	@InjectMocks
	private AttachmentServiceImpl attachmentService;
	@Mock
	private AttachmentRepository attachmentRepository;

	@Mock
	private NasAttachmentService nasAttachmentRepository;
	
	@Mock
	private CollectEventHandler CollectEventHandler;
	
	@Mock
	private AuditGenerator auditGenerator;

	@Spy
	private AttachmentValidator attachmentValidator;

	@Before
	public void init() {
		attachmentValidator.setAuthorizedFormat("PDF,PDF/A,PNG,JPEG,GIF,TIFF,XLS,DOC");
		when(auditGenerator.newAudit(any(), any())).thenReturn(new AuditEvent(new Context(), "", ""));
	}

	@Test
	public void addAttachmentIsOK() {
		final Attachment attachment = new Attachment("1234567", "001", "AP12247", "test.pdf", "pdf", 1000);
		doNothing().when(attachmentRepository).add(attachment);
		doNothing().when(nasAttachmentRepository).add(any(), any(), any());
		final UUID id = attachmentService.addAttachment(attachment, null, new Context("1234567", "001"));
		assertNotNull(id);
		verify(attachmentRepository, times(1)).add(attachment);
		verify(nasAttachmentRepository, times(1)).add(any(), any(), any());
	}

	@Test
	public void validateAttachmentIsOK() {
		final UUID idAttachment = UUID.randomUUID();
		final String idArchive = "GD11100jthcq9w1000001cj";
		final Attachment attachment = new Attachment("1234567", "001", "AP12247", "test.pdf", "pdf", 1000);
		when(attachmentRepository.get(idAttachment)).thenReturn(attachment);
		when(nasAttachmentRepository.get(idAttachment)).thenReturn(null);
		when(attachmentRepository.sendToArchive(attachment, nasAttachmentRepository.get(idAttachment))).thenReturn(idArchive);
		doNothing().when(attachmentRepository).delete(idAttachment);
		doNothing().when(nasAttachmentRepository).delete(idAttachment);
		final String idArchiveReturend = attachmentService.validateAttachment(idAttachment, new Context("1234567", "001"));
		assertEquals(idArchive, idArchiveReturend);
		verify(attachmentRepository, times(1)).get(idAttachment);
	}

	@Test
	public void deleteAttachmentIsOK() {
		final UUID idAttachment = UUID.randomUUID();
		final Attachment attachment = new Attachment("1234567", "001", "AP12247", "test.pdf", "pdf", 1000);
		when(attachmentRepository.get(idAttachment)).thenReturn(attachment);
		doNothing().when(attachmentRepository).delete(idAttachment);
		doNothing().when(nasAttachmentRepository).delete(idAttachment);
		attachmentService.deleteAttachment(idAttachment, new Context("1234567", "001"));
		verify(attachmentRepository, times(1)).get(idAttachment);
		verify(nasAttachmentRepository, times(1)).delete(any());
		verify(attachmentRepository, times(1)).delete(any());
	}

	@Test
	public void getAttachmentIsOK() {
		final UUID idAttachment = UUID.randomUUID();
		final Attachment attachment = new Attachment("1234567", "001", "AP12247", "test.pdf", "pdf", 1000);
		when(attachmentRepository.get(idAttachment)).thenReturn(attachment);
		when(nasAttachmentRepository.get(idAttachment)).thenReturn(null);
		attachmentService.getAttachment(idAttachment, new Context("1234567", "001"));
		verify(attachmentRepository, times(1)).get(idAttachment);
		verify(nasAttachmentRepository, times(1)).get(any());

	}

}
