package com.bnpparibas.bddf.collect.domain.event;

import java.util.UUID;

import com.bnpparibas.bddf.collect.domain.collect.Collect;

public abstract class AbstractCollectEvent {

	private Collect collect;
	private final UUID eventId;
	private String channel;
	private String nomenclatureRef;
	private String media;

	public AbstractCollectEvent() {
		eventId = UUID.randomUUID();
	}

	public Collect getCollect() {
		return collect;
	}

	public void setCollect(Collect collect) {
		this.collect = collect;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getMedia() {
		return media;
	}

	public void setMedia(String media) {
		this.media = media;
	}

	public UUID getEventId() {
		return eventId;
	}

	public String getNomenclatureRef() {
		return nomenclatureRef;
	}

	public void setNomenclatureRef(String nomenclatureRef) {
		this.nomenclatureRef = nomenclatureRef;
	}

}
