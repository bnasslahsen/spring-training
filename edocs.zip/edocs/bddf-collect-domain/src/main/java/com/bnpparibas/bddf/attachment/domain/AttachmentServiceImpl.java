package com.bnpparibas.bddf.attachment.domain;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditEvent;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.errors.TechnicalException;
import com.bnpparibas.bddf.rest.Context;

@Service
@Transactional(transactionManager = "transactionManagerDB")
public class AttachmentServiceImpl implements AttachmentService {

	@Autowired
	private AttachmentRepository attachmentRepository;

	@Autowired
	private NasAttachmentService nasAttachmentRepository;

	@Autowired
	private AttachmentValidator attachmentValidator;
	
	@Autowired
	private AuditGenerator auditGenerator;
	
	@Autowired
	private CollectEventHandler collectEventHandler;

	@Override
	public UUID addAttachment(Attachment attachment, ByteBuffer file, Context context) {
		try {			
			attachmentValidator.validate(attachment);
			final UUID attachmentId = UUID.randomUUID();
			nasAttachmentRepository.add(attachmentId, attachment.getFileName(), file);
			attachment.setId(attachmentId);
			attachment.setCreationDate(Instant.now());
			attachmentRepository.add(attachment);
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ADD_ATTACHMENT).setCodeAP(attachment.getSendingApplicationCode()).setIdPiece(attachmentId).setTotalPieces(1);
			collectEventHandler.sendAuditEventAttachment(auditEvent);
			return attachmentId;
		} catch(TechnicalException | CollectBusinessException ex) {
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_ADD_ATTACHMENT).setCodeError(ex.getMessage()).setCodeAP(attachment.getSendingApplicationCode());
			collectEventHandler.sendAuditEventAttachment(auditEvent);
			throw ex;
		}
	}

	@Override
	public String validateAttachment(UUID idAttachment, Context context) {
		final Attachment attachment = attachmentRepository.get(idAttachment);
		try {
			if (attachment == null) {
				throw new TechnicalException(HttpStatus.NOT_FOUND, CollectErrorConstants.ERR_ATTACHMENT_NOT_FOUND, idAttachment.toString());
			}
			attachmentValidator.checkCanModify(attachment, context);
			final String idArchive = attachmentRepository.sendToArchive(attachment, nasAttachmentRepository.get(idAttachment));
			attachmentRepository.delete(idAttachment);
			nasAttachmentRepository.delete(idAttachment);
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.VALIDATE_ATTACHMENT).setCodeAP(attachment.getSendingApplicationCode()).setIdPiece(idAttachment).setTotalPieces(1);
			collectEventHandler.sendAuditEventAttachment(auditEvent);
			return idArchive;
		} catch(TechnicalException | CollectBusinessException ex) {
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_VALIDATE_ATTACHMENT).setCodeError(ex.getMessage()).setCodeAP(Optional.ofNullable(attachment).map(Attachment::getSendingApplicationCode).orElse("")).setIdPiece(idAttachment).setTotalPieces(1);
			collectEventHandler.sendAuditEventAttachment(auditEvent);
			throw ex;
		}
	}

	@Override
	public void deleteAttachment(UUID idAttachment, Context context) {
		final Attachment attachment = attachmentRepository.get(idAttachment);
		if (attachment == null) {
			throw new TechnicalException(HttpStatus.NOT_FOUND, CollectErrorConstants.ERR_ATTACHMENT_NOT_FOUND, idAttachment.toString());
		}
		attachmentValidator.checkCanModify(attachment, context);
		attachmentRepository.delete(idAttachment);
		nasAttachmentRepository.delete(idAttachment);

	}

	@Override
	public Attachment getAttachment(UUID idAttachment, Context context) {
		final Attachment attachment = attachmentRepository.get(idAttachment);
		if (attachment == null) {
			throw new TechnicalException(HttpStatus.NOT_FOUND, CollectErrorConstants.ERR_ATTACHMENT_NOT_FOUND, idAttachment.toString());
		}
		attachmentValidator.checkCanModify(attachment, context);
		attachment.setFile(nasAttachmentRepository.get(idAttachment));
		return attachment;
	}
	

}