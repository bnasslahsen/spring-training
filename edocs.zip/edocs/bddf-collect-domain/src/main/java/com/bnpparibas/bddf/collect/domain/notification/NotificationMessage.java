package com.bnpparibas.bddf.collect.domain.notification;

import java.util.List;
import java.util.StringJoiner;

import com.bnpparibas.bddf.collect.domain.notification.enums.ConstantNotification;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Entity
public class NotificationMessage {

	// Espace vide (10) - Position 1
	private String space1;
	// Identifiant Émetteur du Message (25) - Position 11
	private String senderId;
	// Identifiant RP (17) - Position 36
	private String idRP;
	// Espace vide (17) - Position 53
	private String space2;
	// Identifiant du type message (10) - Position 70
	private String typeMessageId;
	// Canaux destinataire PUSH (2) - Position 80
	private String pushRecipientCanal;
	// Espace vide (170) - Position 82
	private String space3;
	// Référence de la campagne (10) - Position 252
	private String campaignReference;
	// Libelle de la campagne (50) - Position 262
	private String campaignLabel;
	// Espace vide (36) - Position 312
	private String space4;
	// Canaux destinataire (2) - Position 348
	// Top facturable (1) - Position 350
	private String billable;
	// Nombres de variables dans le message (2) - Position 351
	private String columnsCount;
	// Variable 1 - Libellé Offre/produit - Position 353
	private String productLabel;
	// Variable 2 - Libellé application - Position 403
	private String applicationLabel;
	// Filler (9548) - Position 453
	private String filler;
	private static final String COMPAIGN_LABEL_VALUE = "Notification Client eDoc";

	public NotificationMessage(String senderId, String idRP, String typeMessageId, String pushRecipientCanal, String productLabel, String applicationLabel) {
		super();
		this.space1 = String.format("%010d", 0);
		this.senderId = String.format("%-25s", senderId);
		this.idRP = String.format("%-17s", idRP);
		this.space2 = String.format("%017d", 0);
		this.typeMessageId = String.format("%-10s", typeMessageId);
		this.pushRecipientCanal = String.format("%2s", pushRecipientCanal);
		this.space3 = String.format("%160s", " ");
		this.campaignReference = String.format("%010d", 0);
		this.campaignLabel = String.format("%-50s", COMPAIGN_LABEL_VALUE);
		this.space4 = String.format("%36s", " ");
		this.billable = ConstantNotification.TOP_FACTURABLE.getCode();
		this.columnsCount = ConstantNotification.NBRES_VARIABLES_MESSAGE_DEFAULT.getCode();
		this.productLabel = String.format("%-50s", productLabel);
		this.applicationLabel = String.format("%-50s", applicationLabel);
		this.filler = String.format("%-9548s", " ");
	}

	public NotificationMessage() {
		super();
	}

	public String getNotificationMessage() {
		final StringJoiner join = new StringJoiner("");
		join.add(space1);
		join.add(senderId);
		join.add(idRP);
		join.add(space2);
		join.add(typeMessageId);
		join.add(pushRecipientCanal);
		join.add(space1);
		join.add(space3);
		join.add(campaignReference);
		join.add(campaignLabel);
		join.add(space4);
		join.add(pushRecipientCanal);
		join.add(billable);
		join.add(columnsCount);
		join.add(productLabel);
		join.add(applicationLabel);
		join.add(filler);
		return join.toString();
	}

	public void setSenderId(String senderId) {
		this.senderId = String.format("%25s", senderId);
	}

	public void setIdRP(Long idRP) {
		this.idRP = String.format("%017d", idRP);
	}

	public void setTypeMessageId(Long typeMessageId) {
		this.typeMessageId = String.format("%10s", typeMessageId);
	}

	public void setPushRecipientCanal(String pushRecipientCanal) {
		this.pushRecipientCanal = String.format("%10s", pushRecipientCanal);
	}

	public void setCampaignReference(String campaignReference) {
		this.campaignReference = String.format("%-10s", campaignReference);
	}

	public void setCampaignLabel(String campaignLabel) {
		this.campaignLabel = String.format("%-50s", campaignLabel);
	}

	public void setBillable() {
		this.billable = String.format("%d", 2);
	}

	public void setColumnsCount(int columnsCount) {
		this.columnsCount = String.format("%02d", columnsCount);
	}

	public void setProductLabel(String productLabel) {
		this.productLabel = String.format("%-50s", productLabel);
	}

	public void setApplicationLabel(String applicationLabel) {
		this.applicationLabel = String.format("%-50s", applicationLabel);
	}

	public void setFiller() {
		this.filler = String.format("%-9548s", " ");
	}

	public void setVariablesMessage(List<String> var) {

		final StringJoiner join = new StringJoiner("");
		final int nbMessage = var.size();
		var.stream().forEach(v -> join.add(String.format("%-50s", v)));

		for (int i = nbMessage; i < 99; i++) {
			join.add(String.format("%-50s", columnsCount));
		}
		columnsCount = join.toString();
	}

	public String getSenderId() {
		return senderId;
	}

	public String getIdRP() {
		return idRP;
	}

	public String getTypeMessageId() {
		return typeMessageId;
	}

	public String getPushRecipientCanal() {
		return pushRecipientCanal;
	}

	public String getCampaignReference() {
		return campaignReference;
	}

	public String getCampaignLabel() {
		return campaignLabel;
	}

	public String getBillable() {
		return billable;
	}

	public String getColumnsCount() {
		return columnsCount;
	}

	public String getProductLabel() {
		return productLabel;
	}

	public String getApplicationLabel() {
		return applicationLabel;
	}

	public String getFiller() {
		return filler;
	}

}
