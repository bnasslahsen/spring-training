package com.bnpparibas.bddf.collect.domain.event.type;

import com.bnpparibas.bddf.collect.domain.event.AbstractCollectEvent;

public class EventSendAMI extends AbstractCollectEvent {
	private String colledId;
	private String typeId;
	private String userId;

	public EventSendAMI() {
		super();
	}

	public EventSendAMI(String colledId, String typeId, String userId) {
		super();
		this.colledId = colledId;
		this.typeId = typeId;
		this.userId = userId;
	}

	public String getColledId() {
		return colledId;
	}

	public void setColledId(String colledId) {
		this.colledId = colledId;
	}

	public String getTypeId() {
		return typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
