package com.bnpparibas.bddf.collect.domain.nomenclature;

import java.util.List;

public interface NomenclatureService {

	List<Nomenclature> findAll();

}
