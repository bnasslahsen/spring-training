package com.bnpparibas.bddf.collect.domain.ladrad.enums;

import java.util.Arrays;

public enum PieceIndicators {

	OK("OK"),

	OK_MAN("OK_MAN"),

	KO("KO"),

	KO_UNK("KO_UNK"),

	KO_EXP("KO_EXP"),

	KO_MULT("KO_MULT"),

	KO_COHE("KO_COHE"),

	WARNING("WARNING"),

	WARNING_EXTR("WARNING_EXTR"),

	WARNING_COHE("WARNING_COHE"),

	WARNING_MULT("WARNING_MULT");

	private final String label;

	private PieceIndicators(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	public static PieceIndicators fromLabel(String label) {
		return Arrays.asList(values()).stream().filter(t -> t.getLabel().equals(label)).findAny().orElse(null);
	}

}
