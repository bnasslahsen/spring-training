package com.bnpparibas.bddf.collect.domain.ladrad.enums;

import java.util.Arrays;

public enum TypeControls {

	OK("OK"),

	KO("KO"),

	EC("EC"),
	
	EC_AMI("EC_AMI"),

	ERR("ERR"),

	CT("CT");

	private final String label;

	private TypeControls(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	public static TypeControls fromLabel(String label) {
		return Arrays.asList(values()).stream().filter(t -> t.getLabel().equals(label)).findAny().orElse(null);
	}

}
