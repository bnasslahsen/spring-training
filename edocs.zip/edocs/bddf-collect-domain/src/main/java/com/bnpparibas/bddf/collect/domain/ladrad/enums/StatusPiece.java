package com.bnpparibas.bddf.collect.domain.ladrad.enums;

import java.util.Arrays;

public enum StatusPiece {

	CREATED("0"),

	ANALYSIS_IN_PROGRESS("1"),

	ANALYSIS_SUCCESS("2"),

	ANALYSIS_FAILED("-1"),

	ANALYSED_TYPE_NOT_DETERMINED("-2"),

	DOCUMENT_REJECTED("-3");

	private final String label;

	private StatusPiece(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	public static StatusPiece fromLabel(String label) {
		return Arrays.asList(values()).stream().filter(t -> t.getLabel().equals(label)).findAny().orElse(null);
	}

}
