package com.bnpparibas.bddf.collect.domain.audit.event;

import java.util.List;
import java.util.UUID;

import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.rest.Context;

public interface AuditEventService {

	void sendAuditEventLadRAD(UUID collectId, Context context, String journeyCode, Type type, AuditValue typeAuditEvent, String errorCode);

	void sendAuditEventLadRADFirstIteration(UUID collectId, Context context, String journeyCode, Type type, Integer durationJMC, Integer durationAMI, String documentSet, List<Piece> activedPiecesSendedToJMC);

	void sendAuditEventLadRADSecondIteration(UUID collectId, Context context, String journeyCode, Type type, Integer durationJMC, Integer durationSendsAmi, String documentSet);

	boolean sendAuditEventForcedRecognition(UUID collectId, Context context, String journeyCode, Type updatedType, Type typeRepo);

}
