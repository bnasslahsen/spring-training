package com.bnpparibas.bddf.collect.domain.ladrad;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.bnp.schema.edoc.index.Indexes.EdocIndex;
import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnp.schema.edoc.type.Types.EdocType.PiecesEdoc;
import com.bnpparibas.bddf.collect.domain.helper.DateUtil;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.index.IndexeJmc;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.JmcRecognitionLevel;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceControls;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceIndicators;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.TypeControls;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.type.ControlRequired;
import com.bnpparibas.bddf.collect.domain.type.IndexCategory;
import com.bnpparibas.bddf.collect.domain.type.IndexFormat;
import com.bnpparibas.bddf.collect.domain.type.IndexStatus;
import com.bnpparibas.bddf.collect.domain.type.Type;

@Component
public class LadRadValidator {

	private static final String UNKNOWN = "unknown";
	private static final String OK_JMC = "OK";
	private static final String NOT_APPLICABLE_KO = "NOT_APPLICABLE_KO";
	private static final String NOT_APPLICABLE_WARNING = "NOT_APPLICABLE_WARNING";
	private static final String MSG_DATA_NOT_EXTRACT = "Donnée non extraite dans le document";
	private static final String MSG_ERROR_KO_MULT = "Plusieurs valeurs détectées sur le document";

	public void calculateIndicatorsPieces(Piece piece, Type type, List<EdocType> edocTypes, List<EdocIndex> edocIndexes) {
		if (type.getControlRequired() == ControlRequired.CONTROL_JMC.getCode()) {
			updateReconnaissancePiece(piece, type, edocTypes);
			updateExtractionPiece(piece, type);
			updateStatusControlPiece(piece);
		}
	}

	public void calculateIndicatorsType(Type type, List<EdocType> edocTypes) {
		if (type.getControlRequired() == ControlRequired.CONTROL_JMC.getCode()) {
			updateStatusControlType(type);
			updateCompletenessControl(type, edocTypes);
			verifyNoIndexUNK(type);
		}
	}

	private void verifyNoIndexUNK(Type type) {
		if (TypeControls.OK.name().equals(type.getCompletenessControl()) && type.getIndexes().stream().anyMatch(index -> IndexStatus.KO_UNK.name().equals(index.getStatusControl()))) {
			type.getActivePieces().forEach(piece -> {
				piece.setStatusControl(PieceIndicators.KO.name());
				piece.setExtractionControl(PieceIndicators.KO.name());
				piece.setCoherenceControl(PieceIndicators.KO.name());
				type.setStatusControl(TypeControls.KO.name());
			});
		}
	}

	public void calculateStatusIndexes(Type type, List<EdocIndex> edocIndexes) {
		if (type.getControlRequired() == ControlRequired.CONTROL_JMC.getCode()) {
			type.getIndexes().stream().filter(index -> !IndexStatus.OK_MAN.getCode().equals(index.getStatusControl())).forEach(indexType -> {
				final EdocIndex edocIndex = edocIndexes.stream().filter(edocIdx -> edocIdx.getCode().equals(indexType.getCode())).findAny().orElse(null);
				setValueAndControlIndex(indexType, edocIndex);
			});
		}
	}

	public void updateStatusControlType(Type type) {
		// RG171 - Mise à jour statusControl du type
		if (type.getActivePieces().stream()
				.anyMatch(currentPiece -> StringUtils.isNotEmpty(currentPiece.getStatusControl()) && (currentPiece.getStatusControl().startsWith(PieceControls.KO.name()) || currentPiece.getStatusControl().startsWith(PieceControls.ERR.name())))) {
			type.setStatusControl(TypeControls.KO.name());
		} else {
			type.setStatusControl(TypeControls.OK.name());
		}
	}

	private void setValueAndControlIndex(Indexe indexType, EdocIndex edocIndex) {
		String indexValueExtracted = "";
		if (CollectionUtils.isEmpty(indexType.getIndexesJmc()) || indexType.getIndexesJmc().stream().allMatch(idx -> StringUtils.isEmpty(idx.getStatusControl()))) {
			// handle unkown INDEX
			if (indexType.getCategory().equals(IndexCategory.OB.name())) {
				indexType.setStatusControl(IndexStatus.KO_UNK.name());
			} else {
				indexType.setStatusControl(IndexStatus.WARNING_UNK.name());
			}
			indexType.setMessageControl(MSG_DATA_NOT_EXTRACT);

		} else {
			final boolean statusControlIsOK = indexType.getIndexesJmc().stream().allMatch(idx -> OK_JMC.equals(idx.getStatusControl()));
			final int acceptancePercentage = indexType.getIndexesJmc().stream().filter(idx -> idx.getAcceptancePercentage() > 0).mapToInt(IndexeJmc::getAcceptancePercentage).min().orElse(0);
			final boolean pieceJmcIsSame = indexType.getIndexesJmc().stream().allMatch(e -> StringUtils.equals(indexType.getIndexesJmc().get(0).getIdPieceJmc(), e.getIdPieceJmc()));
			final boolean valueExtractedIsSame = indexType.getIndexesJmc().stream().allMatch(e -> StringUtils.equals(indexType.getIndexesJmc().get(0).getExtractedValue(), e.getExtractedValue()));
			final boolean statusControlIsNotApplicable = indexType.getIndexesJmc().stream().anyMatch(idx -> Arrays.asList(NOT_APPLICABLE_KO, NOT_APPLICABLE_WARNING).contains(idx.getStatusControl()));
			if (StringUtils.isEmpty(indexType.getCorrectedValue())) {
				indexValueExtracted = Optional.ofNullable(indexType.getIndexesJmc().stream().findFirst()).map(o -> o.get().getExtractedValue()).orElse(null);
			} else {
				indexValueExtracted = indexType.getCorrectedValue();
			}
			setIndexControlValues(indexType, edocIndex, indexValueExtracted, statusControlIsOK, acceptancePercentage, pieceJmcIsSame, valueExtractedIsSame, statusControlIsNotApplicable);
		}

	}

	private void setIndexControlValues(Indexe indexType, EdocIndex edocIndex, String indexValueExtracted, final boolean statusControlIsOK, final int acceptancePercentage, final boolean pieceJmcIsSame, final boolean valueExtractedIsSame,
			final boolean statusControlIsNotApplicable) {
		if (statusControlIsOK && (acceptancePercentage >= edocIndex.getAcceptancePercentage())) {
			indexType.setStatusControl(IndexStatus.OK.name());
			updateExtractedValue(indexType, edocIndex, indexValueExtracted);
			indexType.setMessageControl("");
		} else {
			if (statusControlIsNotApplicable || StringUtils.isEmpty(indexValueExtracted)) {
				handleEmptyIndexExtractedValue(indexType);
			} else {
				handleKOIndex(indexType, edocIndex, indexValueExtracted, pieceJmcIsSame, valueExtractedIsSame);
			}
		}
	}

	private void handleKOIndex(Indexe indexType, EdocIndex edocIndex, String indexValueExtracted, final boolean pieceJmcIsSame, final boolean valueExtractedIsSame) {
		// handle mandatory INDEX
		if (indexType.getCategory().equals(IndexCategory.OB.name())) {
			if (pieceJmcIsSame) {
				indexType.setStatusControl(IndexStatus.KO_COHE.name());
				updateExtractedValue(indexType, edocIndex, indexValueExtracted);
				indexType.setMessageControl(edocIndex.getMsgControl());
			} else {
				if (valueExtractedIsSame) {
					indexType.setStatusControl(IndexStatus.KO_COHE.name());
					indexType.setMessageControl(edocIndex.getMsgControl());
					updateExtractedValue(indexType, edocIndex, indexValueExtracted);
				} else {
					indexType.setStatusControl(IndexStatus.KO_MULT.name());
					indexType.setMessageControl(MSG_ERROR_KO_MULT);
				}
			}
		} else {
			// handle optional INDEX
			if (valueExtractedIsSame) {
				indexType.setStatusControl(IndexStatus.WARNING_COHE.name());
				updateExtractedValue(indexType, edocIndex, indexValueExtracted);
				indexType.setMessageControl(edocIndex.getMsgControl());
			} else {
				indexType.setStatusControl(IndexStatus.WARNING_MULT.name());
				indexType.setMessageControl(MSG_ERROR_KO_MULT);
			}
		}
	}

	private void handleEmptyIndexExtractedValue(Indexe indexType) {
		if (indexType.getCategory().equals(IndexCategory.OB.name())) {
			indexType.setStatusControl(IndexStatus.KO_EXTR.name());
		} else {
			indexType.setStatusControl(IndexStatus.WARNING_EXTR.name());
		}
		indexType.setMessageControl(MSG_DATA_NOT_EXTRACT);
	}

	private void updateExtractedValue(Indexe indexType, EdocIndex edocIndex, String indexValueExtracted) {
		if (StringUtils.isEmpty(indexType.getCorrectedValue())) {
			if (IndexFormat.D.name().equals(edocIndex.getFormat()) && StringUtils.isNotEmpty(indexValueExtracted)) {
				indexType.setExtractedValue(DateUtil.formatDateFromJmc(indexValueExtracted));
			} else if (IndexFormat.B.name().equals(edocIndex.getFormat())) {
				if ("0".equals(indexValueExtracted)) {
					indexType.setExtractedValue("false");
				} else if ("1".equals(indexValueExtracted)) {
					indexType.setExtractedValue("true");
				} else {
					indexType.setExtractedValue(indexValueExtracted);
				}
			} else {
				indexType.setExtractedValue(indexValueExtracted);
			}
		}
	}

	private void updateCompletenessControl(Type type, final List<EdocType> edocTypes) {
		final List<PiecesEdoc.Piece> edocPiecesJMC = new ArrayList<>();
		// Recuperation des pieceJmc correspondant à edocType
		edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && edocT.getValue().equals(type.getEdocType())).forEach(edocT -> edocT.getPiecesEdoc().getPiece().forEach(edocPiecesJMC::add));
		// RG170 + Pour le calcul de completeness, on exclu les pièces KO_EXP
		final Set<String> jmcDetectedPieces = getDetectedPieceJmc(type, edocTypes);
		if (type.getCompleteness() != null) {
			final List<PiecesEdoc.Piece> edocPiecesCompleteness = edocPiecesJMC.stream().filter(ep -> type.getCompleteness().contains(ep.getPieceCode())).collect(Collectors.toList());
			type.setCompletenessControl("");
			type.setCompletenessControlLabel("");
			edocPiecesCompleteness.forEach(edocPiece -> {
				if (!jmcDetectedPieces.contains(edocPiece.getPieceJmc())) {
					if (StringUtils.isNotEmpty(type.getCompletenessControl())) {
						type.setCompletenessControl(type.getCompletenessControl() + " / ");
						type.setCompletenessControlLabel(type.getCompletenessControlLabel() + " / ");
					}
					type.setCompletenessControl(type.getCompletenessControl() + edocPiece.getPieceJmc());
					type.setCompletenessControlLabel(type.getCompletenessControlLabel() + edocPiece.getPieceLabel());
				}
			});
		}
		if (StringUtils.isEmpty(type.getCompletenessControl())) {
			type.setCompletenessControl(TypeControls.OK.name());
			type.setCompletenessControlLabel(TypeControls.OK.name());
		}
	}

	// Liste de PieceJmc (cf edocType.xml) correspondante aux types reconnus par JMC
	public Set<String> getDetectedPieceJmc(Type type, List<EdocType> edocTypes) {
		final Set<String> jmcDetectedPieces = Optional.ofNullable(type.getActivePieces().stream().filter(piece -> !PieceIndicators.KO_EXP.name().equals(piece.getTypeControl())).map(Piece::getTypesJmc).flatMap(List::stream).collect(Collectors.toSet()))
				.orElse(new TreeSet<>());
		final String recognitionLevel = edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && edocT.getValue().equals(type.getEdocType())).findFirst().get().getRecognitionLevel();
		// Récupération des pièces selon le niveau de reconnaissance
		// Fait initialement pour résoudre un pb JMC : Facture mobile reconnue dans facture de téléphonie fixe et non reconnue dans facture mobile => on verifie que la piece a la famille facture
		if (JmcRecognitionLevel.FAMILY.getLabel().equals(recognitionLevel)) {
			final Set<String> familiesJmc = edocTypes.stream()
					.filter(edocT -> edocT.getPiecesEdoc() != null && JmcRecognitionLevel.FAMILY.getLabel().equals(edocT.getRecognitionLevel()) && edocT.getPiecesEdoc().getPiece().stream().anyMatch(piece -> jmcDetectedPieces.contains(piece.getPieceJmc())))
					.map(EdocType::getJmcFamily).collect(Collectors.toSet());
			edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && JmcRecognitionLevel.FAMILY.getLabel().equals(edocT.getRecognitionLevel()) && familiesJmc.contains(edocT.getJmcFamily()))
					.forEach(edocT -> jmcDetectedPieces.addAll(edocT.getPiecesEdoc().getPiece().stream().map(PiecesEdoc.Piece::getPieceJmc).collect(Collectors.toSet())));
		} else if (JmcRecognitionLevel.TYPE.getLabel().equals(recognitionLevel)) {
			final Set<String> typesJmc = edocTypes.stream()
					.filter(edocT -> edocT.getPiecesEdoc() != null && JmcRecognitionLevel.TYPE.getLabel().equals(edocT.getRecognitionLevel()) && edocT.getPiecesEdoc().getPiece().stream().anyMatch(piece -> jmcDetectedPieces.contains(piece.getPieceJmc())))
					.map(EdocType::getJmcType).collect(Collectors.toSet());
			edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && JmcRecognitionLevel.TYPE.getLabel().equals(edocT.getRecognitionLevel()) && typesJmc.contains(edocT.getJmcType()))
					.forEach(edocT -> jmcDetectedPieces.addAll(edocT.getPiecesEdoc().getPiece().stream().map(PiecesEdoc.Piece::getPieceJmc).collect(Collectors.toSet())));
		}
		return jmcDetectedPieces;

	}

	// Liste de PieceJmc (cf edocType.xml) correspondante aux edocType de la collecte
	public Set<String> getEdocTypePieceJmc(Type type, List<EdocType> edocTypes) {
		final Set<String> jmcEdocTypePiecePieces = new TreeSet<>();
		edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && edocT.getValue().equals(type.getEdocType()))
				.forEach(edocT -> jmcEdocTypePiecePieces.addAll(edocT.getPiecesEdoc().getPiece().stream().map(PiecesEdoc.Piece::getPieceJmc).collect(Collectors.toList())));
		final String familyJmc = edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && edocT.getValue().equals(type.getEdocType())).findFirst().get().getJmcFamily();
		edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && JmcRecognitionLevel.FAMILY.getLabel().equals(edocT.getRecognitionLevel()) && StringUtils.equals(familyJmc, edocT.getJmcFamily()))
				.forEach(edocT -> jmcEdocTypePiecePieces.addAll(edocT.getPiecesEdoc().getPiece().stream().map(PiecesEdoc.Piece::getPieceJmc).collect(Collectors.toList())));
		final String typeJmc = edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && edocT.getValue().equals(type.getEdocType())).findFirst().get().getJmcType();
		edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && JmcRecognitionLevel.TYPE.getLabel().equals(edocT.getRecognitionLevel()) && StringUtils.equals(typeJmc, edocT.getJmcType()))
				.forEach(edocT -> jmcEdocTypePiecePieces.addAll(edocT.getPiecesEdoc().getPiece().stream().map(PiecesEdoc.Piece::getPieceJmc).collect(Collectors.toList())));
		return jmcEdocTypePiecePieces;
	}

	private void updateStatusControlPiece(Piece piece) {
		// RG169 - Mise à jour statusControl des pièces
		if (StringUtils.isEmpty(piece.getCoherenceControl()) || piece.getCoherenceControl().startsWith(PieceIndicators.KO.name())) {
			piece.setStatusControl(PieceControls.KO.name());
		} else {
			piece.setStatusControl(PieceControls.OK.name());
		}
	}

	private void updateReconnaissancePiece(Piece piece, Type type, List<EdocType> edocTypes) {
		// RG161
		final Set<String> edocPiecesJMC = getEdocTypePieceJmc(type, edocTypes);
		if (piece.getTypesJmc() != null && piece.getTypesJmc().stream().allMatch(e -> e.equals(UNKNOWN))) {
			if (!Arrays.asList(PieceIndicators.OK_MAN.name(), PieceIndicators.OK.name()).contains(piece.getTypeControl())) {
				piece.setTypeControl(PieceIndicators.KO_UNK.name());
			}
			piece.setExtractionControl(PieceIndicators.KO.name());
			piece.setCoherenceControl(PieceIndicators.KO.name());
			// RG160
		} else if (piece.getTypesJmc() != null && piece.getTypesJmc().stream().anyMatch(edocPiece -> !edocPiecesJMC.contains(edocPiece) && !edocPiece.equals(UNKNOWN))) {
			if (!Arrays.asList(PieceIndicators.OK_MAN.name(), PieceIndicators.OK.name()).contains(piece.getTypeControl())) {
				piece.setTypeControl(PieceIndicators.KO_EXP.name());
			}
			piece.setExtractionControl(PieceIndicators.KO.name());
			piece.setCoherenceControl(PieceIndicators.KO.name());
		} else {
			if (!Arrays.asList(PieceIndicators.OK_MAN.name(), PieceIndicators.OK.name()).contains(piece.getTypeControl())) {
				piece.setTypeControl(PieceIndicators.OK.name());
			}
			updateExtractionPiece(piece, type);
		}
	}

	private void updateExtractionPiece(Piece piece, Type type) {
		// RG164 - update ctrlExtr

		if (StringUtils.isNotEmpty(piece.getTypeControl()) && !piece.getTypeControl().startsWith(PieceIndicators.KO.name())) {
			if (type.getIndexes().stream().filter(index -> index.getIndexesJmc().stream().map(IndexeJmc::getIdPiece).collect(Collectors.toList()).contains(piece.getId()))
					.anyMatch(index -> Arrays.asList(IndexStatus.KO_EXTR.name(), IndexStatus.KO_UNK.name()).contains(index.getStatusControl()))) {
				piece.setExtractionControl(PieceIndicators.KO.name());
				piece.setCoherenceControl(PieceIndicators.KO.name());
			} else if (type.getIndexes().stream().filter(index -> index.getIndexesJmc().stream().map(IndexeJmc::getIdPiece).collect(Collectors.toList()).contains(piece.getId()))
					.anyMatch(index -> IndexStatus.KO_MULT.name().equals(index.getStatusControl()))) {
				handleIndexKOMult(piece, type);
				updateCoherencePiece(piece, type);
			} else if (type.getIndexes().stream().filter(index -> index.getIndexesJmc().stream().map(IndexeJmc::getIdPiece).collect(Collectors.toList()).contains(piece.getId()))
					.anyMatch(index -> Arrays.asList(IndexStatus.WARNING_MULT.name(), IndexStatus.WARNING_EXTR.name(), IndexStatus.WARNING_UNK.name()).contains(index.getStatusControl()))) {
				piece.setExtractionControl(PieceIndicators.WARNING.name());
				updateCoherencePiece(piece, type);
			} else {
				piece.setExtractionControl(PieceIndicators.OK.name());
				updateCoherencePiece(piece, type);
			}
		}
	}

	private void handleIndexKOMult(Piece piece, Type type) {
		// verify each index has status KO_MULT
		type.getIndexes().stream().filter(index -> index.getIndexesJmc().stream().map(IndexeJmc::getIdPiece).collect(Collectors.toList()).contains(piece.getId()) && IndexStatus.KO_MULT.name().equals(index.getStatusControl())).forEach(indexKOMULT -> {
			final boolean pieceEdocIsSame = indexKOMULT.getIndexesJmc().stream().allMatch(e -> e.equals(indexKOMULT.getIndexesJmc().get(0)));
			piece.setExtractionControl(pieceEdocIsSame ? PieceIndicators.KO_MULT.name() : PieceIndicators.OK.name());

		});

	}

	private void updateCoherencePiece(Piece piece, Type type) {
		// RG167
		if (type.getIndexes().stream().filter(index -> index.getIndexesJmc().stream().map(IndexeJmc::getIdPiece).collect(Collectors.toList()).contains(piece.getId()))
				.anyMatch(index -> Arrays.asList(IndexStatus.KO_COHE.name(), IndexStatus.KO_MULT.name()).contains(index.getStatusControl()))) {
			piece.setCoherenceControl(PieceIndicators.KO.name());
		} else if (type.getIndexes().stream().filter(index -> index.getIndexesJmc().stream().map(IndexeJmc::getIdPiece).collect(Collectors.toList()).contains(piece.getId()))
				.anyMatch(index -> Arrays.asList(IndexStatus.WARNING_COHE.name()).contains(index.getStatusControl()))) {
			// RG167 - Tous les indexe OK/Warning + au moins un index Warning => completenessControl = Warning
			piece.setCoherenceControl(PieceIndicators.WARNING.name());
		} else {
			// RG168
			piece.setCoherenceControl(PieceIndicators.OK.name());
		}
	}

	public void updateTypeWhenError(Type type) {
		type.setStatusControl(TypeControls.ERR.name());
		type.getActivePieces().stream().forEach(this::updatePieceWhenError);
		type.getIndexes().stream().filter(index -> StringUtils.isEmpty(index.getStatusControl())).forEach(index -> {
			index.setStatusControl(index.getCategory().equals(IndexCategory.OB.name()) ? IndexStatus.KO_UNK.name() : IndexStatus.WARNING_UNK.name());
			index.setMessageControl(MSG_DATA_NOT_EXTRACT);
		});
	}

	public void updatePieceWhenError(Piece piece) {
		if (StringUtils.isEmpty(piece.getStatusControl()) || PieceControls.EC.name().equals(piece.getStatusControl())) {
			piece.setStatusControl(PieceControls.ERR.name());
		}
		if (StringUtils.isEmpty(piece.getTypeControl())) {
			piece.setTypeControl(PieceIndicators.KO_UNK.name());
		}
		if (StringUtils.isEmpty(piece.getExtractionControl())) {
			piece.setExtractionControl(PieceIndicators.KO.name());

		}
		if (StringUtils.isEmpty(piece.getCoherenceControl())) {
			piece.setCoherenceControl(PieceIndicators.KO.name());
		}
	}

}
