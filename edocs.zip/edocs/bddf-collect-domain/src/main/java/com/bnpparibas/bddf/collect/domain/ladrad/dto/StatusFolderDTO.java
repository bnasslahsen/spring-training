package com.bnpparibas.bddf.collect.domain.ladrad.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Data used for create Folder in JOUVE
 *
 * @author c07128
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class StatusFolderDTO {

	@JsonProperty("status")
	private String status;

	@JsonProperty("reference")
	private String reference;

	@JsonProperty("external_ref")
	private String externalRef;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getExternalRef() {
		return externalRef;
	}

	public void setExternalRef(String externalRef) {
		this.externalRef = externalRef;
	}
}
