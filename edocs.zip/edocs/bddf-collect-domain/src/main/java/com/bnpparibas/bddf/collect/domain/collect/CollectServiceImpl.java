package com.bnpparibas.bddf.collect.domain.collect;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.togglz.core.manager.FeatureManager;

import com.bnp.schema.edoc.index.Indexes.EdocIndex;
import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditEvent;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.audit.event.LadRadFeature;
import com.bnpparibas.bddf.collect.domain.audit.event.NomenclatureRefEvent;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.event.collect.UpdatedCollect;
import com.bnpparibas.bddf.collect.domain.helper.StringHelper;
import com.bnpparibas.bddf.collect.domain.nomenclature.Nomenclature;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.GdnParamRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceRecivedFormat;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReference;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceRepository;
import com.bnpparibas.bddf.collect.domain.type.FamilyCategory;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.bnpparibas.bddf.collect.domain.type.TypeValidator;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;

/**
 *
 * Cette classe présente l'implémentation des Web Service Rest de la ressource collect
 *
 */

@Service
@Transactional(transactionManager = "transactionManagerDB")
public class CollectServiceImpl implements CollectService {

	@Value("${collect.authorized-format}")
	private String authorizedFormat;

	private static final String CONTROL_ITERATION_ALLOWED = "param.controlIterationAllowed";
	private static final String AUTO_CLOSING_DELAY = "auto-closure.delay";

	private CollectRepository collectRepository;
	private TypeRepository typeRepository;
	private GdnParamRepository gdnParamRepository;
	private CollectValidator customValidator;
	private CollectEventHandler collectEventHandler;
	private AuditGenerator auditGenerator;
	private Environment environment;
	@Autowired
	private DocReferenceRepository docReferenceRepository;
	@Autowired
	private EdocTypeRepository edocTypeRepository;
	@Autowired
	private EdocIndexRepository edocIndexRepository;
	@Autowired
	private FeatureManager featureManager;
	@Autowired
	private TypeValidator typeValidator;
	@Autowired
	private NomenclatureService nomenclatureService;

	private List<EdocType> edocTypes;
	private List<EdocIndex> edocIndexes;
	private List<Nomenclature> nomenclatures;
	private Map<String, Long> gdnParam;

	public CollectServiceImpl() {

	}

	@Autowired(required = false)
	public CollectServiceImpl(CollectRepository collectRepository, TypeRepository typeRepository, GdnParamRepository gdnParamRepository, CollectValidator customValidator, CollectEventHandler collectEventHandler, AuditGenerator auditGenerator,
			Environment environment, TypeValidator typeValidator, EdocTypeRepository edocTypeRepository, EdocIndexRepository edocIndexRepository) {
		this.collectRepository = collectRepository;
		this.typeRepository = typeRepository;
		this.gdnParamRepository = gdnParamRepository;
		this.customValidator = customValidator;
		this.collectEventHandler = collectEventHandler;
		this.auditGenerator = auditGenerator;
		this.environment = environment;
		this.typeValidator = typeValidator;
		this.edocTypeRepository = edocTypeRepository;
		this.edocIndexRepository = edocIndexRepository;
	}

	@Override
	public Set<UUID> getAllManagedCollects() {
		return collectRepository.findAll();
	}

	@Override
	public Set<Type> getTypesByCollectId(UUID collectId) {
		return typeRepository.findByCollect(collectId);
	}

	@Override
	public Collect getCollect(UUID id) {
		return collectRepository.findOne(id);
	}

	@Override
	public Set<Collect> getCollectsByOwners(Set<String> references, List<String> journeyCodes) {
		return collectRepository.findByOwners(references, journeyCodes);
	}

	@Override
	public Integer countCollectsByOwners(Set<String> references, String journeyCode) {
		return collectRepository.countByOwners(references, journeyCode);
	}

	public void initReferences() {
		if (edocTypes == null) {
			edocTypes = edocTypeRepository.findAll();
		}
		if (edocIndexes == null) {
			edocIndexes = edocIndexRepository.findAll();
		}
		if (nomenclatures == null) {
			nomenclatures = nomenclatureService.findAll();
		}
		if (gdnParam == null) {
			gdnParam = gdnParamRepository.getGdnParam();
		}

	}

	private void calculateTypePositions(final Set<Type> types) {
		typeValidator.calculateFamilyPositions(types);
		types.stream().filter(type -> type.getFamilyId() != null && type.getParentId() == null).collect(Collectors.groupingBy(Type::getFamilyId)).forEach((familyId, parentTypes) -> typeValidator.calculateTypePositions(parentTypes));
		types.stream().filter(type -> type.getFamilyId() != null && type.getParentId() != null).collect(Collectors.groupingBy(Type::getParentId)).forEach((parentId, subTypes) -> typeValidator.calculateTypePositions(subTypes));
	}

	@Override
	public UUID addCollect(Collect collect, Context context) {

		final UUID collectId = UUID.randomUUID();
		try {
			if (collect.getOwners().stream().map(Owner::getReference).noneMatch(ref -> StringUtils.equals(context.getCustomerId(), ref)) && Channel.isClient(context.getCanal())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_HABLITATION_NOT_AUTHORIZED, context.getCustomerId(), ""));
			}
			initReferences();
			customValidator.validateCollect(collect);
			final boolean sendToLadRadEnabled = Optional.ofNullable(LadRadFeature.fromLabel(collect.getJourneyCode())).map(featureManager::isActive).orElse(false);
			collect.getTypes().forEach(t -> typeValidator.validateType(t, edocTypes, collect, sendToLadRadEnabled));
			processEdocTypeFeature(collect);
			// renvoi liste des sous Types et des tout les types
			collect.getTypes().stream().forEach(t -> typeValidator.validateTypeIndex(t, edocTypes, edocIndexes, nomenclatures, collect.getTypes()));
			collect.setId(collectId);
			collect.setCreationDate(Instant.now());
			if (collect.getAutoClosingDelay() == -1) {
				collect.setAutoClosingDelay(environment.getProperty(AUTO_CLOSING_DELAY, Integer.class, 360));
			}
			collect.setStatus(CollectStatus.EC.name());
			collect.getTypes().forEach(t -> t.setStatus(TypeStatus.IN.getLabel()));
			collect.getTypes().forEach(t -> typeValidator.cleanIndexIfNoControlJmc(t));
			calculateTypePositions(collect.getTypes());
			collectRepository.add(collect);

			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.SAVE_COLLECTE).setIdCollect(collectId).setJourneyCode(collect.getJourneyCode());
			collectEventHandler.sendAuditEvent(auditEvent);

		} catch (final CollectBusinessException ex) {
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_SAVE_COLLECTE).setCodeError(ex.getMessage());
			collectEventHandler.sendAuditEvent(auditEvent);
			throw ex;
		}
		return collectId;
	}

	private void processEdocTypeFeature(Collect collect) {
		collect.getTypes().stream().filter(Type::isDigitalAllowed).forEach(t -> t.setMaxSizeDoc(edocTypeRepository.byValue(t.getEdocType()).getMaxSize()));

		final List<UUID> parentTypes = collect.getTypes().stream().map(Type::getParentId).collect(Collectors.toList());

		// Récupération des pièces déjà fournie
		collect.getTypes().stream().filter(t -> !Arrays.asList(FamiliesManagmentAct.ND.name(), FamiliesManagmentAct.DR.name()).contains(t.getFamilyCategory()) && t.getParentId() == null && !parentTypes.contains(t.getId()) && t.isEnableReuse())
				.collect(Collectors.groupingBy(t -> StringHelper.reduceSet(t.getFamilyOwners(), '|')))
				.forEach((id, types) -> docReferenceRepository.getByOwnersAndTypes(id, types.stream().map(Type::getEdocType).collect(Collectors.toList())).stream().collect(Collectors.groupingBy(DocReference::getEdocType))
						.forEach((edocType, refs) -> types.stream().filter(t -> edocType.equals(t.getEdocType())).forEach(t -> t.setPieces(refs.stream().map(this::refToPiece).collect(Collectors.toSet())))));
	}

	private Piece refToPiece(DocReference ref) {
		final Piece p = new Piece();
		p.setState(PieceStates.ACTIF.getLabel());
		p.setId(UUID.randomUUID());
		p.setStatus(PieceStatus.DF.getLabel());
		p.setChannel(ref.getChannel());
		p.setContentType(ref.getContentType());
		p.setSize(ref.getSize());
		p.setPosition(ref.getPosition());
		p.setLabel(ref.getLabel());
		p.setReferencePieceId(ref.getReferencePieceId());
		p.setReferenceGdnId(ref.getReferenceGdnId());
		p.setAcquisitionDate(ref.getFirstAquisitionDate().toInstant());
		p.setReceivedFormat(PieceRecivedFormat.NUM.name());
		if (Channel.isCollab(ref.getChannel())) {
			p.setEmployeeId(ref.getUserId());
		} else {
			p.setOwnerId(ref.getOwnerId());
		}
		return p;
	}

	@Override
	public List<String> endCollect(UUID collectId, String status, Context context) {
		final Collect collect = collectRepository.findOne(collectId);
		final List<String> alerts = new ArrayList<>();

		try {
			final Set<Type> types = collect.getTypes();

			if (CollectStatus.CL.name().equals(status)) {
				final Map<UUID, Set<Type>> typesByFamily = types.stream().collect(Collectors.groupingBy(Type::getFamilyId, LinkedHashMap::new, Collectors.toSet()));
				typesByFamily.forEach((k, typeSet) -> {
					final Type family = types.stream().filter(t -> t.getFamilyId().equals(k)).findFirst().get();
					if (FamilyCategory.OB.name().equals(family.getFamilyCategory()) || FamilyCategory.IN.name().equals(family.getFamilyCategory())) {
						customValidator.validateFamily(collectId, family.getFamilyPropertyType(), typeSet);
					} else if (FamilyCategory.DF.name().equals(family.getFamilyCategory())) {
						alerts.addAll(customValidator.validateFamilyWithAlert(family.getFamilyPropertyType(), typeSet));
					}
				});
			}

			collect.setStatus(status);
			collect.setEndDate(Instant.now());
		} catch (final CollectBusinessException ex) {
			final AuditEvent auditEvent = auditGenerator.newAudit(context, CollectStatus.CL.name().equals(status) ? AuditValue.ERROR_CLOTURE_COLLECTE : AuditValue.ERROR_ABANDON_COLLECTE).setCodeError(ex.getMessage()).setIdCollect(collectId)
					.setJourneyCode(collect.getJourneyCode());
			collectEventHandler.sendAuditEvent(auditEvent);
			throw ex;
		}

		// end
		collectRepository.endCollect(collect);

		final AuditEvent auditEvent = auditGenerator.newAudit(context, CollectStatus.CL.name().equals(status) ? AuditValue.CLOTURE_COLLECTE : AuditValue.ABANDON_COLLECTE).setIdCollect(collectId).setJourneyCode(collect.getJourneyCode());
		collectEventHandler.sendAuditEvent(auditEvent);
		sendEvent(collect, context.getCanal(), context.getMedia(), context.getCustomerId());
		return alerts;
	}

	private void sendEvent(Collect collect, String channel, String media, String employeeId) {
		final UpdatedCollect updatedCollect = new UpdatedCollect();
		updatedCollect.setCollect(collect);
		updatedCollect.setChannel(channel);
		updatedCollect.setMedia(media);
		updatedCollect.setEmployeeId(employeeId);
		if (CollectStatus.CL.name().equals(collect.getStatus())) {
			updatedCollect.setNomenclatureRef(NomenclatureRefEvent.EVENT_CLOTURE_COLLECT.getCode());
		} else if (CollectStatus.AB.name().equals(collect.getStatus())) {
			updatedCollect.setNomenclatureRef(NomenclatureRefEvent.EVENT_ABANDON_COLLECT.getCode());
		}
		collectEventHandler.sendUpdatedCollectEvent(updatedCollect);
	}

	@Override
	public void updateCollect(Collect updatedCollect, UUID collectId, Context context) {
		final Collect collect = collectRepository.findOne(collectId);
		handleClosingOrAbandonCollect(updatedCollect, collectId, context, collect);
		handleOwners(updatedCollect, collectId, context, collect);
		collectRepository.updateCollect(collect);
	}

	private void handleOwners(Collect updatedCollect, UUID collectId, Context context, final Collect collect) {
		AuditEvent auditEvent;
		try {
			// add a new owner
			final Set<Owner> ownersUpdatedCollect = Optional.ofNullable(updatedCollect).map(Collect::getOwners).orElse(new HashSet<Owner>());
			final Set<Owner> existingOwnersCollect = Optional.ofNullable(collect).map(Collect::getOwners).orElse(new HashSet<Owner>());
			final HashSet<Owner> addedOwners = new HashSet<>(ownersUpdatedCollect);
			addedOwners.removeAll(existingOwnersCollect);
			final Set<String> ownersRef = addedOwners.stream().map(Owner::getReference).collect(Collectors.toSet());
			final boolean wellFormatedAddedOwners = addedOwners.stream().allMatch(ownerL -> StringUtils.isNotEmpty(ownerL.getReference()) && ownerL.getReference().length() == 17 && StringUtils.isNotEmpty(ownerL.getFirstname())
					&& StringUtils.isNotEmpty(ownerL.getName()) && Arrays.asList(1, 2).contains(ownerL.getNature()));

			if (CollectionUtils.isNotEmpty(addedOwners) && wellFormatedAddedOwners) {
				collect.getOwners().addAll(updatedCollect.getOwners());
				auditEvent = auditGenerator.newAudit(context, AuditValue.COLLECT_ADD_OWNER, ownersRef.toString()).setIdCollect(collectId).setJourneyCode(Optional.ofNullable(collect.getJourneyCode()).orElse(""));
				collectEventHandler.sendAuditEvent(auditEvent);
			} else {
				auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_COLLECT_ADD_OWNER, ownersRef.toString(), "").setIdCollect(collectId).setJourneyCode(Optional.ofNullable(collect.getJourneyCode()).orElse(""));
				collectEventHandler.sendAuditEvent(auditEvent);
			}
		} catch (final CollectBusinessException ex) {
			auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_COLLECT_ADD_OWNER, "", ex.getMessage()).setIdCollect(collectId).setJourneyCode(Optional.ofNullable(collect.getJourneyCode()).orElse(""));
			collectEventHandler.sendAuditEvent(auditEvent);
			throw ex;
		}
	}

	private void handleClosingOrAbandonCollect(Collect updatedCollect, UUID collectId, Context context, final Collect collect) {
		AuditEvent auditEvent;
		if (Arrays.asList(CollectStatus.CL.name(), CollectStatus.AB.name()).contains(updatedCollect.getStatus())) {
			try {
				if (CollectStatus.CL.name().equals(updatedCollect.getStatus())) {
					final Map<UUID, Set<Type>> typesByFamily = collect.getTypes().stream().collect(Collectors.groupingBy(Type::getFamilyId, LinkedHashMap::new, Collectors.toSet()));
					typesByFamily.forEach((k, typeSet) -> {
						final Type family = collect.getTypes().stream().filter(t -> t.getFamilyId().equals(k)).findFirst().get();
						if (Arrays.asList(FamilyCategory.OB.name(), FamilyCategory.IN.name(), FamilyCategory.DF.name()).contains(family.getFamilyCategory())) {
							customValidator.validateFamily(collectId, family.getFamilyPropertyType(), typeSet);

						}
						;
					});
				}
				collect.setStatus(updatedCollect.getStatus());
				collect.setEndDate(Instant.now());
				auditEvent = auditGenerator.newAudit(context, CollectStatus.CL.name().equals(updatedCollect.getStatus()) ? AuditValue.CLOTURE_COLLECTE : AuditValue.ABANDON_COLLECTE).setIdCollect(collectId).setJourneyCode(collect.getJourneyCode());
				collectEventHandler.sendAuditEvent(auditEvent);
				sendEvent(collect, context.getCanal(), context.getMedia(), context.getCustomerId());
			} catch (final CollectBusinessException ex) {
				auditEvent = auditGenerator.newAudit(context, CollectStatus.CL.name().equals(updatedCollect.getStatus()) ? AuditValue.ERROR_CLOTURE_COLLECTE : AuditValue.ERROR_ABANDON_COLLECTE).setCodeError(ex.getMessage()).setIdCollect(collectId)
						.setJourneyCode(collect.getJourneyCode());
				collectEventHandler.sendAuditEvent(auditEvent);
				throw ex;
			}
		}
	}

	@Override
	public Collect getOnlyCollectById(UUID id) {
		return collectRepository.findOnlyCollect(id);
	}

	public DocReferenceRepository getDocReferenceRepository() {
		return docReferenceRepository;
	}

	public void setDocReferenceRepository(DocReferenceRepository docReferenceRepository) {
		this.docReferenceRepository = docReferenceRepository;
	}

	public EdocTypeRepository getEdocTypeRepository() {
		return edocTypeRepository;
	}

	public void setEdocTypeRepository(EdocTypeRepository edocTypeRepository) {
		this.edocTypeRepository = edocTypeRepository;
	}

	public String getAuthorizedFormat() {
		return authorizedFormat;
	}

	public void setAuthorizedFormat(String authorizedFormat) {
		this.authorizedFormat = authorizedFormat;
	}

	public NomenclatureService getNomenclatureService() {
		return nomenclatureService;
	}

	public void setNomenclatureService(NomenclatureService nomenclatureService) {
		this.nomenclatureService = nomenclatureService;
	}

	public FeatureManager getFeatureManager() {
		return featureManager;
	}

	public void setFeatureManager(FeatureManager featureManager) {
		this.featureManager = featureManager;
	}

}
