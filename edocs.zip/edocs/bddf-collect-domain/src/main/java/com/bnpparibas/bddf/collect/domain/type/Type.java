package com.bnpparibas.bddf.collect.domain.type;

import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Entity
public class Type implements Comparable<Type> {

	private UUID id;
	private UUID familyId;
	private Set<String> familyOwners;
	private String familyLabel;
	private String familyCategory;
	private String familyCategoryComment;
	private String familyPropertyType;
	private String familyIconCode;
	private String familyAdditionalInformation;
	private String familyAdditionalInformationCollab;
	private boolean familyBlocked;
	private UUID parentId;
	private String label;
	private boolean displayToClient;
	private String additionalInformation;
	private String additionalInformationCollab;
	private boolean digitalAllowed;
	private boolean paperAllowed;
	private String controlDocumentType;
	private int controlRequired;
	private long maxSizeDoc;
	private Instant controlDate;
	private boolean pendingDocument;
	private String pendingDocumentLabel;
	private Set<Piece> pieces;
	private String edocType;
	private String status;
	private boolean enableReuse;
	private Set<String> completeness;
	private Set<Indexe> indexes;
	// Families managment act declared in family
	private Set<String> familiesManagementActFamily;
	private Set<String> piecesManagementActFamily;
	private String statusControl;
	private String completenessControl;
	private String completenessControlLabel;
	private int familyPosition;
	private int position;
	private boolean sentGDN;
	private String videoCodingDelay;
	private String pendingDocumentProfile;
	private boolean groupIndexesValidation;
	private boolean autoRecognition;
	private boolean displayCommentToClient;

	public Type() {

	}

	public Type(UUID id, UUID parentId, UUID familyId, Set<String> familyOwners, String familyLabel, String familyCategory, String familyCategoryComment, String familyPropertyType, String familyIconCode, String familyAdditionalInformation, String label,
			String additionalInformation, boolean digitalAllowed, String documentType, long maxSizeDoc, int controlRequired, Instant controlDate, boolean pendingDocument, String pendingDocumentLabel, boolean paperAllowed, String pendingDocumentProfile,
			boolean groupIndexesValidation, boolean displayCommentToClient, String additionalInformationCollab, String familyAdditionalInformationCollab, boolean displayToClient) {
		super();
		this.id = id;
		this.parentId = parentId;
		this.familyId = familyId;
		this.familyOwners = familyOwners;
		this.familyLabel = familyLabel;
		this.familyCategory = familyCategory;
		this.familyCategoryComment = familyCategoryComment;
		this.familyPropertyType = familyPropertyType;
		this.familyIconCode = familyIconCode;
		this.familyAdditionalInformation = familyAdditionalInformation;
		this.label = label;
		this.displayToClient = displayToClient;
		this.additionalInformation = additionalInformation;
		this.digitalAllowed = digitalAllowed;
		this.paperAllowed = paperAllowed;
		this.controlDocumentType = documentType;
		this.maxSizeDoc = maxSizeDoc;
		this.controlRequired = controlRequired;
		this.controlDate = controlDate;
		this.pendingDocument = pendingDocument;
		this.pendingDocumentLabel = pendingDocumentLabel;
		this.pendingDocumentProfile = pendingDocumentProfile;
		this.groupIndexesValidation = groupIndexesValidation;
		this.additionalInformationCollab = additionalInformationCollab;
		this.familyAdditionalInformationCollab = familyAdditionalInformationCollab;
		this.displayCommentToClient = displayCommentToClient;

	}

	public Type(UUID id, UUID parentId, UUID familyId, Set<String> familyOwners, String familyLabel, String familyCategory, String familyCategoryComment, String familyPropertyType, String familyIconCode, String familyAdditionalInformation, String label,
			String additionalInformation, boolean digitalAllowed, String documentType, long maxSizeDoc, int controlRequired, Instant controlDate, boolean pendingDocument, String pendingDocumentLabel, String status, boolean paperAllowed,
			String statusControl, String pendingDocumentProfile, boolean groupIndexesValidation, boolean displayCommentToClient, String additionalInformationCollab, String familyAdditionalInformationCollab) {
		super();
		this.id = id;
		this.parentId = parentId;
		this.familyId = familyId;
		this.familyOwners = familyOwners;
		this.familyLabel = familyLabel;
		this.familyCategory = familyCategory;
		this.familyCategoryComment = familyCategoryComment;
		this.familyPropertyType = familyPropertyType;
		this.familyIconCode = familyIconCode;
		this.familyAdditionalInformation = familyAdditionalInformation;
		this.label = label;
		this.additionalInformation = additionalInformation;
		this.digitalAllowed = digitalAllowed;
		this.controlDocumentType = documentType;
		this.maxSizeDoc = maxSizeDoc;
		this.controlRequired = controlRequired;
		this.controlDate = controlDate;
		this.pendingDocument = pendingDocument;
		this.pendingDocumentLabel = pendingDocumentLabel;
		this.status = status;
		this.statusControl = statusControl;
		this.paperAllowed = paperAllowed;
		this.pendingDocumentProfile = pendingDocumentProfile;
		this.groupIndexesValidation = groupIndexesValidation;
		this.additionalInformationCollab = additionalInformationCollab;
		this.familyAdditionalInformationCollab = familyAdditionalInformationCollab;
		this.displayCommentToClient = displayCommentToClient;
	}

	public String getEdocType() {
		return edocType;
	}

	public boolean isEdocType() {
		return StringUtils.isNotEmpty(getEdocType());
	}

	public void setEdocType(String edocType) {
		this.edocType = edocType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isEnableReuse() {
		return enableReuse;
	}

	public void setEnableReuse(boolean enableReuse) {
		this.enableReuse = enableReuse;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public UUID getFamilyId() {
		return familyId;
	}

	public void setFamilyId(UUID familyId) {
		this.familyId = familyId;
	}

	public Set<String> getCompleteness() {
		if (completeness == null) {
			completeness = new HashSet<>();
		}
		return completeness;
	}

	public void setCompleteness(Set<String> completeness) {
		if (completeness == null) {
			completeness = new HashSet<>();
		}
		this.completeness = completeness;
	}

	public Set<String> getFamilyOwners() {
		return familyOwners;
	}

	public void setFamilyOwners(Set<String> familyOwners) {
		if (familyOwners == null) {
			familyOwners = new HashSet<>();
		}
		this.familyOwners = familyOwners;
	}

	public String getFamilyLabel() {
		return familyLabel;
	}

	public void setFamilyLabel(String familyLabel) {
		this.familyLabel = familyLabel;
	}

	public String getFamilyCategory() {
		return familyCategory;
	}

	public void setFamilyCategory(String familyCategory) {
		this.familyCategory = familyCategory;
	}

	public String getFamilyCategoryComment() {
		return familyCategoryComment;
	}

	public void setFamilyCategoryComment(String familyCategoryComment) {
		this.familyCategoryComment = familyCategoryComment;
	}

	public String getFamilyPropertyType() {
		return familyPropertyType;
	}

	public void setFamilyPropertyType(String familyPropertyType) {
		this.familyPropertyType = familyPropertyType;
	}

	public String getFamilyIconCode() {
		return familyIconCode;
	}

	public void setFamilyIconCode(String familyIconCode) {
		this.familyIconCode = familyIconCode;
	}

	public String getFamilyAdditionalInformation() {
		return familyAdditionalInformation;
	}

	public void setFamilyAdditionalInformation(String familyAdditionalInformation) {
		this.familyAdditionalInformation = familyAdditionalInformation;
	}

	public boolean isFamilyBlocked() {
		return familyBlocked;
	}

	public void setFamilyBlocked(boolean familyBlocked) {
		this.familyBlocked = familyBlocked;
	}

	public UUID getParentId() {
		return parentId;
	}

	public void setParentId(UUID parentId) {
		this.parentId = parentId;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public boolean isDigitalAllowed() {
		return digitalAllowed;
	}

	public void setDigitalAllowed(boolean digitalAllowed) {
		this.digitalAllowed = digitalAllowed;
	}

	public String getControlDocumentType() {
		return controlDocumentType;
	}

	public void setControlDocumentType(String controlDocumentType) {
		this.controlDocumentType = controlDocumentType;
	}

	public int getControlRequired() {
		return controlRequired;
	}

	public void setControlRequired(int controlRequired) {
		this.controlRequired = controlRequired;
	}

	public long getMaxSizeDoc() {
		return maxSizeDoc;
	}

	public void setMaxSizeDoc(long maxSizeDoc) {
		this.maxSizeDoc = maxSizeDoc;
	}

	public Instant getControlDate() {
		return controlDate;
	}

	public void setControlDate(Instant controlDate) {
		this.controlDate = controlDate;
	}

	public boolean isPendingDocument() {
		return pendingDocument;
	}

	public void setPendingDocument(boolean pendingDocument) {
		this.pendingDocument = pendingDocument;
	}

	public String getPendingDocumentLabel() {
		return pendingDocumentLabel;
	}

	public void setPendingDocumentLabel(String pendingDocumentLabel) {
		this.pendingDocumentLabel = pendingDocumentLabel;
	}

	public Set<Piece> getPieces() {
		if (pieces == null) {
			pieces = new HashSet<>();
		}
		return pieces;
	}

	public Set<Piece> getActivePieces() {
		if (pieces == null) {
			pieces = new HashSet<>();
		}
		return pieces.stream().filter(p -> !PieceStates.INACTIF.getLabel().equals(p.getState())).collect(Collectors.toSet());
	}

	public void setPieces(Set<Piece> pieces) {
		this.pieces = pieces;
	}

	public Set<Indexe> getIndexes() {
		if (indexes == null) {
			indexes = new HashSet<>();
		}
		return indexes;
	}

	public void setIndexes(Set<Indexe> indexes) {
		this.indexes = indexes;
	}

	public Set<String> getFamiliesManagementActFamily() {
		return familiesManagementActFamily;
	}

	public void setFamiliesManagementActFamily(Set<String> familiesManagementActFamily) {
		this.familiesManagementActFamily = familiesManagementActFamily;
	}

	public String getStatusControl() {
		return statusControl;
	}

	public void setStatusControl(String statusControl) {
		this.statusControl = statusControl;
	}

	public String getCompletenessControl() {
		return completenessControl;
	}

	public void setCompletenessControl(String completenessControl) {
		this.completenessControl = completenessControl;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || (getClass() != obj.getClass())) {
			return false;
		}

		return equalsPart2(obj);
	}

	private boolean equalsPart2(Object obj) {
		final Type other = (Type) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	public int getFamilyPosition() {
		return familyPosition;
	}

	public void setFamilyPosition(int familyPosition) {
		this.familyPosition = familyPosition;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public Set<String> getPiecesManagementActFamily() {
		return piecesManagementActFamily;
	}

	public void setPiecesManagementActFamily(Set<String> piecesManagementActFamily) {
		this.piecesManagementActFamily = piecesManagementActFamily;
	}

	public String getCompletenessControlLabel() {
		return completenessControlLabel;
	}

	public void setCompletenessControlLabel(String completenessControlLabel) {
		this.completenessControlLabel = completenessControlLabel;
	}

	public boolean isSentGDN() {
		return sentGDN;
	}

	public void setSentGDN(boolean sentGDN) {
		this.sentGDN = sentGDN;
	}

	public String getVideoCodingDelay() {
		return videoCodingDelay;
	}

	public void setVideoCodingDelay(String videoCodingDelay) {
		this.videoCodingDelay = videoCodingDelay;
	}

	public boolean isPaperAllowed() {
		return paperAllowed;
	}

	public void setPaperAllowed(boolean paperAllowed) {
		this.paperAllowed = paperAllowed;
	}

	public String getPendingDocumentProfile() {
		return pendingDocumentProfile;
	}

	public void setPendingDocumentProfile(String pendingDocumentProfile) {
		this.pendingDocumentProfile = pendingDocumentProfile;
	}

	public boolean isGroupIndexesValidation() {
		return groupIndexesValidation;
	}

	public void setGroupIndexesValidation(boolean groupIndexesValidation) {
		this.groupIndexesValidation = groupIndexesValidation;
	}

	public String getAdditionalInformationCollab() {
		return additionalInformationCollab;
	}

	public void setAdditionalInformationCollab(String additionalInformationCollab) {
		this.additionalInformationCollab = additionalInformationCollab;
	}

	public String getFamilyAdditionalInformationCollab() {
		return familyAdditionalInformationCollab;
	}

	public void setFamilyAdditionalInformationCollab(String familyAdditionalInformationCollab) {
		this.familyAdditionalInformationCollab = familyAdditionalInformationCollab;
	}
	
	public boolean isDisplayCommentToClient() {
		return displayCommentToClient;
	}

	public void setDisplayCommentToClient(boolean displayCommentToClient) {
		this.displayCommentToClient = displayCommentToClient;
	}

	public boolean isDisplayToClient() {
		return displayToClient;
	}

	public void setDisplayToClient(boolean displayToClient) {
		this.displayToClient = displayToClient;
	}

	public void setMaxPosition(List<Type> types) {
		if (position == 0) {
			if (CollectionUtils.isNotEmpty(types)) {
				position = types.stream().map(Type::getPosition).collect(Collectors.summarizingInt(Integer::intValue)).getMax() + 1;
			} else {
				position = 1;
			}
		}
	}
	
	@Override
	public int compareTo(Type type) {
		if (StringUtils.isNotEmpty(edocType) && StringUtils.isNotEmpty(type.getEdocType())) {
			return this.edocType.compareTo(type.getEdocType());
		}
		return 0;
	}

	

}
