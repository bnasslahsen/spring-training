package com.bnpparibas.bddf.collect.domain.type;

public enum IndexInjection {
	OB("OB"), FA("FA"), ND("ND");

	private String code;

	IndexInjection(String code) {
		this.code = code;

	}

	public String getCode() {
		return code;
	}

}
