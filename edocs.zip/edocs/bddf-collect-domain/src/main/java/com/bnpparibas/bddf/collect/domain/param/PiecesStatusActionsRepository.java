package com.bnpparibas.bddf.collect.domain.param;

public interface PiecesStatusActionsRepository {

	boolean isNewPieceStatusAuthorizedForPutType(String actualStatus, String newStatus, String channel);

	boolean isNewPieceStatusAuthorizedForPutPieces(String actualStatus, String newStatus, String channel);

	boolean isDeleteAuthorizedForPutType(String actualStatus, String channel);

	boolean isDeleteAuthorizedForPutPieces(String actualStatus, String channel);

}
