package com.bnpparibas.bddf.collect.domain.type;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.togglz.core.manager.FeatureManager;

import com.bnp.schema.edoc.index.Indexes.EdocIndex;
import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditEvent;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditEventService;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.audit.event.LadRadFeature;
import com.bnpparibas.bddf.collect.domain.audit.event.NomenclatureRefEvent;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.FamiliesManagmentAct;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.event.collect.UpdatedCollect;
import com.bnpparibas.bddf.collect.domain.event.type.TypeReceived;
import com.bnpparibas.bddf.collect.domain.event.type.TypeReceivedType;
import com.bnpparibas.bddf.collect.domain.helper.ConverterHelper;
import com.bnpparibas.bddf.collect.domain.helper.StringHelper;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceIndicators;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.TypeControls;
import com.bnpparibas.bddf.collect.domain.nomenclature.Nomenclature;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.owner.ClientNotification;
import com.bnpparibas.bddf.collect.domain.owner.ClientNotificationService;
import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.param.GdnParamRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnService;
import com.bnpparibas.bddf.collect.domain.piece.PieceRecivedFormat;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.piece.PieceValidator;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReference;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceRepository;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.piece.validation.ValidationPieceRepository;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;

/**
 *
 * Cette classe présente l'implémentation des Web Service Rest des ressources Type et Famille
 *
 */

@Service
@Transactional(transactionManager = "transactionManagerDB", rollbackFor = Exception.class)
public class TypeServiceImpl implements TypeService {

	private CollectRepository collectRepository;
	private TypeRepository typeRepository;
	private final FamilyRepository familyRepository;
	private CollectValidator customValidator;
	private AuditGenerator auditGenerator;
	private CollectEventHandler collectEventHandler;

	@Autowired
	private PieceGdnService pieceGdnService;

	@Autowired
	private FeatureManager featureManager;
	@Autowired
	private Environment environment;

	@Autowired
	private EdocTypeRepository edocTypeRepository;
	@Autowired
	private EdocIndexRepository edocIndexRepository;
	@Autowired
	private DocReferenceRepository docReferenceRepository;
	@Autowired
	private DocReferenceService docReferenceService;
	@Autowired
	private TypeValidator typeValidator;
	@Autowired
	private PieceValidator pieceValidator;
	@Autowired
	private GdnParamRepository gdnParamRepository;
	@Autowired
	private NomenclatureService nomenclatureService;
	@Autowired
	private final TypeAutomaticControlService typeAutomaticControlService;
	@Autowired
	private AuditEventService auditEventService;
	@Autowired
	private ValidationPieceRepository validationPieceRepository;
	@Autowired
	ClientNotificationService clientNotificationService;

	public TypeServiceImpl(CollectRepository collectRepository, TypeRepository typeRepository, CollectValidator customValidator, CollectEventHandler collectEventHandler, AuditGenerator auditGenerator, DocReferenceService docReferenceService,
			TypeAutomaticControlService typeAutomaticControlService, FamilyRepository familyRepository) {
		this.collectRepository = collectRepository;
		this.collectEventHandler = collectEventHandler;
		this.typeRepository = typeRepository;
		this.customValidator = customValidator;
		this.auditGenerator = auditGenerator;
		this.typeAutomaticControlService = typeAutomaticControlService;
		this.docReferenceService = docReferenceService;
		this.familyRepository = familyRepository;
	}

	@Override
	public Type getType(UUID collectId, UUID typeId) {
		return Optional.ofNullable(typeRepository.findOne(collectId, typeId)).orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_NOT_FOUND, typeId.toString(), collectId.toString(), typeId.toString())));
	}

	@Override
	public void checkStatusControlInProgress(Type type) {
		if (Arrays.asList(TypeControls.EC.name(), TypeControls.EC_AMI.name()).contains(type.getStatusControl())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_LADRAD_EC));
		}
	}

	@Override
	@Transactional
	public void addType(UUID collectId, UUID familyId, List<Type> types, Context context) throws InterruptedException {
		final Collect collect = collectRepository.findOne(collectId);
		final Type mainType = types.stream().filter(t -> t.getParentId() == null).findAny().orElse(new Type());
		try {
			final Optional<Type> optFamily = collect.getTypes().stream().filter(currentType -> familyId.equals(currentType.getFamilyId())).findAny();
			final Type family = optFamily.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_FAMILY_NOT_FOUND, collectId.toString(), familyId.toString())));
			customValidator.familyBlocked(family);

			types.forEach(type -> {
				validateAddType(type, collect, new HashSet<>(types));
				// Récupération des pièces de référence
				if (isReuseDocsAuthorized(types, family.getFamilyCategory())) {
					final List<DocReference> refs = docReferenceRepository.getByOwnersAndType(StringHelper.reduceSet(family.getFamilyOwners()), type.getEdocType());
					type.setPieces(refs.stream().map(ConverterHelper::buildPieceDFFromReferencePiece).collect(Collectors.toSet()));
				}
				if (type.isDigitalAllowed()) {
					type.setMaxSizeDoc(edocTypeRepository.byValue(type.getEdocType()).getMaxSize());
				}
				typeValidator.cleanIndexIfNoControlJmc(type);
			});
			collect.getTypes().addAll(types);
			calculateTypePositions(collect.getTypes());

			typeRepository.addTypes(collectId, types);
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ADD_TYPE, mainType.getLabel())
					// Collecte
					.setIdCollect(collect.getId()).setJourneyCode(collect.getJourneyCode()).setControlRequired(mainType.getControlRequired())
					// Type
					.setIdType(mainType.getId()).setEdocType(mainType.getEdocType()).setTypeLabel(Optional.ofNullable(mainType.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(mainType.getLabel()));
			collectEventHandler.sendAuditEvent(auditEvent);

			sendAudit(mainType, mainType, context, collect);
		} catch (final CollectBusinessException ex) {
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_ADD_TYPE, mainType.getLabel()).setCodeError(ex.getMessage())
					// Collect
					.setIdCollect(collectId).setJourneyCode(collect.getJourneyCode())
					// type
					.setIdFamily(familyId).setEdocType(mainType.getEdocType()).setTypeLabel(mainType.getLabel());
			collectEventHandler.sendAuditEvent(auditEvent);
			throw ex;
		}
	}

	private void calculateTypePositions(final Set<Type> types) {
		final Set<Type> parentTypes = types.stream().filter(type -> type.getFamilyId() != null && type.getParentId() == null).sorted().collect(Collectors.toSet());
		typeValidator.calculateTypePositions(parentTypes);
		types.stream().filter(type -> type.getFamilyId() != null && type.getParentId() != null).collect(Collectors.groupingBy(Type::getParentId)).forEach((parentId, subTypes) -> typeValidator.calculateTypePositions(subTypes));
	}

	private void validateAddType(Type type, final Collect collect, Set<Type> types) {
		final List<EdocType> edocTypes = edocTypeRepository.findAll();
		final List<EdocIndex> edocIndexes = edocIndexRepository.findAll();
		final List<Nomenclature> nomenclatures = nomenclatureService.findAll();
		final boolean sendToLadRadEnabled = Optional.ofNullable(LadRadFeature.fromLabel(collect.getJourneyCode())).map(featureManager::isActive).orElse(false);

		typeValidator.validateType(type, edocTypes, collect, sendToLadRadEnabled);
		typeValidator.validateTypeIndex(type, edocTypes, edocIndexes, nomenclatures, types);
	}

	@Override
	@Transactional
	public void updateType(UUID collectId, UUID typeId, Type updatedType, Context context) throws InterruptedException {
		final Collect collect = collectRepository.findOne(collectId);
		final Optional<Type> optType = collect.getTypes().stream().filter(t -> typeId.equals(t.getId())).findAny();
		try {
			final Type type = optType.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_NOT_FOUND, typeId.toString(), collectId.toString(), typeId.toString()))); // RG//
			customValidator.familyBlocked(type);
			checkStatusControlInProgress(type);
			final boolean isEventForcedRecognitionSent = auditEventService.sendAuditEventForcedRecognition(collectId, context, collect.getJourneyCode(), updatedType, type);
			if (TypeControls.CT.name().equals(updatedType.getStatusControl())) {
				typeValidator.validateTypeWithPiecesErrorGDN(type);
				typeValidator.initIndexStatusControl(updatedType);
				typeAutomaticControlService.controlSecondIteration(collect, type, updatedType, context);
			} else {
				typeValidator.validateUpdatedType(updatedType, type);
				updatedType.getActivePieces().forEach(piece -> pieceValidator.validatePieceFieldsSize(piece));
				final boolean withRefusedPieces = updatedType.getActivePieces().stream().filter(updatedPiece -> PieceStatus.RF.getLabel().equals(updatedPiece.getStatus()))
						.anyMatch(updatedPiece -> type.getActivePieces().stream().anyMatch(existingPiece -> !PieceStatus.RF.getLabel().equals(existingPiece.getStatus()) && updatedPiece.equals(existingPiece)));
				final Set<Piece> piecesToRemove = handleUpdatePieces(collect, typeId, updatedType, context, type);
				final List<Piece> piecesToBeSendToGDN = initialiseUpdateType(collectId, updatedType, context.getCustomerId(), collect, type);

				final DocReferenceVO soumissionDocReferenceVO = handleDocReference(context, collect, type);
				typeAutomaticControlService.updateIndexesOnDeletePieces(collect, type, piecesToRemove, context, true);
				if (!isEventForcedRecognitionSent) {
					sendAudit(updatedType, type, context, collect);
				}
				if (piecesToBeSendToGDN.isEmpty()) {
					typeRepository.updateType(collectId, type);
					sendTypeControlledEvent(collect, context, type, piecesToRemove.stream().filter(this::eventPieceDeleted).collect(Collectors.toSet()), type.getPieces());
				} else {
					// Appel GDN des pièces DF pour les enregistrer dans la collecte, puis envoi evenement et mise à jour éventuel des documents de références
					piecesToBeSendToGDN.forEach(p -> pieceGdnService.updateTypeOnGdn(collect, type, p, piecesToRemove.stream().filter(this::eventPieceDeleted).collect(Collectors.toSet()), context, updatedType.getStatus(),
							soumissionDocReferenceVO.getUserId(), soumissionDocReferenceVO.getChannel(), soumissionDocReferenceVO.getAqcuisitionDate()));
				}
				notifyClient(type.getId(), collect.getId(), collect.isNotifyOwners(), withRefusedPieces, type.isPendingDocument());
			}
		} catch (final CollectBusinessException ex) {
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_UPDATE_TYPE, optType.map(Type::getLabel).orElse("")).setCodeError(ex.getMessage())
					// Collect
					.setIdCollect(collectId).setJourneyCode(collect.getJourneyCode())
					// type
					.setIdType(typeId).setEdocType(optType.map(Type::getEdocType).orElse(null)).setTypeLabel(optType.map(Type::getEdocType).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(optType.map(Type::getLabel).orElse(null)));
			collectEventHandler.sendAuditEvent(auditEvent);
			throw ex;
		}
	}

	private void notifyClient(UUID typeId, UUID collectId, boolean notifyOwners, boolean withRefusedPieces, boolean pendingDocument) {
		if (notifyOwners && (pendingDocument || withRefusedPieces)) {
			final int notifiesInProgress = clientNotificationService.count(typeId);
			if (notifiesInProgress == 0) {
				clientNotificationService.save(new ClientNotification(typeId, collectId, Timestamp.from(Instant.now())));
			}
		}
	}

	private DocReferenceVO handleDocReference(Context context, final Collect collect, final Type type) {
		final DocReferenceVO soumissionDocReferenceVO = new DocReferenceVO();
		initialiseDocReferenceVO(context, soumissionDocReferenceVO);
		// Mise à jour asynchrone de toutes les pièces pour les types validés directement (sans appel gdn (DP->VA))
		docReferenceService.saveDocReference(collect.getId(), collect.getJourneyCode(), type, soumissionDocReferenceVO.getUserId(), soumissionDocReferenceVO.getChannel(), soumissionDocReferenceVO.getAqcuisitionDate(), context,
				collect.getSendingApplicationCode());
		return soumissionDocReferenceVO;
	}

	private void initialiseDocReferenceVO(Context context, final DocReferenceVO soumissionDocReferenceVO) {
		soumissionDocReferenceVO.setChannel(context.getCanal());
		soumissionDocReferenceVO.setUserId(context.getCustomerId());
		soumissionDocReferenceVO.setAqcuisitionDate(Instant.now());
	}

	private List<Piece> initialiseUpdateType(UUID collectId, Type updatedType, String userId, final Collect collect, final Type type) {
		initPendingDocument(updatedType, type);
		final List<Piece> piecesToSendToGDN = type.getActivePieces().stream().filter(p -> Arrays.asList(PieceStatus.VA_EC.getLabel(), PieceStatus.RC_EC.getLabel()).contains(p.getStatus())).collect(Collectors.toList());
		if (StringUtils.isNotEmpty(updatedType.getStatus())) {
			type.setStatus(updatedType.getStatus());
		} else {
			type.setStatus(TypeStatus.IN.getLabel());
			updatedType.setStatus(TypeStatus.IN.getLabel());
		}
		handleDevalidation(updatedType, type);
		type.setControlDate(Instant.now());
		typeValidatedDeleteOtherPieces(collectId, userId, collect, type);
		typeRepository.updateType(collectId, type);
		return piecesToSendToGDN;
	}

	private void initPendingDocument(Type updatedType, final Type type) {
		type.setPendingDocument(updatedType.isPendingDocument());
		type.setPendingDocumentLabel(updatedType.getPendingDocumentLabel());
		type.setDisplayCommentToClient(updatedType.isDisplayCommentToClient());

		if (!type.isPendingDocument()) {
			type.setPendingDocumentLabel(null);
			type.setPendingDocumentProfile(null);
		} else if (StringUtils.isNotEmpty(type.getPendingDocumentLabel())) {
			initPendingDocumentProfile(updatedType, type);
		}
	}

	private void typeValidatedDeleteOtherPieces(UUID collectId, String userId, final Collect collect, final Type type) {
		// If FamilyPropertyType is LISTE, delete pieces of other family's types
		if (Arrays.asList(TypeStatus.VA.getLabel(), TypeStatus.VA_AUTO.getLabel(), TypeStatus.RC.getLabel(), TypeStatus.RC_AUTO.getLabel()).contains(type.getStatus()) && PropertyType.LISTE.getLabel().equals(type.getFamilyPropertyType())) {
			collect.getTypes().stream().filter(t -> !t.equals(type) && t.getFamilyId().equals(type.getFamilyId()) && !t.getActivePieces().isEmpty() && (type.getParentId() == null || !type.getParentId().equals(t.getParentId())))
					.peek(t -> t.getActivePieces().forEach(p -> deletePiece(userId, p, t))).forEach(t -> typeRepository.updateType(collectId, t));
		}
	}

	private void handleDevalidation(Type updatedType, Type type) {
		if (typeValidator.isDevalidationBO(updatedType) && TypeStatus.IN.getLabel().equals(updatedType.getStatus())) {
			type.getActivePieces().stream().filter(piece -> piece.isControlled() && updatedType.getActivePieces().stream().anyMatch(updatedPiece -> updatedPiece.equals(piece) && !updatedPiece.isControlled()))
					.forEach(piece -> validationPieceRepository.deleteByID(piece.getId()));
		}

	}

	private void initPendingDocumentProfile(Type updatedType, Type existingType) {
		if (StringUtils.isEmpty(updatedType.getPendingDocumentProfile())) {
			existingType.setPendingDocumentProfile(Profile.BO.getLabel());
		} else {
			existingType.setPendingDocumentProfile(updatedType.getPendingDocumentProfile());
		}

	}

	private Set<Piece> handleUpdatePieces(Collect collect, UUID typeId, Type updatedType, Context context, final Type type) {
		final UUID collectId = collect.getId();
		final Set<Piece> piecesToRemove = new HashSet<>();
		piecesToRemove.addAll(type.getActivePieces());
		piecesToRemove.removeAll(updatedType.getActivePieces());
		piecesToRemove.forEach(p -> pieceValidator.validatePieceSupprPutType(p, context.getCanal()));

		updatedType.getActivePieces().stream()
				// Map with repository piece
				.map(piece -> buildPair(collectId, typeId, piece, type.getActivePieces()))
				// Validate new status
				.peek(pair -> pieceValidator.validatePutTypeStatus(pair.getRight(), pair.getLeft().getStatus(), context.getCanal()))
				// Validate rejection
				.peek(pair -> validateRejection(pair.getLeft()))
				// Save pieces
				.forEach(pair -> performUpdatePiece(context.getCustomerId(), pair));

		piecesToRemove.forEach(p -> deletePiece(context.getCustomerId(), p, type));
		return piecesToRemove;
	}

	private boolean isPieceReference(Piece piece) {
		return PieceStatus.DF.getLabel().equals(piece.getStatus()) || (StringUtils.isEmpty(piece.getIdDocGdn()) && StringUtils.isNotEmpty(piece.getReferencePieceId()));
	}

	private void performUpdatePiece(String userId, Pair<Piece, Piece> pair) {
		final Piece piece = pair.getLeft();
		final Piece pieceRepo = pair.getRight();

		// Filter piece with changed status
		if (!piece.getStatus().equals(pieceRepo.getStatus())) {
			if (isPieceReference(pieceRepo)) {
				if (PieceStatus.VA.getLabel().equals(piece.getStatus())) {
					pieceRepo.setStatus(PieceStatus.VA_EC.getLabel());
				} else if (PieceStatus.RC.getLabel().equals(piece.getStatus())) {
					pieceRepo.setStatus(PieceStatus.RC_EC.getLabel());
				} else {
					pieceRepo.setStatus(piece.getStatus());
				}
			} else {
				pieceRepo.setStatus(piece.getStatus());
			}
			pieceRepo.setEmployeeId(userId);
			pieceRepo.setUpdateDate(Instant.now());
		}

		handleRefuse(userId, piece, pieceRepo);
		handleForcedPiece(userId, piece, pieceRepo);
	}

	private void handleForcedPiece(String userId, final Piece piece, final Piece pieceRepo) {
		if (!StringUtils.equals(piece.getStatusControl(), pieceRepo.getStatusControl()) && StringUtils.equals(PieceIndicators.OK_MAN.name(), piece.getTypeControl())) {
			pieceRepo.setTypeControl(piece.getTypeControl());
			pieceRepo.setEmployeeId(userId);
			pieceRepo.setUpdateDate(Instant.now());
		}
	}

	private void handleRefuse(String userId, final Piece piece, final Piece pieceRepo) {
		if (PieceStatus.RF.getLabel().equals(piece.getStatus()) && (!StringUtils.equals(piece.getRejectionComment(), pieceRepo.getRejectionComment()) || !StringUtils.equals(piece.getRejectionReason(), pieceRepo.getRejectionReason()) || piece.isDisplayCommentToClient() != pieceRepo.isDisplayCommentToClient())) {
			pieceRepo.setRejectionComment(piece.getRejectionComment());
			pieceRepo.setRejectionReason(piece.getRejectionReason());
			pieceRepo.setEmployeeId(userId);
			pieceRepo.setUpdateDate(Instant.now());
			pieceRepo.setDisplayCommentToClient(piece.isDisplayCommentToClient());
			initPieceRejectionProfile(piece, pieceRepo);
		} else if (!PieceStatus.RF.getLabel().equals(piece.getStatus())) {
			pieceRepo.setRejectionComment(null);
			pieceRepo.setRejectionReason(null);
			pieceRepo.setRejectionProfile(null);
		}
	}

	private void initPieceRejectionProfile(Piece updatedPiece, Piece existingPiece) {

		if (StringUtils.isEmpty(updatedPiece.getRejectionProfile())) {
			existingPiece.setRejectionProfile(Profile.BO.getLabel());
		} else {
			existingPiece.setRejectionProfile(updatedPiece.getRejectionProfile());
		}

	}

	private void sendAudit(Type updatedType, Type type, Context context, Collect collect) {
		final Set<String> status = updatedType.getActivePieces().stream().map(Piece::getStatus).collect(Collectors.toSet());
		final String receivedFormat = Optional.ofNullable(updatedType.getActivePieces()).map(p -> p.stream().findAny().orElse(null)).map(Piece::getReceivedFormat).orElse(StringUtils.EMPTY);
		final Integer maxIeration = type.getActivePieces().stream().mapToInt(Piece::getControlIterationAchieved).max().orElse(0);
		AuditValue auditValue = null;
		int nbrPieces = 0;
		String[] params;
		if (updatedType.isPendingDocument()) {
			auditValue = AuditValue.UPDATE_TYPE_INCOMPLET;
			params = new String[] { type.getLabel() };
		} else if (status != null && status.contains(PieceStatus.RF.getLabel())) {
			auditValue = AuditValue.REJECTION_TYPE;
			params = new String[] { type.getLabel(), receivedFormat, String.valueOf(updatedType.getActivePieces().stream().filter(p -> PieceStatus.RF.getLabel().equals(p.getStatus())).count()) };
			nbrPieces = (int) updatedType.getActivePieces().stream().filter(p -> PieceStatus.RF.getLabel().equals(p.getStatus())).count();
		} else {
			if (!updatedType.isPendingDocument() && TypeStatus.VA.name().equals(updatedType.getStatus())) {
				auditValue = AuditValue.VALIDATE_TYPE;
			} else if (!updatedType.isPendingDocument() && TypeStatus.RC.name().equals(updatedType.getStatus())) {
				auditValue = AuditValue.ACCEPT_TYPE;
			}
			params = new String[] { type.getLabel(), receivedFormat, String.valueOf(updatedType.getActivePieces().size()) };
			nbrPieces = updatedType.getActivePieces().size();
		}
		if (auditValue != null) {
			final AuditEvent auditEvent = auditGenerator.newAudit(context, auditValue, params)
					// Collecte
					.setIdCollect(collect.getId()).setJourneyCode(collect.getJourneyCode()).setControlRequired(type.getControlRequired()).setIterationLadRad(maxIeration)
					//

					// Type
					.setIdType(type.getId()).setEdocType(type.getEdocType()).setTypeLabel(Optional.ofNullable(type.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(type.getLabel()));
			if (nbrPieces != 0) {
				auditEvent.setTotalPieces(nbrPieces);

			}
			collectEventHandler.sendAuditEvent(auditEvent);
		}
	}

	@Override
	public void updateFamilies(UUID collectId, Map<UUID, Type> families, Context context) {
		final Collect collectRepo = collectRepository.findOne(collectId);

		try {
			final Set<UUID> familiesRepoIds = collectRepo.getTypes().stream().map(Type::getFamilyId).collect(Collectors.toSet());
			customValidator.validateUpdateFamilies(familiesRepoIds, families, collectId, collectRepo.getFamiliesManagementAct());
			final Set<Type> updatedTypes = collectRepo.getTypes().stream()

					.filter(t -> !t.getFamilyCategory().equals(families.get(t.getFamilyId()).getFamilyCategory()))

					.collect(Collectors.toSet());

			if (CollectionUtils.isNotEmpty(updatedTypes)) {
				customValidator.familyBlocked(updatedTypes.iterator().next());
			}
			// Récupère les pièces DF
			updatedTypes.stream().collect(Collectors.groupingBy(t -> StringHelper.reduceSet(t.getFamilyOwners(), '|'))).forEach((owners, types) -> populateTypesOfAFamily(types, families, context, owners, collectRepo));
			// Réinitialise les statuts des types
			updatedTypes.forEach(t -> t.setStatus(TypeStatus.IN.getLabel()));
			if (CollectionUtils.isNotEmpty(updatedTypes)) {
				familyRepository.update(collectRepo, updatedTypes);
			}
			if (!updatedTypes.isEmpty()) {
				sendEventUpdatedCollect(context, collectRepo, updatedTypes);
			}
			auditUpdateType(collectId, context, collectRepo, updatedTypes);

		} catch (final CollectBusinessException ex) {
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_UPDATE_FAMILY, getFamilyLabel(ex, collectRepo)).setCodeError(ex.getMessage())
					// Collecte
					.setIdFamily(collectId).setJourneyCode(collectRepo.getJourneyCode())
					// Family
					.setIdFamily(Arrays.stream(ex.getParams()).filter(s -> families.keySet().stream().map(Object::toString).anyMatch(param -> param.equals(s))).findAny().map(UUID::fromString).orElse(null));
			collectEventHandler.sendAuditEvent(auditEvent);
			throw ex;
		}
	}

	private void auditUpdateType(UUID collectId, Context context, final Collect collectRepo, final Set<Type> updatedTypes) {
		updatedTypes.stream().filter(distinctByKey(Type::getFamilyId)).forEach(t -> {
			final AuditEvent audit = auditGenerator.newAudit(context, AuditValue.UPDATE_FAMILY, t.getFamilyLabel(), t.getFamilyCategory())
					// Collecte
					.setIdCollect(collectId).setJourneyCode(collectRepo.getJourneyCode())
					// Family
					.setIdFamily(t.getFamilyId());

			collectEventHandler.sendAuditEvent(audit);
		});
	}

	private void sendEventUpdatedCollect(Context context, final Collect collectRepo, final Set<Type> updatedTypes) {
		collectRepo.setTypes(updatedTypes);
		final UpdatedCollect updatedCollect = new UpdatedCollect();
		updatedCollect.setChannel(context.getCanal());
		updatedCollect.setMedia(context.getMedia());
		updatedCollect.setEmployeeId(context.getCustomerId());
		updatedCollect.setCollect(collectRepo);
		updatedCollect.setNomenclatureRef(NomenclatureRefEvent.EVENT_UPDATE_COLLECT.getCode());
		updatedCollect.setFamiliesIds(updatedTypes.stream().map(Type::getFamilyId).distinct().collect(Collectors.toSet()));
		collectEventHandler.sendUpdatedCollectEvent(updatedCollect);
	}

	private String getFamilyLabel(CollectBusinessException ex, Collect collectRepo) {
		String label = "";
		if (CollectErrorConstants.ERR_COL_DELETE_FAMILY_UNAUTHORIZED.equals(ex.getMessage())) {
			label = collectRepo.getTypes().stream().filter(t -> t.getFamilyId().equals(UUID.fromString(ex.getParams()[0]))).findAny().map(Type::getFamilyLabel).orElse("");
		} else if (CollectErrorConstants.ERR_COL_FAMILY_NOT_FOUND.equals(ex.getMessage())) {
			label = collectRepo.getTypes().stream().filter(t -> t.getFamilyId().equals(UUID.fromString(ex.getParams()[1]))).findAny().map(Type::getFamilyLabel).orElse("");
		} else if (CollectErrorConstants.ERR_COL_FAMILY_CATEGORY_COMMENT.equals(ex.getMessage())) {
			label = ex.getParams()[1];
		} else if (CollectErrorConstants.ERR_COL_FAMILY_CATEGORY.equals(ex.getMessage())) {
			label = collectRepo.getTypes().stream().filter(t -> t.getFamilyId().equals(UUID.fromString(ex.getParams()[2]))).findAny().map(Type::getFamilyLabel).orElse("");
		}
		return label;
	}

	private void populateTypesOfAFamily(List<Type> types, Map<UUID, Type> families, Context context, String owners, Collect collect) {
		final String oldCat = types.get(0).getFamilyCategory();
		final String newCat = families.get(types.get(0).getFamilyId()).getFamilyCategory();
		if (types.get(0).isEdocType()) {
			final List<UUID> parentTypes = types.stream().map(Type::getParentId).collect(Collectors.toList());
			final List<Type> reuseTypes = types.stream().filter(Type::isEnableReuse).filter(t -> t.getParentId() == null && !parentTypes.contains(t.getId())).collect(Collectors.toList());
			if (FamiliesManagmentAct.OB.name().equals(newCat) && Arrays.asList(FamiliesManagmentAct.DR.name(), FamiliesManagmentAct.ND.name()).contains(oldCat) && !reuseTypes.isEmpty()) {
				final List<DocReference> refs = docReferenceRepository.getByOwnersAndTypes(owners, reuseTypes.stream().map(Type::getEdocType).collect(Collectors.toList()));
				reuseTypes.forEach(t -> t.setPieces(refs.stream().filter(r -> r.getEdocType().equals(t.getEdocType())).map(ConverterHelper::buildPieceDFFromReferencePiece).collect(Collectors.toSet())));
			}
		}
		types.forEach(type -> {
			type.setFamilyCategory(families.get(type.getFamilyId()).getFamilyCategory());
			type.setFamilyCategoryComment(families.get(type.getFamilyId()).getFamilyCategoryComment());
			if (Arrays.asList(FamiliesManagmentAct.DR.name(), FamiliesManagmentAct.ND.name()).contains(type.getFamilyCategory())) {

				// suppression des pieces
				type.getActivePieces().forEach(piece -> deletePiece(context.getCustomerId(), piece, type));
				// set null des champs controDate, pendingDocument, pendingDocumentLabel
				type.setPendingDocument(false);
				type.setControlDate(null);
				type.setPendingDocumentLabel(null);
				typeAutomaticControlService.updateIndexesOnDeletePieces(collect, type, type.getPieces(), context, true);
			}
		});
	}

	private void validateRejection(Piece p) {
		if (PieceStatus.RF.getLabel().equals(p.getStatus())) {
			if (StringUtils.isEmpty(p.getRejectionReason())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_REJECT_REASON, p.getLabel())); // RG 47
			} else if ("Autre".equals(p.getRejectionReason()) && StringUtils.isEmpty(p.getRejectionComment())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_REJECT_COMMENT, p.getLabel())); // RG 49
			}
		}
	}

	private boolean eventPieceDeleted(Piece p) {
		return StringUtils.isNotEmpty(p.getIdDocGdn()) || PieceRecivedFormat.PAP.name().equals(p.getReceivedFormat());
	}

	private void sendTypeControlledEvent(Collect collect, Context context, Type type, Set<Piece> piecesToRemoveList, Set<Piece> savedPieces) {
		final TypeReceived typeReceived = new TypeReceived();

		final Set<Piece> piecesToSend = savedPieces.stream().filter(p -> StringUtils.isNotEmpty(p.getIdDocGdn()) || PieceRecivedFormat.PAP.name().equals(p.getReceivedFormat())).collect(Collectors.toSet());

		piecesToSend.addAll(piecesToRemoveList);
		typeReceived.setPieces(piecesToSend);
		typeReceived.setChannel(context.getCanal());
		typeReceived.setMedia(context.getMedia());
		typeReceived.setUserId(context.getCustomerId());

		if (Optional.ofNullable(type.getParentId()).isPresent()) {
			typeReceived.setSubType(type);
			typeReceived.setType(collect.getTypes().stream().filter(t -> type.getParentId().equals(t.getId())).findAny().orElse(null));
		} else {
			typeReceived.setType(type);
		}
		typeReceived.setCollect(collect);
		typeReceived.setTypeReceivedType(TypeReceivedType.CONTROLLED);

		collectEventHandler.sendTypeReceivedEvent(typeReceived);
	}

	private void deletePiece(String userId, Piece piece, Type type) {
		piece.setState(PieceStates.INACTIF.getLabel());
		piece.setUpdateDate(Instant.now());
		piece.setEmployeeId(userId);

		type.getIndexes().stream().forEach(index -> {
			if (index.getIndexesJmc().stream().allMatch(indexJMC -> indexJMC.getIdPiece().equals(piece.getId()))) {
				index.initControls();
				index.getIndexesJmc().clear();
			} else if (index.getIndexesJmc().stream().anyMatch(indexJMC -> indexJMC.getIdPiece().equals(piece.getId()))) {
				index.getIndexesJmc().removeIf(indexJmc -> indexJmc.getIdPiece().equals(piece.getId()));
			}
		});

	}

	private Pair<Piece, Piece> buildPair(UUID collectId, UUID typeId, Piece piece, Set<Piece> existingPieces) {
		return Pair.of(piece, existingPieces.stream().filter(p -> p.equals(piece)).findAny()
				.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_NOT_FOUND, piece.getId().toString(), collectId.toString(), typeId.toString(), piece.getId().toString()))));
	}

	public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
		final Map<Object, Boolean> seen = new ConcurrentHashMap<>();
		return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
	}

	@Override
	public void addFamily(UUID collectId, Set<Type> familyTypes, Context context) throws InterruptedException {
		final Collect collect = collectRepository.findOne(collectId);

		try {
			final List<EdocType> edocTypes = edocTypeRepository.findAll();
			final List<EdocIndex> edocIndexes = edocIndexRepository.findAll();
			final List<Nomenclature> nomenclatures = nomenclatureService.findAll();
			customValidator.validateFamily(collect, new ArrayList<>(familyTypes));
			final boolean sendToLadRadEnabled = Optional.ofNullable(LadRadFeature.fromLabel(collect.getJourneyCode())).map(featureManager::isActive).orElse(false);
			familyTypes.forEach(t -> typeValidator.validateType(t, edocTypes, collect, sendToLadRadEnabled));
			familyTypes.forEach(type -> typeValidator.validateTypeIndex(type, edocTypes, edocIndexes, nomenclatures, familyTypes));
			familyTypes.forEach(type -> typeValidator.cleanIndexIfNoControlJmc(type));
			familyTypes.stream().filter(Type::isDigitalAllowed).forEach(t -> t.setMaxSizeDoc(edocTypeRepository.byValue(t.getEdocType()).getMaxSize()));
			calculateTypePositions(familyTypes);
			collect.getTypes().addAll(familyTypes);
			typeValidator.calculateFamilyPositions(collect.getTypes());
			// Récupère les pièces DF
			final List<Type> reuseTypes = extractReuseTypes(familyTypes);
			if (reuseTypes != null && !reuseTypes.isEmpty()) {
				final List<DocReference> refs = docReferenceRepository.getByOwnersAndTypes(StringHelper.reduceSet(reuseTypes.get(0).getFamilyOwners()), reuseTypes.stream().map(Type::getEdocType).collect(Collectors.toList()));
				reuseTypes.forEach(t -> t.setPieces(refs.stream().filter(r -> r.getEdocType().equals(t.getEdocType())).map(ConverterHelper::buildPieceDFFromReferencePiece).collect(Collectors.toSet())));
			}

			familyTypes.forEach(t -> t.setStatus(TypeStatus.IN.getLabel()));
			familyRepository.add(collect, new ArrayList<>(familyTypes));
			familyTypes.stream().filter(distinctByKey(Type::getFamilyId)).forEach(t -> {
				final AuditEvent audit = auditGenerator.newAudit(context, AuditValue.ADD_FAMILY, t.getFamilyLabel())
						// Collecte
						.setIdCollect(collectId).setJourneyCode(collect.getJourneyCode())
						// Family
						.setIdFamily(t.getFamilyId());

				collectEventHandler.sendAuditEvent(audit);
			});

		} catch (final CollectBusinessException ex) {
			final String familyLabel = StringUtils.isNotEmpty(getFamilyLabel(ex, collect)) ? getFamilyLabel(ex, collect) : familyTypes.stream().map(Type::getFamilyLabel).findFirst().orElse("<none>");
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_ADD_FAMILY, familyLabel).setCodeError(ex.getMessage())
					// Collecte
					.setIdCollect(collectId).setJourneyCode(collect.getJourneyCode())
					// Family
					.setIdFamily(Arrays.stream(ex.getParams()).filter(s -> familyTypes.stream().map(Object::toString).anyMatch(param -> param.equals(s))).findAny().map(UUID::fromString).orElse(null));
			collectEventHandler.sendAuditEvent(auditEvent);
			throw ex;
		}

	}

	@Override
	public void deleteFamily(UUID collectId, UUID familyId, Context context) {

		final Collect collect = collectRepository.findOne(collectId);
		final AtomicInteger nbPieces = new AtomicInteger(0);
		String familyLabel = null;
		try {

			final Set<Type> types = collect.getTypes();
			customValidator.validateFamilyExistance(familyId, collect.getTypes(), collectId);
			types.stream().filter(type -> type.getFamilyId().equals(familyId)).forEach(type -> checkStatusControlInProgress(type));
			types.stream().filter(type -> type.getFamilyId().equals(familyId)).findFirst().ifPresent(family -> customValidator.familyBlocked(family)); 
			familyLabel = types.stream().filter(type -> type.getFamilyId().equals(familyId)).findAny().map(Type::getFamilyLabel).orElse("<unknown>");
			types.forEach(t -> {

				if (t.getFamilyId().equals(familyId)) {
					// suppression des pieces
					t.getActivePieces().forEach(piece -> nbPieces.incrementAndGet());
				}
			});
			familyRepository.delete(familyId);

			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.DELETE_FAMILY, familyLabel).setIdCollect(collectId).setJourneyCode(collect.getJourneyCode()).setIdFamily(familyId);
			collectEventHandler.sendAuditEvent(auditEvent);
		} catch (final CollectBusinessException ex) {
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_DELETE_FAMILY, familyLabel).setCodeError(ex.getMessage()).setIdCollect(collectId).setJourneyCode(collect.getJourneyCode()).setIdFamily(familyId);
			collectEventHandler.sendAuditEvent(auditEvent);
			throw ex;
		}

	}

	private List<Type> extractReuseTypes(Set<Type> familyTypes) {
		return familyTypes.stream().filter(
				t -> t.getParentId() == null && familyTypes.stream().noneMatch(tt -> t.getId().equals(tt.getParentId())) && t.isEnableReuse() && Arrays.asList(FamiliesManagmentAct.OB.name(), FamiliesManagmentAct.FA.name()).contains(t.getFamilyCategory()))
				.collect(Collectors.toList());
	}

	private boolean isReuseDocsAuthorized(List<Type> types, String familyCategory) {
		return Arrays.asList(FamiliesManagmentAct.OB.name(), FamiliesManagmentAct.FA.name()).contains(familyCategory) && types.stream().allMatch(type -> type.getParentId() == null && type.isEnableReuse());
	}

	@Override
	public boolean deleteType(UUID idCollect, UUID idType, Context context) {
		final Collect collect = Optional.ofNullable(collectRepository.findOne(idCollect)).orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_NOT_FOUND, idCollect.toString())));
		final Type type = collect.getTypes().stream().filter(t -> t.getParentId() == null).filter(t -> t.getId().equals(idType)).findAny()
				.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_NOT_FOUND, idType.toString(), idCollect.toString(), idType.toString())));
		try {
			typeValidator.validateTypeDelete(collect, type);
			checkStatusControlInProgress(type);
			customValidator.familyBlocked(type);
			typeRepository.delete(type);
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.DELETE_TYPE, Optional.ofNullable(type).map(Type::getLabel).orElse("")).setIdCollect(idCollect).setJourneyCode(collect.getJourneyCode()).setIdFamily(type.getFamilyId());
			collectEventHandler.sendAuditEvent(auditEvent);
			return true;
		} catch (final CollectBusinessException ex) {
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_DELETE_TYPE, Optional.ofNullable(type).map(Type::getLabel).orElse("")).setCodeError(ex.getMessage()).setIdCollect(idCollect)
					.setJourneyCode(collect.getJourneyCode()).setIdFamily(type.getFamilyId());
			collectEventHandler.sendAuditEvent(auditEvent);
			throw ex;
		}
	}

	public FeatureManager getFeatureManager() {
		return featureManager;
	}

	public void setFeatureManager(FeatureManager featureManager) {
		this.featureManager = featureManager;
	}

	public DocReferenceRepository getDocReferenceRepository() {
		return docReferenceRepository;
	}

	public void setDocReferenceRepository(DocReferenceRepository docReferenceRepository) {
		this.docReferenceRepository = docReferenceRepository;
	}

	public TypeValidator getTypeValidator() {
		return typeValidator;
	}

	public void setTypeValidator(TypeValidator typeValidator) {
		this.typeValidator = typeValidator;
	}

	public GdnParamRepository getGdnParamRepository() {
		return gdnParamRepository;
	}

	public void setGdnParamRepository(GdnParamRepository gdnParamRepository) {
		this.gdnParamRepository = gdnParamRepository;
	}

	public CollectRepository getCollectRepository() {
		return collectRepository;
	}

	public void setCollectRepository(CollectRepository collectRepository) {
		this.collectRepository = collectRepository;
	}

	public TypeRepository getTypeRepository() {
		return typeRepository;
	}

	public void setTypeRepository(TypeRepository typeRepository) {
		this.typeRepository = typeRepository;
	}

	public CollectValidator getCustomValidator() {
		return customValidator;
	}

	public void setCustomValidator(CollectValidator customValidator) {
		this.customValidator = customValidator;
	}

	public AuditGenerator getAuditGenerator() {
		return auditGenerator;
	}

	public void setAuditGenerator(AuditGenerator auditGenerator) {
		this.auditGenerator = auditGenerator;
	}

	public CollectEventHandler getCollectEventHandler() {
		return collectEventHandler;
	}

	public void setCollectEventHandler(CollectEventHandler collectEventHandler) {
		this.collectEventHandler = collectEventHandler;
	}

	public PieceGdnService getPieceGdnService() {
		return pieceGdnService;
	}

	public void setPieceGdnService(PieceGdnService pieceGdnService) {
		this.pieceGdnService = pieceGdnService;
	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

	public DocReferenceService getDocReferenceService() {
		return docReferenceService;
	}

	public void setDocReferenceService(DocReferenceService docReferenceService) {
		this.docReferenceService = docReferenceService;
	}

	public EdocIndexRepository getEdocIndexRepository() {
		return edocIndexRepository;
	}

	public void setEdocIndexRepository(EdocIndexRepository edocIndexRepository) {
		this.edocIndexRepository = edocIndexRepository;
	}

	public NomenclatureService getNomenclatureService() {
		return nomenclatureService;
	}

	public void setNomenclatureService(NomenclatureService nomenclatureService) {
		this.nomenclatureService = nomenclatureService;
	}

	public PieceValidator getPieceValidator() {
		return pieceValidator;
	}

	public void setPieceValidator(PieceValidator pieceValidator) {
		this.pieceValidator = pieceValidator;
	}

	public AuditEventService getAuditEventService() {
		return auditEventService;
	}

	public void setAuditEventService(AuditEventService auditEventService) {
		this.auditEventService = auditEventService;
	}

	public EdocTypeRepository getEdocTypeRepository() {
		return edocTypeRepository;
	}

	public void setEdocTypeRepository(EdocTypeRepository edocTypeRepository) {
		this.edocTypeRepository = edocTypeRepository;
	}

	public ValidationPieceRepository getValidationPieceRepository() {
		return validationPieceRepository;
	}

	public void setValidationPieceRepository(ValidationPieceRepository validationPieceRepository) {
		this.validationPieceRepository = validationPieceRepository;
	}

}
