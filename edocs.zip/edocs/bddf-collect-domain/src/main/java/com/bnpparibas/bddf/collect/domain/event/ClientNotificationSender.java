package com.bnpparibas.bddf.collect.domain.event;

import java.util.List;

import com.bnpparibas.bddf.collect.domain.notification.NotificationDIGICOMMessage;
import com.bnpparibas.bddf.collect.domain.notification.NotificationMessage;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Repository
public interface ClientNotificationSender {


	public void sendNotificationDIGICOM(List<NotificationDIGICOMMessage> notificationDIGICOMmessages, String collectId);

	void sendNotification(List<NotificationMessage> notificationMessages, String collectId);

}
