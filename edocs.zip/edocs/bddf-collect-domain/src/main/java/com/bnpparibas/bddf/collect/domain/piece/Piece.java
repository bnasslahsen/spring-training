package com.bnpparibas.bddf.collect.domain.piece;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;

import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Entity
public class Piece implements Comparable<Piece> {

	private UUID id;
	private String label;
	private String ownerId;
	private String employeeId;
	private String channel;
	private Instant acquisitionDate;
	private Instant updateDate;
	private long size;
	private String receivedFormat;
	private String status;
	private String idDocGdn;
	private String rejectionReason;
	private String rejectionComment;
	private String state;
	private String contentType;
	private String referencePieceId;
	private String referenceGdnId;
	private String statusControl;
	private List<String> typesJmc;
	private String typeControl;
	private String extractionControl;
	private String coherenceControl;
	private int controlIterationAchieved;
	private int deletedNas;
	private int position;
	private String rejectionProfile;
	private String statusSentToGdn;
	private boolean displayCommentToClient;

	public Piece() {

	}

	public Piece(UUID id, String label, String ownerId, String employeeId, String channel, Instant acquisitionDate, long size, String receivedFormat, String status, String idDocGdn, String rejectionReason, String rejectionComment, String typeControl,
			String rejectionProfile, boolean displayCommentToClient) {
		super();
		this.id = id;
		this.label = label;
		this.ownerId = ownerId;
		this.employeeId = employeeId;
		this.channel = channel;
		this.acquisitionDate = acquisitionDate;
		this.size = size;
		this.receivedFormat = receivedFormat;
		this.status = status;
		this.idDocGdn = idDocGdn;
		this.rejectionReason = rejectionReason;
		this.rejectionComment = rejectionComment;
		this.rejectionProfile = rejectionProfile;
		this.state = "ACTIF";
		this.typeControl = typeControl;
		this.displayCommentToClient = displayCommentToClient;
	}

	public String getReferencePieceId() {
		return referencePieceId;
	}

	public void setReferencePieceId(String referencePieceId) {
		this.referencePieceId = referencePieceId;
	}

	public String getReferenceGdnId() {
		return referenceGdnId;
	}

	public void setReferenceGdnId(String referenceGdnId) {
		this.referenceGdnId = referenceGdnId;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public Instant getAcquisitionDate() {
		return acquisitionDate;
	}

	public void setAcquisitionDate(Instant acquisitionDate) {
		this.acquisitionDate = acquisitionDate;
	}

	public Instant getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Instant updateDate) {
		this.updateDate = updateDate;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public String getReceivedFormat() {
		return receivedFormat;
	}

	public void setReceivedFormat(String receivedFormat) {
		this.receivedFormat = receivedFormat;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getIdDocGdn() {
		return idDocGdn;
	}

	public void setIdDocGdn(String idDocGdn) {
		this.idDocGdn = idDocGdn;
	}

	public String getRejectionReason() {
		return rejectionReason;
	}

	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}

	public String getRejectionComment() {
		return rejectionComment;
	}

	public void setRejectionComment(String rejectionComment) {
		this.rejectionComment = rejectionComment;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || (getClass() != obj.getClass())) {
			return false;
		}

		return equalsPart2(obj);
	}

	private boolean equalsPart2(Object obj) {
		final Piece other = (Piece) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		final int numberChar = 186;
		final StringBuilder builder = new StringBuilder(numberChar);
		builder.append("Piece [id=");
		builder.append(id);
		builder.append(", label=");
		builder.append(label);
		builder.append(", ownerId=");
		builder.append(ownerId);
		builder.append(", employeeId=");
		builder.append(employeeId);
		builder.append(", channel=");
		builder.append(channel);
		builder.append(", acquisitionDate=");
		builder.append(acquisitionDate);
		builder.append(", updateDate=");
		builder.append(updateDate);
		builder.append(", size=");
		builder.append(size);
		builder.append(", receivedFormat=");
		builder.append(receivedFormat);
		builder.append(", status=");
		builder.append(status);
		builder.append(", idDocGdn=");
		builder.append(idDocGdn);
		builder.append(", rejectionReason=");
		builder.append(rejectionReason);
		builder.append(", rejectionComment=");
		builder.append(rejectionComment);
		builder.append(", state=");
		builder.append(state);
		builder.append(", contentType=");
		builder.append(contentType);
		builder.append("]");
		return builder.toString();
	}

	public void ecToOk() {
		if (PieceStatus.VA_EC.getLabel().equals(status)) {
			status = PieceStatus.VA.getLabel();
		} else if (PieceStatus.RC_EC.getLabel().equals(status)) {
			status = PieceStatus.RC.getLabel();
		} else if (PieceStatus.DP_EC.getLabel().equals(status)) {
			status = PieceStatus.DP.getLabel();
		}
	}

	public void ecToKo() {
		if (PieceStatus.VA_EC.getLabel().equals(status)) {
			status = PieceStatus.VA_ERR.getLabel();
		} else if (PieceStatus.RC_EC.getLabel().equals(status)) {
			status = PieceStatus.RC_ERR.getLabel();
		} else if (PieceStatus.DP_EC.getLabel().equals(status)) {
			status = PieceStatus.DP_ERR.getLabel();
		}

	}

	public boolean isStatusEC() {
		return PieceStatus.VA_EC.getLabel().equals(status) || PieceStatus.RC_EC.getLabel().equals(status) || PieceStatus.DP_EC.getLabel().equals(status);
	}

	public boolean isControlled() {
		return Arrays.asList(PieceStatus.VA.getLabel(), PieceStatus.VA_EC.getLabel(), PieceStatus.VA_ERR.getLabel(), PieceStatus.RC.getLabel(), PieceStatus.RC_EC.getLabel(), PieceStatus.RC_ERR.getLabel()).contains(status);
	}

	public String getStatusControl() {
		return statusControl;
	}

	public void setStatusControl(String statusControl) {
		this.statusControl = statusControl;
	}

	public String getTypeControl() {
		return typeControl;
	}

	public void setTypeControl(String typeControl) {
		this.typeControl = typeControl;
	}

	public String getExtractionControl() {
		return extractionControl;
	}

	public void setExtractionControl(String extractionControl) {
		this.extractionControl = extractionControl;
	}

	public String getCoherenceControl() {
		return coherenceControl;
	}

	public void setCoherenceControl(String coherenceControl) {
		this.coherenceControl = coherenceControl;
	}

	public List<String> getTypesJmc() {
		if (typesJmc == null) {
			typesJmc = new ArrayList<>();
		}
		return typesJmc;
	}

	public void setTypesJmc(List<String> typesJmc) {
		this.typesJmc = typesJmc;
	}

	public int getControlIterationAchieved() {
		return controlIterationAchieved;
	}

	public void setControlIterationAchieved(int controlIterationAchieved) {
		this.controlIterationAchieved = controlIterationAchieved;
	}

	public int isDeletedNas() {
		return deletedNas;
	}

	public void setDeletedNas(int deletedNas) {
		this.deletedNas = deletedNas;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public void setMaxPosition(Type type) {
		if (position == 0) {
			if (type != null && CollectionUtils.isNotEmpty(type.getPieces())) {
				position = type.getPieces().stream().map(Piece::getPosition).collect(Collectors.summarizingInt(Integer::intValue)).getMax() + 1;
			} else {
				position = 1;
			}
		}
	}

	public String getRejectionProfile() {
		return rejectionProfile;
	}

	public void setRejectionProfile(String rejectionProfile) {
		this.rejectionProfile = rejectionProfile;
	}

	public String getStatusSentToGdn() {
		return statusSentToGdn;
	}

	public void setStatusSentToGdn(String statusSentToGdn) {
		this.statusSentToGdn = statusSentToGdn;
	}

	public boolean isDisplayCommentToClient() {
		return displayCommentToClient;
	}

	public void setDisplayCommentToClient(boolean displayCommentToClient) {
		this.displayCommentToClient = displayCommentToClient;
	}

	@Override
	public int compareTo(Piece piece) {
		if (id != null && piece.getId() != null) {
			return this.id.compareTo(piece.getId());
		}
		return 0;
	}

}
