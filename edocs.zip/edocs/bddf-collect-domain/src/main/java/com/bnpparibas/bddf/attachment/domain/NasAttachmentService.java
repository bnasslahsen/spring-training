package com.bnpparibas.bddf.attachment.domain;

import java.nio.ByteBuffer;
import java.util.UUID;

public interface NasAttachmentService {

	/**
	 * Add a file in the NAS
	 *
	 * @param idAttachment
	 * @param contentType
	 * @param file
	 */
	void add(UUID idAttachment, String contentType, ByteBuffer file);

	/**
	 * Get file from NAS
	 * 
	 * @param idAttachment
	 * @return
	 */
	ByteBuffer get(UUID idAttachment);

	/**
	 * Delete a file from a NAS
	 *
	 * @param idAttachment
	 */
	void delete(UUID idAttachment);

}
