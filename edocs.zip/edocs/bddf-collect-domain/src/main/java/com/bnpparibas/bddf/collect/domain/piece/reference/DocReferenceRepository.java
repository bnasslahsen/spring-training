package com.bnpparibas.bddf.collect.domain.piece.reference;

import java.util.List;

import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Repository
public interface DocReferenceRepository {

	List<DocReference> getByOwnersAndTypes(String owners, List<String> edocTypes);

	void saveDocReferences(List<DocReference> docReferences, String ownerId, String edocType);

	void deleteById(List<DocReference> docReferences);

	List<DocReference> getByOwnersAndType(String owners, String edocType);

	void insertDocRef(Type type, final List<DocReference> repositoryRefs, final List<DocReference> referenceToRemove);

}
