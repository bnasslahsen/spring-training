package com.bnpparibas.bddf.collect.domain.ladrad.enums;

import java.util.Arrays;

public enum RequestWSJMCType {

	CREATE_FOLDER("D1"), GET_FOLDER("D2"), GET_STATUS_FOLDER("D3"), INJECT_REF_DATA("D5"), ANAYLYSE_FOLDER("D6"),
	//
	UPLOAD_DOCUMENT("DC1"), GET_STATUS_DOCUMENT("DC2"), GET_STATUS_PIECE("P3"), GET_PIECE("P4"), CREATE_PIECE("P6"), FORCE_TYPE_PIECE("P7"), UPDATE_PIECE("P8"), DELETE_FOLDER("D11"), DELETE_DOCUMENT("DC3"), POST_AMI("AMI");

	private final String label;

	private RequestWSJMCType(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	public static RequestWSJMCType fromLabel(String label) {
		return Arrays.asList(values()).stream().filter(t -> t.getLabel().equals(label)).findAny().orElse(null);
	}

}
