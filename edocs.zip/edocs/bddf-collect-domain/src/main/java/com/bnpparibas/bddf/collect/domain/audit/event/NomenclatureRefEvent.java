package com.bnpparibas.bddf.collect.domain.audit.event;

import java.util.Arrays;

import org.togglz.core.Feature;

public enum NomenclatureRefEvent implements Feature {

	EVENT_CLOTURE_COLLECT("000000086"), EVENT_ABANDON_COLLECT("000000087"), EVENT_UPDATE_COLLECT("000000083");
	private final String code;

	private NomenclatureRefEvent(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
	
	public static NomenclatureRefEvent fromLabel(String code) {
		return Arrays.asList(values()).stream().filter(c -> c.getCode().equals(code)).findAny().orElse(null);
	}

}
