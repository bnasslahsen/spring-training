package com.bnpparibas.bddf.collect.domain.piece.reference;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditEvent;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.helper.ListHelper;
import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.domain.helper.StringHelper;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.bnpparibas.bddf.rest.Context;

/**
 *
 * Cette classe englobe les méthodes de gestion des documents de référence
 *
 */

@Service
public class DocReferenceServiceImpl implements DocReferenceService {

	private static final Logger LOG = LoggerFactory.getLogger(DocReferenceServiceImpl.class);

	@Autowired
	private PieceGdnRepository pieceGdnRepository;
	@Autowired
	private DocReferenceRepository docReferenceRepository;
	@Autowired
	private EdocTypeRepository edocTypeRepository;
	@Autowired
	private CollectEventHandler collectEventHandler;
	@Autowired
	private AuditGenerator auditGenerator;
	@Autowired
	private PieceRepository pieceRepository;

	@Override
	@Async("saveRefTaskExecutor")
	public void saveDocReference(UUID collectId, String journeyCode, Type type, String refUserId, String refChannel, Instant refAquisitioDate, Context context, String sendingApplicationCode) {
		if (isTypeEligibleToReference(type)) {
			LoggerHelper.logForPerfTest(LOG, "Début saveDocReference pour le type " + type.getId() + " de la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
			final boolean reuseRefDoc = type.getActivePieces().stream().anyMatch(piece -> StringUtils.isNotEmpty(piece.getReferencePieceId()));
			final boolean newRefDoc = type.getActivePieces().stream().anyMatch(piece -> StringUtils.isEmpty(piece.getReferencePieceId()));
			try {
				final String ownersType = StringHelper.reduceSet(type.getFamilyOwners());

				// Liste des nouvelles pièces de référence
				final Set<Piece> referencePieces = type.getActivePieces();

				final Map<UUID, UUID> oldNewUUID = new HashMap<>();

				// Liste de référence à sauvegarder
				final List<DocReference> newRefs = referencePieces.stream().map(piece -> pieceToRef(piece, context.getCustomerId(), ownersType, type.getEdocType(), oldNewUUID, context)).collect(Collectors.toList());

				// Récupération de la liste des documents de référence existant
				final List<DocReference> repositoryRefs = docReferenceRepository.getByOwnersAndType(ownersType, type.getEdocType());

				// Suppression des documents de référence obsolètes
				final List<DocReference> referenceToRemove = repositoryRefs.stream().filter(p -> !newRefs.contains(p)).collect(Collectors.toList());
				repositoryRefs.removeIf(referenceToRemove::contains);

				// Mise à jour des documents de référence existant
				repositoryRefs.stream()
						// Filtrage doc existant
						.forEach(existingRef -> ListHelper.anyEq(newRefs, existingRef)
								// MAJ doc
								.ifPresent(newDocRef -> updateDocReference(existingRef, newDocRef.getOwnerId(), refUserId, refChannel, journeyCode, Date.from(refAquisitioDate))));
				// Ajout des nouveaux documents de référence
				newRefs.stream().filter(docRef -> !repositoryRefs.contains(docRef))
						// Ajout du journeyCode
						.peek(docRef -> updateDocReference(docRef, docRef.getOwnerId(), refUserId, refChannel, journeyCode, Date.from(refAquisitioDate)))
						// Ajout du doc
						.forEach(repositoryRefs::add);

				// Sauvegarde des documents de référence
				final String keySync = (ownersType + type.getEdocType()).intern();
				// Suite au DeadLock dans la base , on bloque la modification dans la table doc_reference au meme temps si on a le meme owner et le meme edoctype pour deux collectes différentes
				synchronized (keySync) {
					docReferenceRepository.insertDocRef(type, repositoryRefs, referenceToRemove);
				}

				// Map idPiece, gdnRef
				// Fait un appel saveDoc2 pour les pièces ne possédant pas encore de référence
				final Map<UUID, String> uidGdnReferencesMap = referencePieces.stream().collect(Collectors.toMap(Piece::getId, p -> buildRef(collectId, type.getId(), context, p, sendingApplicationCode)));

				uidGdnReferencesMap.forEach((idPiece, gdnReference) -> {
					final String idPieceCopy = Optional.ofNullable(oldNewUUID.get(idPiece)).orElse(idPiece).toString();
					repositoryRefs.stream().filter(docReference -> docReference.getReferencePieceId().equals(idPieceCopy)).forEach(docReference -> docReference.setReferenceGdnId(gdnReference));
				});

				synchronized (keySync) {
					docReferenceRepository.saveDocReferences(repositoryRefs, StringHelper.reduceSet(type.getFamilyOwners()), type.getEdocType());
					oldNewUUID.values().forEach(idPieceCopy -> {
						pieceRepository.deletePiece(idPieceCopy);
						pieceRepository.deleteThumbnail(idPieceCopy);
					});
				}

				if (newRefDoc) {
					sendAuditEvent(AuditValue.DOC_REF_CREATED, type, collectId, new Context(refUserId, refChannel), journeyCode, newRefs.size());
				}
				if (reuseRefDoc) {
					sendAuditEvent(AuditValue.REUSE_DOC_REF, type, collectId, new Context(refUserId, refChannel), journeyCode, 0);
				}
			} catch (final Exception ex) {
				if (newRefDoc) {
					sendAuditEvent(AuditValue.DOC_REF_CREATED_ERROR, type, collectId, new Context(refUserId, refChannel), journeyCode, 0);
				}
				throw ex;
			}
			LoggerHelper.logForPerfTest(LOG, "Fin saveDocReference pour le type " + type.getId() + " de la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
		}
	}

	private void sendAuditEvent(AuditValue auditValue, Type type, UUID idCollect, Context context, String journeyCode, int nbrPieces) {
		final AuditEvent auditEvent = auditGenerator.newAudit(context, auditValue, type.getLabel()).setIdCollect(idCollect).setIdType(type.getId()).setJourneyCode(journeyCode)
				//
				.setEdocType(type.getEdocType()).setTotalPieces(nbrPieces)
				//
				.setTypeLabel(Optional.ofNullable(type.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(type.getLabel()));

		collectEventHandler.sendAuditEvent(auditEvent);

	}

	private boolean isTypeEligibleToReference(Type type) {
		boolean isEligible = false;
		isEligible =
				// Type edoc
				type.isEdocType() &&
				// Type eligible reuse
						edocTypeRepository.byValue(type.getEdocType()).isReuseEligibility() &&
						// Type validé et recuillie
						(Arrays.asList(TypeStatus.VA.getLabel(), TypeStatus.VA_AUTO.getLabel(), TypeStatus.RC_AUTO.getLabel(), TypeStatus.RC.getLabel()).contains(type.getStatus())) &&
						// Pieces validées
						(type.getActivePieces().stream().map(Piece::getStatus).allMatch(status -> Arrays.asList(PieceStatus.VA.getLabel(), PieceStatus.RC.getLabel()).contains(status)))
						&& (type.getActivePieces().stream().map(Piece::getChannel).allMatch(channel -> Arrays.asList(Channel.SPIRIT.getValue(), Channel.SITE_WEB_COLLAB.getValue()).contains(channel)))
						// Type non sous-type
						&& type.getParentId() == null;
		return isEligible;
	}

	private String buildRef(UUID collectId, UUID typeId, Context context, Piece piece, String sendingApplicationCode) {
		String gdnReference = "";
		if (StringUtils.isNotEmpty(piece.getReferenceGdnId())) {
			gdnReference = piece.getReferenceGdnId();
		} else if (StringUtils.isEmpty(piece.getReferencePieceId())) {
			gdnReference = saveGdn(piece, collectId.toString(), typeId.toString(), context, sendingApplicationCode);
		}
		return gdnReference;
	}

	private void updateDocReference(DocReference existinfDocRef, String ownerId, String refUserId, String refChannel, String journeyCode, Date aquisitionDate) {
		existinfDocRef.setOwnerId(ownerId);
		existinfDocRef.setChannel(refChannel);
		existinfDocRef.getJourneyCodes().put(aquisitionDate, journeyCode);
		if (Channel.isCollab(refChannel)) {
			existinfDocRef.setUserId(refUserId);
		} else {
			existinfDocRef.setUserId(ownerId);
		}
	}

	private String saveGdn(Piece piece, String collectId, String typeId, Context context, String sendingApplicationCode) {
		final ByteBuffer pieceData = pieceGdnRepository.getPieceData(piece.getId(), context, piece.getIdDocGdn());
		final long start = System.currentTimeMillis();
		LoggerHelper.logForPerfTest(LOG, "Début de l'envoi de la piece vers GDN " + piece.getId() + " pour la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
		final String gdnReference = pieceGdnRepository.savePiece(piece, pieceData, collectId, typeId, context, sendingApplicationCode);
		final long duration = System.currentTimeMillis() - start;
		LoggerHelper.logForPerfTest(LOG, "Durée de l'envoi de la piece vers GDN " + piece.getId() + " pour la collecte " + collectId + " : " + duration + " (ms)" + " (thread id " + Thread.currentThread().getId() + ")");
		LoggerHelper.logForPerfTest(LOG, "Fin de l'envoi de la piece vers GDN " + piece.getId() + " pour la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
		return gdnReference;
	}

	private DocReference pieceToRef(Piece piece, String userId, String ownerId, String edocType, Map<UUID, UUID> oldNewUUID, Context context) {
		final DocReference docRef = new DocReference();
		docRef.setChannel(piece.getChannel());
		docRef.setContentType(piece.getContentType());
		docRef.setOwnerId(ownerId);
		docRef.setEdocType(edocType);
		docRef.setSize(piece.getSize());
		docRef.setPosition(piece.getPosition());
		docRef.setLabel(piece.getLabel());
		if (StringUtils.isNotEmpty(piece.getReferencePieceId())) {
			docRef.setReferencePieceId(piece.getReferencePieceId());
		} else {
			final UUID newUUID = copyPiece(piece, context);
			docRef.setReferencePieceId(newUUID.toString());
			oldNewUUID.put(piece.getId(), newUUID);
		}
		docRef.setUserId(userId);
		return docRef;
	}

	private UUID copyPiece(Piece piece, Context context) {
		final UUID idNewPiece = UUID.randomUUID();
		final ByteBuffer data = pieceRepository.tryGetPieceNasElseGdn(piece.getId(), context, piece);
		pieceRepository.addPieceData(idNewPiece, data, piece.getContentType(), piece.getLabel());
		return idNewPiece;
	}

}
