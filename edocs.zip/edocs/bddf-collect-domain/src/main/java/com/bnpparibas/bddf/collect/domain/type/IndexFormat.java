package com.bnpparibas.bddf.collect.domain.type;

public enum IndexFormat {
	A("Alphanumérique"), B("Booléen"), D("Date"), N("Numérique");

	private String label;

	IndexFormat(String label) {
		this.label = label;

	}

	public String getLabel() {
		return label;
	}

}
