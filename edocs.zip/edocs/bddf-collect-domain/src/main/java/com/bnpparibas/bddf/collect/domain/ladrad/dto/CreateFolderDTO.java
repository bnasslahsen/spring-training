package com.bnpparibas.bddf.collect.domain.ladrad.dto;

/**
 * Data used for create Folder in JOUVE
 *
 * @author c07128
 *
 */
public class CreateFolderDTO {

	private String externalRef;

	public String getExternalRef() {
		return externalRef;
	}

	public void setExternalRef(String externalRef) {
		this.externalRef = externalRef;
	}

}
