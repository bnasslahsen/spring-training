package com.bnpparibas.bddf.collect.domain.owner;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Repository
@Repository
@Transactional(transactionManager = "transactionManagerDB")
public class ClientNotificationServiceImpl implements ClientNotificationService {

	@Autowired
	ClientNotificationRepository clientNotificationRepository;

	@Override
	@Transactional(transactionManager = "transactionManagerDB")
	public void save(ClientNotification clientNotification) {
		clientNotificationRepository.save(clientNotification);
	}
	
	@Override
	@Transactional(transactionManager = "transactionManagerDB")
	public void delete(UUID typeId) {
		clientNotificationRepository.delete(typeId);
	}

	@Override
	@Transactional(transactionManager = "transactionManagerDB", propagation = Propagation.REQUIRES_NEW)
	public void update(ClientNotification clientNotification) {
		clientNotificationRepository.update(clientNotification);
	}

	@Override
	@Transactional(transactionManager = "transactionManagerDB")
	public int count(UUID typeId) {
		return clientNotificationRepository.count(typeId);
	}

}
