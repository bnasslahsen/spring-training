package com.bnpparibas.bddf.collect.domain.owner;

import java.util.UUID;

public interface ClientNotificationRepository {
	void save(ClientNotification clientNotification);

	void update(ClientNotification clientNotification);

	int count(UUID typeId);

	void updateNotificationNumber(String typeId, Integer notificationNumber);

	void delete(ClientNotification clientNotification);
	
	void delete(UUID collectId);

}
