package com.bnpparibas.bddf.collect.domain.piece.reference;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.google.common.collect.Lists;

public class DocReference {

	private String ownerId;
	private String edocType;

	private String referencePieceId;
	private String referenceGdnId;
	private String label;
	private String channel;
	private String userId;
	private String contentType;
	private long size;
	private int position;
	private Map<Date, String> journeyCodes;

	public DocReference() {
		super();
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getEdocType() {
		return edocType;
	}

	public void setEdocType(String edocType) {
		this.edocType = edocType;
	}

	public String getReferencePieceId() {
		return referencePieceId;
	}

	public void setReferencePieceId(String referencePieceId) {
		this.referencePieceId = referencePieceId;
	}

	public String getReferenceGdnId() {
		return referenceGdnId;
	}

	public void setReferenceGdnId(String referenceGdnId) {
		this.referenceGdnId = referenceGdnId;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public Map<Date, String> getJourneyCodes() {
		if (journeyCodes == null) {
			journeyCodes = new HashMap<>();
		}
		return journeyCodes;
	}

	public void setJourneyCodes(Map<Date, String> journeyCodes) {
		this.journeyCodes = journeyCodes;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((edocType == null) ? 0 : edocType.hashCode());
		result = prime * result + ((ownerId == null) ? 0 : ownerId.hashCode());
		result = prime * result + ((referencePieceId == null) ? 0 : referencePieceId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof DocReference)) {
			return false;
		}
		final DocReference objRef = (DocReference) obj;
		return StringUtils.equals(edocType, objRef.edocType) && StringUtils.equals(referencePieceId, objRef.referencePieceId) && StringUtils.equals(ownerId, objRef.ownerId);
	}

	public Date getLastAquisitionDate() {
		if (journeyCodes != null) {
			final List<Date> journeyDates = Lists.newArrayList(journeyCodes.keySet());
			Collections.sort(journeyDates);
			final int journeyLength = journeyDates.size();
			if (journeyLength > 0) {
				return journeyDates.get(journeyLength - 1);
			}
		}
		return new Date();
	}

	public Date getFirstAquisitionDate() {
		if (journeyCodes != null) {
			final List<Date> journeyDates = Lists.newArrayList(journeyCodes.keySet());
			Collections.sort(journeyDates);
			if (!journeyDates.isEmpty()) {
				return journeyDates.get(0);
			}
		}
		return new Date();
	}

}