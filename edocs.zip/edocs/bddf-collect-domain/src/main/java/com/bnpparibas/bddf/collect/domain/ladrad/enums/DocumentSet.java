package com.bnpparibas.bddf.collect.domain.ladrad.enums;

import java.util.Arrays;

public enum DocumentSet {

	FREE_SET("FREE_SET"),

	JMC_SET("JMC_SET"),

	MIDW_SET("MIDW_SET");

	private final String label;

	private DocumentSet(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	public static DocumentSet fromLabel(String label) {
		return Arrays.asList(values()).stream().filter(t -> t.getLabel().equals(label)).findAny().orElse(null);
	}

}
