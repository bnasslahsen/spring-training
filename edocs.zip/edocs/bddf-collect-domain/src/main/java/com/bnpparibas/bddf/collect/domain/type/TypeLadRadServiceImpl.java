package com.bnpparibas.bddf.collect.domain.type;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URI;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.bnp.schema.edoc.index.Indexes.EdocIndex;
import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnp.schema.edoc.type.Types.EdocType.PiecesEdoc;
import com.bnpparibas.bddf.collect.domain.helper.DateUtil;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.index.IndexeJmc;
import com.bnpparibas.bddf.collect.domain.ladrad.LadRadValidator;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.PageDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.PieceDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.UploadDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.DocumentSet;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceControls;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceIndicators;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.TypeControls;
import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.monitoring.jmc.MonitoringJmcRepository;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 *
 * Cette classe contient les méthodes du niveau domain des appels WS Jouve
 *
 */

@DDD.RepositoryImpl
@Repository
public class TypeLadRadServiceImpl implements TypeLadRadService {

	private static final Logger LOGGER = LoggerFactory.getLogger(TypeLadRadServiceImpl.class);
	private static final String UNKONW_TYPE_JMC = "unknown";
	private static final String LADRAD_URL_AMI_STATUS_BASE_PIECE = "ladrad.path.statusAmiBase.piece";
	private static final String LADRAD_URL_AMI_STATUS_BASE_PAGE = "ladrad.path.statusAmiBase.page";
	private static final String LADRAD_URL_AMI_STATUS_END_PIECE = "ladrad.path.statusAmiEnd.piece";
	private static final String LADRAD_URL_AMI_STATUS_END_PAGE = "ladrad.path.statusAmiEnd.page";
	private static final String AMI_AUTHENTIFICATION = "edoc";
	private static final String MAX_PAGES = "param.max-pages-ami";
	private static final Object IUP_CLIENT_CODE = "10000000000000021";

	@Autowired
	private LadRadRepository ladRadRepository;

	@Autowired
	private EdocIndexRepository edocIndexRepository;

	@Autowired
	private TypeRepository typeRepository;

	@Autowired
	private EdocTypeRepository edocTypeRepository;

	@Autowired
	private LadRadValidator ladRadValidator;

	@Autowired
	private Environment env;

	@Lazy
	@Autowired
	private TypeAutomaticControlUtils typeAutomaticControlUtils;

	@Autowired
	private MonitoringJmcRepository monitoringJmcRepository;

	@Autowired
	private PieceRepository pieceRepository;

	@Autowired
	private AmiBatchService amiBatchService;

	public TypeLadRadServiceImpl() {
	}

	public TypeLadRadServiceImpl(LadRadRepository ladRadRepository, EdocIndexRepository edocIndexRepository, TypeRepository typeRepository, EdocTypeRepository edocTypeRepository, LadRadValidator ladRadValidator) {
		this.ladRadRepository = ladRadRepository;
		this.edocIndexRepository = edocIndexRepository;
		this.typeRepository = typeRepository;
		this.edocTypeRepository = edocTypeRepository;
		this.ladRadValidator = ladRadValidator;
	}

	@Override
	public void uploadDocument(UUID collectId, String journeyCode, Type type, List<Indexe> indexesForAnOwner, String ownerIndex, Piece piece, ByteBuffer pieceData, String documentSet) {
		final String externalRefPiece = computeExternalRef(piece.getId(), ownerIndex);
		piece.setStatusControl(PieceControls.EC.name());
		pieceRepository.updateStatusControl(piece.getId(), PieceControls.EC.name());
		final String externalRef = computeExternalRef(type.getId(), ownerIndex);
		// Upload document chez JMC
		final UploadDocumentDTO uploadDocumentDTO = getUploadDocumentDTO(type, edocTypeRepository.findAll(), externalRefPiece, documentSet);
		final InputStream inputStreamDocument = new ByteArrayInputStream(pieceData.array());
		ladRadRepository.uploadDocument(externalRef, uploadDocumentDTO, inputStreamDocument, type.getId());

	}

	@Override
	public void extractValuesAndControls(UUID collectId, Type type, List<Indexe> indexesForAnOwner, String ownerIndex, Piece piece, StatusDocumentDTO statusDocument) {
		if (type.getControlRequired() == ControlRequired.CONTROL_JMC.getCode()) {
			final List<EdocType> edocTypes = edocTypeRepository.findAll();
			final String pieceId = piece.getId().toString();
			handleIndexes(type, indexesForAnOwner, piece, pieceId, statusDocument, edocTypes);
		}
	}

	private String computeExternalRef(UUID id, String ownerIndex) {
		return id.toString() + "-" + ownerIndex;
	}

	@Override
	public void updateIndexOfJmcPiece(final Type updatedType, String ownerIndex) {

		final List<Indexe> forcedIndexes = updatedType.getIndexes().stream().filter(index -> ownerIndex.equals(index.getOwnerIndex()) && StringUtils.isNotEmpty(index.getCorrectedValue()) && !IndexStatus.OK_MAN.getCode().equals(index.getStatusControl()))
				.collect(Collectors.toList());
		// Liste des Id de pièces avec des indexes corrigés
		final Set<String> forcedPiecesJmcId = updatedType.getIndexes().stream().filter(index -> ownerIndex.equals(index.getOwnerIndex()) && forcedIndexes.contains(index)).map(Indexe::getIndexesJmc).flatMap(List::stream).map(IndexeJmc::getIdPieceJmc)
				.filter(idPiece -> idPiece != null).collect(Collectors.toSet());

		forcedPiecesJmcId.forEach(idPieceJmc -> {
			// Réindexation des pièces concernées
			final String correctedIndexesJson = buildForcedIndexesJsonToInject(forcedIndexes.stream()
					.filter(index -> updatedType.getIndexes().stream().filter(index::equals).findAny().get().getIndexesJmc().stream().map(IndexeJmc::getIdPieceJmc).collect(Collectors.toList()).contains(idPieceJmc)).collect(Collectors.toList()));
			if (StringUtils.isNotEmpty(correctedIndexesJson)) {
				ladRadRepository.updatePiece(correctedIndexesJson, idPieceJmc, updatedType.getId());
			}
		});
	}

	@Override
	public void createAndForceJmcPiece(Type updatedType, String ownerIndex) {
		if (updatedType.getCompleteness() != null && StringUtils.isNotEmpty(updatedType.getCompletenessControl()) && !TypeControls.OK.name().equals(updatedType.getCompletenessControl())) {
			// Récupération des Id pages triés selon un certain ordre de priorité pour création des pièces
			final Map<String, Piece> pages = getPagesIdForCreatePiece(updatedType, ownerIndex);
			// Récupération de la première page (la plus prioritaire)
			final Iterator<String> pagesIdIterator = pages.keySet().iterator();
			String pageId = pagesIdIterator.next();
			final List<PiecesEdoc.Piece> edocPiecesJMC = new ArrayList<>();
			edocTypeRepository.findAll().stream().filter(edocT -> edocT.getPiecesEdoc() != null && edocT.getValue().equals(updatedType.getEdocType())).forEach(edocT -> edocT.getPiecesEdoc().getPiece().forEach(edocPiecesJMC::add));
			// Récupération des pièces JMC paramétrées pour cet edocType
			final Set<String> jmcPieces = ladRadValidator.getDetectedPieceJmc(updatedType, edocTypeRepository.findAll());
			final List<PiecesEdoc.Piece> edocPiecesCompleteness = edocPiecesJMC.stream().filter(edocPiece -> updatedType.getCompleteness().contains(edocPiece.getPieceCode())).collect(Collectors.toList());

			for (final PiecesEdoc.Piece edocPiece : edocPiecesCompleteness) {
				if (!jmcPieces.contains(edocPiece.getPieceJmc())) {
					final Piece unknownEdocPiece = pages.get(pageId);
					final String typeJmcJason = "{\"type\":\"" + edocPiece.getPieceJmc() + "\"}";
					// WS P6 POST /pages/{pageId}/createPiece
					final URI uriPieceJmc = ladRadRepository.createPiece(typeJmcJason, pageId, updatedType.getId());
					if (uriPieceJmc != null) {
						final String idPieceJmc = uriPieceJmc.toString().substring(uriPieceJmc.toString().lastIndexOf('/') + 1);
						final List<String> pieceJmcIndexes = edocTypeRepository.findAll().stream().filter(edocType -> edocType.getPiecesEdoc() != null && StringUtils.equals(edocType.getValue(), updatedType.getEdocType())).findFirst().get().getPiecesEdoc()
								.getPiece().stream().filter(pieceJmc -> StringUtils.equals(pieceJmc.getPieceJmc(), edocPiece.getPieceJmc())).findFirst().get().getIndexes().getIndex();
						updatedType.getIndexes().stream().filter(index -> ownerIndex.equals(index.getOwnerIndex())).filter(index -> pieceJmcIndexes.contains(index.getCode())).forEach(index -> initIndexJmc(unknownEdocPiece.getId(), idPieceJmc, index));
						// WS P7 POST /pieces/{pieceId}/forcePieceType
						ladRadRepository.forcePieceType(typeJmcJason, idPieceJmc, updatedType.getId());
					}
					if (pagesIdIterator.hasNext()) {
						pageId = pagesIdIterator.next();
					}
				}
			}
		}
	}

	public Map<String, Piece> getPagesIdForCreatePiece(Type updatedType, String ownerIndex) {
		// Retourne la liste des ids de pages disponibles pour création et rattachement des nouvelles pièces JMC
		// La priorité est donnée au pages vides, sinon les pages avec des pièces JMC
		final Map<String, Piece> result = new HashMap<>();
		// Pieces edoc sur lesquels on va rattacher les pièces JMC crées
		Set<Piece> pieces = new HashSet();
		final Set<Piece> unknownPieces = updatedType.getActivePieces().stream().filter(piece -> PieceIndicators.OK_MAN.name().equals(piece.getTypeControl()) && !PieceIndicators.OK.name().equals(piece.getStatusControl())).collect(Collectors.toSet());
		if (CollectionUtils.isEmpty(unknownPieces)) {
			pieces = new HashSet(Arrays.asList(updatedType.getActivePieces().iterator().next()));
		} else {
			pieces = unknownPieces;
		}
		pieces.forEach(piece -> {
			final StatusDocumentDTO statusDocument = ladRadRepository.getStatusDocument(computeExternalRef(piece.getId(), ownerIndex), updatedType.getId());
			final Set<String> pagesId = getPagesIdFromStatusDocument(statusDocument);
			pagesId.forEach(pageId -> result.put(pageId, piece));
		});

		return result;

	}

	private Set<String> getPagesIdFromStatusDocument(final StatusDocumentDTO statusDocument) {
		Set<String> pagesId = statusDocument.getPages().stream().filter(page -> CollectionUtils.isEmpty(page.getPieces())).sorted((page1, page2) -> page1.compareTo(page2)).map(PageDTO::getReference).collect(Collectors.toSet());
		if (CollectionUtils.isEmpty(pagesId)) {
			pagesId = new HashSet(Arrays.asList(statusDocument.getPages().get(0).getReference()));
		}
		return pagesId;
	}

	private void initIndexJmc(final UUID pieceId, final String idPieceJmc, Indexe index) {
		// Ajout des conformityControl et validity control (depuis edocType.xml) pour faire le rattachement entre la pièce et l'indexe passés en paramètre
		final EdocIndex edocIndex = edocIndexRepository.findAll().stream().filter(edocIdx -> edocIdx.getCode().equals(index.getCode())).findAny().orElse(null);
		final List<String> listIndexJmcControl = new ArrayList<>();
		if (StringUtils.isNotEmpty(edocIndex.getJmcConformityControl())) {
			listIndexJmcControl.addAll(Arrays.asList(edocIndex.getJmcConformityControl().split(",")));
		}
		if (StringUtils.isNotEmpty(edocIndex.getJmcValidityControl())) {
			listIndexJmcControl.addAll(Arrays.asList(edocIndex.getJmcValidityControl().split(",")));
		}
		listIndexJmcControl.forEach(jmcControl -> index.getIndexesJmc().add(new IndexeJmc(jmcControl, "", "", pieceId, idPieceJmc)));

	}

	private UploadDocumentDTO getUploadDocumentDTO(Type type, List<EdocType> edocTypes, String pieceId, String documentSet) {
		final UploadDocumentDTO uploadDocumentDTO = new UploadDocumentDTO();
		uploadDocumentDTO.setDocumentExternalRef(pieceId);
		if (type.getCompleteness() != null) {
			final List<String> expectedTypes = new ArrayList<>();
			edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && edocT.getValue().equals(type.getEdocType())).forEach(edocT -> edocT.getPiecesEdoc().getPiece().forEach(p -> expectedTypes.add(p.getPieceJmc())));
			uploadDocumentDTO.setExpectedType(expectedTypes);
		}
		uploadDocumentDTO.setToAnalyze(getToAnalyzeFromDocumentSet(documentSet));
		return uploadDocumentDTO;
	}

	private String getToAnalyzeFromDocumentSet(String documentSet) {
		if (DocumentSet.FREE_SET.getLabel().equals(documentSet)) {
			return "no";
		} else {
			return "yes";
		}
	}

	private void handleIndexes(Type type, List<Indexe> indexesForAnOwner, Piece piece, final String pieceId, StatusDocumentDTO statusDocument, List<EdocType> edocTypes) {
		String idPieceJMC;
		if (verifyCompleteness(type, piece, statusDocument, edocTypes)) {
			for (final PageDTO pageDTO : statusDocument.getPages()) {
				for (final PieceDTO pieceDTOJMC : pageDTO.getPieces()) {
					if (pieceDTOJMC.getType() != null && !UNKONW_TYPE_JMC.equals(pieceDTOJMC.getType())) {
						idPieceJMC = pieceDTOJMC.getReference();
						extractData(type, indexesForAnOwner, pieceId, idPieceJMC);
					}

				}
			}
			piece.setStatusControl(PieceControls.OK.name());
		}

	}

	private void extractData(Type type, List<Indexe> indexesForAnOwner, final String pieceId, String idPieceJMC) {
		final String pieceJMCData = ladRadRepository.getPiece(idPieceJMC, type.getId());
		final JsonObject jsonObject = (JsonObject) new JsonParser().parse(pieceJMCData);
		populateResultJmc(indexesForAnOwner, jsonObject, pieceId, idPieceJMC);

	}

	private void populateResultJmc(List<Indexe> indexesForAnOwner, JsonObject jsonObject, String pieceId, String idPieceJMC) {
		final Map<String, String> listExtractedValue = new HashMap<>();
		final Map<String, String> listStatusControl = new HashMap<>();
		final Map<String, Integer> listAccpetancePercentage = new HashMap<>();
		extractFields(jsonObject, listExtractedValue, listStatusControl, listAccpetancePercentage);
		populateIndexesValuesAndControls(indexesForAnOwner, pieceId, idPieceJMC, listExtractedValue, listStatusControl, listAccpetancePercentage);

	}

	private void populateIndexesValuesAndControls(List<Indexe> indexesForAnOwner, String pieceId, String idPieceJMC, final Map<String, String> listExtractedValue, final Map<String, String> listStatusControl,
			final Map<String, Integer> listAccpetancePercentage) {
		final List<String> listIndexCodeControl = new ArrayList<>();
		for (final Indexe indexType : indexesForAnOwner) {
			listIndexCodeControl.clear();
			final EdocIndex edocIndex = edocIndexRepository.findAll().stream().filter(edocIdx -> edocIdx.getCode().equals(indexType.getCode())).findAny().orElse(null);
			final List<IndexeJmc> listeIndexe = indexType.getIndexesJmc();
			if (edocIndex != null) {
				// Récupération des validity et confirmity controls rattachés à l'index
				if (StringUtils.isNotEmpty(edocIndex.getJmcConformityControl())) {
					listIndexCodeControl.addAll(Arrays.asList(edocIndex.getJmcConformityControl().split(",")));
				}

				if (StringUtils.isNotEmpty(edocIndex.getJmcValidityControl())) {
					listIndexCodeControl.addAll(Arrays.asList(edocIndex.getJmcValidityControl().split(",")));
				}
				// Récupération des valeurs, pourcentages et des status des controls (conformity et validity)
				populateIndexesJmcValues(pieceId, idPieceJMC, listExtractedValue, listStatusControl, listAccpetancePercentage, listIndexCodeControl, edocIndex, listeIndexe);
			}
			// Rattachement des nouveaux conformity/validity controls à l'index concerné
			indexType.setIndexesJmc(listeIndexe);
		}
	}

	private void populateIndexesJmcValues(String pieceId, String idPieceJMC, final Map<String, String> listExtractedValue, final Map<String, String> listStatusControl, final Map<String, Integer> listAccpetancePercentage, List<String> listIndexCodeControl,
			final EdocIndex edocIndex, final List<IndexeJmc> listeIndexe) {
		IndexeJmc indexeJmc;
		// Mise à jour des conformity/validity controls des indexes suite à une itération JMC
		for (final String idxCode : listIndexCodeControl) {
			if (StringUtils.isNotEmpty(listStatusControl.get(idxCode))) {
				final Optional<IndexeJmc> optionalIndexJmc = listeIndexe.stream().filter(index -> StringUtils.equals(idPieceJMC, index.getIdPieceJmc()) && StringUtils.equals(idxCode, index.getControlCode())).findAny();
				if (optionalIndexJmc.isPresent()) {
					indexeJmc = optionalIndexJmc.get();
				} else {
					indexeJmc = new IndexeJmc();
				}
				indexeJmc.setControlCode(idxCode);
				indexeJmc.setExtractedValue(listExtractedValue.get(edocIndex.getJmcCode()));
				indexeJmc.setStatusControl(listStatusControl.get(idxCode));
				indexeJmc.setIdPiece(UUID.fromString(pieceId));
				indexeJmc.setIdPieceJmc(idPieceJMC);
				if (listAccpetancePercentage.containsKey(edocIndex.getJmcCode())) {
					final Integer value = listAccpetancePercentage.get(edocIndex.getJmcCode());
					indexeJmc.setAcceptancePercentage(value == null ? 0 : value);
				}
				if (!optionalIndexJmc.isPresent()) {
					listeIndexe.add(indexeJmc);
				}
			}
		}
	}

	private void extractFields(JsonObject jsonObject, final Map<String, String> listExtractedValue, final Map<String, String> listStatusControl, final Map<String, Integer> listAccpetancePercentage) {
		extractValues(jsonObject, listExtractedValue, listAccpetancePercentage);
		extractControls(jsonObject, listStatusControl);
	}

	private void extractValues(JsonObject jsonObject, final Map<String, String> listExtractedValue, final Map<String, Integer> listAccpetancePercentage) {
		String indexName;
		String indexValueExtracted;
		// Récupération des valeurs extraites de JMC
		if (jsonObject.get("fields") instanceof JsonObject) {
			final JsonObject fields = jsonObject.get("fields").getAsJsonObject();
			for (final Map.Entry<String, JsonElement> entry : fields.entrySet()) {
				indexName = entry.getKey();
				final JsonObject index = entry.getValue().getAsJsonObject();
				indexValueExtracted = index.get("value").isJsonNull() ? null : index.get("value").getAsString();
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("The value for index {} is {} ", indexName, indexValueExtracted);
				}
				listExtractedValue.put(indexName, indexValueExtracted);

				// Récupération des percentages d'acceptation
				if (index.get("controls") instanceof JsonObject) {
					final JsonObject controls = index.get("controls").getAsJsonObject();
					for (final Map.Entry<String, JsonElement> entry2 : controls.entrySet()) {
						final JsonObject control = entry2.getValue().getAsJsonObject();
						if ("conformity".equals(entry2.getKey())) {
							listAccpetancePercentage.put(indexName, control.get("level").isJsonNull() ? null : control.get("level").getAsInt());
						}
					}
				}

			}
		}
	}

	private void extractControls(JsonObject jsonObject, final Map<String, String> listStatusControl) {
		String indexName;
		String statusControl;
		// Récupération des conformity controls suite au retour JMC
		if (jsonObject.get("conformity_controls") instanceof JsonObject) {
			final JsonObject controls = jsonObject.get("conformity_controls").getAsJsonObject();
			for (final Map.Entry<String, JsonElement> entry : controls.entrySet()) {
				indexName = entry.getKey();
				statusControl = entry.getValue().getAsString();
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("The status of control for index {} is {} ", indexName, statusControl);
				}
				listStatusControl.put(indexName, statusControl);

			}
		}

		// Récupération des validity controls suite au retour JMC
		if (jsonObject.get("validity_controls") instanceof JsonObject) {
			final JsonObject controls = jsonObject.get("validity_controls").getAsJsonObject();
			for (final Map.Entry<String, JsonElement> entry : controls.entrySet()) {
				for (final Map.Entry<String, JsonElement> validityControl : entry.getValue().getAsJsonObject().entrySet()) {
					indexName = validityControl.getKey();
					statusControl = validityControl.getValue().getAsString();
					if (LOGGER.isDebugEnabled()) {
						LOGGER.debug("The status of control for index {} is {} ", indexName, statusControl);
					}
					listStatusControl.put(indexName, statusControl);
				}

			}
		}
	}

	private boolean verifyCompleteness(Type type, Piece piece, StatusDocumentDTO statusDocument, List<EdocType> edocTypes) {
		final Set<String> completenessPieceJmc = (CollectionUtils.isNotEmpty(type.getCompleteness())) ? ladRadValidator.getEdocTypePieceJmc(type, edocTypes) : new TreeSet<>();
		piece.setTypesJmc(new ArrayList<>());
		if (statusDocument == null) {
			piece.getTypesJmc().add(UNKONW_TYPE_JMC);
			piece.setStatusControl(PieceControls.KO.name());
			return false;
		}
		for (final PageDTO pageDTO : statusDocument.getPages()) {
			// Page JMC contains empty list piece because piece is not recongized by JMC
			if (CollectionUtils.isEmpty(pageDTO.getPieces())) {
				piece.getTypesJmc().add(UNKONW_TYPE_JMC);
				piece.setStatusControl(PieceControls.KO.name());

			}
			for (final PieceDTO pieceDTOJMC : pageDTO.getPieces()) {
				if (pieceDTOJMC.getType() == null || UNKONW_TYPE_JMC.equals(pieceDTOJMC.getType())) {
					piece.setStatusControl(PieceControls.KO.name());
					piece.getTypesJmc().add(UNKONW_TYPE_JMC);

				} else {
					piece.getTypesJmc().add(pieceDTOJMC.getType());
					if (!completenessPieceJmc.contains(pieceDTOJMC.getType())) {
						piece.setStatusControl(PieceControls.KO.name());
						return false;
					}
				}
			}
		}
		return true;
	}

	@Override
	public void analyseFolder(UUID typeId, String ownerIndex) {
		final String externalRef = computeExternalRef(typeId, ownerIndex);
		ladRadRepository.analyseFolder(externalRef, typeId);
	}

	@Override
	public void createFolderIfNotExists(Type type, List<Indexe> indexesForAnOwner, String ownerIndex, String documentSet, String journeyCode) {
		final String externalRef = computeExternalRef(type.getId(), ownerIndex);
		String createFolderParameteresJson = "";
		String idFolderJMC;
		// verify if the Folder JMC exist for The type ID
		idFolderJMC = ladRadRepository.getFolder(externalRef, type.getId());
		final String fieldsFolderJsonToInject = buildFieldsFolderJsonToInject(indexesForAnOwner);
		if (idFolderJMC == null) {
			createFolderParameteresJson = buildJsonParametersCreateFolder(externalRef, documentSet, journeyCode, new ArrayList<String>(type.getFamilyOwners()));
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("The parameteres JSON for Type ID : {} ", createFolderParameteresJson, externalRef);
			}
			final URI uriCreateFolder = ladRadRepository.createFolder(externalRef, createFolderParameteresJson, type.getId());
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("The ID folder JMC {} is created for Type ID : {} ", uriCreateFolder, externalRef);
			}
			if (StringUtils.isNotEmpty(fieldsFolderJsonToInject)) {
				ladRadRepository.injectRefDataFolder(externalRef, fieldsFolderJsonToInject, type.getId());
			}
		} else if (monitoringJmcRepository.isLastInjectDataError(type.getId().toString())) {
			// retry Inject_ref_data if last one failed
			ladRadRepository.injectRefDataFolder(externalRef, fieldsFolderJsonToInject, type.getId());
		}
	}

	private String buildJsonParametersCreateFolder(String externalRef, String documentSet, String journeyCode, ArrayList<String> familyOwners) {
		try {
			final JsonObject obj = new JsonObject();
			obj.addProperty("externalRef", externalRef);
			obj.addProperty("dossierType", documentSet);
			obj.addProperty("contractCode", journeyCode);
			// add iup in createFolder for JMC (they need it for their stats)
			obj.addProperty("iup_client", familyOwners.get(0));
			return obj.toString();
		} catch (final Exception ex) {
			LOGGER.error(ex.getMessage(), ex);
		}
		return "";
	}

	/**
	 *
	 * @param type
	 *            : The type
	 * @param indexesForAnOwner
	 * @param familyOwners
	 * @return Parameters in format JSON
	 *
	 *         // "{\"name\" : \"BERTHIER\",\"firstname\" :\"CORINN\",\"usual_name\" : \"BERTHIER\",\"nationality\" : \"TUN\",\"piece_number\" : \"ZER3\",\"birth_date\" :\"1965-12-06\", \"expiration_date\":\"1965-12-06\",
	 *         \"issue_date_identity\":\"1965-12-06\"}";
	 *
	 */
	private String buildFieldsFolderJsonToInject(List<Indexe> indexesForAnOwner) {

		boolean isInjectData = false;
		final StringBuilder jsonFieldsToInject = new StringBuilder("{");
		String formatValue = "";
		Optional<EdocIndex> edocIndex = null;
		for (final Indexe index : indexesForAnOwner) {
			edocIndex = edocIndexRepository.findAll().stream().filter(edocIdx -> edocIdx.getCode().equals(index.getCode())).findAny();
			if (edocIndex.isPresent() && StringUtils.isNotEmpty(edocIndex.get().getJmcRef()) && StringUtils.isNotEmpty(index.getReferenceValue())) {
				formatValue = index.getReferenceValue();
				formatValue = formatValue(formatValue, edocIndex);
				jsonFieldsToInject.append("\"").append(edocIndex.get().getJmcRef()).append("\":\"").append(formatValue).append("\"").append(",");
				isInjectData = true;
			}
		}

		if (StringUtils.contains(jsonFieldsToInject, ",")) {
			jsonFieldsToInject.deleteCharAt(jsonFieldsToInject.lastIndexOf(","));
		}
		jsonFieldsToInject.append("}");
		return isInjectData ? jsonFieldsToInject.toString() : "";

	}

	private String formatValue(String formatValue, Optional<EdocIndex> edocIndex) {
		String valueToFormat = formatValue;
		if (IndexFormat.D.name().equals(edocIndex.get().getFormat())) {
			valueToFormat = DateUtil.formatDateForJmc(formatValue, "yyyy-MM-dd");
		} else if (IndexFormat.B.name().equals(edocIndex.get().getFormat())) {
			if ("FALSE".equalsIgnoreCase(formatValue)) {
				valueToFormat = "0";
			} else if ("TRUE".equalsIgnoreCase(formatValue)) {
				valueToFormat = "1";
			}
		}
		return valueToFormat;
	}

	private String buildForcedIndexesJsonToInject(List<Indexe> indexes) {
		boolean isInjectData = false;
		final StringBuilder jsonFieldsToInject = new StringBuilder("{\"data\" : { \"fields\" : {");
		for (final Indexe index : indexes) {
			final Optional<EdocIndex> edocIndex = edocIndexRepository.findAll().stream().filter(edocIdx -> edocIdx.getCode().equals(index.getCode())).findAny();
			if (edocIndex.isPresent() && StringUtils.isNotEmpty(edocIndex.get().getJmcCode()) && StringUtils.isNotEmpty(index.getCorrectedValue())) {
				String formatValue = index.getCorrectedValue();
				if ("10000000000000034".equals(edocIndex.get().getCode())) {
					formatValue = DateUtil.formatDateForJmc(formatValue, "dd MM yyyy");
				} else {
					formatValue = formatValue(formatValue, edocIndex);
				}
				jsonFieldsToInject.append("\"").append(edocIndex.get().getJmcCode()).append("\":\"").append(formatValue).append("\"").append(",");
				isInjectData = true;
			}
		}
		if (StringUtils.contains(jsonFieldsToInject, ",")) {
			jsonFieldsToInject.deleteCharAt(jsonFieldsToInject.lastIndexOf(","));
		}
		jsonFieldsToInject.append("}}}");
		return isInjectData ? jsonFieldsToInject.toString() : "";

	}

	private List<String> getPieceJmcIndexes(Type type, List<EdocType> edocTypes, final PieceDTO pieceJmc) {
		List<String> pieceJmcIndexes = new ArrayList<>();
		// Liste des pièces paramétrées dans edocType.xml
		final List<PiecesEdoc.Piece> edocTypePieces = edocTypes.stream().filter(edocType -> edocType.getPiecesEdoc() != null && StringUtils.equals(edocType.getValue(), type.getEdocType())).findFirst().get().getPiecesEdoc().getPiece();
		// Liste des indexes paramétrés pour la pièce JMC
		final Optional<PiecesEdoc.Piece> optionalEdocPieceJmc = edocTypePieces.stream().filter(edocPieceJmc -> StringUtils.equals(edocPieceJmc.getPieceJmc(), pieceJmc.getType())).findFirst();
		if (optionalEdocPieceJmc.isPresent()) {
			pieceJmcIndexes = optionalEdocPieceJmc.get().getIndexes().getIndex();
			// Parmis les indexes passés en paramètre, y'en a-t-il qui sont rattachés à la pièce (statusDocument)
		}
		return pieceJmcIndexes;
	}

	private String getHrefStatusAmiPiece(String reference) {
		return env.getProperty(LADRAD_URL_AMI_STATUS_BASE_PIECE) + reference + env.getProperty(LADRAD_URL_AMI_STATUS_END_PIECE);
	}

	private String getHrefStatusAmiPage(String reference) {
		return env.getProperty(LADRAD_URL_AMI_STATUS_BASE_PAGE) + reference + env.getProperty(LADRAD_URL_AMI_STATUS_END_PAGE);
	}

	public LadRadRepository getLadRadRepository() {
		return ladRadRepository;
	}

	public void setLadRadRepository(LadRadRepository ladRadRepository) {
		this.ladRadRepository = ladRadRepository;
	}

	public EdocIndexRepository getEdocIndexRepository() {
		return edocIndexRepository;
	}

	public void setEdocIndexRepository(EdocIndexRepository edocIndexRepository) {
		this.edocIndexRepository = edocIndexRepository;
	}

	public TypeRepository getTypeRepository() {
		return typeRepository;
	}

	public void setTypeRepository(TypeRepository typeRepository) {
		this.typeRepository = typeRepository;
	}

	public EdocTypeRepository getEdocTypeRepository() {
		return edocTypeRepository;
	}

	public void setEdocTypeRepository(EdocTypeRepository edocTypeRepository) {
		this.edocTypeRepository = edocTypeRepository;
	}

	public LadRadValidator getLadRadValidator() {
		return ladRadValidator;
	}

	public void setLadRadValidator(LadRadValidator ladRadValidator) {
		this.ladRadValidator = ladRadValidator;
	}

	public PieceRepository getPieceRepository() {
		return pieceRepository;
	}

	public void setPieceRepository(PieceRepository pieceRepository) {
		this.pieceRepository = pieceRepository;
	}

	public Environment getEnv() {
		return env;
	}

	public void setEnv(Environment env) {
		this.env = env;
	}

	public TypeAutomaticControlUtils getTypeAutomaticControlUtils() {
		return typeAutomaticControlUtils;
	}

	public void setTypeAutomaticControlUtils(TypeAutomaticControlUtils typeAutomaticControlUtils) {
		this.typeAutomaticControlUtils = typeAutomaticControlUtils;
	}

}
