package com.bnpparibas.bddf.collect.domain.piece;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.Repository
public interface PieceGdnService {

	CompletableFuture<Void> savePieceOnGdn(UUID collectId, Type type, Piece piece, Context context, String journeyCode, Set<Piece> removesPieces) throws InterruptedException;

	ByteBuffer getPieceData(UUID pieceId, Context context, String idGdn);

	void updateTypeOnGdn(Collect collect, Type type, Piece piece, Set<Piece> piecesToRemoveList, Context context, String newTypeStatus, String refUserId, String refChannel, Instant refAquisitionDate);

	boolean updateTypeOnGdnForBatch(Collect collect, Type type, Piece piece, Set<Piece> piecesToRemoveList, Context context, String newTypeStatus, String refUserId, String refChannel, Instant refAquisitionDate);

}
