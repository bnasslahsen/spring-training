package com.bnpparibas.bddf.collect.domain.piece;

public enum PieceStatus {
	TP("TP"), DP("DP"), DP_EC("DP_EC"), DP_ERR("DP_err"), RC("RC"), RC_EC("RC_EC"), RC_ERR("RC_err"), RF("RF"), VA("VA"), VA_EC("VA_EC"), VA_ERR("VA_err"), DF("DF"), SU("SU");

	private String label;

	PieceStatus(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

}
