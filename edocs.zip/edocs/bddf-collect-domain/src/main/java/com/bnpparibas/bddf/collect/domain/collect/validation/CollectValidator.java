package com.bnpparibas.bddf.collect.domain.collect.validation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.domain.collect.FamiliesManagmentAct;
import com.bnpparibas.bddf.collect.domain.collect.Owner;
import com.bnpparibas.bddf.collect.domain.collect.PiecesManagmentAct;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.owner.CommunicationTemplate;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.type.PropertyType;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.bnpparibas.bddf.errors.BusinessException.Builder;

/**
 *
 * Cette classe présente les implémentations des contrôles demandés au niveau Collect.
 *
 * Ces contrôles sont invoqués principalement par le postCollect
 *
 */
@Component
public class CollectValidator {

	private static final String ERROR_FAMILIES_LABEL = "families[";
	private static final String PAGES_DOCUMENT_2 = " sont en attente de collecte";
	private static final String PAGES_DOCUMENT_1 = "Des pages du document ";

	@Autowired
	private FeatureManager featureManager;
	@Autowired
	private Environment environment;
	@Value("${collect.authorized-format}")
	private String authorizedFormat;
	@Value("${collect.default-format}")
	private String defaultFormat;

	public CollectValidator() {
		super();
	}

	public void validateCollect(Collect collect) {
		validatePiecesManagementActs(collect.getPiecesManagementAct());
		initCollectManagementActs(collect);
		validateCollectManagementActs(collect.getCollectManagementAct());
		final Map<UUID, List<Type>> typesByFamily = collect.getTypes().stream().collect(Collectors.groupingBy(Type::getFamilyId, LinkedHashMap::new, Collectors.toList()));
		validateCollectFieldsSize(collect);
		validateAllowedFiles(collect);
		validateAutoClosingDelay(collect);
		typesByFamily.forEach((famId, types) -> validateFamily(collect, types));
		validateCommunicationTemplate(collect);
		validateControlIterationAllowed(collect);

	}

	private void validateCommunicationTemplate(Collect collect) {
		collect.getOwners().forEach(owner -> {
			if (StringUtils.isNotEmpty(owner.getCommunicationTemplate()) && !Arrays.stream(CommunicationTemplate.values()).map(CommunicationTemplate::name).collect(Collectors.toList()).contains(owner.getCommunicationTemplate())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COMMUNICATION_TEMPLATE, owner.getCommunicationTemplate()));
			}
		});
	}

	private void validateAllowedFiles(Collect collect) {
		if (StringUtils.isNotEmpty(authorizedFormat)) {
			final List<String> edocAuthorizedFormat = Arrays.asList(authorizedFormat.split(","));
			if (collect.getAllowedFile().isEmpty()) {
				collect.setAllowedFile(new HashSet<String>(Arrays.asList(defaultFormat.split(","))));
			} else {
				collect.getAllowedFile().forEach(fileFormat -> {
					if (!edocAuthorizedFormat.contains(fileFormat)) {
						throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_ALLOWED_FILES, collect.getAllowedFile().toString(), authorizedFormat));
					}
				});
			}
		}
	}

	public void initCollectManagementActs(Collect collect) {
		if (collect.getCollectManagementActWithoutInit() == null) {
			collect.setCollectManagementAct(new HashSet<>(Arrays.asList(CollectStatus.AB.name(), CollectStatus.CL.name())));
		}
	}

	private void validateCollectManagementActs(Set<String> collectManagementAct) {
		if (collectManagementAct != null) {
			collectManagementAct.stream().forEach(collectStatus -> {
				if (!Arrays.asList(CollectStatus.AB.name(), CollectStatus.CL.name()).contains(collectStatus)) {
					throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DATA_VALUE, "collectManagementAct", collectStatus));
				}
			});
		}
	}

	private void validateControlIterationAllowed(Collect collect) {
		if (collect.getControlIterationAllowed() == 0) {
			collect.setControlIterationAllowed(2);
		} else if (collect.getControlIterationAllowed() > 3 || collect.getControlIterationAllowed() < 0) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_ADD_CONTROL_ITERATION_ALLOWED, "controlIterationAllowed"));
		}

	}

	private void validatePiecesManagementActs(Set<String> piecesManagementAct) {
		if (piecesManagementAct != null) {
			final Optional<String> invalidPiecesMangmentAct = piecesManagementAct.stream().filter(m -> Arrays.stream(PiecesManagmentAct.values()).noneMatch(e -> e.name().equals(m))).findAny();
			invalidPiecesMangmentAct.ifPresent(a -> {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DATA_VALUE, "PiecesManagementAct", a));
			});
		}
	}

	public void validateFamilyCategory(Set<String> familiesManagementAct, Type type) {
		if (!familiesManagementAct.contains(type.getFamilyCategory())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_FAMILY_CATEGORY, type.getFamilyCategory(), type.getFamilyId().toString(), familiesManagementAct.toString()));
		}
		if (FamiliesManagmentAct.DR.name().equals(type.getFamilyCategory()) && StringUtils.isEmpty(type.getFamilyCategoryComment())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_FAMILY_CATEGORY_COMMENT, type.getFamilyCategory(), type.getFamilyLabel(), type.getFamilyId().toString()));
		}
	}

	public void validateFamilyExistance(UUID familyId, Set<Type> typesRepo, UUID collectId) {
		if (typesRepo.stream().noneMatch(t -> t.getFamilyId().equals(familyId))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_FAMILY_NOT_FOUND, collectId.toString(), familyId.toString()));
		}
	}

	public List<String> validateFamilyWithAlert(String propertyType, Set<Type> typeList) {
		final List<String> alerts = new ArrayList<>();
		if (PropertyType.FIXE.getLabel().equals(propertyType)) {
			typeList.forEach(t -> validateTypeFixeWithAlert(typeList, alerts, t));
		} else if (PropertyType.LISTE.getLabel().equals(propertyType)) {
			final List<Pair<String, Integer>> piecesNumber = new ArrayList<>();
			typeList.forEach(t -> validateTypeListeWithAlert(typeList, alerts, piecesNumber, t));
			if (piecesNumber.stream().noneMatch(pair -> pair.getRight() > 0)) {
				piecesNumber.forEach(pair -> alerts.add(PAGES_DOCUMENT_1 + pair.getLeft() + PAGES_DOCUMENT_2));
			}
		}
		return alerts;
	}

	public void validateFamily(UUID collectId, String propertyType, Set<Type> typeList) {
		if (PropertyType.FIXE.getLabel().equals(propertyType)) {
			typeList.forEach(t -> validateTypeFixe(collectId, typeList, t));
		} else if (PropertyType.LISTE.getLabel().equals(propertyType)) {
			final List<Integer> piecesNumber = new ArrayList<>();
			typeList.forEach(t -> validateTypeListe(collectId, typeList, piecesNumber, t));
			if (piecesNumber.stream().noneMatch(i -> i > 0)) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_INVALID, collectId.toString()));
			}
		}
	}

	public void validateFamily(Collect collect, List<Type> familyTypes) {
		final Type f = familyTypes.get(0);
		if (!Arrays.stream(FamiliesManagmentAct.values()).map(FamiliesManagmentAct::name).anyMatch(p -> p.equals(f.getFamilyCategory()))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DATA_VALUE, "category", f.getFamilyCategory()));
		}
		final List<String> references = collect.getOwners().stream().map(Owner::getReference).collect(Collectors.toList());
		// verify is Family has a List of FamilyManagmentAct
		final Set<String> familiesManagementAct = CollectionUtils.isNotEmpty(f.getFamiliesManagementActFamily()) ? f.getFamiliesManagementActFamily() : collect.getFamiliesManagementAct();
		final Optional<String> invalidFamiliesMangmentAct = familiesManagementAct.stream().filter(m -> Arrays.stream(FamiliesManagmentAct.values()).noneMatch(e -> e.name().equals(m))).findAny();
		invalidFamiliesMangmentAct.ifPresent(a -> {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DATA_VALUE, "FamiliesManagementAct", a));
		});
		if (!familiesManagementAct.stream().anyMatch(a -> a.equals(f.getFamilyCategory()))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_FAMILY_CATEGORY_UNAUTHORIZED, f.getFamilyLabel(), familiesManagementAct.toString()));
		}
		if (isFimilyCategoryMissing(f)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_FAMILY_CATEGORY_COMMENT, f.getFamilyCategory(), f.getFamilyLabel(), f.getLabel()));
		}
		f.getFamilyOwners().stream().filter(r -> !references.contains(r)).findAny().ifPresent(r -> {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DATA_CONSISTENCY, ERROR_FAMILIES_LABEL + f.getFamilyLabel() + "].owners", r, "owners"));
		});
		if (!Arrays.stream(PropertyType.values()).map(PropertyType::getLabel).anyMatch(p -> p.equals(f.getFamilyPropertyType()))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DATA_VALUE, "propertyType", f.getFamilyPropertyType()));
		}
		if (isMultiValueNotNeeded(familyTypes, f)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DATA_MULTI_VALUE, "types", ERROR_FAMILIES_LABEL + f.getFamilyLabel() + "].types", ERROR_FAMILIES_LABEL + f.getFamilyLabel() + "].propertyType"));
		}
		validatePiecesManagementActs(f.getPiecesManagementActFamily());
		validateFamilyFieldsSize(f);
		initBlocked(familyTypes);
	}

	private void initBlocked(List<Type> familyTypes) {
		familyTypes.forEach(type -> type.setFamilyBlocked(false));
	}

	public void validateFamily(Collect collect, Map<UUID, List<Type>> typesByFamily, List<Type> families, int idx) {
		final Type f = families.get(idx);
		final List<String> references = collect.getOwners().stream().map(Owner::getReference).collect(Collectors.toList());
		if (!collect.getFamiliesManagementAct().stream().anyMatch(a -> a.equals(f.getFamilyCategory()))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_FAMILY_CATEGORY_UNAUTHORIZED, f.getFamilyLabel(), collect.getFamiliesManagementAct().toString()));
		}
		if (isFimilyCategoryMissing(f)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_FAMILY_CATEGORY_COMMENT, f.getFamilyCategory(), f.getFamilyLabel(), f.getLabel()));
		}
		final List<String> ownersList = new ArrayList<>(f.getFamilyOwners());
		ownersList.removeAll(references);
		if (!ownersList.isEmpty()) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DATA_CONSISTENCY, ERROR_FAMILIES_LABEL + idx + "].owners", ownersList.get(0), "owners"));
		}
		if (!Arrays.stream(PropertyType.values()).map(PropertyType::getLabel).anyMatch(p -> p.equals(f.getFamilyPropertyType()))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DATA_VALUE, "propertyType", f.getFamilyPropertyType()));
		}
		if (isMultiValueNotNeeded(typesByFamily, f)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DATA_MULTI_VALUE, "types", ERROR_FAMILIES_LABEL + idx + "].types", ERROR_FAMILIES_LABEL + idx + "].propertyType"));
		}
	}

	private boolean isMultiValueNotNeeded(Map<UUID, List<Type>> typesByFamily, Type f) {
		final int numberValue = 2;
		return PropertyType.LISTE.getLabel().equals(f.getFamilyPropertyType()) && typesByFamily.get(f.getFamilyId()).stream().filter(t -> !Optional.ofNullable(t.getParentId()).isPresent()).count() < numberValue;
	}

	private boolean isMultiValueNotNeeded(List<Type> typesByFamily, Type f) {
		final int numberValue = 2;
		return PropertyType.LISTE.getLabel().equals(f.getFamilyPropertyType()) && typesByFamily.stream().filter(t -> !Optional.ofNullable(t.getParentId()).isPresent()).count() < numberValue;
	}

	private boolean isFimilyCategoryMissing(Type f) {
		return f.getFamilyCategory().equals(FamiliesManagmentAct.DR.name()) && (null == f.getFamilyCategoryComment() || f.getFamilyCategoryComment().isEmpty());
	}

	private void validateTypeListe(UUID collectId, Set<Type> typeList, List<Integer> piecesNumber, Type t) {
		final Set<Piece> pieces = t.getActivePieces();
		if (typeList.stream().noneMatch(x -> t.getId().equals(x.getParentId()))) {
			piecesNumber.add(pieces.size());
			if (t.isPendingDocument() || pieces.stream().filter(p -> !PieceStatus.VA.getLabel().equals(p.getStatus())).count() > 0) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_INVALID, collectId.toString()));
			}
		}
	}

	private void validateTypeFixe(UUID collectId, Set<Type> typeList, Type t) {
		final Set<Piece> pieces = t.getActivePieces();
		if (typeList.stream().noneMatch(x -> t.getId().equals(x.getParentId())) && t.isPendingDocument() || pieces.isEmpty() || pieces.stream().filter(p -> !PieceStatus.VA.getLabel().equals(p.getStatus())).count() > 0) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_INVALID, collectId.toString()));
		}
	}

	private void validateTypeListeWithAlert(Set<Type> typeList, List<String> alerts, List<Pair<String, Integer>> piecesNumber, Type t) {
		final Set<Piece> pieces = t.getActivePieces();
		if (typeList.stream().noneMatch(x -> t.getId().equals(x.getParentId()))) {
			piecesNumber.add(Pair.of(t.getLabel(), pieces.size()));
			if (t.isPendingDocument()) {
				alerts.add(PAGES_DOCUMENT_1 + t.getLabel() + PAGES_DOCUMENT_2);
			}
			if (pieces.stream().filter(p -> !PieceStatus.VA.getLabel().equals(p.getStatus())).count() > 0) {
				alerts.add(PAGES_DOCUMENT_1 + t.getLabel() + PAGES_DOCUMENT_2);
			}
		}
	}

	private void validateTypeFixeWithAlert(Set<Type> typeList, List<String> alerts, Type t) {
		final Set<Piece> pieces = t.getActivePieces();
		if (typeList.stream().noneMatch(x -> t.getId().equals(x.getParentId()))) {
			if (t.isPendingDocument() || pieces.isEmpty()) {
				alerts.add(PAGES_DOCUMENT_1 + t.getLabel() + PAGES_DOCUMENT_2);
			}
			if (pieces.stream().filter(p -> !PieceStatus.VA.getLabel().equals(p.getStatus())).count() > 0) {
				alerts.add(PAGES_DOCUMENT_1 + t.getLabel() + PAGES_DOCUMENT_2);
			}
		}
	}

	public void validateUpdateFamilies(Set<UUID> oldFamiliesId, Map<UUID, Type> newCategories, UUID collectId, Set<String> familiesManagementActCollect) {
		oldFamiliesId.stream().filter(famId -> !newCategories.keySet().contains(famId)).findAny().ifPresent(famId -> {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DELETE_FAMILY_UNAUTHORIZED, famId.toString()));
		});
		newCategories.keySet().stream().filter(famId -> !oldFamiliesId.contains(famId)).findAny().ifPresent(famId -> {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_FAMILY_NOT_FOUND, collectId.toString(), famId.toString()));
		});
		newCategories.forEach((id, fam) -> {
			// verify is Family has a List of FamilyManagmentAct
			final Set<String> familiesManagementAct = CollectionUtils.isNotEmpty(fam.getFamiliesManagementActFamily()) ? fam.getFamiliesManagementActFamily() : familiesManagementActCollect;
			if (!familiesManagementAct.contains(fam.getFamilyCategory())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_FAMILY_CATEGORY, fam.getFamilyCategory(), familiesManagementAct.toString(), id.toString()));
			}
			if (FamiliesManagmentAct.DR.name().equals(fam.getFamilyCategory()) && StringUtils.isEmpty(fam.getFamilyCategoryComment())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_FAMILY_CATEGORY_COMMENT, fam.getFamilyCategory(), fam.getFamilyLabel(), fam.getFamilyId().toString()));
			}
		});
	}

	public FeatureManager getFeatureManager() {
		return featureManager;
	}

	public void setFeatureManager(FeatureManager featureManager) {
		this.featureManager = featureManager;
	}

	public void setTypeStatusToInWhenNonePieceAndTypeStatusWasRC(Type type) {
		if (TypeStatus.RC.getLabel().equals(type.getStatus()) && type.getActivePieces().stream().count() < 1) {
			type.setStatus(TypeStatus.IN.getLabel());
		}
	}
	
	public void familyBlocked(final Type family) {
		if(family.isFamilyBlocked()) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_FAMILY_BLOCKED, family.getFamilyLabel()));
		}
		
	}

	private void validateFamilyFieldsSize(Type family) {
		// family.label - 200
		validateFieldSize(family.getFamilyLabel(), "label de la famille", 200);
		// family.category - 3
		validateFieldSize(family.getFamilyCategory(), "category de la famille", 3);
		// family.category_comment - 100
		validateFieldSize(family.getFamilyCategoryComment(), "categoryComment de la famille", 100);
		// family..property_type - 200
		validateFieldSize(family.getFamilyPropertyType(), "propertyType de la famille", 200);
		// family.icone_code - 45
		validateFieldSize(family.getFamilyIconCode(), "iconeCode de la famille", 45);
		// family.additional_information - 200
		validateFieldSize(family.getFamilyAdditionalInformation(), "additionalInformation de la famille", 200);
	}

	private void validateCollectFieldsSize(Collect collect) {
		// collect.status - 3
		validateFieldSize(collect.getStatus(), "status de la collecte", 3);
		// collect.entity_label - 100
		validateFieldSize(collect.getEntityLabel(), "entityLabel", 100);
		// collect.product_label - 100
		validateFieldSize(collect.getProductLabel(), "productLabel", 100);
		// collect.step_label - 100
		validateFieldSize(collect.getStepLabel(), "stepLabel", 100);
		// collect.journey_code - 6
		validateFieldSize(collect.getJourneyCode(), "journeyCode", 6);
		// collect.project - 50
		validateFieldSize(collect.getProject(), "project", 50);
		// collect.sending_application_code - 50
		validateFieldSize(collect.getSendingApplicationCode(), "sendingApplicationCode", 50);
		// owners.reference - 17
		collect.getOwners().forEach(owner -> {
			// owners.name - 100
			validateFieldSize(owner.getName(), "name du owner", 100);
			// owners.firstname - 100
			validateFieldSize(owner.getFirstname(), "firstname du owner", 100);
		});
	}

	private void validateFieldSize(String field, String fieldName, int maxSize) {
		if (StringUtils.isNotEmpty(field) && field.length() > maxSize) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_SIZE_MAX, fieldName, String.valueOf(maxSize)));
		}
	}

	private void validateAutoClosingDelay(Collect collect) {
		if (collect.getAutoClosingDelay() > 360 || collect.getAutoClosingDelay() < -1) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_AUTO_CLOSING_DELAY));
		}
	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

}
