package com.bnpparibas.bddf.collect.domain.notification.enums;

public enum ConstantNotification {

	ID_PREFIX("ED", "EDOC"), TOP_FACTURABLE("2", "Top facturabe"), NBRES_VARIABLES_MESSAGE_DEFAULT("02", "nombres de variables dans le message"), BNP_APP("1", "- sur l'application Mes Comptes"), HB_APP("1",
			"- sur l'application Hello bank!"), ID_DIGICOM_APP("AP12247", "applicationIdDigicom"), MSG_REFERENCE_DIGICOM("AP122470000001", "Reference du message"), START_DIFF_DATE_DIGICOM("",
					"date d'envoi "), RECEIVER_PREFERENCES_DIGICOM("receiverPreferences", "N"), MULTICHANNEL_DIGICOM("multiChannel", "N"), CHANNEL_LIST("channel", "NTF"), RECEIVER_ID_TYPE("receiverIdType", "ID_PERSONNE"), PARTHB("HB",
							"PARTHB"), PARTBNP("BNP ", "PARTBNP"), VARIABLE_LIST_HB("HB", "Hello la Team"), VARIABLE_LIST_BNP("BNP",
									"BNP Paribas"), REMOVE_NAMESPACE("nameSpace", " xmlns=\"bnp.com/schema/edoc/notification\""), VARIABLE_LIST_VAR1("key", "VAR1"), VARIABLE_LIST_VAR2("key", "VAR2"), MESSAGE_DIGICOM("Message", "message");

	private String code;
	private String libelle;

	private ConstantNotification(String code, String libelle) {

		this.libelle = libelle;
		this.code = code;
	}

	public String getLibelle() {
		return libelle;
	}

	public String getCode() {
		return code;
	}

}
