package com.bnpparibas.bddf.collect.domain.notification.enums;

public enum NotificationMessageType {
	MBEDOC01("MBEDOC01", "MS Retails et BPF"), BDEDOC01("BDEDOC01", "MS HB"), MBEDOC02("MBEDOC02", "Mail Retail, BPF"), BDEDOC02("BDEDOC02", "Mail HB"), 
	EDOCUPD001("EDOCUPD001","PARTBNP");

	private String code;
	private String libelle;

	private NotificationMessageType(String code, String libelle) {

		this.libelle = libelle;
		this.code = code;
	}

	public String getLibelle() {
		return libelle;
	}

	public String getCode() {
		return code;
	}

}
