package com.bnpparibas.bddf.collect.domain.type;

public enum TypeStatus {
	IN("IN"), RC("RC"), RC_AUTO("RC_AUTO"), VA("VA"), VA_AUTO("VA_AUTO");

	private String label;

	TypeStatus(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

}
