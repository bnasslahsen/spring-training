package com.bnpparibas.bddf.collect.domain.event.type;

import java.util.Arrays;

public enum TypeReceivedType {

	DEPOSED(1, "000000084"), CONTROLLED(2, "000000085"), AUTOMATTC_CONTROL(3, "00050000000000010L"), SEND_GDN(4, "00005000000000176"), NOTIFIED_MS(5, "Notif BMM MS"), NOTIFIED_EMAIL(6, "Notif BMM EMAIL"), NOTIFIED_DIGICOM(7,
			"Notif DIGICOM"), SEND_TO_AMI(8, "00005000000000189");

	private int code;
	private String label;

	TypeReceivedType(int code, String label) {
		this.code = code;
		this.label = label;
	}

	public int getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}

	public static TypeReceivedType fromLabel(String label) {
		return Arrays.asList(values()).stream().filter(c -> c.getLabel().equals(label)).findAny().orElse(null);
	}

}
