package com.bnpparibas.bddf.collect.domain.type;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Repository
public interface FamilyRepository {

	void add(Collect collect, List<Type> types);

	void delete(UUID familyId);

	void update(Collect collect, Set<Type> types);
	
	void updateBlocked(UUID familyId);

}
