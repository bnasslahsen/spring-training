package com.bnpparibas.bddf.collect.domain.type;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Repository
public interface TypeRepository {

	Set<Type> findByCollect(UUID collectId);

	Type findOne(UUID collectId, UUID typeId);

	void updateType(UUID collectId, Type type);

	Type findOneWithInactivePieces(UUID collectId, UUID id);

	void updateStatusControl(UUID id, String name);

	void deleteAllIndexJmc(Set<Indexe> indexes);

	Type findCompleteType(UUID collectId, UUID typeId);

	Set<Type> findByStatusControl(String statusControl);

	void updateForAddPiece(UUID id, String status, boolean pendingDocument, String pendingDocumentLabel);

	void addTypes(UUID collectId, List<Type> types);

	void delete(Type type);

}
