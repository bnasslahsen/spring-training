package com.bnpparibas.bddf.collect.domain.collect;

public enum FamiliesManagmentAct {
	OB("Obligatoire"), ND("Non demandé"), DR("Dérogé"), DF("Déjà fourni"), IN("Interne"), FA("Facultatif");

	private String label;

	FamiliesManagmentAct(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

}
