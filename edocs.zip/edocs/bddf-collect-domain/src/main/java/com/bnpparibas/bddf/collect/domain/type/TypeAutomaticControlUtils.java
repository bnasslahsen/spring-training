package com.bnpparibas.bddf.collect.domain.type;

import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.togglz.core.manager.FeatureManager;

import com.bnp.schema.edoc.index.Indexes.EdocIndex;
import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditEventService;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.event.type.EventSendAMI;
import com.bnpparibas.bddf.collect.domain.event.type.TypeReceivedType;
import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.ladrad.LadRadValidator;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.DocumentSet;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.RequestWSJMCType;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.StatusDocument;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.TypeControls;
import com.bnpparibas.bddf.collect.domain.nomenclature.Nomenclature;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.errors.TechnicalException;
import com.bnpparibas.bddf.rest.Context;

/**
 *
 * Cette classe contient des services utilitaires utilisés par les méthode de contrôles automatiques
 *
 * @author c07130
 *
 */
@Component
public class TypeAutomaticControlUtils {

	private static final List<String> listRejectedCode = Arrays.asList(StatusDocument.ANALYSIS_FAILED.getLabel(), StatusDocument.DOCUMENT_REJECTED.getLabel(), StatusDocument.NOT_FOUND.getLabel());
	private static final String WAITING_PERIOD_INIT_PREFIX = "waitingPeriod.init.";
	private static final String WAITING_PERIOD_LOOP_PREFIX = "waitingPeriod.inLoop.";
	private static final String MAX_DURATION = "waitingPeriod.maxDuration.";
	private static final Logger LOGGER = LoggerFactory.getLogger(TypeAutomaticControlUtils.class);

	@Autowired
	private LadRadRepository ladRadRepository;

	@Autowired
	private LadRadValidator ladRadValidator;

	@Autowired
	private TypeRepository typeRepository;

	@Autowired
	private TypeValidator typeValidator;

	@Autowired
	private TypeLadRadService typeLadRadService;

	@Autowired
	private AmiService amiService;

	@Autowired
	private CollectRepository collectRepository;

	@Autowired
	private CollectEventHandler collectEventHandler;

	@Autowired
	private EdocTypeRepository edocTypeRepository;

	@Autowired
	private NomenclatureService nomenclatureService;

	@Autowired
	private EdocIndexRepository edocIndexRepository;

	@Autowired
	private DocReferenceService docReferenceService;

	@Autowired
	private FeatureManager featureManager;

	@Autowired
	private AuditEventService auditEventService;

	@Autowired
	private Environment environment;

	public TypeAutomaticControlUtils() {

	}

	public TypeAutomaticControlUtils(LadRadRepository ladRadRepository, LadRadValidator ladRadValidator, TypeRepository typeRepository, TypeValidator typeValidator, TypeLadRadService typeLadRadService, CollectRepository collectRepository,
			CollectEventHandler collectEventHandler, EdocTypeRepository edocTypeRepository, NomenclatureService nomenclatureService, EdocIndexRepository edocIndexRepository, DocReferenceService docReferenceService, FeatureManager featureManager) {
		super();
		this.ladRadRepository = ladRadRepository;
		this.ladRadValidator = ladRadValidator;
		this.typeRepository = typeRepository;
		this.typeValidator = typeValidator;
		this.typeLadRadService = typeLadRadService;
		this.collectRepository = collectRepository;
		this.collectEventHandler = collectEventHandler;
		this.edocTypeRepository = edocTypeRepository;
		this.nomenclatureService = nomenclatureService;
		this.edocIndexRepository = edocIndexRepository;
		this.docReferenceService = docReferenceService;
		this.featureManager = featureManager;
	}

	private boolean isAuthorizedForAmi(Type type) {
		// on envoie vers AMI si au moins un index non indexable à KO
		// et viceocoding = immediate
		final boolean existsNotIndexableAndKo = type.getIndexes().stream().anyMatch(indexe -> !IndexStatus.isOK(indexe.getStatusControl()) && indexe.isVideoCoding() && !indexe.isIndexable());

		return (VideoCodingDelay.IMMEDIATE.getCode().equals(type.getVideoCodingDelay()) && existsNotIndexableAndKo);
	}

	@Async("sendJMCTaskExecutor")
	@Transactional(transactionManager = "transactionManagerDB")
	public void handleSecondIteration(Collect collect, Type type, Context context, String documentSet) {
		LoggerHelper.logForPerfTest(LOGGER, "Début de l'envoi du deuxieme iteration JMC pour type" + type.getId() + " pour la collecte " + collect.getId() + " (thread id " + Thread.currentThread().getId() + ")");
		final UUID collectId = collect.getId();
		final Map<String, List<Indexe>> indexesByOwners = type.getIndexes().stream().collect(Collectors.groupingBy(Indexe::getOwnerIndex));
		Integer durationSendsJMC = 0;
		Integer durationSendsAmi = 0;
		try {
			// Tester si utile de faire une deuxième itération JMC ou alors faire directement un échange avec AMI
			if (isExecuteSecondIteration(type)) {
				final long start = System.currentTimeMillis();
				// on envoie vers JMC si au moins une piece est reconnue
				indexesByOwners.keySet().forEach(ownerIndex -> forceIndexesTypes(type, ownerIndex));
				// 3. Extraction des données JMC
				indexesByOwners.keySet().forEach(ownerIndex -> extractIndexePiecesSecondIteration(collectId, type, ownerIndex, documentSet));
				final long end = System.currentTimeMillis();
				durationSendsJMC = (int) (end - start) / 1000;
				// Recalcul des indicateurs suite échange JMC
				calculateIndicators(type);
			}
			// Envoi AMI 2ème itération
			if (isAuthorizedForAmi(type)) {
				final long start = System.currentTimeMillis();
				initStatusEventAMI(type, collectId, context, collect);
				amiService.sendAMISecondIteration(collectId, type, !isExecuteSecondIteration(type), collect.getJourneyCode());
				final long end = System.currentTimeMillis();
				durationSendsAmi = (int) (end - start) / 1000;
			}
			// Sauvegarde audit-event de contrôle auto
			auditEventService.sendAuditEventLadRADSecondIteration(collectId, context, collect.getJourneyCode(), type, durationSendsJMC, durationSendsAmi, documentSet);
			// Essai d'auto-validation des pièces et du type
			autoValidateType(collect.getId(), type, context, AuditValue.LAD_RAD_AUTOMATIC_VALIDATION_ITERATION_2);
		} catch (final Exception ex) {
			// Gestion des erreurs
			ladRadValidator.updateTypeWhenError(type);
			auditEventService.sendAuditEventLadRAD(collectId, context, collect.getJourneyCode(), type, AuditValue.LAD_RAD_AUTOMATIC_CONTROL_ERROR, ex.getMessage());
			LOGGER.info(ex.getMessage(), ex);
		} finally {
			// Essai d'auto-acceptation des pièces et du type (Envoi en back-office)
			autoAcceptType(collect.getId(), type, context, AuditValue.LAD_RAD_AUTOMATIC_ACCEPTATION);
			// Sauvegarde en base à la fin du contrôle auto
			typeRepository.updateType(collectId, type);
			// Envoi d'event de contrôle auto
			collectEventHandler.sendAutomaticControlEvent(collectId, context, type);
			LoggerHelper.logForPerfTest(LOGGER, "Durée de l'envoi du deuxieme iteration JMC pour type" + type.getId() + " pour la collecte " + collect.getId() + "  : " + durationSendsJMC + " s" + " (thread id " + Thread.currentThread().getId() + ")");
			LoggerHelper.logForPerfTest(LOGGER, "Fin de l'envoi du deuxieme iteration JMC pour type" + type.getId() + " pour la collecte " + collect.getId() + " (thread id " + Thread.currentThread().getId() + ")");
		}
	}

	private boolean isExecuteSecondIteration(Type type) {
		return !Arrays.asList(VideoCodingDelay.IMMEDIATE.getCode()).contains(type.getVideoCodingDelay())
				// Toutes les pièces sont reconnues
				|| TypeControls.OK.name().equals(type.getCompletenessControl())
				// Au moins une piece est reconnue
				|| type.getCompletenessControl().split("/").length != type.getCompleteness().size()
				// Au moins un index non indexable à KO
				|| type.getIndexes().stream().noneMatch(indexe -> !IndexStatus.isOK(indexe.getStatusControl()) && indexe.isVideoCoding() && !indexe.isIndexable());
	}

	@Async("sendJMCTaskExecutor")
	@Transactional(transactionManager = "transactionManagerDB")
	public void deleteOnJMC(Type type, Map<String, List<Indexe>> indexesByOwners, Set<Piece> piecesRemoved) {
		indexesByOwners.keySet().forEach(ownerIndex -> piecesRemoved.stream().filter(piece -> !piece.getStatus().equals(PieceStatus.TP.getLabel()) && !piece.getStatus().equals(PieceStatus.DF.getLabel())).forEach(piece -> {
			try {
				ladRadRepository.deleteDocument(computeExternalRef(piece.getId(), ownerIndex), type.getId());
			} catch (final Exception ex) {
				LOGGER.info(ex.getMessage(), ex);
			}
		}));
	}

	public void forceIndexesTypes(Type updatedType, String ownerIndex) {
		if (updatedType.getControlRequired() == ControlRequired.CONTROL_JMC.getCode()) {
			// 1. Créer pièce JMC fictive si inexistante
			typeLadRadService.createAndForceJmcPiece(updatedType, ownerIndex);
			// 2. Correction/saisie des données d’une pièce
			typeLadRadService.updateIndexOfJmcPiece(updatedType, ownerIndex);
		}
	}

	public void extractIndexePiecesSecondIteration(UUID collectId, Type type, String ownerIndex, String documentSet) {
		final Map<String, List<Indexe>> indexesByOwners = type.getIndexes().stream().collect(Collectors.groupingBy(Indexe::getOwnerIndex));
		final List<Indexe> indexesForAnOwner = indexesByOwners.get(ownerIndex);
		final Map<UUID, StatusDocumentDTO> listStatusDocumentJMC = new HashMap<>();
		// Récupération des documents JMC (getStatusDocument()) après vérification de la fin des traitements JMC sur les documents
		type.getActivePieces().forEach(pieceIdx -> listStatusDocumentJMC.put(pieceIdx.getId(), verifyStatusDocument(pieceIdx, ownerIndex, type.getId(), documentSet, System.currentTimeMillis())));
		// Récupération des pièces JMC (getPiece()) et recalcul des indicateurs
		extractIndexesPiece(collectId, type, indexesForAnOwner, ownerIndex, listStatusDocumentJMC, documentSet, true);
	}

	public void autoValidateType(UUID collectId, Type type, Context context, AuditValue auditValue) {
		final Collect collect = collectRepository.findOnlyCollect(collectId);
		//
		if (isEligibleForAutoValidation(type, collect.isAutoValidation())) {
			// Validation du type et des pièces si éligible pour auto-validation
			type.setStatus(TypeStatus.VA_AUTO.name());
			type.getActivePieces().forEach(piece -> piece.setStatus(PieceStatus.VA.name()));
			// Sauvegarde des pièces de références suite à la validation du type
			docReferenceService.saveDocReference(collectId, collect.getJourneyCode(), type, context.getCustomerId(), context.getCanal(), Instant.now(), context, collect.getSendingApplicationCode());
			auditEventService.sendAuditEventLadRAD(collectId, context, collect.getJourneyCode(), type, auditValue, null);
		}
	}

	public void autoAcceptType(UUID collectId, Type type, Context context, AuditValue auditValue) {
		final Collect collect = collectRepository.findOnlyCollect(collectId);
		if (isEligibleForAutoAcceptation(type, collect.isAutoAcceptationAllowed(), collect.getControlIterationAllowed())) {
			// Envoi en back-office du type et des pièces si éligible pour auto-acceptation
			type.setStatus(TypeStatus.RC_AUTO.name());
			type.getActivePieces().stream().filter(piece -> !PieceStatus.VA.name().equals(piece.getStatus())).forEach(piece -> piece.setStatus(PieceStatus.RC.name()));
			docReferenceService.saveDocReference(collectId, collect.getJourneyCode(), type, context.getCustomerId(), context.getCanal(), Instant.now(), context, collect.getSendingApplicationCode());
			auditEventService.sendAuditEventLadRAD(collectId, context, collect.getJourneyCode(), type, auditValue, null);
		}
	}

	public boolean isEligibleForAutoValidation(Type type, boolean autoValidation) {
		boolean result = false;
		if (autoValidation && type.getControlRequired() != 0 && !type.isPendingDocument() && TypeControls.OK.name().equals(type.getStatusControl()) && TypeControls.OK.name().equals(type.getCompletenessControl())) {
			result = true;
		}
		return result;
	}

	public boolean isEligibleForAutoAcceptation(Type type, boolean autoAcceptation, int maxIterationAllowed) {
		boolean result = false;
		// Auto-acceptation si collecte éligible (autoAcceptation à true), type à KO/ERR et au moins une pièce a atteint le nombre max d'itérations autorisées
		if (autoAcceptation && type.getControlRequired() != 0 && (Arrays.asList(TypeControls.KO.name(), TypeControls.ERR.name()).contains(type.getStatusControl()) || !type.getCompletenessControl().equals(TypeControls.OK.name()))
				&& type.getActivePieces().stream().anyMatch(piece -> piece.getControlIterationAchieved() >= maxIterationAllowed)) {
			result = true;
		}
		return result;
	}

	public void calculateIndicators(final Type type) {
		final List<EdocType> edocTypes = edocTypeRepository.findAll();
		final List<Nomenclature> nomenclatures = nomenclatureService.findAll();
		final List<EdocIndex> edocIndexes = edocIndexRepository.findAll();
		// Calcul des indicateurs des indexes
		ladRadValidator.calculateStatusIndexes(type, edocIndexes);
		// Calcul des indicateurs des pièces
		type.getActivePieces().forEach(pieceIdx -> ladRadValidator.calculateIndicatorsPieces(pieceIdx, type, edocTypes, edocIndexes));
		// Calcul des indicateurs du type
		ladRadValidator.calculateIndicatorsType(type, edocTypes);
		// Formatter les retours de nomenclature
		typeValidator.convertTypesExtractedIndexToEdoc(type.getIndexes(), nomenclatures);
	}

	public void extractIndexesPiece(UUID collectId, Type type, List<Indexe> indexesForAnOwner, String ownerIndex, Map<UUID, StatusDocumentDTO> listStatusDocumentJMC, String documentSet, boolean isSecondOrAfter) {
		if (type.getControlRequired() == ControlRequired.CONTROL_JMC.getCode()) {
			if (!DocumentSet.FREE_SET.getLabel().equals(documentSet) || isSecondOrAfter) {
				typeLadRadService.analyseFolder(type.getId(), ownerIndex);
			}
			type.getActivePieces().forEach(pieceIdx -> typeLadRadService.extractValuesAndControls(collectId, type, indexesForAnOwner, ownerIndex, pieceIdx, listStatusDocumentJMC.get(pieceIdx.getId())));
		}
	}

	public void initControlIterationAchieved(Type type) {
		// Incrémentation du nombre d'itérations suite à la première itération
		type.getActivePieces().forEach(piece -> {
			if (piece.getControlIterationAchieved() == 0) {
				piece.setControlIterationAchieved(1);
			}
		});
		type.setStatusControl(TypeControls.EC.name());
	}

	public void initStatusEventAMI(Type type, UUID collectId, Context context, Collect collect) {

		type.setStatusControl(TypeControls.EC_AMI.name());
		typeRepository.updateStatusControl(type.getId(), type.getStatusControl());
		sendEventPostAMI(collect, type.getId().toString(), context);

	}

	private void sendEventPostAMI(Collect collect, String typeId, Context context) {
		final EventSendAMI eventSendAMI = new EventSendAMI();
		eventSendAMI.setChannel(context.getCanal());
		eventSendAMI.setCollect(collect);
		eventSendAMI.setMedia(context.getMedia());
		eventSendAMI.setNomenclatureRef(TypeReceivedType.SEND_TO_AMI.getLabel()); // n° event
		eventSendAMI.setTypeId(typeId);
		eventSendAMI.setColledId(collect.getId().toString());
		eventSendAMI.setUserId(context.getCustomerId());
		collectEventHandler.sendEventAMI(eventSendAMI);
	}

	public String findDocumentSetFromType(Type type) {
		final List<EdocType> edocTypes = edocTypeRepository.findAll();
		return edocTypes.stream().filter(edocTypeL -> edocTypeL.getValue().equals(type.getEdocType())).findAny().map(EdocType::getDocumentSet).orElse(DocumentSet.JMC_SET.getLabel());
	}

	private String computeExternalRef(UUID id, String ownerIndex) {
		return id.toString() + "-" + ownerIndex;
	}

	public StatusDocumentDTO verifyStatusDocument(Piece piece, String ownerIndex, UUID typeId, String documentSet, Long startFirstCall) {
		final String externalRefPiece = computeExternalRef(piece.getId(), ownerIndex);

		final long loopTime = Long.parseLong(environment.getProperty(WAITING_PERIOD_LOOP_PREFIX + documentSet));
		final long maxDuration = Long.parseLong(environment.getProperty(MAX_DURATION + documentSet));
		Long startEachCall;
		long durationLastCallWS = 0L;
		long waitEachCall;
		StatusDocumentDTO statusDocument = ladRadRepository.getStatusDocument(externalRefPiece, typeId);
		String status = getDocumentStatusFromDocumentSet(piece, documentSet, statusDocument);
		if (listRejectedCode.contains(status)) {
			throw new TechnicalException("REJECTED CODE JMC", externalRefPiece);
		}
		if (!getSuccess(status, documentSet) || statusDocument.getTotalPages() < 1) {
			while ((System.currentTimeMillis() - startFirstCall) <= maxDuration) {
				startEachCall = System.currentTimeMillis();
				if (loopTime > durationLastCallWS) {
					waitEachCall = loopTime - durationLastCallWS;
				} else {
					waitEachCall = loopTime;
				}
				try {
					Thread.sleep(waitEachCall);
				} catch (final InterruptedException e) {
					LOGGER.error(e.getMessage(), e);
				}

				statusDocument = ladRadRepository.getStatusDocument(externalRefPiece, typeId);
				status = getDocumentStatusFromDocumentSet(piece, documentSet, statusDocument);
				logStatusDocument(externalRefPiece, status);
				if (listRejectedCode.contains(status)) {
					throw new TechnicalException("REJECTED CODE JMC", externalRefPiece);
				}
				if (getSuccess(status, documentSet) && statusDocument.getTotalPages() > 0) {
					break;
				}
				durationLastCallWS = System.currentTimeMillis() - startEachCall;
			}
			if (!getSuccess(status, documentSet)) {
				ladRadRepository.traceCallWS(externalRefPiece, typeId, RequestWSJMCType.GET_STATUS_DOCUMENT, HttpStatus.NO_CONTENT, "TimeOut Upload JMC", null, null);
				throw new TechnicalException(HttpStatus.REQUEST_TIMEOUT, CollectErrorConstants.ERR_ACCES_LADRAD_TECH, externalRefPiece);
			}
		}
		return statusDocument;
	}

	public Map<UUID, StatusDocumentDTO> verifyStatusDocuments(List<Piece> pieces, String ownerIndex, UUID typeId, String documentSet) {
		final Map<UUID, StatusDocumentDTO> listStatusDocumentJMC = new HashMap<>();
		final long initialTime = Long.parseLong(environment.getProperty(WAITING_PERIOD_INIT_PREFIX + documentSet));
		final Long startFirstCall = System.currentTimeMillis();
		try {
			Thread.sleep(initialTime);
		} catch (final InterruptedException e) {
			LOGGER.error(e.getMessage(), e);
		}
		if (documentSet.startsWith("AMI") && CollectionUtils.isNotEmpty(pieces)) {
			Collections.sort(pieces);
			final Piece piece = pieces.get(0);
			// On se base sur la première pièce, celle qui a porté le postAmi, pour détecter la fin du traitement JMC (status=2)
			final StatusDocumentDTO statusDocumentInit = verifyStatusDocument(piece, ownerIndex, typeId, documentSet, startFirstCall);
			checkIfNoPage(statusDocumentInit);
			listStatusDocumentJMC.put(piece.getId(), statusDocumentInit);
			// On récupère quand meme le statusDocument des autres pièces pour calculer les indicateurs
			pieces.stream().filter(currentPiece -> !piece.getId().toString().equals(currentPiece.getId().toString())).forEach(currentPiece -> {
				final String externalRefPiece = computeExternalRef(currentPiece.getId(), ownerIndex);
				final StatusDocumentDTO statusDocument = ladRadRepository.getStatusDocument(externalRefPiece, typeId);
				checkIfNoPage(statusDocument);
				listStatusDocumentJMC.put(currentPiece.getId(), statusDocument);
			});
		} else {
			pieces.forEach(piece -> {
				final StatusDocumentDTO statusDocument = verifyStatusDocument(piece, ownerIndex, typeId, documentSet, startFirstCall);
				checkIfNoPage(statusDocument);
				listStatusDocumentJMC.put(piece.getId(), statusDocument);
			});
		}
		return listStatusDocumentJMC;
	}

	private void checkIfNoPage(StatusDocumentDTO statusDocument) {
		if (CollectionUtils.isEmpty(statusDocument.getPages())) {
			throw new TechnicalException(CollectErrorConstants.ERR_TECH_JMC_NO_PIECE);
		}

	}

	public boolean getSuccess(String status, String documentSet) {
		if (DocumentSet.FREE_SET.getLabel().equals(documentSet)) {
			return StatusDocument.NOT_ANAYLSED.getLabel().equals(status);
		} else {
			return StatusDocument.ANALYSIS_SUCCESS.getLabel().equals(status);
		}
	}

	private void logStatusDocument(final String externalRefPiece, String status) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("The status of Document JMC {} is {} ", externalRefPiece, status);
		}
	}

	public String getDocumentStatusFromDocumentSet(Piece piece, String documentSet, StatusDocumentDTO statusDocument) {
		String status = "";
		if (DocumentSet.MIDW_SET.getLabel().equals(documentSet)) {
			status = statusDocument.getDifferedTimeStatus();
		} else if (piece.getControlIterationAchieved() == 9) {
			// Si pièce envoyée à AMI, la fin du traitement est indiqué dans differedTimeStatusList
			if (Optional.ofNullable(statusDocument.getDifferedTimeStatusList()).isPresent() && Optional.ofNullable(statusDocument.getDifferedTimeStatusList().findValue("status")).isPresent()) {
				status = statusDocument.getDifferedTimeStatusList().findValue("status").asText();
			} else {
				status = StatusDocument.ANALYSIS_IN_PROGRESS.getLabel();
			}
		} else {
			// FREE_Set et JMC_SET sans AMI
			status = statusDocument.getStatus();
		}
		return status;
	}

	public CollectRepository getCollectRepository() {
		return collectRepository;
	}

	public void setCollectRepository(CollectRepository collectRepository) {
		this.collectRepository = collectRepository;
	}

	public TypeRepository getTypeRepository() {
		return typeRepository;
	}

	public void setTypeRepository(TypeRepository typeRepository) {
		this.typeRepository = typeRepository;
	}

	public DocReferenceService getDocReferenceService() {
		return docReferenceService;
	}

	public void setDocReferenceService(DocReferenceService docReferenceService) {
		this.docReferenceService = docReferenceService;
	}

	public FeatureManager getFeatureManager() {
		return featureManager;
	}

	public void setFeatureManager(FeatureManager featureManager) {
		this.featureManager = featureManager;
	}

	public AuditEventService getAuditEventService() {
		return auditEventService;
	}

	public void setAuditEventService(AuditEventService auditEventService) {
		this.auditEventService = auditEventService;
	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

	public TypeLadRadService getTypeLadRadService() {
		return typeLadRadService;
	}

	public void setTypeLadRadService(TypeLadRadService typeLadRadService) {
		this.typeLadRadService = typeLadRadService;
	}

	public EdocTypeRepository getEdocTypeRepository() {
		return edocTypeRepository;
	}

	public void setEdocTypeRepository(EdocTypeRepository edocTypeRepository) {
		this.edocTypeRepository = edocTypeRepository;
	}

	public EdocIndexRepository getEdocIndexRepository() {
		return edocIndexRepository;
	}

	public void setEdocIndexRepository(EdocIndexRepository edocIndexRepository) {
		this.edocIndexRepository = edocIndexRepository;
	}

	public LadRadValidator getLadRadValidator() {
		return ladRadValidator;
	}

	public void setLadRadValidator(LadRadValidator ladRadValidator) {
		this.ladRadValidator = ladRadValidator;
	}

	public NomenclatureService getNomenclatureService() {
		return nomenclatureService;
	}

	public void setNomenclatureService(NomenclatureService nomenclatureService) {
		this.nomenclatureService = nomenclatureService;
	}

	public TypeValidator getTypeValidator() {
		return typeValidator;
	}

	public void setTypeValidator(TypeValidator typeValidator) {
		this.typeValidator = typeValidator;
	}

	public LadRadRepository getLadRadRepository() {
		return ladRadRepository;
	}

	public void setLadRadRepository(LadRadRepository ladRadRepository) {
		this.ladRadRepository = ladRadRepository;
	}

}
