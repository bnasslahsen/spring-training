package com.bnpparibas.bddf.collect.domain.collect;

public enum PiecesManagmentAct {
	DP("Déposer"), RC("Recueillir"), VA("Valider"), RF("Refuser");

	private String label;

	PiecesManagmentAct(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}
}
