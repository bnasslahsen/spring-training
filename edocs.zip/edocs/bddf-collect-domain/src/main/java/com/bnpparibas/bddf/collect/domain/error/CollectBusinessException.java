package com.bnpparibas.bddf.collect.domain.error;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditEvent;
import com.bnpparibas.bddf.errors.BusinessException;

public class CollectBusinessException extends BusinessException {

	private static final long serialVersionUID = 1L;

	private final AuditEvent auditEvent;

	public CollectBusinessException(Builder builder) {
		super(builder);
		this.auditEvent = null;
	}

	public CollectBusinessException(AuditEvent auditEvent, Builder builder) {
		super(builder);
		this.auditEvent = auditEvent;
	}

	public AuditEvent getAuditEvent() {
		return auditEvent;
	}

}
