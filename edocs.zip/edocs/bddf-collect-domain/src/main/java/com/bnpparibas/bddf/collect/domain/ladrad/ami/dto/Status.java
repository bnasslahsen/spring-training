
package com.bnpparibas.bddf.collect.domain.ladrad.ami.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "href" })
public class Status {

	@JsonProperty("href")
	private String href;

	public Status() {
	}

	public Status(String href) {
		this.href = href;
	}

	@JsonProperty("href")
	public String getHref() {
		return href;
	}

	@JsonProperty("href")
	public void setHref(String href) {
		this.href = href;
	}

}
