package com.bnpparibas.bddf.collect.domain.type;

import java.nio.ByteBuffer;
import java.util.List;
import java.util.UUID;

import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Repository
public interface TypeLadRadService {

	void extractValuesAndControls(UUID collectId, Type type, List<Indexe> indexesForAnOwner, String ownerIndex, Piece piece, StatusDocumentDTO statusDocument);

	void uploadDocument(UUID collectId, String journeyCode, Type type, List<Indexe> indexesForAnOwner, String ownerIndex, Piece piece, ByteBuffer pieceData, String documentSet);

	void createFolderIfNotExists(Type type, List<Indexe> indexesForAnOwner, String ownerIndex, String documentSet, String journeyCode);

	void analyseFolder(UUID typeId, String ownerIndex);

	void createAndForceJmcPiece(Type updatedType, String ownerIndex);

	void updateIndexOfJmcPiece(final Type updatedType, String ownerIndex);

}
