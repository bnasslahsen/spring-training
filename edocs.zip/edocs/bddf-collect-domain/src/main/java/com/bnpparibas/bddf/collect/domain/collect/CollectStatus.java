package com.bnpparibas.bddf.collect.domain.collect;

public enum CollectStatus {
	EC(1, "En cours"), AB(2, "Abandonné"), CL(3, "Clos");

	private int code;
	private String label;

	CollectStatus(int code, String label) {
		this.code = code;
		this.label = label;

	}

	public int getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}

}
