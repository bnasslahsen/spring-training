package com.bnpparibas.bddf.collect.domain.type;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.bnp.schema.edoc.index.Indexes.EdocIndex;
import com.bnp.schema.edoc.type.Types;
import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnp.schema.edoc.type.Types.EdocType.PiecesEdoc;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectStatus;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.helper.DateUtil;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceIndicators;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.TypeControls;
import com.bnpparibas.bddf.collect.domain.nomenclature.Nomenclature;
import com.bnpparibas.bddf.collect.domain.piece.PieceRecivedFormat;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.errors.BusinessException.Builder;

/**
 *
 * Cette classe présente les implémentations des contrôles demandés au niveau Type et Famille.
 *
 * Ces contrôles sont invoqués principalement par les service postCollect, addFamily, addType et updateType.
 *
 * @author c07130
 *
 */

@Component
public class TypeValidator {

	private static final String ND = "ND";

	private static final String B = "B";

	@Autowired
	private Environment env;
	@Autowired
	private CollectValidator collectValidator;

	public void validateType(Type type, List<EdocType> edocTypes, Collect collect, boolean sendToLadRadEnabled) {
		validateTypeWithEdocType(type, edocTypes, collect, sendToLadRadEnabled);
		validateTypeFieldsSize(type);
	}

	private void validateTypeWithEdocType(Type type, List<EdocType> edocTypes, Collect collect, boolean sendToLadRadEnabled) {
		validateEdocType(type, edocTypes);
		validateEnableReuse(type, collect, sendToLadRadEnabled);
		validatePaperAllowed(type);
		initTypeVideoCodingDelay(type, sendToLadRadEnabled);
		validateTypeVideoCodingDelay(type, sendToLadRadEnabled);
	}

	private void validateEnableReuse(Type type, Collect collect, boolean sendToLadRadEnabled) {
		if (!type.isDigitalAllowed() && type.isEnableReuse()) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_REUSE_FORBIDEN, type.getId().toString(), type.getLabel()));
		}
		if (type.getControlRequired() != 0 && type.isEnableReuse()) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_AUTO_REUSE_FORBIDDEN, type.getLabel()));
		}
		if (!sendToLadRadEnabled && ControlRequired.CONTROL_JMC.getCode() == type.getControlRequired()) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_UNAUTHORIZED_LADRAD, collect.getJourneyCode()));
		}
	}

	private void validateEdocType(Type type, List<EdocType> edocTypes) {
		if (StringUtils.isNotEmpty(type.getEdocType()) && !edocTypes.stream().map(EdocType::getValue).anyMatch(type.getEdocType()::equals)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_EDOC_UNKOWN, type.getEdocType()));
		}
		if (type.isDigitalAllowed() && StringUtils.isEmpty(type.getEdocType())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_EDOC_MANDATORY, type.getId().toString(), type.getLabel()));
		}
		if (type.isDigitalAllowed() && type.getControlRequired() != 0 && edocTypes.stream().filter(edt -> edt.getValue().equals(type.getEdocType())).findAny().map(EdocType::getJmcType).map(StringUtils::isEmpty).orElse(false)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_JMC_MANDATORY, type.getEdocType()));
		}
	}

	public void validateUpdatedType(Type updatedType, Type existingType) {
		validateKnownTypeStatus(updatedType, existingType);
		validateTypeWithNoPieces(updatedType, existingType);
		if (!isDevalidationBO(updatedType)) {
			validateUpdatedType(existingType);
		}
		validateTypeWithValidatedPieces(updatedType, existingType);
		validateTypeWithRefusedPieces(updatedType);
		validateTypeWithPendingDocument(updatedType);
		validateTypeWithPendingDocumentAndMaxPieces(updatedType);
		controlValidatedType(updatedType, existingType);
	}

	public void controlValidatedType(Type updatedType, Type existingType) {
		if (existingType.getControlRequired() == ControlRequired.CONTROL_JMC.getCode() && existingType.getActivePieces().stream().allMatch(piece -> piece.getReceivedFormat().equals(PieceRecivedFormat.NUM.name()))) {
			// RG 177
			if (Arrays.asList(TypeStatus.VA.getLabel(), TypeStatus.RC.getLabel()).contains(updatedType.getStatus())) {
				existingType.getActivePieces().forEach(piece -> {
					if (!PieceIndicators.OK.name().equals(piece.getTypeControl())
							&& !updatedType.getActivePieces().stream().filter(modifiedPiece -> modifiedPiece.equals(piece)).allMatch(modifiedPiece -> PieceIndicators.OK_MAN.name().equals(modifiedPiece.getTypeControl()))) {
						throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_UNKNOWN_PIECE, piece.getId().toString(), piece.getLabel()));
					}
				});
			}
			// RG 178
			existingType.getActivePieces().forEach(piece -> {
				if (piece.getTypeControl() != null && !PieceIndicators.KO_UNK.name().equals(piece.getTypeControl()) && !PieceIndicators.OK_MAN.name().equals(piece.getTypeControl())
						&& updatedType.getActivePieces().stream().filter(modifiedPiece -> modifiedPiece.equals(piece)).anyMatch(modifiedPiece -> PieceIndicators.OK_MAN.name().equals(modifiedPiece.getTypeControl()))) {
					throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_UNAUTHORIZED_OK_MAN, piece.getId().toString(), piece.getLabel()));
				}
			});
		}
	}

	private void validateTypeWithPendingDocument(Type updatedType) {
		if (updatedType.isPendingDocument()) {
			if (StringUtils.isEmpty(updatedType.getPendingDocumentLabel())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_PENDING_COMMENT)); // RG 73
			}
			if (StringUtils.isNotEmpty(updatedType.getPendingDocumentProfile()) && Arrays.stream(Profile.values()).noneMatch(profile -> profile.getLabel().equals(updatedType.getPendingDocumentProfile()))) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_INCORRECT_PENDING_DOCUMENT_PROFILE, updatedType.getPendingDocumentProfile(), updatedType.getLabel())); // RG 236
			}
		}

	}

	private void validateTypeWithPendingDocumentAndMaxPieces(Type updatedType) {
		if (updatedType.getPieces().size() >= 5 && (updatedType.isPendingDocument())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_SIGNAL_DOC_MANQUANT)); // RG 268
		}

	}

	private void validateTypeWithValidatedPieces(Type updatedType, Type existingType) {
		if (TypeStatus.VA.getLabel().equals(updatedType.getStatus()) && updatedType.getActivePieces() != null && (updatedType.isPendingDocument() || !updatedType.getActivePieces().stream().allMatch(p -> PieceStatus.VA.getLabel().equals(p.getStatus())))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_STATUS_NOT_ALLOWED, updatedType.getStatus(), existingType.getId().toString(), existingType.getLabel()));
		}
		// RG120
		if (TypeStatus.RC.getLabel().equals(updatedType.getStatus()) && updatedType.getActivePieces() != null
				&& (updatedType.isPendingDocument() || !updatedType.getActivePieces().stream().allMatch(p -> PieceStatus.RC.getLabel().equals(p.getStatus()) || PieceStatus.VA.getLabel().equals(p.getStatus())))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_STATUS_NOT_ALLOWED, updatedType.getStatus(), existingType.getId().toString(), existingType.getLabel()));
		}
	}

	private void validateTypeWithRefusedPieces(Type updatedType) {
		updatedType.getPieces().stream().filter(updatedPiece -> PieceStatus.RF.name().equals(updatedPiece.getStatus()) && PieceStates.ACTIF.getLabel().equals(updatedPiece.getState())).forEach(updatedPiece -> {
			if (StringUtils.isNotEmpty(updatedPiece.getRejectionProfile()) && Arrays.stream(Profile.values()).noneMatch(profile -> profile.getLabel().equals(updatedPiece.getRejectionProfile()))) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_INCORRECT_REJECTION_PROFILE, updatedPiece.getRejectionProfile(), updatedPiece.getLabel())); // RG 236
			}
		});
	}

	private void validateUpdatedType(Type existingType) {
		// RG101
		if (Arrays.asList(TypeStatus.VA.getLabel(), TypeStatus.VA_AUTO.getLabel()).contains(existingType.getStatus())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UPDATE_UNAUTHORIZED, existingType.getStatus(), existingType.getId().toString(), existingType.getLabel()));
		}
	}

	public boolean isDevalidationBO(Type updatedType) {
		return updatedType.getActivePieces().stream().anyMatch(updatedPiece -> PieceStatus.RF.name().equals(updatedPiece.getStatus()) && !Profile.FO.getLabel().equals(updatedPiece.getRejectionProfile()))
				|| (BooleanUtils.isTrue(updatedType.isPendingDocument()) && !Profile.FO.getLabel().equals(updatedType.getPendingDocumentProfile()));
	}

	private void validateTypeWithNoPieces(Type updatedType, Type existingType) {
		// RG153
		if ((TypeStatus.VA.getLabel().equals(updatedType.getStatus()) || TypeStatus.RC.getLabel().equals(updatedType.getStatus())) && CollectionUtils.isEmpty(existingType.getActivePieces())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_VA_INCORRECT_NO_FILE, updatedType.getStatus()));
		}
	}

	public void validateTypeWithPiecesErrorGDN(Type existingType) {
		// RG153
		if (existingType.getActivePieces().stream().anyMatch(p -> Arrays.asList(PieceStatus.DP_EC.getLabel(), PieceStatus.DP_ERR.getLabel()).contains(p.getStatus()))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_VERSEMENT_GDN));
		}
	}

	private void validateKnownTypeStatus(Type updatedType, Type existingType) {
		if (StringUtils.isNotEmpty(updatedType.getStatus()) && !Arrays.asList(TypeStatus.IN.getLabel(), TypeStatus.RC.getLabel(), TypeStatus.VA.getLabel()).contains(updatedType.getStatus())
				&& !(TypeStatus.RC_AUTO.getLabel().equals(updatedType.getStatus()) && TypeStatus.RC_AUTO.getLabel().equals(existingType.getStatus()))
				&& !(TypeStatus.VA_AUTO.getLabel().equals(updatedType.getStatus()) && TypeStatus.VA_AUTO.getLabel().equals(existingType.getStatus()))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNKNOWN_ACTION, updatedType.getStatus(), updatedType.getId().toString(), updatedType.getLabel()));
		}
	}

	private void validatePaperAllowed(Type type) {
		if (!type.isDigitalAllowed() && !type.isPaperAllowed()) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_NO_ALLOWED_CHOSEN, type.getId().toString(), type.getLabel()));
		}

	}

	public void validateSubTypeIndexes(Type type, List<EdocIndex> edocIndexes, Set<Type> types) {
		// si type contient des subtypes et contient aussi des indexes
		if (!type.getIndexes().isEmpty() && isTypeWithSubType(types, type)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_TYPE_UNAUTHORIZED_INDEX, type.getLabel()));

		}
	}

	public void validateSubTypeCompleteness(Type type, List<EdocIndex> edocIndexes, Set<Type> types) {
		// si type contient des subtypes et contient aussi des indexes
		if (!CollectionUtils.isEmpty(type.getCompleteness()) && isTypeWithSubType(types, type)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_TYPE_UNAUTHORIZED_COMPLETENESS, type.getLabel()));

		}
	}

	private boolean isTypeWithSubType(Set<Type> types, Type type) {
		return type.getParentId() == null && types.stream().anyMatch(subType -> type.getId().equals(subType.getParentId()));

	}

	public void validateTypeIndexes(Type type, List<EdocIndex> edocIndexes) {
		final List<String> indexCodes = edocIndexes.stream().map(EdocIndex::getCode).collect(Collectors.toList());
		if (!type.getIndexes().isEmpty()) {
			type.getIndexes().stream().map(Indexe::getCode).filter(StringUtils::isNotEmpty).forEach(indexCode -> {
				if (!indexCodes.contains(indexCode)) {
					throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNKNOWN_INDEX, indexCode));
				}
			});
		}
	}

	public void validateTypeCompleteness(Type type, List<EdocType> edocTypes, Set<Type> types) {
		final List<String> completenessCodes = new ArrayList<>();
		if (type.getCompleteness() != null) {
			edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && edocT.getValue().equals(type.getEdocType())).forEach(edocT -> edocT.getPiecesEdoc().getPiece().forEach(p -> completenessCodes.add(p.getPieceCode())));
			type.getCompleteness().stream().filter(StringUtils::isNotEmpty).forEach(comp -> {
				if (!completenessCodes.contains(comp)) {
					final String labelPiece = edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && edocT.getPiecesEdoc().getPiece() != null).flatMap(edocT -> edocT.getPiecesEdoc().getPiece().stream())
							.filter(piece -> piece.getPieceCode() != null && piece.getPieceCode().equals(comp)).findAny().map(Types.EdocType.PiecesEdoc.Piece::getPieceLabel).orElse("<not found>");
					final Optional<EdocType> edocTypeAutOpt = edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && edocT.getPiecesEdoc().getPiece() != null)
							.filter(edocT -> edocT.getPiecesEdoc().getPiece().stream().anyMatch(p -> p.getPieceCode().equals(comp))).findFirst();
					final String authorizedEdocCode = edocTypeAutOpt.map(EdocType::getValue).orElse("<none>");
					final String authorizedEdocLabel = edocTypeAutOpt.map(EdocType::getLabel).orElse("<none>");

					throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNKNOWN_COMPLETENESS, comp, labelPiece, type.getEdocType(), authorizedEdocCode, authorizedEdocLabel));
				}
			});
		}
	}

	public void validateTypeControlRequired(Type type, Set<Type> types) {
		if (!Arrays.asList(0, 1, 2, 3, 9, 10).contains(type.getControlRequired())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNKNOWN_INDEX_CONTROL_REQUIRED, String.valueOf(type.getControlRequired()), type.getId().toString(), type.getLabel()));
		}
		if (type.getControlRequired() > 1 && (type.getIndexes().isEmpty() || !type.getIndexes().stream().anyMatch(ind -> !IndexCategory.ND.name().equals(ind.getCategory()))) && !isTypeWithSubType(types, type)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_EMPTY_INDEX, type.getId().toString(), type.getLabel()));
		}
	}

	public void validateTypeIndexCategory(Type type) {
		final List<String> indexCategories = Arrays.stream(IndexCategory.values()).map(IndexCategory::name).collect(Collectors.toList());
		if (!type.getIndexes().isEmpty()) {
			type.getIndexes().stream().forEach(index -> {
				if (!indexCategories.contains(index.getCategory())) {
					throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNKNOWN_INDEX_CATEGORY, index.getCategory(), index.getLabel()));
				}
			});
		}
	}

	public void updateIndexesType(Type type, Type updatedType, List<EdocIndex> edocIndexes, List<Nomenclature> nomenclatures, int controlIterationAllowed) {
		initTypeIndexFormatAndSize(updatedType, edocIndexes);
		// RG147
		validateUpdateIndexes(type, updatedType, controlIterationAllowed);
		// RG148
		validateTypeIndexCorrectedValueFormat(updatedType, edocIndexes);
		// RG149
		validateNonEmptyIndex(type, updatedType);
		validateTypeIndexCorrectedNomenclature(updatedType, nomenclatures);
	}

	private void validateUpdateIndexes(final Type type, final Type updatedType, int controlIterationAllowed) {
		if ((type.getControlRequired() == ControlRequired.CONTROL_JMC.getCode() && !type.isPendingDocument())
				&& (!type.getActivePieces().stream().allMatch(piece -> piece.getControlIterationAchieved() > 0 && !Arrays.asList(PieceStatus.RF.name(), PieceStatus.SU.name()).contains(piece.getStatus()))
						|| !type.getActivePieces().stream().allMatch(piece -> piece.getControlIterationAchieved() < controlIterationAllowed)
						|| !updatedType.getActivePieces().stream().allMatch(piece -> Arrays.asList(PieceIndicators.OK.name(), PieceIndicators.OK_MAN.name()).contains(piece.getTypeControl())))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_UNAUTHORIZED_AUTOMATIC_CONTROL, type.getId().toString(), type.getLabel()));
		}
	}

	public void validateTypeVideoCodingDelay(Type type, boolean sendToLadRadEnabled) {
		if (sendToLadRadEnabled && ControlRequired.CONTROL_JMC.getCode() == type.getControlRequired()
				&& !Arrays.asList(VideoCodingDelay.IMMEDIATE.getCode(), VideoCodingDelay.DELAYED.getCode(), VideoCodingDelay.NOT_ALLOWED.getCode()).contains(type.getVideoCodingDelay())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DATA_VALUE, "videoCodingDelay", type.getVideoCodingDelay()));
		}
	}

	public void initTypeVideoCodingDelay(Type type, boolean sendToLadRadEnabled) {
		if (sendToLadRadEnabled && ControlRequired.CONTROL_JMC.getCode() == type.getControlRequired() && StringUtils.isEmpty(type.getVideoCodingDelay())) {
			type.setVideoCodingDelay(VideoCodingDelay.NOT_ALLOWED.getCode());
		}
	}

	public void validateTypeIndexCorrectedValueFormat(Type type, List<EdocIndex> edocIndexes) {
		if (!type.getIndexes().isEmpty()) {
			validateTypeIndexCorrectedValueDateFormat(type, edocIndexes);
			validateTypeIndexCorrectedValueNumericFormat(type, edocIndexes);
			validateTypeIndexCorrectedValueBooleanFormat(type, edocIndexes);
			validateTypeIndexCorrectedValueSizeFormat(type);
		}
	}

	private void validateTypeIndexCorrectedValueSizeFormat(Type type) {
		type.getIndexes().stream().filter(index -> index.getMaxSize() > 0).forEach(index -> {
			if (StringUtils.isNotEmpty(index.getCorrectedValue()) && (index.getCorrectedValue().length() > index.getMaxSize() || index.getCorrectedValue().length() < index.getMinSize())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNKNOWN_INDEX_CORRECTED_FORMAT, index.getCode(), index.getLabel()));
			}
		});
	}

	private void validateTypeIndexCorrectedValueBooleanFormat(Type type, List<EdocIndex> edocIndexes) {
		final List<String> booleanIndexCodes = edocIndexes.stream().filter(edoc -> IndexFormat.B.name().equals(edoc.getFormat())).map(EdocIndex::getCode).collect(Collectors.toList());
		type.getIndexes().stream().forEach(index -> {
			if (StringUtils.isNotEmpty(index.getCorrectedValue()) && booleanIndexCodes.contains(index.getCode()) && !"TRUE".equalsIgnoreCase(index.getCorrectedValue()) && !"FALSE".equalsIgnoreCase(index.getCorrectedValue())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNKNOWN_INDEX_CORRECTED_FORMAT, index.getCode(), index.getLabel()));
			}
		});
	}

	private void validateTypeIndexCorrectedValueNumericFormat(Type type, List<EdocIndex> edocIndexes) {
		final List<String> numericIndexCodes = edocIndexes.stream().filter(edoc -> IndexFormat.N.name().equals(edoc.getFormat())).map(EdocIndex::getCode).collect(Collectors.toList());
		type.getIndexes().stream().forEach(index -> {
			if (StringUtils.isNotEmpty(index.getCorrectedValue()) && numericIndexCodes.contains(index.getCode()) && !index.getCorrectedValue().matches("\\p{Digit}+")) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNKNOWN_INDEX_CORRECTED_FORMAT, index.getCode(), index.getLabel()));
			}
		});
	}

	private void validateTypeIndexCorrectedValueDateFormat(Type type, List<EdocIndex> edocIndexes) {
		final List<String> datesIndexCodes = edocIndexes.stream().filter(edoc -> IndexFormat.D.name().equals(edoc.getFormat())).map(EdocIndex::getCode).collect(Collectors.toList());
		type.getIndexes().stream().forEach(index -> {
			if (StringUtils.isNotEmpty(index.getCorrectedValue()) && datesIndexCodes.contains(index.getCode()) && !DateUtil.isFormatDateValid(index.getCorrectedValue())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNKNOWN_INDEX_CORRECTED_FORMAT, index.getCode(), index.getLabel()));
			}
		});
	}

	public void validateNonEmptyIndex(Type type, Type updatedType) {
		if (!updatedType.isGroupIndexesValidation()) {
			type.getIndexes().stream().filter(index -> index.isIndexable() && IndexCategory.OB.name().equals(index.getCategory())).forEach(index -> {
				if (StringUtils.isEmpty(index.getExtractedValue()) && StringUtils.isEmpty(updatedType.getIndexes().stream().filter(updatedIndex -> updatedIndex.equals(index)).findAny().get().getCorrectedValue())) {
					throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_INDEX_UNAUTHORIZED_UPDATE, index.getCode(), index.getLabel()));
				}
			});
		}
	}

	public void validateTypeIndexReferenceFormat(Type type, List<EdocIndex> edocIndexes) {
		if (!type.getIndexes().isEmpty()) {
			validateTypeIndexReferenceValueDateFormat(type, edocIndexes);
			validateTypeIndexReferenceValueNumericFormat(type, edocIndexes);
			validateTypeIndexReferenceValueBooleanFormat(type, edocIndexes);
			validateTypeIndexReferenceValueSizeFormat(type);
		}
	}

	private void validateTypeIndexReferenceValueSizeFormat(Type type) {
		type.getIndexes().stream().filter(index -> index.getMaxSize() > 0).forEach(index -> {
			if (StringUtils.isNotEmpty(index.getReferenceValue()) && (index.getReferenceValue().length() > index.getMaxSize() || index.getReferenceValue().length() < index.getMinSize())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNKNOWN_INDEX_REFERENCE_FORMAT, index.getReferenceValue(), index.getCode(), index.getLabel()));
			}
		});
	}

	private void validateTypeIndexReferenceValueBooleanFormat(Type type, List<EdocIndex> edocIndexes) {
		final List<String> booleanIndexCodes = edocIndexes.stream().filter(edoc -> IndexFormat.B.name().equals(edoc.getFormat())).map(EdocIndex::getCode).collect(Collectors.toList());
		type.getIndexes().stream().forEach(index -> {
			if (StringUtils.isNotEmpty(index.getReferenceValue()) && booleanIndexCodes.contains(index.getCode()) && !"TRUE".equalsIgnoreCase(index.getReferenceValue()) && !"FALSE".equalsIgnoreCase(index.getReferenceValue())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNKNOWN_INDEX_REFERENCE_FORMAT, index.getReferenceValue(), index.getCode(), index.getLabel()));
			}
		});
	}

	private void validateTypeIndexReferenceValueNumericFormat(Type type, List<EdocIndex> edocIndexes) {
		final List<String> numericIndexCodes = edocIndexes.stream().filter(edoc -> IndexFormat.N.name().equals(edoc.getFormat())).map(EdocIndex::getCode).collect(Collectors.toList());
		type.getIndexes().stream().forEach(index -> {
			if (StringUtils.isNotEmpty(index.getReferenceValue()) && numericIndexCodes.contains(index.getCode()) && !index.getReferenceValue().matches("\\p{Digit}+")) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNKNOWN_INDEX_REFERENCE_FORMAT, index.getReferenceValue(), index.getCode(), index.getLabel()));
			}
		});
	}

	private void validateTypeIndexReferenceValueDateFormat(Type type, List<EdocIndex> edocIndexes) {
		final List<String> datesIndexCodes = edocIndexes.stream().filter(edoc -> IndexFormat.D.name().equals(edoc.getFormat())).map(EdocIndex::getCode).collect(Collectors.toList());
		type.getIndexes().stream().forEach(index -> {
			if (StringUtils.isNotEmpty(index.getReferenceValue()) && datesIndexCodes.contains(index.getCode()) && !DateUtil.isFormatDateValid(index.getReferenceValue())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNKNOWN_INDEX_REFERENCE_FORMAT, index.getReferenceValue(), index.getCode(), index.getLabel()));
			}
		});
	}

	public void validateTypeIndexList(Type type, List<EdocType> edocTypes) {
		if (!CollectionUtils.isEmpty(type.getIndexes()) && StringUtils.isNotEmpty(type.getEdocType())) {
			final Set<String> authorizedIndexCodes = edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && edocT.getValue().equals(type.getEdocType())).flatMap(edocT -> edocT.getPiecesEdoc().getPiece().stream())
					.filter(pieceJmc -> pieceJmc.getIndexes() != null).flatMap(pieceJmc -> pieceJmc.getIndexes().getIndex().stream()).collect(Collectors.toSet());
			type.getIndexes().stream().forEach(index -> {
				if (!authorizedIndexCodes.contains(index.getCode())) {
					throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_UNAUTHORIZED_INDEX, index.getCode(), index.getLabel(), type.getId().toString(), type.getLabel()));
				}
			});
		}
	}

	public void validateTypeIndexReferenceNomenclature(Type type, List<Nomenclature> nomenclatures) {
		if (!type.getIndexes().isEmpty()) {
			type.getIndexes().stream().forEach(index -> {
				final String code = index.getCode();
				if (StringUtils.isNotEmpty(index.getReferenceValue()) && nomenclatures.stream().anyMatch(n -> n.getEdoc().equals(code))) {
					final String[] indexes = index.getReferenceValue().split(";");
					final ArrayList al = new ArrayList(Arrays.asList(indexes));
					al.stream().forEach(item -> nomenclatures.stream().filter(n -> n.getEdoc().equals(index.getCode()) && n.getCode().equalsIgnoreCase(item.toString())).findFirst()
							.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_REF_VALUE, index.getLabel(), index.getReferenceValue()))));

				}
			});
		}
	}

	public void validateTypeIndexCorrectedNomenclature(Type type, List<Nomenclature> nomenclatures) {
		if (!type.getIndexes().isEmpty()) {
			type.getIndexes().stream().forEach(index -> {
				if (StringUtils.isNotEmpty(index.getCorrectedValue())) {
					final String code = index.getCode();
					if (nomenclatures.stream().anyMatch(n -> n.getEdoc().equals(code))) {
						nomenclatures.stream().filter(n -> n.getEdoc().equals(index.getCode()) && n.getCode().equalsIgnoreCase(index.getCorrectedValue())).findFirst()
								.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_REF_VALUE, index.getLabel())));
					}
				}

			});
		}
	}

	public void validateTypeIndexExtractedNomenclature(Type type, List<Nomenclature> nomenclatures) {
		if (!type.getIndexes().isEmpty()) {
			type.getIndexes().stream().forEach(index -> {
				if (StringUtils.isNotEmpty(index.getReferenceValue()) && nomenclatures.stream().anyMatch(n -> n.getEdoc().equals(index.getCode()))) {
					nomenclatures.stream().filter(n -> n.getEdoc().equals(index.getCode()) && n.getCode().equalsIgnoreCase(index.getExtractedValue())).findFirst()
							.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_REF_VALUE, index.getLabel(), index.getExtractedValue())));
				}

			});
		}
	}

	public void convertTypesExtractedIndexToEdoc(Set<Indexe> indexes, List<Nomenclature> nomenclatures) {
		for (final Indexe index : indexes) {
			nomenclatures.stream().filter(n -> n.getJmc().equalsIgnoreCase(index.getExtractedValue()) && n.getEdoc().equals(index.getCode())).findFirst().ifPresent(n -> index.setExtractedValue(n.getCode()));

		}

	}

	public void initTypeIndexLabel(Type type, List<EdocIndex> edocIndexes) {
		type.getIndexes().stream().filter(index -> StringUtils.isEmpty(index.getLabel())).forEach(index -> index.setLabel(edocIndexes.stream().filter(edocI -> edocI.getCode().equals(index.getCode())).findAny().get().getLabel()));
	}

	public void initTypeIndexFormatAndSize(Type type, List<EdocIndex> edocIndexes) {
		type.getIndexes().forEach(index -> index.setFormat(edocIndexes.stream().filter(edocI -> edocI.getCode().equals(index.getCode())).findAny().get().getFormat()));
		type.getIndexes().forEach(index -> index.setMinSize(edocIndexes.stream().filter(edocI -> edocI.getCode().equals(index.getCode())).findAny().get().getMinSize()));
		type.getIndexes().forEach(index -> index.setMaxSize(edocIndexes.stream().filter(edocI -> edocI.getCode().equals(index.getCode())).findAny().get().getMaxSize()));
		type.getIndexes().stream().sorted().forEach(index -> index.setMaxPosition(type.getIndexes()));
	}

	public void initTypeIndexAdditionalInformation(Type type, List<EdocIndex> edocIndexes) {
		type.getIndexes().stream().filter(index -> StringUtils.isEmpty(index.getAdditionalInformation()))
				.forEach(index -> index.setAdditionalInformation(edocIndexes.stream().filter(edocI -> edocI.getCode().equals(index.getCode())).findAny().get().getAdditionalInformation()));
	}

	public void initTypeIndexOwnerIndex(Type type) {
		type.getIndexes().stream().forEach(i -> {
			if (i.getOwnerIndex() == null) {
				i.setOwnerIndex(Indexe.DEFAULT_OWNER_INDEX);
			}
		});
	}

	public void initTypeCompleteness(Type type, List<EdocType> edocTypes, Set<Type> types) {
		if (CollectionUtils.isEmpty(type.getCompleteness()) && !isTypeWithSubType(types, type)) {
			final Set<String> fullCompletenessSet = edocTypes.stream().filter(edocT -> edocT.getPiecesEdoc() != null && edocT.getValue().equals(type.getEdocType())).flatMap(edocT -> edocT.getPiecesEdoc().getPiece().stream())
					.filter(piece -> Optional.ofNullable(piece.isPieceDefault()).orElse(false)).map(PiecesEdoc.Piece::getPieceCode).collect(Collectors.toSet());

			type.setCompleteness(fullCompletenessSet);
		}

	}

	public void validateTypeIndexOwnerIndex(Type type) {
		type.getIndexes().stream().forEach(index -> {
			if (!StringUtils.isNumeric(index.getOwnerIndex())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_INDEX_OWNER_NOT_CORRECT, index.getLabel(), index.getOwnerIndex()));
			}
		});

	}

	public void validateTypeIndexUniqueForEachOwner(Type type) {
		final Map<String, List<Indexe>> indexesByCode = type.getIndexes().stream().collect(Collectors.groupingBy(Indexe::getCode));
		final AtomicInteger proposition = new AtomicInteger();
		indexesByCode.keySet().stream().forEach(indexCode -> {
			final Indexe index = indexesByCode.get(indexCode).get(0);
			final List<String> ownerList = indexesByCode.get(indexCode).stream().map(Indexe::getOwnerIndex).sorted().collect(Collectors.toList());
			if (ownerList.size() > 1) {
				for (int i = 0; i < ownerList.size() - 1; i++) {
					final String indexN = ownerList.get(i);
					final String indexNPlus1 = ownerList.get(i + 1);
					if (indexN.equals(indexNPlus1)) {
						final IntStream range1ToOwnerListSize = IntStream.range(1, ownerList.size() + 1);
						range1ToOwnerListSize.forEach(number -> {
							if (!ownerList.contains(Integer.toString(number))) {
								proposition.set(number);
							}
						});
						throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_INDEX_NOT_UNIQUE, index.getLabel(), proposition.toString()));
					}
				}
			}
		});
	}

	public void validateTypeIndexInjection(Type type, List<EdocIndex> edocIndexes) {
		if (!type.getIndexes().isEmpty()) {
			final Map<String, String> injectionList = edocIndexes.stream().collect(Collectors.toMap(EdocIndex::getCode, EdocIndex::getInjection));
			type.getIndexes().stream().forEach(index -> {
				if (StringUtils.isNotEmpty(index.getReferenceValue()) && IndexInjection.ND.getCode().equals(injectionList.get(index.getCode()))) {
					throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_INDEX_UNAUTHORIZED_REFERENCE, index.getCode(), index.getLabel()));
				}
				if (StringUtils.isEmpty(index.getReferenceValue()) && IndexInjection.OB.getCode().equals(injectionList.get(index.getCode()))) {
					throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_INDEX_MISSING_REFERENCE, index.getCode(), index.getLabel()));
				}
			});
		}
	}

	public void validateTypeIndex(Type type, List<EdocType> edocTypes, List<EdocIndex> edocIndexes, List<Nomenclature> nomenclatures, Set<Type> types) {
		if (type.getControlRequired() == ControlRequired.CONTROL_JMC.getCode()) {
			validateSubTypeIndexes(type, edocIndexes, types);
			validateSubTypeCompleteness(type, edocIndexes, types);
			validateTypeIndexes(type, edocIndexes);
			initTypeIndexAdditionalInformation(type, edocIndexes);
			initTypeIndexFormatAndSize(type, edocIndexes);
			validateTypeCompleteness(type, edocTypes, types);
			validateTypeControlRequired(type, types);
			validateTypeIndexCategory(type);
			validateTypeIndexReferenceFormat(type, edocIndexes);
			validateTypeIndexReferenceNomenclature(type, nomenclatures);
			initTypeCompleteness(type, edocTypes, types);
			initTypeIndexOwnerIndex(type);
			validateTypeIndexOwnerIndex(type);
			validateTypeIndexUniqueForEachOwner(type);
			validateTypeIndexList(type, edocTypes);
			validateTypeIndexInjection(type, edocIndexes);
			initTypeIndexLabel(type, edocIndexes);
			validateTypeIndexGroupLabel(type, edocTypes, edocIndexes);
		}
	}

	public void validateTypeIndexGroupLabel(Type type, List<EdocType> edocTypes, List<EdocIndex> edocIndexes) {
		type.getIndexes().forEach(index -> {
			final EdocIndex edocIndex = edocIndexes.stream().filter(edocIndexL -> edocIndexL.getCode().equals(index.getCode())).findAny().orElseThrow(IllegalArgumentException::new);
			if (StringUtils.isNotEmpty(index.getGroupLabel()) && edocIndex.getInjection().equals(ND) && !edocIndex.getFormat().equals(B)) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.GROUP_LABEL_JMC_INJECTION_ND, index.getLabel()));
			}
		});

	}

	private void validateTypeFieldsSize(Type type) {
		// type.label - 200
		validateFieldSize(type.getLabel(), "label du type " + type.getId().toString(), 200);
		// type.additional_information - 200
		validateFieldSize(type.getAdditionalInformation(), "additionalInformation du type " + type.getId().toString(), 200);
		// type.edoc_type - 45
		validateFieldSize(type.getEdocType(), "edocType du type " + type.getId().toString(), 45);
		// type.pending_document_label - 200
		validateFieldSize(type.getPendingDocumentLabel(), "pendingDocumentLabel du type " + type.getId().toString(), 200);
		// type.videocoding_delay - 200
		validateFieldSize(type.getVideoCodingDelay(), "videocodingDelay du type " + type.getId().toString(), 200);
		type.getIndexes().forEach(index -> {
			// indexe.code - 17
			validateFieldSize(index.getCode(), "code de l'index " + index.getCode(), 17);
			// indexe.label - 200
			validateFieldSize(index.getLabel(), "label de l'index " + index.getCode(), 200);
			// indexe.category - 2
			validateFieldSize(index.getCategory(), "category de l'index " + index.getCode(), 2);
			// indexe.reference_value - 200
			validateFieldSize(index.getReferenceValue(), "referenceValue de l'index " + index.getCode(), 200);
			// indexe.corrected_value - 200
			validateFieldSize(index.getCorrectedValue(), "correctedValue de l'index " + index.getCode(), 200);
			// indexe.owner_index - 2
			validateFieldSize(index.getOwnerIndex(), "ownerIndex de l'index " + index.getCode(), 2);
			// indexe.additional_information - 200
			validateFieldSize(index.getAdditionalInformation(), "additionalInformation de l'index " + index.getCode(), 200);
		});
	}

	public void calculateTypePositions(Set<Type> familyTypes) {
		calculateTypePositions(familyTypes.stream().collect(Collectors.toList()));
	}

	public void calculateTypePositions(List<Type> familyTypes) {
		if (CollectionUtils.isNotEmpty(familyTypes)) {
			familyTypes.stream().sorted().forEach(type -> type.setMaxPosition(familyTypes));
		}
	}

	public void calculateFamilyPositions(Set<Type> listTypes) {

		final List<Type> types = new ArrayList<>(listTypes);
		final Map<String, List<Type>> multimap = new HashMap<>(types.stream().collect(Collectors.groupingBy(Type::getFamilyLabel)));
		final Map<String, List<Type>> multimapSorted = multimap.entrySet().stream().sorted(Map.Entry.comparingByKey()).collect((Collectors.toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2, LinkedHashMap::new)));

		multimapSorted.forEach((familyId, familyTypes) -> {
			final int familyPosition = familyTypes.get(0).getFamilyPosition();
			if (familyPosition == 0) {
				if (CollectionUtils.isNotEmpty(familyTypes)) {
					final int maxPosition = types.stream().map(Type::getFamilyPosition).collect(Collectors.summarizingInt(Integer::intValue)).getMax() + 1;
					familyTypes.forEach(type -> type.setFamilyPosition(maxPosition));
				} else {
					familyTypes.forEach(type -> type.setFamilyPosition(1));
				}
			}
		});
	}

	private void validateFieldSize(String field, String fieldName, int maxSize) {
		if (StringUtils.isNotEmpty(field) && field.length() > maxSize) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_SIZE_MAX, fieldName, String.valueOf(maxSize)));
		}
	}

	public void initIndexStatusControl(Type type) {
		if (type.isGroupIndexesValidation() && "CT".equals(type.getStatusControl())) {
			type.getIndexes().stream().filter(index -> StringUtils.isNotEmpty(index.getGroupLabel()) && !IndexStatus.OK.getCode().equals(index.getStatusControl())).forEach(index -> index.setStatusControl(IndexStatus.OK_MAN.getCode()));
		}
	}

	public void validateTypeDelete(Collect collect, Type type) {
		final List<Type> typesByFamily = collect.getTypes().stream().filter(typeL -> typeL.getFamilyId().equals(type.getFamilyId())).filter(t -> !Optional.ofNullable(t.getParentId()).isPresent()).collect(Collectors.toList());
		if (CollectStatus.CL.name().equals(collect.getStatus()) || CollectStatus.AB.name().equals(collect.getStatus())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_CLOSED, collect.getStatus(), collect.getId().toString()));
		}
		if (Arrays.asList(TypeStatus.VA.getLabel(), TypeStatus.VA_AUTO.getLabel()).contains(type.getStatus())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_TYPE_DEL_VA, type.getLabel()));
		}
		if (typesByFamily.size() == 1) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_SUPP_TYPE_UNIQUE, type.getLabel()));
		}
		if (isMultiValueNotNeeded(typesByFamily, type)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DATA_MULTI_VALUE, "types", "families[" + type.getFamilyLabel() + "].types", "families[" + type.getFamilyLabel() + "].propertyType"));
		}
		if (Arrays.asList(TypeControls.EC.name(), TypeControls.EC_AMI.name()).contains(type.getStatusControl())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_LADRAD_EC));
		}
	}

	private boolean isMultiValueNotNeeded(List<Type> typesByFamily, Type type) {
		final int numberValue = 2;
		final List<Type> list = typesByFamily.stream().filter(t -> !Optional.ofNullable(t.getParentId()).isPresent()).collect(Collectors.toList());
		return PropertyType.LISTE.getLabel().equals(type.getFamilyPropertyType()) && typesByFamily.stream().filter(t -> !t.getId().equals(type.getId())).filter(t -> !Optional.ofNullable(t.getParentId()).isPresent()).count() < numberValue;
	}

	public Environment getEnv() {
		return env;
	}

	public void setEnv(Environment env) {
		this.env = env;
	}

	public void cleanIndexIfNoControlJmc(Type type) {
		if (type.getControlRequired() == ControlRequired.NO_CONTROL.getCode()) {
			type.getIndexes().clear();
			type.getCompleteness().clear();
		}
	}

}
