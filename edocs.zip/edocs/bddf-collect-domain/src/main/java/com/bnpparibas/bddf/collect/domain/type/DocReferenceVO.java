package com.bnpparibas.bddf.collect.domain.type;

import java.time.Instant;

public class DocReferenceVO {

	private String channel;
	private String userId;
	private Instant aqcuisitionDate;

	public DocReferenceVO() {
		super();
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Instant getAqcuisitionDate() {
		return aqcuisitionDate;
	}

	public void setAqcuisitionDate(Instant aqcuisitionDate) {
		this.aqcuisitionDate = aqcuisitionDate;
	}

	void reinitialise() {
		channel = "";
		userId = "";
		aqcuisitionDate = Instant.now();
	}

}