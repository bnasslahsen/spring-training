package com.bnpparibas.bddf.collect.domain.piece;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.FamiliesManagmentAct;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.param.PiecesStatusActionsRepository;
import com.bnpparibas.bddf.collect.domain.type.ControlRequired;
import com.bnpparibas.bddf.collect.domain.type.PropertyType;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.bnpparibas.bddf.errors.BusinessException.Builder;

/**
 *
 * Cette classe présente les implémentations des contrôles demandés au niveau Piece.
 *
 * Ces contrôles sont invoqués principalement par le addPiece, updatePiece et updateType
 *
 */
@Component
public class PieceValidator {

	@Autowired
	private PiecesStatusActionsRepository pieceStatusRepository;

	public void validatePiece(Piece piece, Collect collect, Type type, String contentType, String blackListJmcFormat, long numberOfPiece) {
		if (Arrays.asList(TypeStatus.VA.getLabel(), TypeStatus.VA_AUTO.getLabel()).contains(type.getStatus())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UPDATE_UNAUTHORIZED, type.getStatus(), type.getId().toString(), type.getLabel()));
		}

		validatePieceList(collect, type);

		if (Arrays.stream(PieceRecivedFormat.values()).noneMatch(e -> e.name().equals(piece.getReceivedFormat()))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_DATA_VALUE, "recivedFormat", piece.getReceivedFormat()));
		}
		if (Arrays.asList(FamiliesManagmentAct.ND.name(), FamiliesManagmentAct.DR.name()).contains(type.getFamilyCategory())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_CATEGORY_TYPE_UNAUTHORIZED, type.getFamilyCategory(), type.getFamilyId().toString()));
		}

		if (PieceRecivedFormat.NUM.name().equals(piece.getReceivedFormat())) {
			validateNumeric(piece, collect, type, contentType, blackListJmcFormat, numberOfPiece);
		} else if (PieceRecivedFormat.PAP.name().equals(piece.getReceivedFormat())) {
			validatePap(piece);
		}
		validatePieceFieldsSize(piece);
	}

	public void validatePieceSupprPutPieces(Piece piece, String channel) {
		if (!pieceStatusRepository.isDeleteAuthorizedForPutPieces(piece.getStatus(), channel)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_DELETE_UNAUTHORIZED, piece.getLabel()));
		}
	}

	public void validatePieceExistence(Set<Piece> existingPieces, Set<Piece> newPieces, UUID collectId, UUID typeId) {
		newPieces.forEach(p -> {
			if (!existingPieces.contains(p)) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_NOT_FOUND, Optional.ofNullable(p.getId()).map(Object::toString).orElse(null), collectId.toString(), typeId.toString(),
						Optional.ofNullable(p.getId()).map(Object::toString).orElse(null)));
			}
		});

	}

	public void validatePieceSupprPutType(Piece piece, String channel) {
		if (!pieceStatusRepository.isDeleteAuthorizedForPutType(piece.getStatus(), channel)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_DELETE_UNAUTHORIZED, piece.getLabel()));
		}
	}

	public void validatePutPiecesStatus(Piece existingPiece, String newStatus, String channel) {
		if (Arrays.stream(PieceStatus.values()).map(PieceStatus::name).noneMatch(e -> e.equals(newStatus))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_UNKNOWN_ACTION, newStatus, existingPiece.getId().toString(), existingPiece.getLabel()));
		}
		if (!pieceStatusRepository.isNewPieceStatusAuthorizedForPutPieces(existingPiece.getStatus(), newStatus, channel)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_UNAUTHORIZED_ACTION, newStatus, existingPiece.getId().toString(), existingPiece.getLabel()));
		}
	}

	public void validatePutTypeStatus(Piece existingPiece, String newStatus, String channel) {
		if (Arrays.stream(PieceStatus.values()).map(PieceStatus::name).noneMatch(e -> e.equals(newStatus))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_UNKNOWN_ACTION, newStatus, existingPiece.getId().toString(), existingPiece.getLabel()));
		}
		if (!pieceStatusRepository.isNewPieceStatusAuthorizedForPutType(existingPiece.getStatus(), newStatus, channel)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_UNAUTHORIZED_ACTION, newStatus, existingPiece.getId().toString(), existingPiece.getLabel()));
		}
	}

	private void validatePieceList(Collect collect, Type type) {
		if (PropertyType.LISTE.getLabel().equals(type.getFamilyPropertyType()) && collect.getTypes().stream().filter(subtype -> type.getParentId() == null || !type.getParentId().equals(subtype.getParentId()))
				.anyMatch(t -> t.getFamilyId().equals(type.getFamilyId()) && !t.equals(type) && t.getActivePieces().stream().anyMatch(p -> !PieceStatus.DF.getLabel().equals(p.getStatus())))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_CATEGORY_TYPE_LISTE, type.getFamilyPropertyType(), type.getFamilyId().toString()));
		}
	}

	private void validatePap(Piece piece) {
		if (PieceStatus.RF.getLabel().equals(piece.getStatus())) {
			if (StringUtils.isEmpty(piece.getRejectionReason())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_REJECT_REASON, piece.getLabel())); // RG 47
			} else if ("Autre".equals(piece.getRejectionReason()) && StringUtils.isEmpty(piece.getRejectionComment())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_REJECT_COMMENT, piece.getLabel())); // RG 49
			}
		}

		if (isUnauthorizedPapStatus(piece)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_UNAUTHORIZED, piece.getId().toString(), piece.getLabel())); // RG 54
		}
	}

	private boolean isUnauthorizedPapStatus(Piece piece) {
		return !(PieceStatus.RF.getLabel().equals(piece.getStatus()) || PieceStatus.VA.getLabel().equals(piece.getStatus()) || PieceStatus.RC.getLabel().equals(piece.getStatus()));
	}

	private void validateNumeric(Piece piece, Collect collect, Type type, String contentType, String blacklistJmcFormat, long numberOfPiece) {
		validateNumericFormat(piece, type, collect, contentType, blacklistJmcFormat);

		if (!type.isDigitalAllowed()) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_DIGITAL_NOT_ALLOWED, type.getId().toString(), type.getLabel()));
		}
		if (numberOfPiece >= 5) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_NUMBER, type.getId().toString(), type.getLabel()));
		}

		if (piece.getSize() < 10) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_SIZE_MIN, piece.getLabel()));
		}

		if (piece.getSize() > type.getMaxSizeDoc()) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_SIZE_MAX, piece.getLabel(), String.valueOf(type.getMaxSizeDoc())));
		}
	}

	private void validateNumericFormat(Piece piece, Type type, Collect collect, String contentType, String blackListJmcFormat) {
		final List<String> blackListJmcFormatList = Arrays.asList(blackListJmcFormat.split(","));
		if (!collect.getAllowedFile().contains(mapContentFileToExtension(contentType))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_FORMAT, piece.getLabel(), collect.getAllowedFile().toString()));
		}
		if (type.getControlRequired() == ControlRequired.CONTROL_JMC.getCode() && blackListJmcFormatList.contains(mapContentFileToExtension(contentType))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_JMC_DOC_FORMAT, type.getLabel()));
		}
	}

	private String mapContentFileToExtension(String contentType) {
		if (Arrays.asList("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel", "application/vnd.ms-excel.sheet.macroEnabled.12").contains(contentType)) {
			return "XLS";
		} else if (Arrays.asList("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword").contains(contentType)) {
			return "DOC";
		} else {
			return contentType.substring(contentType.indexOf('/') + 1).toUpperCase();
		}

	}

	public PiecesStatusActionsRepository getPieceStatusRepository() {
		return pieceStatusRepository;
	}

	public void setPieceStatusRepository(PiecesStatusActionsRepository pieceStatusRepository) {
		this.pieceStatusRepository = pieceStatusRepository;
	}

	public void validatePieceFieldsSize(Piece piece) {
		// piece.label - 200
		validateFieldSize(piece.getLabel(), "label de la pièce " + piece.getId().toString(), 200);
		// piece.owner_id - 17
		validateFieldSize(piece.getOwnerId(), "ownerId de la pièce " + piece.getId().toString(), 17);
		// piece.employee_id - 17
		validateFieldSize(piece.getEmployeeId(), "employeeId de la pièce " + piece.getId().toString(), 17);
		// piece.received_format - 45
		validateFieldSize(piece.getReceivedFormat(), "receivedFormat de la pièce " + piece.getId().toString(), 45);
		// piece.status - 5
		validateFieldSize(piece.getStatus(), "status de la pièce " + piece.getId().toString(), 5);
		// piece.status_control - 6
		validateFieldSize(piece.getStatusControl(), "statusControl de la pièce " + piece.getId().toString(), 6);
		// piece.rejecton_reason - 200
		validateFieldSize(piece.getRejectionReason(), "rejectionReason de la pièce " + piece.getId().toString(), 200);
		// piece.rejection_comment - 200
		validateFieldSize(piece.getRejectionComment(), "rejectionComment de la pièce " + piece.getId().toString(), 200);
		// piece.content_type - 50
		validateFieldSize(piece.getContentType(), "contentType de la pièce " + piece.getId().toString(), 50);
		// piece.state - 10
		validateFieldSize(piece.getState(), "state de la pièce " + piece.getId().toString(), 10);
	}

	private void validateFieldSize(String field, String fieldName, int maxSize) {
		if (StringUtils.isNotEmpty(field) && field.length() > maxSize) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_SIZE_MAX, fieldName, String.valueOf(maxSize)));
		}
	}

}
