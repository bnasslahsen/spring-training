package com.bnpparibas.bddf.collect.domain.owner;

public enum CommunicationTemplate {
	BNP("BNP"), HB("HB");

	private String label;

	CommunicationTemplate(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}
}
