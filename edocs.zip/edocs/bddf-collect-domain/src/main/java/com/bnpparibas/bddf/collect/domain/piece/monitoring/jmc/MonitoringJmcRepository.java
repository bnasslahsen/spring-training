package com.bnpparibas.bddf.collect.domain.piece.monitoring.jmc;

import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Repository
public interface MonitoringJmcRepository {

	boolean isLastInjectDataError(String typId);

}
