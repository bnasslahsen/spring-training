package com.bnpparibas.bddf.collect.domain.ladrad.enums;

import java.util.Arrays;

public enum PieceControls {

	OK("OK"),

	KO("KO"),

	EC("EC"),

	ERR("ERR");

	private final String label;

	private PieceControls(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	public static PieceControls fromLabel(String label) {
		return Arrays.asList(values()).stream().filter(t -> t.getLabel().equals(label)).findAny().orElse(null);
	}

}
