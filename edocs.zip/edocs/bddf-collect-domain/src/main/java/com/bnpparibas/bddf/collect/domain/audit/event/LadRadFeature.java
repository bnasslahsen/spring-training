package com.bnpparibas.bddf.collect.domain.audit.event;

import java.util.Arrays;

import org.togglz.core.Feature;

public enum LadRadFeature implements Feature {

	LADRAD_CJ100000("100000"), LADRAD_CJ000001("000001"), LADRAD_CJ000000("000000"), LADRAD_CJ100001("100001"), LADRAD_CJ110000("110000"), LADRAD_CJ110001("110001"), LADRAD_CJ200000("200000"), LADRAD_CJ300000("300000"), LADRAD_CJ910000(
			"910000"), LADRAD_CJ666666("666666"), LADRAD_CJ200001("200001"), LADRAD_CJ800("800"), LADRAD_CJ110("110"), LADRAD_CJ011("011");
	private final String label;

	private LadRadFeature(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	public static LadRadFeature fromLabel(String label) {
		return Arrays.asList(values()).stream().filter(t -> t.getLabel().equals(label)).findAny().orElse(null);
	}

}
