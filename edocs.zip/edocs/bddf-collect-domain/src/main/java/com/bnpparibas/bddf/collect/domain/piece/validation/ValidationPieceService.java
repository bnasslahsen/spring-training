package com.bnpparibas.bddf.collect.domain.piece.validation;

import java.util.Date;
import java.util.List;

public interface ValidationPieceService {

	void update(ValidationPiece validationPiece);

	void save(ValidationPiece validationPiece);

	void delete(ValidationPiece validationPiece);

	List<ValidationPiece> getByCreationDate(Date creationDate);

}
