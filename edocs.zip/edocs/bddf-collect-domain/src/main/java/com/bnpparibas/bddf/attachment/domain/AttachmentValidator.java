package com.bnpparibas.bddf.attachment.domain;

import java.util.Arrays;
import java.util.HashSet;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;

@Component
public class AttachmentValidator {

	private static final long MAX_FILESIZE_OCTET = 10000000;
	private static final String CHANNEL_AUTHORIZED_LIST = "001,012,017,004,007";
	private static final String CHANNEL_NO_CHECK_CONTEXT_LIST = "012";
	private static final String DEFAULT_USER_ID = "999";

	@Value("${attachment.authorized-format}")
	private String authorizedFormat;

	public void validate(Attachment attachment) {
		final HashSet<String> listAuthorizedFormat = new HashSet<>(Arrays.asList(authorizedFormat.split(",")));
		final String extension = mapContentFileToExtension(attachment.getMimeType());
		if (!listAuthorizedFormat.contains(extension)) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_ATTACHMENT_ALLOWED_FILES, authorizedFormat));
		}
		if (attachment.getFileSize() > MAX_FILESIZE_OCTET) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_ATTACHMENT_MAX_SIZE, attachment.getFileName(), " 10 MO"));
		}
		if (!StringUtils.startsWithIgnoreCase(attachment.getSendingApplicationCode(), "AP") || attachment.getSendingApplicationCode().length() != 7) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_ATTACHMENT_SENDING_APPLICATION_CODE, attachment.getSendingApplicationCode()));
		}
		if (!CHANNEL_AUTHORIZED_LIST.contains(attachment.getChannel())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_ATTACHMENT_INCORRECT_CHANNEL, attachment.getChannel(), CHANNEL_AUTHORIZED_LIST));
		}
	}

	private String mapContentFileToExtension(String contentType) {
		if (Arrays.asList("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel", "application/vnd.ms-excel.sheet.macroEnabled.12").contains(contentType)) {
			return "XLS";
		} else if (Arrays.asList("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword").contains(contentType)) {
			return "DOC";
		} else {
			return contentType.substring(contentType.indexOf('/') + 1).toUpperCase();
		}

	}

	public void checkCanModify(Attachment attachment, Context context) {
		if (!CHANNEL_AUTHORIZED_LIST.contains(context.getCanal())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_ATTACHMENT_INCORRECT_CHANNEL, attachment.getChannel(), CHANNEL_AUTHORIZED_LIST));
		}
		if(!CHANNEL_NO_CHECK_CONTEXT_LIST.contains(context.getCanal())) {
			if (!StringUtils.equals(attachment.getUserId(), context.getCustomerId())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_ATTACHMENT_USER_ID_NOT_ALLOWED, context.getCustomerId()));
			}
			if (!StringUtils.equals(attachment.getChannel(), context.getCanal())) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_ATTACHMENT_CHANNEL_NOT_ALLOWED, context.getCanal()));
			}
		}
	}
	
	public boolean isAPI(String channel) {
		return CHANNEL_NO_CHECK_CONTEXT_LIST.contains(channel);
	}

	public String getAuthorizedFormat() {
		return authorizedFormat;
	}

	public void setAuthorizedFormat(String authorizedFormat) {
		this.authorizedFormat = authorizedFormat;
	}


}
