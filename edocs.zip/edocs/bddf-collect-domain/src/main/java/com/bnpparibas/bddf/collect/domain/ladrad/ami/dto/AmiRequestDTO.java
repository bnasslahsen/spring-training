
package com.bnpparibas.bddf.collect.domain.ladrad.ami.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "priority", "authentification", "contractCode", "pages" })
public class AmiRequestDTO {

	@JsonProperty("priority")
	private Priority priority;
	@JsonProperty("authentification")
	private Authentification authentification;
	@JsonProperty("authentification")
	private String contractCode;
	@JsonProperty("pages")
	private List<Page> pages;

	private String externalRef;

	public AmiRequestDTO() {
	}

	public AmiRequestDTO(String priority, String authentification, String contractCode) {
		this.priority = new Priority(priority);
		this.authentification = new Authentification(authentification);
		this.contractCode = contractCode;
	}

	@JsonProperty("priority")
	public Priority getPriority() {
		return priority;
	}

	@JsonProperty("priority")
	public void setPriority(Priority priority) {
		this.priority = priority;
	}

	@JsonProperty("authentification")
	public Authentification getAuthentification() {
		return authentification;
	}

	@JsonProperty("authentification")
	public void setAuthentification(Authentification authentification) {
		this.authentification = authentification;
	}

	@JsonProperty("pages")
	public List<Page> getPages() {
		if (pages == null) {
			pages = new ArrayList();
		}
		return pages;
	}

	@JsonProperty("pages")
	public void setPages(List<Page> pages) {
		this.pages = pages;
	}

	public String getExternalRef() {
		return externalRef;
	}

	public void setExternalRef(String externalRef) {
		this.externalRef = externalRef;
	}

	public String getContractCode() {
		return contractCode;
	}

	public void setContractCode(String contractCode) {
		this.contractCode = contractCode;
	}

	@Override
	public String toString() {
		final String tmpExternalRef = this.externalRef;
		this.externalRef = null;
		final ObjectMapper objectMapper = new ObjectMapper();
		final String amiRequestJson;
		try {
			amiRequestJson = objectMapper.writeValueAsString(this);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
		this.externalRef = tmpExternalRef;
		return amiRequestJson;
	}

}
