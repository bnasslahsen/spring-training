package com.bnpparibas.bddf.collect.domain.helper;

import java.time.Instant;
import java.util.UUID;

import com.bnpparibas.bddf.collect.domain.piece.Channel;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceRecivedFormat;
import com.bnpparibas.bddf.collect.domain.piece.PieceStates;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReference;

public final class ConverterHelper {
	private ConverterHelper() {
		super();
	}

	public static Piece buildPieceDFFromReferencePiece(DocReference ref) {
		final Piece p = new Piece();
		p.setState(PieceStates.ACTIF.getLabel());
		p.setId(UUID.randomUUID());
		p.setStatus(PieceStatus.DF.getLabel());
		p.setChannel(ref.getChannel());
		p.setContentType(ref.getContentType());
		p.setOwnerId(ref.getOwnerId());
		p.setSize(ref.getSize());
		p.setPosition(ref.getPosition());
		p.setLabel(ref.getLabel());
		p.setReferencePieceId(ref.getReferencePieceId());
		p.setReferenceGdnId(ref.getReferenceGdnId());
		p.setAcquisitionDate(Instant.now());
		p.setReceivedFormat(PieceRecivedFormat.NUM.name());
		p.setStatusSentToGdn("NOT_SENT");
		if (Channel.isCollab(ref.getChannel())) {
			p.setEmployeeId(ref.getUserId());
		}
		return p;
	}

	
}
