package com.bnpparibas.bddf.collect.domain.collect;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.DomainService
public interface CollectService {

	Collect getCollect(UUID id);

	Collect getOnlyCollectById(UUID id);

	Set<UUID> getAllManagedCollects();

	Set<Type> getTypesByCollectId(UUID id);

	Set<Collect> getCollectsByOwners(Set<String> references, List<String> journeyCodes);

	UUID addCollect(Collect collect, Context context);

	List<String> endCollect(UUID collectId, String status, Context context);

	void updateCollect(Collect updatedCollect, UUID collectId, Context context);

	Integer countCollectsByOwners(Set<String> references, String journeyCode);

}
