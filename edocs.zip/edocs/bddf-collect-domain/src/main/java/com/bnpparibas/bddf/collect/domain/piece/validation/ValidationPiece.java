package com.bnpparibas.bddf.collect.domain.piece.validation;

import java.util.Date;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import com.bnpparibas.bddf.collect.domain.piece.Piece;

public class ValidationPiece {

	private Date creationDate;
	private String pieceId;
	private String typeId;
	private String collectId;
	private String userId;
	private String channel;
	private String newTypeStatus;
	private int triesNumber;
	private Date aquisitionDate;
	private String status;
	private Set<Piece> removedPieces;

	public ValidationPiece() {
		super();
	}

	public ValidationPiece(Date creationDate, String pieceId, String typeId, String collectId, String userId, String channel, String newTypeStatus, int triesNumber, Date aquisitionDate, String status, Set<Piece> removedPieces) {
		super();
		this.creationDate = Optional.ofNullable(creationDate).map(d -> (Date) d.clone()).orElse(null);
		this.pieceId = pieceId;
		this.typeId = typeId;
		this.collectId = collectId;
		this.userId = userId;
		this.channel = channel;
		this.newTypeStatus = newTypeStatus;
		this.triesNumber = triesNumber;
		this.aquisitionDate = Optional.ofNullable(aquisitionDate).map(d -> (Date) d.clone()).orElse(null);
		this.status = status;
		this.removedPieces = removedPieces;
	}

	public Date getCreationDate() {
		return Optional.ofNullable(creationDate).map(d -> (Date) d.clone()).orElse(null);
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = Optional.ofNullable(creationDate).map(d -> (Date) d.clone()).orElse(null);
	}

	public String getPieceId() {
		return pieceId;
	}

	public void setPieceId(String pieceId) {
		this.pieceId = pieceId;
	}

	public String getTypeId() {
		return typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	public String getCollectId() {
		return collectId;
	}

	public void setCollectId(String collectId) {
		this.collectId = collectId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getNewTypeStatus() {
		return newTypeStatus;
	}

	public void setNewTypeStatus(String newTypeStatus) {
		this.newTypeStatus = newTypeStatus;
	}

	public int getTriesNumber() {
		return triesNumber;
	}

	public void setTriesNumber(int triesNumber) {
		this.triesNumber = triesNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getAquisitionDate() {
		return Optional.ofNullable(aquisitionDate).map(d -> (Date) d.clone()).orElse(null);
	}

	public void setAquisitionDate(Date aquisitionDate) {
		this.aquisitionDate = Optional.ofNullable(aquisitionDate).map(d -> (Date) d.clone()).orElse(null);
	}

	public Set<Piece> getRemovedPieces() {
		if (removedPieces == null) {
			removedPieces = new HashSet<>();
		}
		return removedPieces;
	}

	public void setRemovedPieces(Set<Piece> removedPieces) {
		this.removedPieces = removedPieces;
	}
}