package com.bnpparibas.bddf.collect.domain.notification;

import java.util.Map;

import com.bnpparibas.bddf.domain.ddd.DDD;

/*
Entity to send a message Format XML to DIGICOM
*/
@DDD.Entity
public class NotificationDIGICOMMessage {

	private String eventId;
	private String receiverId;
	private String receiverIdType;
	private String receiverNature;
	private String applicationId;
	private String customerJourneyId;
	private String applicationUseCase;
	private String msgReference;
	private String startDiffusionDate;
	private String receiverPreferences;
	private String multiChannel;
	private Map<String, String> mapVariablesList;

	private String channelsList;

	public NotificationDIGICOMMessage() {
		super();
	}

	public NotificationDIGICOMMessage(String eventId, String receiverId, String receiverIdType, String receiverNature, String applicationId, String customerJourneyId, String applicationUseCase, String msgReference, String startDiffusionDate,
			String receiverPreferences, String multiChannel, Map<String, String> mapVariablesList, String channelsList) {
		super();
		this.eventId = eventId;
		this.receiverId = receiverId;
		this.receiverIdType = receiverIdType;
		this.receiverNature = receiverNature;
		this.applicationId = applicationId;
		this.customerJourneyId = customerJourneyId;
		this.applicationUseCase = applicationUseCase;
		this.msgReference = msgReference;
		this.startDiffusionDate = startDiffusionDate;
		this.receiverPreferences = receiverPreferences;
		this.multiChannel = multiChannel;
		this.mapVariablesList = mapVariablesList;
		this.channelsList = channelsList;
	}

	public Map<String, String> getMapVariablesList() {
		return mapVariablesList;
	}

	public void setMapVariablesList(Map<String, String> mapVariablesList) {
		this.mapVariablesList = mapVariablesList;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getReceiverId() {
		return receiverId;
	}

	public void setReceiverId(String receiverId) {
		this.receiverId = receiverId;
	}

	public String getReceiverIdType() {
		return receiverIdType;
	}

	public void setReceiverIdType(String receiverIdType) {
		this.receiverIdType = receiverIdType;
	}

	public String getReceiverNature() {
		return receiverNature;
	}

	public void setReceiverNature(String receiverNature) {
		this.receiverNature = receiverNature;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getCustomerJourneyId() {
		return customerJourneyId;
	}

	public void setCustomerJourneyId(String customerJourneyId) {
		this.customerJourneyId = customerJourneyId;
	}

	public String getApplicationUseCase() {
		return applicationUseCase;
	}

	public void setApplicationUseCase(String applicationUseCase) {
		this.applicationUseCase = applicationUseCase;
	}

	public String getMsgReference() {
		return msgReference;
	}

	public void setMsgReference(String msgReference) {
		this.msgReference = msgReference;
	}

	public String getStartDiffusionDate() {
		return startDiffusionDate;
	}

	public void setStartDiffusionDate(String startDiffusionDate) {
		this.startDiffusionDate = startDiffusionDate;
	}

	public String getReceiverPreferences() {
		return receiverPreferences;
	}

	public void setReceiverPreferences(String receiverPreferences) {
		this.receiverPreferences = receiverPreferences;
	}

	public String getMultiChannel() {
		return multiChannel;
	}

	public void setMultiChannel(String multiChannel) {
		this.multiChannel = multiChannel;
	}

	public String getChannelsList() {
		return channelsList;
	}

	public void setChannelsList(String channelsList) {
		this.channelsList = channelsList;
	}

}
