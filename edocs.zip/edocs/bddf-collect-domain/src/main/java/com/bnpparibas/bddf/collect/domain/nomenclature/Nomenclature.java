package com.bnpparibas.bddf.collect.domain.nomenclature;

import java.io.Serializable;

public class Nomenclature implements Serializable {
	
	private static final long serialVersionUID = 1;
	
    private String edoc;
    private String code;
    private String label;
    private String jmc;
	public String getEdoc() {
		return edoc;
	}
	public void setEdoc(String edoc) {
		this.edoc = edoc;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getJmc() {
		return jmc;
	}
	public void setJmc(String jmc) {
		this.jmc = jmc;
	}
    
    
    

}
