package com.bnpparibas.bddf.collect.domain.param;

import java.util.List;

import com.bnp.schema.edoc.type.Types.EdocType;

public interface EdocTypeRepository {

	List<EdocType> findAll();

	EdocType byValue(String value);

}
