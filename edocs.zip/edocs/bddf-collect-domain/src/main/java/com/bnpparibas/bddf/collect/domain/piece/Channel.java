package com.bnpparibas.bddf.collect.domain.piece;

import java.util.Arrays;

public enum Channel {
	SPIRIT("001", "collab"), API("012", "API"), SITE_WEB_COLLAB("017", "Site web collaborateur"), CLIENT_004("004", "client"), CLIENT_007("007", "Espace client");

	private final String value;
	private final String gdnType;

	private Channel(String value, String gdnType) {
		this.value = value;
		this.gdnType = gdnType;
	}

	public String getValue() {
		return value;
	}

	public String getGdnType() {
		return gdnType;
	}

	public static Channel fromValue(String value) {
		return Arrays.asList(values()).stream().filter(c -> c.getValue().equals(value)).findAny().orElse(null);
	}

	public static boolean isClient(String channel) {
		return Arrays.asList(Channel.CLIENT_004.getValue(), Channel.CLIENT_007.getValue()).contains(channel);
	}

	public static boolean isCollab(String channel) {
		return Arrays.asList(Channel.SPIRIT.getValue(), Channel.API.getValue(), Channel.SITE_WEB_COLLAB.getValue()).contains(channel);
	}

}
