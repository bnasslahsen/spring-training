package com.bnpparibas.bddf.attachment.domain;

import com.bnpparibas.bddf.errors.BusinessException;

public class AttachmentBusinessException extends BusinessException {
	
	private static final long serialVersionUID = 1L;

	public AttachmentBusinessException(Builder builder) {
		super(builder);
	}

}
