package com.bnpparibas.bddf.collect.domain.edoc.families.types;

import java.util.List;

import com.bnp.schema.edoc_types_families.EdocFamiliesTypes.EdocFamilyTypes;


public interface EdocFamiliesTypesRepository {
	List<EdocFamilyTypes> findAll();

}
