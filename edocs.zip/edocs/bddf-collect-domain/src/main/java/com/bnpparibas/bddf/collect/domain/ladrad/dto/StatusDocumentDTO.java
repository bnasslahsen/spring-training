package com.bnpparibas.bddf.collect.domain.ladrad.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Data used for create Folder in JOUVE
 *
 * @author c07128
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class StatusDocumentDTO {

	@JsonProperty("status")
	private String status;

	@JsonProperty("differed_time_status")
	private String differedTimeStatus;
	
	@JsonProperty("differed_time_status_list")
	private JsonNode differedTimeStatusList;
	
	@JsonProperty("reference")
	private String reference;

	@JsonProperty("external_ref")
	private String externalRef;

	@JsonProperty("total_pages")
	private Integer totalPages;

	@JsonProperty("processed_pages")
	private Integer processedPages;

	@JsonProperty("pages")
	private List<PageDTO> pages;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getExternalRef() {
		return externalRef;
	}

	public void setExternalRef(String externalRef) {
		this.externalRef = externalRef;
	}

	public Integer getTotalPages() {
		if (totalPages != null) {
			return totalPages;
		} else {
			return 0;
		}
	}

	public void setTotalPages(Integer totalPages) {
		this.totalPages = totalPages;
	}

	public Integer getProcessedPages() {
		return processedPages;
	}

	public void setProcessedPages(Integer processedPages) {
		this.processedPages = processedPages;
	}

	public List<PageDTO> getPages() {
		return pages;
	}

	public void setPages(List<PageDTO> pages) {
		this.pages = pages;
	}

	public String getDifferedTimeStatus() {
		return differedTimeStatus;
	}

	public void setDifferedTimeStatus(String differedTimeStatus) {
		this.differedTimeStatus = differedTimeStatus;
	}

	@Override
	public String toString() {
		final ObjectMapper objectMapper = new ObjectMapper();
		try {
			return objectMapper.writeValueAsString(this);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
	}

	public JsonNode getDifferedTimeStatusList() {
		return differedTimeStatusList;
	}

	public void setDifferedTimeStatusList(JsonNode differedTimeStatusList) {
		this.differedTimeStatusList = differedTimeStatusList;
	}





}
