package com.bnpparibas.bddf.collect.domain.ladrad.enums;

import java.util.Arrays;

public enum JmcRecognitionLevel {

	PIECE("piece"),

	TYPE("type"),

	// JMC: Facture mobile reconnue dans facture de téléphonie fixe et non reconnue dans facture mobile => on verifie que la piece a la famille facture
	FAMILY("family");

	private final String label;

	private JmcRecognitionLevel(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	public static JmcRecognitionLevel fromLabel(String label) {
		return Arrays.asList(values()).stream().filter(t -> t.getLabel().equals(label)).findAny().orElse(null);
	}

}
