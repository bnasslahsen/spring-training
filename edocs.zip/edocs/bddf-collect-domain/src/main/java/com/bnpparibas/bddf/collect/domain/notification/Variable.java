package com.bnpparibas.bddf.collect.domain.notification;

import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Entity
public class Variable {

	private String value;
	private String name;

	public Variable() {
		super();
	}

	public Variable(String value, String name) {
		super();
		this.value = value;
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
