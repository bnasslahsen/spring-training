package com.bnpparibas.bddf.collect.domain.type;

public enum FamilyCategory {
	OB(1, "Obligatoire"), ND(2, "Non demandé"), DR(3, "Dérogé"), DF(4, "Déjà fourni"), IN(5, "Interne"), FA(6, "Facultaif");

	private int code;
	private String label;

	FamilyCategory(int code, String label) {
		this.code = code;
		this.label = label;

	}

	public int getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}

}
