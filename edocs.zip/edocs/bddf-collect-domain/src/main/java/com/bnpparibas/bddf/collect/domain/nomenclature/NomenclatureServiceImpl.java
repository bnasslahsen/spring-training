package com.bnpparibas.bddf.collect.domain.nomenclature;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class NomenclatureServiceImpl implements NomenclatureService {

	@Autowired
	private NomenclatureRepository nomenclatureRepository;
	
	@Override
	public List<Nomenclature> findAll() {
		return nomenclatureRepository.findAll();
	}

}
