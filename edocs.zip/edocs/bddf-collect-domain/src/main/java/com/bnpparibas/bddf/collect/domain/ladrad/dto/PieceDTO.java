package com.bnpparibas.bddf.collect.domain.ladrad.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PieceDTO {

	@JsonProperty("status")
	private String status;

	@JsonProperty("refDocFamily")
	private String refDocFamily;

	@JsonProperty("type")
	private String type;

	@JsonProperty("reference")
	private String reference;

	@JsonProperty("document_type")
	private String documentType;

	@JsonProperty("document_family")
	private String documentFamily;

	@JsonProperty("piece_order")
	private String pieceOrder;

	@JsonProperty("match_expected_doc_family")
	private Integer matchExpectedDocFamily;

	@JsonProperty("match_expected_doc_type")
	private Integer matchExpectedDocType;

	@JsonProperty("match_expected_type")
	private Integer matchExpectedType;

	@JsonProperty("business_status")
	private String businessStatus;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRefDocFamily() {
		return refDocFamily;
	}

	public void setRefDocFamily(String refDocFamily) {
		this.refDocFamily = refDocFamily;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDocumentFamily() {
		return documentFamily;
	}

	public void setDocumentFamily(String documentFamily) {
		this.documentFamily = documentFamily;
	}

	public String getPieceOrder() {
		return pieceOrder;
	}

	public void setPieceOrder(String pieceOrder) {
		this.pieceOrder = pieceOrder;
	}

	public Integer getMatchExpectedDocFamily() {
		return matchExpectedDocFamily;
	}

	public void setMatchExpectedDocFamily(Integer matchExpectedDocFamily) {
		this.matchExpectedDocFamily = matchExpectedDocFamily;
	}

	public Integer getMatchExpectedDocType() {
		return matchExpectedDocType;
	}

	public void setMatchExpectedDocType(Integer matchExpectedDocType) {
		this.matchExpectedDocType = matchExpectedDocType;
	}

	public Integer getMatchExpectedType() {
		return matchExpectedType;
	}

	public void setMatchExpectedType(Integer matchExpectedType) {
		this.matchExpectedType = matchExpectedType;
	}

	public String getBusinessStatus() {
		return businessStatus;
	}

	public void setBusinessStatus(String businessStatus) {
		this.businessStatus = businessStatus;
	}

}
