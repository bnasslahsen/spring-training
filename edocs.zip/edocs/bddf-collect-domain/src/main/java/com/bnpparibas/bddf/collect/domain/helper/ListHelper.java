package com.bnpparibas.bddf.collect.domain.helper;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public final class ListHelper {

	private ListHelper() {
		super();
	}

	public static <T> Optional<T> findAny(List<T> list, Predicate<? super T> predicate) {
		return list.stream().filter(predicate).findAny();
	}

	public static <T> Optional<T> anyEq(List<T> list, T obj) {
		return findAny(list, obj::equals);
	}

	public static <T> List<T> findAll(List<T> list, Predicate<? super T> predicate) {
		return list.stream().filter(predicate).collect(Collectors.toList());
	}
}
