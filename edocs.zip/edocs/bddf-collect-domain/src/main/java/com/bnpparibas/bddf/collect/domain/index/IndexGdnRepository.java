package com.bnpparibas.bddf.collect.domain.index;

import java.nio.ByteBuffer;
import java.util.UUID;

import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Repository
public interface IndexGdnRepository {

	String saveIndex(Indexe piece, ByteBuffer pieceData, String idCollecte, String idType, String employeeId, String userId, String channel);

	ByteBuffer getPieceData(UUID pieceId, String callingUser, String userType, String idGdn);
}
