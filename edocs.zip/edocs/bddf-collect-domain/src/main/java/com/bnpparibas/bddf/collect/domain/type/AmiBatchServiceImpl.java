package com.bnpparibas.bddf.collect.domain.type;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpparibas.bddf.collect.domain.ami.batch.AmiBatchRepository;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Repository
@Repository
@Transactional(transactionManager = "transactionManagerDB")
public class AmiBatchServiceImpl implements AmiBatchService {

	@Autowired
	AmiBatchRepository amiBatchRepository;

	@Override
	@Transactional(transactionManager = "transactionManagerDB")
	public void save(AmiBatch amiBatch) {
		amiBatchRepository.saveAmiBatch(amiBatch);
	}

	@Override
	@Transactional(transactionManager = "transactionManagerDB", propagation = Propagation.REQUIRES_NEW)
	public void update(AmiBatch amiBatch) {
		amiBatchRepository.update(amiBatch);
	}

}
