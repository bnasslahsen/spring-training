package com.bnpparibas.bddf.collect.domain.piece;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.togglz.core.manager.FeatureManager;

import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditEvent;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.collect.validation.CollectValidator;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.event.type.TypeReceived;
import com.bnpparibas.bddf.collect.domain.event.type.TypeReceivedType;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.TypeControls;
import com.bnpparibas.bddf.collect.domain.owner.ClientNotificationService;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlService;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.collect.domain.type.TypeStatus;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.errors.TechnicalException;
import com.bnpparibas.bddf.rest.Context;

/**
 *
 * Cette classe présente l'implémentation des Web Service Rest de la ressource Piece
 *
 */

@Service
@Transactional(transactionManager = "transactionManagerDB", rollbackFor = Exception.class)
public class PieceServiceImpl implements PieceService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PieceServiceImpl.class);

	private final CollectRepository collectRepository;
	private final TypeRepository typeRepository;
	private final PieceRepository pieceRepository;
	private final CollectValidator customValidator;
	private final CollectEventHandler collectEventHandler;
	private final PieceGdnService pieceGdnService;
	private final AuditGenerator auditGenerator;
	private final Environment environment;

	@Autowired
	private EdocTypeRepository edocTypeRepository;
	@Autowired
	private final TypeAutomaticControlService typeAutomaticControlService;
	@Autowired
	private PieceValidator pieceValidator;
	@Autowired
	private FeatureManager featureManager;
	@Autowired
	private PieceAutomaticControlUtils pieceAutomaticControlUtils;
	@Autowired
	private ClientNotificationService clientNotificationService;

	@Value("${collect.blacklist-jmc-format}")
	private String blackListJmcFormat;

	@Autowired(required = false)
	public PieceServiceImpl(CollectRepository collectRepository, TypeRepository typeRepository, PieceRepository pieceRepository, CollectValidator customValidator, CollectEventHandler collectEventHandler, PieceGdnService pieceGdnService,
			AuditGenerator auditGenerator, Environment environment, TypeAutomaticControlService typeAutomaticControlService, FeatureManager featureManager, PieceAutomaticControlUtils pieceAutomaticControlUtils) {
		this.collectRepository = collectRepository;
		this.typeRepository = typeRepository;
		this.pieceRepository = pieceRepository;
		this.customValidator = customValidator;
		this.collectEventHandler = collectEventHandler;
		this.pieceGdnService = pieceGdnService;
		this.auditGenerator = auditGenerator;
		this.environment = environment;
		this.typeAutomaticControlService = typeAutomaticControlService;
		this.featureManager = featureManager;
		this.pieceAutomaticControlUtils = pieceAutomaticControlUtils;
	}

	@Override
	public UUID addPiece(UUID collectId, UUID typeId, Piece piece, ByteBuffer bytes, String contentType, Context context) throws InterruptedException {
		final Collect collect = collectRepository.findOne(collectId);
		final UUID pieceId = UUID.randomUUID();
		Optional<Type> optType = Optional.empty();
		try {
			final Type type = collect.getTypes().stream().filter(t -> t.getId().equals(typeId)).findAny()
					.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_NOT_FOUND, typeId.toString(), collectId.toString(), typeId.toString())));
			optType = Optional.ofNullable(type);
			customValidator.familyBlocked(type);
			final Set<Piece> pieces = validatePiece(typeId, piece, contentType, context, collect, pieceId, type);
			// RG127 Ajout Pièce pour un type RC
			if (!Arrays.asList(PieceStatus.VA.getLabel(), PieceStatus.RC.getLabel()).contains(piece.getStatus()) && TypeStatus.RC.getLabel().equals(type.getStatus())) {
				type.setStatus(TypeStatus.IN.getLabel());
			}

			AuditEvent auditEvent;
			if (PieceRecivedFormat.PAP.name().equals(piece.getReceivedFormat())) {
				processAddPiecePap(piece, context.getCustomerId(), collect, type, pieces, context.getMedia());
				type.getPieces().add(piece);
				updateTypeStatus(type, piece);
				pieceRepository.addPiece(piece, typeId);
				typeRepository.updateForAddPiece(type.getId(), type.getStatus(), type.isPendingDocument(), type.getPendingDocumentLabel());
				// Audit
				AuditValue auditValue = null;
				if (PieceStatus.RF.getLabel().equals(piece.getStatus())) {
					auditValue = AuditValue.REJECTION_TYPE;
				} else if (PieceStatus.RC.getLabel().equals(piece.getStatus())) {
					auditValue = AuditValue.ACCEPT_TYPE;
				} else {
					auditValue = AuditValue.VALIDATE_TYPE;
				}
				auditEvent = auditGenerator.newAudit(context, auditValue, type.getLabel(), piece.getReceivedFormat(), "1")
						// Collecte
						.setIdCollect(collectId).setJourneyCode(collect.getJourneyCode()).setTotalPieces(1).setControlRequired(type.getControlRequired())
						// type
						.setIdType(typeId).setIdPiece(pieceId).setEdocType(type.getEdocType()).setTypeLabel(Optional.ofNullable(type.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(type.getLabel()));
			} else {
				piece.setContentType(contentType);
				pieceRepository.addPieceData(piece.getId(), bytes, contentType, piece.getLabel());
				type.getPieces().add(piece);
				pieceRepository.addPiece(piece, typeId);
				typeRepository.updateForAddPiece(type.getId(), type.getStatus(), type.isPendingDocument(), type.getPendingDocumentLabel());
				auditEvent = auditGenerator.newAudit(context, AuditValue.ADD_PIECE_NUM, type.getLabel())
						// Collecte
						.setIdCollect(collectId).setJourneyCode(collect.getJourneyCode())
						// type
						.setIdType(typeId).setIdPiece(pieceId)
						//
						.setControlRequired(type.getControlRequired())
						// edocType
						.setEdocType(type.getEdocType()).setTypeLabel(Optional.ofNullable(type.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(type.getLabel()));
			}
			collectEventHandler.sendAuditEvent(auditEvent);
			return pieceId;
		} catch (final CollectBusinessException ex) {

			String[] params;
			AuditValue auditValue;
			if (piece.getReceivedFormat().equals(PieceRecivedFormat.NUM.name())) {
				params = new String[] { optType.map(Type::getLabel).orElse("") };
				auditValue = AuditValue.ERROR_ADD_PIECE_NUM;
			} else {
				params = new String[] { optType.map(Type::getLabel).orElse(""), "PAP" };
				auditValue = AuditValue.ERROR_UPDATE_TYPE;
			}
			final AuditEvent auditEvent = auditGenerator.newAudit(context, auditValue, params).setCodeError(ex.getMessage())
					// Collecte
					.setIdCollect(collectId).setJourneyCode(collect.getJourneyCode())
					// Type
					.setIdType(typeId);
			collectEventHandler.sendAuditEvent(auditEvent);
			throw ex;
		}

	}

	private Set<Piece> validatePiece(UUID typeId, Piece piece, String contentType, Context context, final Collect collect, final UUID pieceId, final Type type) {
		checkUnAuthorizedChannel(piece, context.getCanal());

		final Set<Piece> pieces = type.getActivePieces().stream().filter(p -> PieceStates.ACTIF.name().equals(p.getState())).collect(Collectors.toSet());

		checkUnAuthorizedType(typeId, collect, type);
		checkTypeStatusControl(type);
		checkTypePaperAllowed(piece, type);
		piece.setId(pieceId);
		piece.setAcquisitionDate(Instant.now());
		piece.setMaxPosition(type);
		piece.setStatusSentToGdn("NOT_SENT");
		if (piece.getReceivedFormat().equals(PieceRecivedFormat.NUM.name())) {
			piece.setStatus(PieceStatus.TP.getLabel());
		}

		final long nbPieces = pieces.stream().filter(pieceL -> Arrays.asList(PieceStatus.DF.getLabel(), PieceStatus.TP.getLabel()).contains(pieceL.getStatus())).count();

		pieceValidator.validatePiece(piece, collect, type, contentType, blackListJmcFormat, nbPieces);

		final boolean receivedFormatChanged = pieces.stream().anyMatch(p -> PieceStates.ACTIF.name().equals(p.getState()) && !p.getReceivedFormat().equals(piece.getReceivedFormat()));

		// RG 82
		checkAuthorizedColOnePiece(piece, type, pieces, receivedFormatChanged);
		// RG22
		if (receivedFormatChanged) {
			checkUnAuthorizedPieceChannel(piece, context.getCanal(), type, pieces);
			pieces.forEach(p -> {
				deletePiece(context, type, p);
				pieceRepository.updatePiece(p, type.getId());
			});

		}
		return pieces;
	}

	private void updateTypeStatus(Type type, Piece piece) {
		if (PieceStatus.VA.getLabel().equals(piece.getStatus())) {
			type.setStatus(TypeStatus.VA.getLabel());
		} else if (PieceStatus.RC.getLabel().equals(piece.getStatus())) {
			type.setStatus(TypeStatus.RC.getLabel());
		}
	}

	private void processAddPiecePap(Piece piece, String userId, Collect collect, Type type, Set<Piece> pieces, String media) {
		final TypeReceived typeReceived = new TypeReceived();
		typeReceived.setChannel(piece.getChannel());
		typeReceived.setMedia(media);
		typeReceived.setCollect(collect);
		typeReceived.setUserId(userId);
		if (type.getParentId() == null) {
			typeReceived.setType(type);
		} else {
			typeReceived.setType(collect.getTypes().stream().filter(t -> t.getId().equals(type.getParentId())).findAny().orElse(null));
			typeReceived.setSubType(type);
		}

		final Set<Piece> piecesToSend = new HashSet<>();
		piecesToSend.add(piece);
		pieces.stream().filter(this::eventPieceDeleted).forEach(piecesToSend::add);
		typeReceived.setPieces(piecesToSend);
		typeReceived.setTypeReceivedType(TypeReceivedType.CONTROLLED);
		collectEventHandler.sendTypeReceivedEvent(typeReceived);
		type.setPendingDocument(false);
		type.setPendingDocumentLabel(null);
	}

	private void checkAuthorizedColOnePiece(Piece piece, Type type, Set<Piece> pieces, boolean receivedFormatChanged) {
		if (!receivedFormatChanged && PieceRecivedFormat.PAP.name().equals(piece.getReceivedFormat()) && !pieces.isEmpty()) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_ONE_PIECE_AUTHORIZED, type.getId().toString()));
		}
	}

	private void checkUnAuthorizedPieceChannel(Piece piece, String channel, Type type, Set<Piece> pieces) {
		if (!Channel.isCollab(channel) && PieceRecivedFormat.NUM.name().equals(piece.getReceivedFormat()) && pieces.stream().anyMatch(p -> PieceStatus.VA.getLabel().equals(p.getStatus()) || PieceStatus.RC.getLabel().equals(p.getStatus()))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_CHANNEL_UNAUTHORIZED, type.getId().toString(), piece.getChannel())); // RG87
		}
	}

	private void checkUnAuthorizedType(UUID typeId, Collect collect, Type type) {
		if (type.getParentId() == null && collect.getTypes().stream().anyMatch(t -> typeId.equals(t.getParentId()))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_UNAUTHORIZED, typeId.toString()));// RG 83
		}
	}

	private void checkTypePaperAllowed(Piece piece, Type type) {
		if (!type.isPaperAllowed() && PieceRecivedFormat.PAP.name().equals(piece.getReceivedFormat())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_ONE_PIECE_PAPER_NOT_ALLOWED, type.getId().toString(), type.getLabel()));
		}

	}

	private void checkUnAuthorizedChannel(Piece piece, String channel) {
		if (!Channel.isCollab(channel) && PieceRecivedFormat.PAP.name().equals(piece.getReceivedFormat())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_CHANNEL_UNAUTHORIZED, piece.getChannel())); // RG86
		}
	}

	private void checkTypeStatusControl(Type type) {
		if (Arrays.asList(TypeControls.EC.name(), TypeControls.EC_AMI.name()).contains(type.getStatusControl())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_LADRAD_EC));
		}
	}

	@Override
	public Pair<Piece, ByteBuffer> getPiece(UUID collectId, UUID typeId, UUID pieceId, Context context) {
		final Optional<Type> type = Optional.ofNullable(typeRepository.findOne(collectId, typeId));
		String pieceLabel = null;
		try {
			final Piece piece = Optional.ofNullable(pieceRepository.getPiece(collectId, typeId, pieceId))
					.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_NOT_FOUND, pieceId.toString(), collectId.toString(), typeId.toString(), pieceId.toString())));
			final ByteBuffer pieceData = pieceRepository.tryGetPieceNasElseGdn(pieceId, context, piece);
			pieceLabel = piece.getLabel();
			return Pair.of(piece, pieceData);
		} catch (final CollectBusinessException bex) {
			sendAuditPieceError(collectId, typeId, context, type, pieceLabel, bex.getMessage(), pieceId);
			throw bex;
		} catch (final TechnicalException tex) {
			sendAuditPieceError(collectId, typeId, context, type, pieceLabel, tex.getMessage(), pieceId);
			throw tex;
		}
	}

	private void sendAuditPieceError(UUID collectId, UUID typeId, Context context, Optional<Type> type, String pieceLabel, String codeError, UUID pieceId) {
		final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_GET_PIECE, type.map(Type::getLabel).orElse(""), Optional.ofNullable(pieceLabel).orElse("")).setCodeError(codeError)
				// Collecte
				.setIdCollect(collectId).setJourneyCode(collectRepository.getJourneyCode(collectId))
				// Type & piece
				.setIdType(typeId).setIdPiece(pieceId).setEdocType(type.map(Type::getEdocType).orElse(null)).setTypeLabel(type.map(Type::getEdocType).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(type.map(Type::getLabel).orElse("")));
		collectEventHandler.sendAuditEvent(auditEvent);
	}

	@Override
	public void updatePieces(UUID collectId, UUID typeId, Set<Piece> pieces, Context context) throws InterruptedException {

		final Collect collect = Optional.ofNullable(collectRepository.findOne(collectId)).orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_NOT_FOUND, collectId.toString()))); // RG 76

		Type type = null;

		try {
			type = collect.getTypes().stream().filter(t -> t.getId().equals(typeId)).findAny()
					.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_NOT_FOUND, typeId.toString(), collectId.toString(), typeId.toString())));
			customValidator.familyBlocked(type);
			checkTypeStatusControl(type);
			final Set<Piece> activesPieces = type.getActivePieces();

			if (pieces.size() > 5) {
				throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_NUMBER, type.getId().toString(), type.getLabel()));
			}
			pieceValidator.validatePieceExistence(activesPieces, pieces, collectId, typeId);
			pieces.forEach(piece -> pieceValidator.validatePieceFieldsSize(piece));

			final Set<Piece> piecesToRemoveList = preparePiecesToRemove(pieces, context, type, activesPieces);

			final Set<Piece> gdnPieces = preparePiecesToSendToGDN(pieces, context, activesPieces);

			// case only delete piece without send piece to GDN ??
			if (CollectionUtils.isNotEmpty(piecesToRemoveList)) {
				typeAutomaticControlService.updateIndexesOnDeletePieces(collect, type, new HashSet<Piece>(piecesToRemoveList), context, CollectionUtils.isEmpty(gdnPieces));
			}

			handleType(type);

			typeRepository.updateType(collectId, type);

			pieceAutomaticControlUtils.sendPiecesToGdnAndControlFirstIteration(collectId, context, collect, type, piecesToRemoveList.stream().filter(this::eventPieceDeleted).collect(Collectors.toSet()), gdnPieces);

			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.UPDATE_PIECES, type.getLabel(), String.valueOf(gdnPieces.size()))
					// Collecte
					.setIdCollect(collectId).setJourneyCode(collect.getJourneyCode())
					// Control Required
					.setControlRequired(type.getControlRequired())
					//
					.setTotalPieces(gdnPieces.size())
					// Type
					.setIdType(typeId).setEdocType(type.getEdocType()).setTypeLabel(Optional.ofNullable(type.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(type.getLabel()));
			collectEventHandler.sendAuditEvent(auditEvent);

		} catch (final CollectBusinessException ex) {
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_VALIDATE_TYPE, Optional.ofNullable(type).map(Type::getId).map(Object::toString).orElse(""), Optional.ofNullable(type).map(Type::getLabel).orElse(""))
					.setCodeError(ex.getMessage())
					// Collecte
					.setIdCollect(collectId).setJourneyCode(collect.getJourneyCode())
					// Type
					.setIdType(typeId);
			collectEventHandler.sendAuditEvent(auditEvent);
			throw ex;
		}
	}

	private void handleType(final Type type) {
		type.setPendingDocument(false); // RG-37
		// RG127 Réinitialisation du statut des types RC
		if (TypeStatus.RC.getLabel().equals(type.getStatus())) {
			type.setStatus(TypeStatus.IN.getLabel());
		}
		// RG154
		customValidator.setTypeStatusToInWhenNonePieceAndTypeStatusWasRC(type);
	}

	private Set<Piece> preparePiecesToSendToGDN(Set<Piece> pieces, Context context, final Set<Piece> activesPieces) {
		final Set<Piece> gdnPieces = new HashSet<>();
		pieces.stream()
				// Map with repository piece
				.map(piece -> buildPair2(piece, activesPieces))
				// Validate new status
				.peek(pair -> pieceValidator.validatePutPiecesStatus(pair.getRight(), pair.getLeft().getStatus(), context.getCanal()))
				// Filter piece with changed status
				.filter(pair -> !pair.getRight().getStatus().equals(pair.getLeft().getStatus()))
				// Save pieces
				.forEach(pair -> performUpdatePiece(context, gdnPieces, pair));
		gdnPieces.forEach(piece -> initialiseDPEC(piece));
		return gdnPieces;
	}

	private Set<Piece> preparePiecesToRemove(Set<Piece> pieces, Context context, final Type type, final Set<Piece> activesPieces) {
		final Set<Piece> piecesToRemoveList = new HashSet<>();
		piecesToRemoveList.addAll(activesPieces);
		piecesToRemoveList.removeAll(pieces);
		piecesToRemoveList.forEach(p -> pieceValidator.validatePieceSupprPutPieces(p, context.getCanal()));
		piecesToRemoveList.forEach(piece -> deletePiece(context, type, piece));
		return piecesToRemoveList;
	}

	private void initialiseDPEC(Piece piece) {
		pieceRepository.updatePieceStatus(piece.getId(), PieceStatus.DP_EC.getLabel());
	}

	private boolean eventPieceDeleted(Piece p) {
		return StringUtils.isNotEmpty(p.getIdDocGdn()) || "PAP".equals(p.getReceivedFormat());
	}

	@Override
	public boolean deletePiece(UUID collectId, UUID typeId, UUID pieceId, Context context) {

		final Collect collect = Optional.ofNullable(collectRepository.findOne(collectId)).orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_COLLECT_NOT_FOUND, collectId.toString()))); // RG 76

		Optional<Type> optType = Optional.empty();
		Optional<Piece> optPiece = Optional.empty();
		try {
			final String channel = context.getCanal();
			final Type type = collect.getTypes().stream().filter(t -> t.getId().equals(typeId)).findAny()
					.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_TYPE_NOT_FOUND, typeId.toString(), collectId.toString(), typeId.toString()))); // RG
			optType = Optional.ofNullable(type);
			checkTypeStatusControl(type);
			final Piece piece = type.getActivePieces().stream().filter(p -> p.getId().equals(pieceId)).findAny()
					.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_NOT_FOUND, pieceId.toString(), collectId.toString(), typeId.toString(), pieceId.toString())));
			optPiece = Optional.ofNullable(piece);

			isDeleteAuthorized(channel, piece);

			deletePiece(context, type, piece);
			typeAutomaticControlService.updateIndexesOnDeletePieces(collect, type, new HashSet<Piece>(Arrays.asList(piece)), context, true);
			// RG154
			customValidator.setTypeStatusToInWhenNonePieceAndTypeStatusWasRC(type);

			typeRepository.updateType(collectId, type);

			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.DELETE_PIECE, type.getLabel(), piece.getReceivedFormat(), piece.getStatus())
					// Collecte
					.setIdCollect(collectId).setJourneyCode(collect.getJourneyCode())
					// Type & piece
					.setIdType(typeId).setIdPiece(pieceId).setEdocType(type.getEdocType()).setTypeLabel(Optional.ofNullable(type.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(type.getLabel()));
			collectEventHandler.sendAuditEvent(auditEvent);
			return true;
		} catch (final CollectBusinessException ex) {
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_DELETE_PIECE, optType.map(Type::getLabel).orElse(""), optPiece.map(Piece::getReceivedFormat).orElse(""), optPiece.map(Piece::getStatus).orElse(""))
					.setCodeError(ex.getMessage())
					// Collecte
					.setIdCollect(collectId).setJourneyCode(collect.getJourneyCode())
					// Type & piece
					.setIdType(typeId).setIdPiece(pieceId);
			collectEventHandler.sendAuditEvent(auditEvent);
			throw ex;
		}

	}

	private void isDeleteAuthorized(final String channel, final Piece piece) {
		if (PieceStatus.DP_EC.getLabel().equals(piece.getStatus())) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_DELETE_UNAUTHORIZED, piece.getLabel()));
		}
		if (Channel.isClient(channel) && (PieceStatus.DP.getLabel().equals(piece.getStatus()) || PieceStatus.VA.getLabel().equals(piece.getStatus()) || PieceStatus.RC.getLabel().equals(piece.getStatus()))) {
			throw new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_DELETE_UNAUTHORIZED, piece.getLabel()));
		}
	}

	@Override
	public ByteBuffer getThumbnail(UUID collectId, UUID typeId, UUID pieceId, String channel) {
		final Optional<Type> type = Optional.ofNullable(typeRepository.findOne(collectId, typeId));
		final Piece piece = type

				// get pieces
				.map(Type::getActivePieces).map(Collection::stream)
				// filterPieces
				.map(pieces -> pieces.filter(p -> pieceId.equals(p.getId())).findAny().orElse(null))
				// throw ex when not found
				.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_NOT_FOUND, pieceId.toString(), collectId.toString(), typeId.toString(), pieceId.toString())));

		if ("PAP".equals(piece.getReceivedFormat())) {
			return null;
		}
		return pieceRepository.getThumbnail(pieceId);
	}

	private void updatePieceAttributes(Piece p, String channel, String userId) {
		if (Channel.isCollab(channel)) {
			p.setEmployeeId(userId);
			p.setOwnerId(null);
		} else if (Channel.isClient(channel)) {
			p.setEmployeeId(null);
			p.setOwnerId(userId);
		}
	}

	private void performUpdatePiece(Context context, Set<Piece> gdnPieces, Pair<Piece, Piece> pair) {
		final Piece pieceRepo = pair.getRight();
		updatePieceAttributes(pieceRepo, context.getCanal(), context.getCustomerId());
		// Save in GDN
		gdnPieces.add(pieceRepo);
		pieceRepo.setStatus(PieceStatus.DP_EC.getLabel());
		pieceRepo.setAcquisitionDate(Instant.now());
		pieceRepo.setChannel(context.getCanal());
	}

	private void deletePiece(Context context, Type type, Piece piece) {
		piece.setState(PieceStates.INACTIF.getLabel());
		piece.setUpdateDate(Instant.now());
		updatePieceAttributes(piece, context.getCanal(), context.getCustomerId());

		type.getIndexes().stream().forEach(index -> {
			if (index.getIndexesJmc().stream().allMatch(indexJMC -> indexJMC.getIdPiece().equals(piece.getId()))) {
				index.initControls();
				index.getIndexesJmc().clear();
			} else if (index.getIndexesJmc().stream().anyMatch(indexJMC -> indexJMC.getIdPiece().equals(piece.getId()))) {
				index.getIndexesJmc().removeIf(indexJmc -> indexJmc.getIdPiece().equals(piece.getId()));
			}
		});
	}

	private Pair<Piece, Piece> buildPair2(Piece piece, Set<Piece> pieces) {
		return Pair.of(piece, pieces.stream().filter(p -> p.equals(piece)).findAny().orElse(null));
	}

	public EdocTypeRepository getEdocTypeRepository() {
		return edocTypeRepository;
	}

	public void setEdocTypeRepository(EdocTypeRepository edocTypeRepository) {
		this.edocTypeRepository = edocTypeRepository;
	}

	public PieceValidator getPieceValidator() {
		return pieceValidator;
	}

	public void setPieceValidator(PieceValidator pieceValidator) {
		this.pieceValidator = pieceValidator;
	}

	public String getBlackListJmcFormat() {
		return blackListJmcFormat;
	}

	public void setBlackListJmcFormat(String blackListJmcFormat) {
		this.blackListJmcFormat = blackListJmcFormat;
	}

}