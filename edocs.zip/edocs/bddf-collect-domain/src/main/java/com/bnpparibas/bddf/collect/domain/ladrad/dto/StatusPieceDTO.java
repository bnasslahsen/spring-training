package com.bnpparibas.bddf.collect.domain.ladrad.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Data used for create Folder in JOUVE
 *
 * @author c07128
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class StatusPieceDTO {

	@JsonProperty("status")
	private String status;

	@JsonProperty("reference")
	private String reference;

	@JsonProperty("type")
	private String type;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
