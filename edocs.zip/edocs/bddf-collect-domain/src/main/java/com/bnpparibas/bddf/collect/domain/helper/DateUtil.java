package com.bnpparibas.bddf.collect.domain.helper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import com.bnp.schema.edoc.type.Types.EdocType;

public final class DateUtil {

	private static final String JJMMAAAA_HHMMSS = "dd/MM/yyyy HH:mm:ss";
	private static final String AAAAMMDDHH = "yyyyMMddHH";
	private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss").withZone(ZoneId.systemDefault());
	private static final String YYYYMMDD = "yyyy-MM-dd";

	private DateUtil() {
		super();
	}

	public static String instantToString(Instant instant) {
		return FORMATTER.format(instant);
	}

	public static String toGdnFormat(Date date) {
		return new SimpleDateFormat(JJMMAAAA_HHMMSS).format(date);
	}

	public static String toLotIdFormat(Date date) {
		return new SimpleDateFormat(AAAAMMDDHH).format(date);
	}

	public static Date todayMidnight() {
		final Calendar date = new GregorianCalendar();
		date.set(Calendar.HOUR_OF_DAY, 0);
		date.set(Calendar.MINUTE, 0);
		date.set(Calendar.SECOND, 0);
		date.set(Calendar.MILLISECOND, 0);
		return date.getTime();
	}

	public static Date midnightOf(Date date) {
		final Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}

	public static Date roundDate(Instant creationDate) {
		LocalDateTime time = LocalDateTime.ofInstant(creationDate, ZoneId.systemDefault());
		time = time.truncatedTo(ChronoUnit.HOURS).plusMinutes(15 * (time.getMinute() / 15));
		return Date.from(time.atZone(ZoneId.systemDefault()).toInstant());
	}

	public static Instant getRetentionDate(EdocType edocType) {
		ZonedDateTime todayMidnight = ZonedDateTime.now(ZoneId.systemDefault()).truncatedTo(ChronoUnit.DAYS);
		todayMidnight = todayMidnight.plusMonths(-edocType.getMonthRentetionTime());
		todayMidnight = todayMidnight.plusYears(-edocType.getYearRentetionTime());
		return todayMidnight.toInstant();
	}

	public static boolean isFormatDateValid(String date) {
		final List<String> knownPatterns = Arrays.asList(YYYYMMDD, "dd-MM-yyyy", "dd.MM.yyyy", "yyyy/MM/dd", "dd/MM/yyyy", "dd MM yyyy");
		Date dateToParse = null;
		for (final String pattern : knownPatterns) {
			try {
				dateToParse = isLegalDate(date, pattern);
				break;
			} catch (final ParseException ex) {
				dateToParse = null;
			}
		}
		return dateToParse != null && date.length() == 10;
	}

	public static String formatDateForJmc(String date, String format) {
		final List<String> knownPatterns = Arrays.asList(YYYYMMDD, "dd-MM-yyyy", "dd.MM.yyyy", "yyyy/MM/dd", "dd/MM/yyyy", "dd MM yyyy");
		Date dateToParse = null;
		for (final String pattern : knownPatterns) {
			try {
				dateToParse = isLegalDate(date, pattern);
				break;
			} catch (final ParseException ex) {
				dateToParse = null;
			}
		}

		return dateToParse == null ? "" : (new SimpleDateFormat(format)).format(dateToParse);
	}

	public static String formatDateFromJmc(String date) {
		Date dateToParse = null;
		try {
			dateToParse = isLegalDate(date, "yyyy-MM-dd");

		} catch (final ParseException ex) {
			try {
				dateToParse = isLegalDate(date, "dd MM yyyy");
			} catch (final ParseException e) {
				dateToParse = null;
			}
		}
		return dateToParse == null ? "" : (new SimpleDateFormat("dd/MM/yyyy")).format(dateToParse);
	}

	public static Date isLegalDate(String dateToParse, String format) throws ParseException {
		final SimpleDateFormat sdf = new SimpleDateFormat(format);
		sdf.setLenient(false);
		return sdf.parse(dateToParse);
	}
}
