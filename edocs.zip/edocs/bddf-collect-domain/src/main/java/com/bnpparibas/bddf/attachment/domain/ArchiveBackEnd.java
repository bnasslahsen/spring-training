package com.bnpparibas.bddf.attachment.domain;

public enum ArchiveBackEnd {
	GDN("GDN");
	
	private String label;
	
	private ArchiveBackEnd(String label) {
		this.label = label; 
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
}
