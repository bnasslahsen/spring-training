package com.bnpparibas.bddf.collect.domain.edoc.families;

import java.util.List;

import com.bnp.schema.edoc_families.EdocFamilies.EdocFamily;

public interface EdocFamiliesRepository {
	public List<EdocFamily> findAll();
}
