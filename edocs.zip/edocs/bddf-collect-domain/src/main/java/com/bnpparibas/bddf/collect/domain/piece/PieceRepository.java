package com.bnpparibas.bddf.collect.domain.piece;

import java.nio.ByteBuffer;
import java.util.List;
import java.util.UUID;

import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.Repository
public interface PieceRepository {

	Piece getPiece(UUID collectId, UUID typeId, UUID pieceId);

	public ByteBuffer getPieceFromNas(UUID pieceId);

	ByteBuffer getThumbnail(UUID pieceId);

	void addPieceData(UUID pieceId, ByteBuffer data, String contentType, String label);

	void addPiece(Piece piece, UUID typeId);

	void deletePiece(UUID pieceId);

	void deleteThumbnail(UUID pieceId);

	void updateStatusAndIdGdn(UUID pieceId, String status, String gdnId);

	void updatePieceStatus(UUID pieceId, String status);

	void updatePiece(Piece piece, UUID typeId);

	void updateStatusControl(UUID pieceId, String statusControl);

	void updateStatusSentToGdn(UUID pieceId, String status);

	void deleteAllPiecesOnGdnAndNas(List<Piece> pieces);

	ByteBuffer tryGetPieceNasElseGdn(UUID pieceId, Context context, final Piece piece);

	ByteBuffer getPieceDataFromGdn(UUID pieceId, Context context, final Piece piece);

}
