package com.bnpparibas.bddf.attachment.domain;

public enum ArchivingStatus {
	TP("TP"), DP("DP");
	
	private String label;
	
	private ArchivingStatus(String label) {
		this.label = label; 
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
}
