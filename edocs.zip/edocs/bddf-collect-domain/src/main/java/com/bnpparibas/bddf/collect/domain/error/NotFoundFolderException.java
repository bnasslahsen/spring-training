package com.bnpparibas.bddf.collect.domain.error;

public class NotFoundFolderException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public NotFoundFolderException() {
		super();
	}

}
