package com.bnpparibas.bddf.collect.domain.piece.validation;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Repository
public interface ValidationPieceRepository {

	List<ValidationPiece> getByCreationDate(Date creationDate);

	void update(ValidationPiece validationPiece);

	void save(ValidationPiece validationPiece);

	void delete(ValidationPiece validationPiece);

	void deleteByID(UUID id);

}
