package com.bnpparibas.bddf.collect.domain.notification;

import java.util.List;

import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Entity

public class VariablesList {
	private List<Variable> variable;

	public VariablesList() {
		super();
	}

	public VariablesList(List<Variable> variable) {
		super();
		this.variable = variable;
	}

	public List<Variable> getVariable() {
		return variable;
	}

	public void setVariable(List<Variable> variable) {
		this.variable = variable;
	}

}
