package com.bnpparibas.bddf.collect.domain.index;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Entity
public class Indexe implements Comparable<Indexe> {

	private UUID id;
	private String code;
	private String label;
	private String category;
	private boolean indexable;
	private String referenceValue;
	private String extractedValue;
	private String correctedValue;
	private String format;
	private int minSize;
	private int maxSize;
	private int position;
	private String statusControl;
	private String messageControl;
	private String ownerIndex;
	private String additionalInformation;
	private boolean videoCoding;
	private List<IndexeJmc> indexesJmc;
	private String groupLabel;
	public static final String DEFAULT_OWNER_INDEX = "1";

	public Indexe() {
	}

	public Indexe(UUID id, String code, String label, String category, boolean indexable, String referenceValue, String extractedValue, String correctedValue, String format, int position, String statusControl, String messageControl, String ownerIndex,
			String additionalInformation, boolean videoCoding, String groupLabel) {
		super();
		this.id = id;
		this.code = code;
		this.label = label;
		this.category = category;
		this.indexable = indexable;
		this.referenceValue = referenceValue;
		this.extractedValue = extractedValue;
		this.correctedValue = correctedValue;
		this.format = format;
		this.position = position;
		this.statusControl = statusControl;
		this.messageControl = messageControl;
		this.ownerIndex = ownerIndex;
		this.additionalInformation = additionalInformation;
		this.videoCoding = videoCoding;
		this.groupLabel = groupLabel;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || (getClass() != obj.getClass())) {
			return false;
		}

		return equalsPart2(obj);
	}

	private boolean equalsPart2(Object obj) {
		final Indexe other = (Indexe) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		final int numberChar = 186;
		final StringBuilder builder = new StringBuilder(numberChar);
		builder.append("Index [id=");
		builder.append(id);
		builder.append(", code=");
		builder.append(code);
		builder.append(", label=");
		builder.append(label);
		builder.append(", category=");
		builder.append(category);
		builder.append(", indexable=");
		builder.append(indexable);
		builder.append(", referenceValue=");
		builder.append(referenceValue);
		builder.append(", extractedValue=");
		builder.append(extractedValue);
		builder.append(", correctedValue=");
		builder.append(correctedValue);
		builder.append(", format=");
		builder.append(format);
		builder.append(", sizeMin=");
		builder.append(minSize);
		builder.append(", sizeMax=");
		builder.append(maxSize);
		builder.append(", position=");
		builder.append(position);
		builder.append(", statusControl=");
		builder.append(statusControl);
		builder.append(", messageControl =");
		builder.append(messageControl);
		builder.append("]");
		return builder.toString();
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public boolean isIndexable() {
		return indexable;
	}

	public void setIndexable(boolean indexable) {
		this.indexable = indexable;
	}

	public String getReferenceValue() {
		return referenceValue;
	}

	public void setReferenceValue(String referenceValue) {
		this.referenceValue = referenceValue;
	}

	public String getExtractedValue() {
		return extractedValue;
	}

	public void setExtractedValue(String extractedValue) {
		this.extractedValue = extractedValue;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public int getMinSize() {
		return minSize;
	}

	public int getMaxSize() {
		return maxSize;
	}

	public void setMinSize(int minSize) {
		this.minSize = minSize;
	}

	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public String getStatusControl() {
		return statusControl;
	}

	public void setStatusControl(String statusControl) {
		this.statusControl = statusControl;
	}

	public String getMessageControl() {
		return messageControl;
	}

	public void setMessageControl(String messageControl) {
		this.messageControl = messageControl;
	}

	public String getOwnerIndex() {
		return ownerIndex;
	}

	public void setOwnerIndex(String ownerIndex) {
		this.ownerIndex = ownerIndex;
	}

	public void initControls() {
		setExtractedValue(null);
		setMessageControl(null);
		setStatusControl(null);
		setCorrectedValue(null);
	}

	public List<IndexeJmc> getIndexesJmc() {
		if (indexesJmc == null) {
			indexesJmc = new ArrayList<>();
		}
		return indexesJmc;
	}

	public void setIndexesJmc(List<IndexeJmc> indexesJmc) {
		this.indexesJmc = indexesJmc;
	}

	public String getCorrectedValue() {
		return correctedValue;
	}

	public void setCorrectedValue(String correctedValue) {
		this.correctedValue = correctedValue;
	}

	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public boolean isVideoCoding() {
		return videoCoding;
	}

	public void setVideoCoding(boolean videoCoding) {
		this.videoCoding = videoCoding;
	}

	public String getGroupLabel() {
		return groupLabel;
	}

	public void setGroupLabel(String groupLabel) {
		this.groupLabel = groupLabel;
	}

	public void setMaxPosition(Set<Indexe> indexes) {

		if (position == 0) {
			if (CollectionUtils.isNotEmpty(indexes)) {
				position = indexes.stream().map(Indexe::getPosition).collect(Collectors.summarizingInt(Integer::intValue)).getMax() + 1;
			} else {
				position = 1;
			}
		}
	}

	@Override
	public int compareTo(Indexe index) {
		if (StringUtils.isNotEmpty(code)) {
			return this.code.compareTo(index.getCode());
		}
		return 0;
	}

}
