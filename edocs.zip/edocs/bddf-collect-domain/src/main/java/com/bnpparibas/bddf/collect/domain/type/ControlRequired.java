package com.bnpparibas.bddf.collect.domain.type;

public enum ControlRequired {
	NO_CONTROL(0), CONTROL_JMC(3);

	private int code;

	ControlRequired(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}

}
