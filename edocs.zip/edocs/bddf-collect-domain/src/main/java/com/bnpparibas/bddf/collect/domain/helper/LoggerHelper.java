package com.bnpparibas.bddf.collect.domain.helper;

import org.jboss.logging.MDC;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class LoggerHelper {

	private static boolean isLogForPerfActivated;

	@SuppressWarnings("static-access")
	@Value("${param.logForPerf}")
	public void setLogForPerf(boolean logForPerf) {
		this.isLogForPerfActivated = logForPerf;
	}

	public static String correctionId() {
		final int number = 55;
		final StringBuilder sb = new StringBuilder(number)
				// applicationName
				.append('[').append(MDC.get("appName")).append(',')
				// traceId
				.append(MDC.get("X-B3-TraceId")).append(',')
				// spanId
				.append(MDC.get("X-B3-SpanId")).append(',')
				// spanId
				.append(MDC.get("X-Span-Export")).append(']');
		return sb.toString();
	}

	public static void logForPerfTest(Logger logger, String info) {
		if (isLogForPerfActivated) {
			logger.info(info);
		}
	}

}
