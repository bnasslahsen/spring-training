package com.bnpparibas.bddf.collect.domain.notification;

import java.util.HashMap;
import java.util.Map;

import com.bnpparibas.bddf.collect.domain.notification.enums.ConstantNotification;
import com.bnpparibas.bddf.collect.domain.notification.enums.NotificationMessageType;
import com.bnpparibas.bddf.collect.domain.notification.enums.RecipientChannelNotification;
import com.bnpparibas.bddf.collect.domain.owner.CommunicationTemplate;

public final class NotificationUtils {

	private NotificationUtils() {
	}

	public static NotificationMessage generateMessageByOwner(String eventId, String communicationTemplate, String ownerReference, String recipientCanal, String collectProductLabel) {

		final String senderId = ConstantNotification.HB_APP.getCode();
		final String typeMessageId = getTypeMessageFromCanal(communicationTemplate, recipientCanal);
		final String applicationLabel = getApplicationLabel(communicationTemplate);
		return new NotificationMessage(senderId, ownerReference, typeMessageId, recipientCanal, collectProductLabel, applicationLabel);
	}

	public static NotificationDIGICOMMessage generateMessageDIGICOMByOwner(String event, String diffussionDate, String communicationTemplate, String ownerReference, String collectProductLabel) {

		final String eventId = event;
		final String receiverId = ownerReference;
		final String receiverIdType = ConstantNotification.RECEIVER_ID_TYPE.getLibelle();
		final String receiverNature = getApplicationLabelDigicom(communicationTemplate);
		final String applicationId = ConstantNotification.ID_DIGICOM_APP.getCode();
		final String customerJourneyId = "";
		final String applicationUseCase = "";
		final String msgReference = ConstantNotification.MSG_REFERENCE_DIGICOM.getCode();
		final String startDiffusionDate = diffussionDate;
		final String receiverPreferences = ConstantNotification.RECEIVER_PREFERENCES_DIGICOM.getLibelle();
		final String multiChannel = ConstantNotification.MULTICHANNEL_DIGICOM.getLibelle();
		final String channelsList = ConstantNotification.CHANNEL_LIST.getLibelle();
		final Map<String, String> variablesList = getVariableList(collectProductLabel, communicationTemplate);

		return new NotificationDIGICOMMessage(eventId, receiverId, receiverIdType, receiverNature, applicationId, customerJourneyId, applicationUseCase, msgReference, startDiffusionDate, receiverPreferences, multiChannel, variablesList, channelsList);

	}

	private static String getApplicationLabel(String communicationTemplate) {
		if (CommunicationTemplate.BNP.getLabel().equals(communicationTemplate)) {
			return ConstantNotification.BNP_APP.getLibelle();
		} else {
			return ConstantNotification.HB_APP.getLibelle();
		}
	}

	private static String getTypeMessageFromCanal(String communicationTemplate, String recipientCanal) {
		String messageType = "";
		if (CommunicationTemplate.BNP.getLabel().equals(communicationTemplate)) {
			if (RecipientChannelNotification.MESSAGE_SECUR_BNP.getCode().equals(recipientCanal)) {
				messageType = NotificationMessageType.MBEDOC01.getCode();
			} else if (RecipientChannelNotification.EMAILS.getCode().equals(recipientCanal)) {
				messageType = NotificationMessageType.MBEDOC02.getCode();
			}
		} else if (CommunicationTemplate.HB.getLabel().equals(communicationTemplate)) {
			if (RecipientChannelNotification.MESSAGE_SECUR_BNP.getCode().equals(recipientCanal)) {
				messageType = NotificationMessageType.BDEDOC01.getCode();
			} else if (RecipientChannelNotification.EMAILS.getCode().equals(recipientCanal)) {
				messageType = NotificationMessageType.BDEDOC02.getCode();
			}
		}
		return messageType;
	}

	private static String getApplicationLabelDigicom(String communicationTemplate) {
		if (CommunicationTemplate.BNP.getLabel().equals(communicationTemplate)) {
			return ConstantNotification.PARTBNP.getLibelle();
		} else {
			return ConstantNotification.PARTHB.getLibelle();
		}
	}

	private static String getVariableListDigicom(String communicationTemplate) {
		if (CommunicationTemplate.BNP.getLabel().equals(communicationTemplate)) {
			return ConstantNotification.VARIABLE_LIST_BNP.getLibelle();
		} else {
			return ConstantNotification.VARIABLE_LIST_HB.getLibelle();
		}
	}

	private static Map<String, String> getVariableList(String collectProductLabel, String communicationTemplate) {
		return new HashMap<String, String>() {
			{
				put(ConstantNotification.VARIABLE_LIST_VAR1.getLibelle(), collectProductLabel);
				put(ConstantNotification.VARIABLE_LIST_VAR2.getLibelle(), getVariableListDigicom(communicationTemplate));
			}
		};

	}

}
