package com.bnpparibas.bddf.attachment.domain;

import java.nio.ByteBuffer;
import java.util.UUID;

import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.DomainService
public interface AttachmentService {

	/**
	 * Add a file to the NAS
	 *
	 * @param attachment
	 * @param file
	 * @return
	 */
	UUID addAttachment(Attachment attachment, ByteBuffer file, Context context);

	/**
	 * Send the temporary file to GDN and delete it in the NAS and the database
	 *
	 * @param idAttachment
	 * @param context
	 * @return
	 */
	String validateAttachment(UUID idAttachment, Context context);

	/**
	 * Delete a file from NAS
	 *
	 * @param idAttachment
	 * @param context
	 */
	void deleteAttachment(UUID idAttachment, Context context);

	/**
	 * Get file from NAS
	 * 
	 * @param idAttachment
	 * @param context
	 * @return
	 */
	Attachment getAttachment(UUID idAttachment, Context context);

}
