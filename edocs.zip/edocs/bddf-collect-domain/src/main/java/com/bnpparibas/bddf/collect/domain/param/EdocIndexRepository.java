package com.bnpparibas.bddf.collect.domain.param;

import java.util.List;

import com.bnp.schema.edoc.index.Indexes.EdocIndex;

public interface EdocIndexRepository {

	List<EdocIndex> findAll();

	EdocIndex byValue(String value);

}
