package com.bnpparibas.bddf.collect.domain.type;

public enum PropertyType {
	LISTE("Liste"), FIXE("Fixe");

	private String label;

	PropertyType(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

}
