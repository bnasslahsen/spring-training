package com.bnpparibas.bddf.collect.domain.error;

public final class CollectErrorConstants {

	public static final String ERR_COL_DATA_VALUE = "ERR-FUNC-UPD-00003";

	public static final String ERR_COL_DATA_CONSISTENCY = "ERR-FUNC-UPD-00002";

	public static final String ERR_COL_DATA_MULTI_VALUE = "ERR-FUNC-UPD-00004";

	public static final String ERR_COL_PIECE_FORMAT = "ERR-FUNC-UPD-00006";

	public static final String ERR_COL_PIECE_SIZE_MIN = "ERR-FUNC-UPD-00007";

	public static final String ERR_COL_PIECE_SIZE_MAX = "ERR-FUNC-UPD-00008";

	public static final String ERR_COL_PIECE_NUMBER = "ERR-FUNC-UPD-00010";

	public static final String ERR_COL_TYPE_DIGITAL_NOT_ALLOWED = "ERR-FUNC-UPD-00011";

	public static final String ERR_COL_PIECE_UNAUTHORIZED_ACTION = "ERR-FUNC-UPD-00012";

	public static final String ERR_COL_PIECE_CHANNEL = "ERR-FUNC-UPD-00013";

	public static final String ERR_SIGNAL_DOC_MANQUANT = "ERR-FUNC-UPD-00101";

	public static final String ERR_COL_PIECE_DELETE_UNAUTHORIZED = "ERR-FUNC-UPD-00015";

	public static final String ERR_COL_PIECE_REJECT_REASON = "ERR-FUNC-UPD-00016";

	public static final String ERR_COL_FAMILY_CATEGORY_UNAUTHORIZED = "ERR-FUNC-UPD-00017";

	public static final String ERR_COL_COLLECT_CLOSED = "ERR-FUNC-UPD-00018";

	public static final String ERR_COL_INVALID = "ERR-FUNC-UPD-00019";

	public static final String ERR_COL_COLLECT_ABANDONED = "ERR-FUNC-UPD-00021";

	public static final String ERR_HABLITATION_NOT_AUTHORIZED = "ERR-FUNC-UPD-00022";

	public static final String ERR_COL_FAMILY_CATEGORY_COMMENT = "ERR-FUNC-UPD-00023";

	public static final String ERR_COL_FAMILY_CATEGORY = "ERR-FUNC-UPD-00024";

	public static final String ERR_COL_TYPE_CLIENT_CHANNEL = "ERR-FUNC-UPD-00025";

	public static final String ERR_COL_TYPE_PENDING_COMMENT = "ERR-FUNC-UPD-00026";

	public static final String ERR_COL_PIECE_REJECT_COMMENT = "ERR-FUNC-UPD-00027";

	public static final String ERR_COL_PIECE_NOT_FOUND = "ERR-FUNC-UPD-00028";

	public static final String ERR_COL_PIECE_UNKNOWN_ACTION = "ERR-FUNC-UPD-00029";

	public static final String ERR_COL_COLLECT_NOT_FOUND = "ERR-FUNC-UPD-00030";

	public static final String ERR_COL_PIECE_UNAUTHORIZED = "ERR-FUNC-UPD-00032";

	public static final String ERR_VERSEMENT_GDN = "ERR-FUNC-UPD-00033";

	public static final String ERR_COL_TYPE_NOT_FOUND = "ERR-FUNC-UPD-00035";

	public static final String ERR_COL_TYPE_REF_VALUE = "ERR-FUNC-UPD-00070";

	public static final String ERR_COL_TYPE_AUTO_REUSE_FORBIDDEN = "ERR-FUNC-UPD-00075";

	public static final String ERR_COL_FAMILY_NOT_FOUND = "ERR-FUNC-UPD-00036";

	public static final String ERR_COL_ONE_PIECE_AUTHORIZED = "ERR-FUNC-UPD-00037";

	public static final String ERR_COL_TYPE_UNAUTHORIZED = "ERR-FUNC-UPD-00038";

	public static final String ERR_COL_CHANNEL_UNAUTHORIZED = "ERR-FUNC-UPD-00040";

	public static final String ERR_COL_PIECE_CHANNEL_UNAUTHORIZED = "ERR-FUNC-UPD-00041";

	public static final String ERR_COL_CATEGORY_TYPE_UNAUTHORIZED = "ERR-FUNC-UPD-00042";

	public static final String ERR_COL_CATEGORY_TYPE_LISTE = "ERR-FUNC-UPD-00044";

	public static final String ERR_COL_TYPE_EDOC_UNKOWN = "ERR-FUNC-UPD-00045";

	public static final String ERR_COL_TYPE_EDOC_MANDATORY = "ERR-FUNC-UPD-00046";

	public static final String ERR_COL_REUSE_FORBIDEN = "ERR-FUNC-UPD-00047";

	public static final String ERR_COL_TYPE_JMC_MANDATORY = "ERR-FUNC-UPD-00048";

	public static final String ERR_COL_TYPE_UPDATE_UNAUTHORIZED = "ERR-FUNC-UPD-00049";

	public static final String ERR_COL_PIECE_UNAUTHORIZED_USER = "ERR-FUNC-UPD-00050";

	public static final String ERR_COL_TYPE_STATUS_NOT_ALLOWED = "ERR-FUNC-UPD-00051";

	public static final String ERR_COL_DELETE_FAMILY_UNAUTHORIZED = "ERR-FUNC-UPD-00052";

	public static final String ERR_COL_TYPE_UNKNOWN_ACTION = "ERR-FUNC-UPD-00054";

	public static final String ERR_COL_TYPE_UNKNOWN_INDEX = "ERR-FUNC-UPD-00055";

	public static final String ERR_COL_TYPE_UNKNOWN_COMPLETENESS = "ERR-FUNC-UPD-00071";

	public static final String ERR_COL_TYPE_EMPTY_INDEX = "ERR-FUNC-UPD-00057";

	public static final String ERR_COL_TYPE_UNKNOWN_INDEX_CATEGORY = "ERR-FUNC-UPD-00058";

	public static final String ERR_COL_TYPE_UNKNOWN_INDEX_FORMAT = "ERR-FUNC-UPD-00059";

	public static final String ERR_COL_TYPE_UNKNOWN_INDEX_CONTROL_REQUIRED = "ERR-FUNC-UPD-00060";

	public static final String ERR_COL_TYPE_UNKNOWN_INDEX_REFERENCE_FORMAT = "ERR-FUNC-UPD-00061";

	public static final String ERR_UNAUTHORIZED_AUTOMATIC_CONTROL = "ERR-FUNC-UPD-00062";

	public static final String ERR_COL_TYPE_UNKNOWN_INDEX_CORRECTED_FORMAT = "ERR-FUNC-UPD-00063";

	public static final String ERR_INDEX_UNAUTHORIZED_UPDATE = "ERR-FUNC-UPD-00064";

	public static final String ERR_COL_TYPE_VA_INCORRECT_NO_FILE = "ERR-FUNC-UPD-00065";

	public static final String ERR_LADRAD_EC = "ERR-FUNC-UPD-00066";

	public static final String ERR_UNKNOWN_PIECE = "ERR-FUNC-UPD-00069";

	public static final String ERR_INDEX_OWNER_NOT_CORRECT = "ERR-FUNC-UPD-00072";

	public static final String ERR_INDEX_NOT_UNIQUE = "ERR-FUNC-UPD-00073";

	public static final String ERR_UNAUTHORIZED_OK_MAN = "ERR-FUNC-UPD-00076";

	public static final String ERR_UNAUTHORIZED_INDEX = "ERR-FUNC-UPD-00077";

	public static final String ERR_INDEX_MISSING_REFERENCE = "ERR-FUNC-UPD-00078";

	public static final String ERR_INDEX_UNAUTHORIZED_REFERENCE = "ERR-FUNC-UPD-00079";

	public static final String ERR_COL_UNAUTHORIZED_LADRAD = "ERR-FUNC-UPD-00082";

	public static final String ERR_COL_ONE_PIECE_PAPER_NOT_ALLOWED = "ERR-FUNC-UPD-00085";

	public static final String ERR_COL_TYPE_NO_ALLOWED_CHOSEN = "ERR-FUNC-UPD-00086";

	public static final String ERR_COL_SIZE_MAX = "ERR-FUNC-UPD-00087";

	public static final String ERR_COL_ALLOWED_FILES = "ERR-FUNC-UPD-00088";

	public static final String ERR_COL_PIECE_INCORRECT_REJECTION_PROFILE = "ERR-FUNC-UPD-00089";

	public static final String ERR_COL_TYPE_INCORRECT_PENDING_DOCUMENT_PROFILE = "ERR-FUNC-UPD-00090";

	public static final String GROUP_LABEL_JMC_INJECTION_ND = "ERR-FUNC-UPD-00092";

	public static final String ERR_AUTO_CLOSING_DELAY = "ERR-FUNC-UPD-00093";

	public static final String ERR_COL_COMMUNICATION_TEMPLATE = "ERR-FUNC-UPD-00094";

	public static final String ERR_JMC_DOC_FORMAT = "ERR-FUNC-UPD-00095";

	public static final String ERR_TYPE_DEL_VA = "ERR-FUNC-UPD-00096";

	public static final String ERR_TYPE_UNAUTHORIZED_INDEX = "ERR-FUNC-UPD-00097";

	public static final String ERR_TYPE_UNAUTHORIZED_COMPLETENESS = "ERR-FUNC-UPD-00098";
	
	public static final String ERR_FAMILY_BLOCKED = "ERR-FUNC-UPD-00111";

	public static final String ERR_COL_TECH = "ERR-TECH-UPD-00004";

	public static final String ERR_ACCES_GDN_TECH = "ERR-TECH-UPD-00003";

	public static final String ERR_ACCES_LADRAD_TECH = "ERR-TECH-UPD-00005";

	public static final String ERR_GET_STATUS_FOLDER_JMC = "ERR-TECH-UPD-00007";

	public static final String ERR_CREATE_FOLDER_JMC = "ERR-TECH-UPD-00008";

	public static final String ERR_UPLOAD_DOCUMENT_JMC = "ERR-TECH-UPD-00009";

	public static final String ERR_GET_STATUS_DOCULENT_JMC = "ERR-TECH-UPD-00010";

	public static final String ERR_ANALYSE_FOLDER_JMC = "ERR-TECH-UPD-00011";

	public static final String ERR_GET_PIECE_JMC = "ERR-TECH-UPD-00012";

	public static final String ERR_GET_STATUS_PIECE_JMC = "ERR-TECH-UPD-00013";

	public static final String ERR_JMC_DELETE_DOCUMENT = "ERR-TECH-UPD-00029";

	public static final String ERR_JMC_DELETE_FOLDER = "ERR-TECH-UPD-00030";

	public static final String ERR_CREATE_PIECE_JMC = "ERR-TECH-UPD-00014";

	public static final String ERR_FORCE_PIECE_JMC = "ERR-TECH-UPD-00015";

	public static final String ERR_UPDATE_PIECE_JMC = "ERR-TECH-UPD-00016";

	public static final String ERR_UPD_GDN_TECH = "ERR-TECH-UPD-00017";

	public static final String ERR_SUPP_GDN_TECH = "ERR-TECH-UPD-00018";

	public static final String ERR_UPD_GDN_FUNC = "ERR-TECH-UPD-00019";

	public static final String ERR_SUPP_GDN_FUNC = "ERR-TECH-UPD-00020";

	public static final String ERR_NAS_READ_PIECE = "ERR-TECH-UPD-00021";

	public static final String ERR_NAS_WRITE = "ERR-TECH-UPD-00022";

	public static final String ERR_NAS_DELETE = "ERR-TECH-UPD-00023";

	public static final String ERR_NAS_READ_THUMBNAIL = "ERR-TECH-UPD-00024";

	public static final String ERR_NAS_GENERATE_THUMBNAIL = "ERR-TECH-UPD-00026";

	public static final String ERR_POST_AMI = "ERR-TECH-UPD-00027";

	public static final String ERR_INJECT_REF_DATA = "ERR-TECH-UPD-00028";

	public static final String ERR_TECH_TIMEOUT = "ERR-TECH-UPD-00031";

	public static final String ERR_TECH_JMC_NO_PIECE = "ERR-TECH-UPD-00034";

	public static final String ERR_ATTACHMENT_ALLOWED_FILES = "ERR-FUNC-UPD-10001";

	public static final String ERR_ATTACHMENT_MAX_SIZE = "ERR-FUNC-UPD-10002";

	public static final String ERR_ATTACHMENT_INCORRECT_CHANNEL = "ERR-FUNC-UPD-10003";

	public static final String ERR_ATTACHMENT_SENDING_APPLICATION_CODE = "ERR-FUNC-UPD-10004";

	public static final String ERR_ATTACHMENT_USER_ID_NOT_ALLOWED = "ERR-FUNC-UPD-10022";

	public static final String ERR_ATTACHMENT_CHANNEL_NOT_ALLOWED = "ERR-FUNC-UPD-10021";

	public static final String ERR_ATTACHMENT_NOT_FOUND = "ERR-FUNC-UPD-10028";

	public static final String ERR_TECH_ADD_ATTACHMENT_BAD_FORMAT = "ERR-TECH-UPD-10032";

	public static final String ERR_ATTACHMENT_GDN_TECH = "ERR-TECH-UPD-10017";

	public static final String ERR_ATTACHMENT_GDN_FUNC = "ERR-TECH-UPD-10019";

	public static final String ERR_SUPP_TYPE_UNIQUE = "ERR-FUNC-UPD-00100";

	public static final String ERR_ADD_CONTROL_ITERATION_ALLOWED = "ERR-FUNC-UPD-00110";

	private CollectErrorConstants() {
		super();
	}

}
