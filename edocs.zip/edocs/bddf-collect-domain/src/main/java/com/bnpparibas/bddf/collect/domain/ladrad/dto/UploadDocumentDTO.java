package com.bnpparibas.bddf.collect.domain.ladrad.dto;

import java.util.List;

/**
 * Data used for upload Document in JOUVE
 *
 * @author c07128
 *
 */
public class UploadDocumentDTO {

	private String documentExternalRef;
	private String refDocFamily;
	private List<String> expectedType;
	private String toAnalyze;

	public String getDocumentExternalRef() {
		return documentExternalRef;
	}

	public void setDocumentExternalRef(String documentExternalRef) {
		this.documentExternalRef = documentExternalRef;
	}

	public String getRefDocFamily() {
		return refDocFamily;
	}

	public void setRefDocFamily(String refDocFamily) {
		this.refDocFamily = refDocFamily;
	}

	public List<String> getExpectedType() {
		return expectedType;
	}

	public void setExpectedType(List<String> expectedType) {
		this.expectedType = expectedType;
	}

	public String getToAnalyze() {
		return toAnalyze;
	}

	public void setToAnalyze(String toAnalyze) {
		this.toAnalyze = toAnalyze;
	}

}
