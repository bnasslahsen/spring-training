package com.bnpparibas.bddf.collect.domain.piece;

public enum PieceStates {
	ACTIF(1, "ACTIF"), INACTIF(2, "INACTIF");

	private int code;
	private String label;

	PieceStates(int code, String label) {
		this.code = code;
		this.label = label;

	}

	public int getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}
}
