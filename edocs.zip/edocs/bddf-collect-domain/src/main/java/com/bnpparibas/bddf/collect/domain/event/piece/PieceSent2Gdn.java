package com.bnpparibas.bddf.collect.domain.event.piece;

import com.bnpparibas.bddf.collect.domain.event.AbstractCollectEvent;
import com.bnpparibas.bddf.collect.domain.piece.Piece;

public class PieceSent2Gdn extends AbstractCollectEvent {
	private Piece piece;
	private String userId;
	private String typeId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Piece getPiece() {
		return piece;
	}

	public void setPiece(Piece piece) {
		this.piece = piece;
	}

	public String getTypeId() {
		return typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

}
