package com.bnpparibas.bddf.collect.domain.nomenclature;

import java.util.List;

public interface NomenclatureRepository {

	List<Nomenclature> findAll();

}
