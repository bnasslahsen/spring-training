package com.bnpparibas.bddf.collect.domain.owner;

import java.util.UUID;

import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.DomainService
public interface ClientNotificationService {

	void save(ClientNotification clientNotification);

	void update(ClientNotification clientNotification);
	
	void delete(UUID typeId);

	int count(UUID typeId);
}
