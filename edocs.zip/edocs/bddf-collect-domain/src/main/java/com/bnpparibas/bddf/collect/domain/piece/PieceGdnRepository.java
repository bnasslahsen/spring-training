package com.bnpparibas.bddf.collect.domain.piece;

import java.nio.ByteBuffer;
import java.util.UUID;

import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.Repository
public interface PieceGdnRepository {

	String savePiece(Piece piece, ByteBuffer pieceData, String idCollecte, String idType, Context context, String sendingApplication);

	String savePiece(Piece piece, ByteBuffer pieceData, String idCollecte, String idType, Context context, boolean retry, String sendingApplication);

	ByteBuffer getPieceData(UUID pieceId, Context context, String idGdn);
}
