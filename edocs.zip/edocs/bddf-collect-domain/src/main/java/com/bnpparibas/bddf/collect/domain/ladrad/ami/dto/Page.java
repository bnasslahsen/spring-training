
package com.bnpparibas.bddf.collect.domain.ladrad.ami.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "links", "page_number", "pieces", "ami_request" })
public class Page {

	@JsonProperty("links")
	private Links links;
	@JsonProperty("page_number")
	private Integer pageNumber;
	@JsonProperty("pieces")
	private List<Piece> pieces;
	@JsonProperty("AMI_request")
	private String amiRequest;
	@JsonProperty("expected_type")
	private String expectedType;

	public Page() {
	}

	public Page(String href, Integer pageNumber, String amiRequest) {
		this.links = new Links(href);
		this.pageNumber = pageNumber;
		this.amiRequest = amiRequest;
		pieces = new ArrayList();
	}

	@JsonProperty("links")
	public Links getLinks() {
		return links;
	}

	@JsonProperty("links")
	public void setLinks(Links links) {
		this.links = links;
	}

	@JsonProperty("page_number")
	public Integer getPageNumber() {
		return pageNumber;
	}

	@JsonProperty("page_number")
	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}

	@JsonProperty("pieces")
	public List<Piece> getPieces() {
		if (pieces == null) {
			pieces = new ArrayList();
		}
		return pieces;
	}

	@JsonProperty("pieces")
	public void setPieces(List<Piece> pieces) {
		this.pieces = pieces;
	}

	@JsonProperty("AMI_request")
	public String getAmiRequest() {
		return amiRequest;
	}

	@JsonProperty("AMI_request")
	public void setAmiRequest(String amiRequest) {
		this.amiRequest = amiRequest;
	}

	public String getExpectedType() {
		return expectedType;
	}

	public void setExpectedType(String expectedType) {
		this.expectedType = expectedType;
	}

	@Override
	public String toString() {
		final ObjectMapper objectMapper = new ObjectMapper();
		try {
			return objectMapper.writeValueAsString(this);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
	}

}
