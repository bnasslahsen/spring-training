package com.bnpparibas.bddf.collect.domain.index;

import java.util.UUID;

import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Entity
public class IndexeJmc {

	private String controlCode;
	private String extractedValue;
	private String statusControl;
	private UUID idPiece;
	private String idPieceJmc;
	private int acceptancePercentage;

	public IndexeJmc() {
		super();
	}

	public IndexeJmc(String controlCode, String extractedValue, String statusControl, UUID idPiece, String idPieceJmc) {
		super();
		this.controlCode = controlCode;
		this.extractedValue = extractedValue;
		this.statusControl = statusControl;
		this.idPiece = idPiece;
		this.idPieceJmc = idPieceJmc;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idPiece == null) ? 0 : idPiece.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}

		return equalsPart2(obj);
	}

	private boolean equalsPart2(Object obj) {
		final IndexeJmc other = (IndexeJmc) obj;
		if (idPiece == null) {
			if (other.idPiece != null) {
				return false;
			}
		} else if (!idPiece.equals(other.idPiece)) {
			return false;
		}
		return true;
	}

	public String getControlCode() {
		return controlCode;
	}

	public void setControlCode(String controlCode) {
		this.controlCode = controlCode;
	}

	public String getExtractedValue() {
		return extractedValue;
	}

	public void setExtractedValue(String extractedValue) {
		this.extractedValue = extractedValue;
	}

	public String getStatusControl() {
		return statusControl;
	}

	public void setStatusControl(String statusControl) {
		this.statusControl = statusControl;
	}

	public UUID getIdPiece() {
		return idPiece;
	}

	public void setIdPiece(UUID idPiece) {
		this.idPiece = idPiece;
	}

	public String getIdPieceJmc() {
		return idPieceJmc;
	}

	public void setIdPieceJmc(String idPieceJmc) {
		this.idPieceJmc = idPieceJmc;
	}

	public int getAcceptancePercentage() {
		return acceptancePercentage;
	}

	public void setAcceptancePercentage(int acceptancePercentage) {
		this.acceptancePercentage = acceptancePercentage;
	}

}
