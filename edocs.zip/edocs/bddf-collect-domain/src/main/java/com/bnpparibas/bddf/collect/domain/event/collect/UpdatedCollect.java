package com.bnpparibas.bddf.collect.domain.event.collect;

import java.util.Set;
import java.util.UUID;

import com.bnpparibas.bddf.collect.domain.event.AbstractCollectEvent;

public class UpdatedCollect extends AbstractCollectEvent {

	private String employeeId;
	private Set<UUID> familiesIds;

	public UpdatedCollect() {
		super();
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public Set<UUID> getFamiliesIds() {
		return familiesIds;
	}

	public void setFamiliesIds(Set<UUID> familiesIds) {
		this.familiesIds = familiesIds;
	}

}
