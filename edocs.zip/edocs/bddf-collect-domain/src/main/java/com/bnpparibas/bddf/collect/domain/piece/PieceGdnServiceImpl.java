package com.bnpparibas.bddf.collect.domain.piece;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.Date;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.togglz.core.manager.FeatureManager;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditEvent;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditGenerator;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.event.piece.PieceSent2Gdn;
import com.bnpparibas.bddf.collect.domain.event.type.TypeReceived;
import com.bnpparibas.bddf.collect.domain.event.type.TypeReceivedType;
import com.bnpparibas.bddf.collect.domain.helper.DateUtil;
import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.collect.domain.piece.validation.ValidationPiece;
import com.bnpparibas.bddf.collect.domain.piece.validation.ValidationPieceService;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeRepository;
import com.bnpparibas.bddf.rest.Context;

/**
 *
 * Cette classe offre des services de communication avec GDN (principalement les dépots, accès et suppressions des documents)
 *
 */

@Service
public class PieceGdnServiceImpl implements PieceGdnService {

	private static final Logger LOG = LoggerFactory.getLogger(PieceGdnServiceImpl.class);
	@Autowired
	private CollectRepository collectRepository;
	@Autowired
	private TypeRepository typeRepository;
	@Autowired
	private PieceRepository pieceRepository;
	@Autowired
	private PieceGdnRepository pieceGdnRepository;
	@Autowired
	private CollectEventHandler collectEventHandler;
	@Autowired
	private AuditGenerator auditGenerator;
	@Autowired
	private DocReferenceService docReferenceService;
	@Autowired
	private ValidationPieceService validationPieceService;
	@Autowired
	private EdocTypeRepository edocTypeRepository;
	@Autowired
	private NomenclatureService nomenclatureService;
	@Autowired
	private FeatureManager featureManager;

	public PieceGdnServiceImpl() {
	}

	@Autowired(required = false)
	public PieceGdnServiceImpl(CollectRepository collectRepository, TypeRepository typeRepository, PieceRepository pieceRepository, PieceGdnRepository pieceGdnRepository, CollectEventHandler collectEventHandler, AuditGenerator auditGenerator,
			EdocTypeRepository edocTypeRepository, NomenclatureService nomenclatureService) {
		this.collectRepository = collectRepository;
		this.typeRepository = typeRepository;
		this.pieceRepository = pieceRepository;
		this.pieceGdnRepository = pieceGdnRepository;
		this.collectEventHandler = collectEventHandler;
		this.auditGenerator = auditGenerator;
		this.edocTypeRepository = edocTypeRepository;
		this.nomenclatureService = nomenclatureService;
	}

	@Override
	@Async("gdnTaskExecutor")
	@Transactional
	public CompletableFuture<Void> savePieceOnGdn(UUID collectId, Type type, Piece piece, Context context, String journeyCode, Set<Piece> removedPieces) throws InterruptedException {
		final Collect collect = collectRepository.findOne(collectId);
		ByteBuffer pieceData = null;
		long duration = 0;
		LoggerHelper.logForPerfTest(LOG, "Début la méthode savePieceOnGdn " + piece.getId() + " pour la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
		try {
			pieceData = pieceRepository.tryGetPieceNasElseGdn(piece.getId(), context, piece);
		} catch (final Exception e) {
			piece.ecToKo();
			LOG.error(e.getMessage(), e);
			return CompletableFuture.completedFuture(null);
		}
		try {
			final long start = System.currentTimeMillis();
			LoggerHelper.logForPerfTest(LOG, "Début de l'envoi de la piece vers GDN " + piece.getId() + " pour la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
			//TODO MOCK GDN
			final String idDocGdn = "MOCKIDGDN";
			//pieceGdnRepository.savePiece(piece, pieceData, collectId.toString(), type.getId().toString(), context, collect.getSendingApplicationCode());
			duration = System.currentTimeMillis() - start;
			LoggerHelper.logForPerfTest(LOG, "Durée de l'envoi de la piece vers GDN " + piece.getId() + " pour la collecte " + collectId + " : " + duration + " (ms)" + " (thread id " + Thread.currentThread().getId() + ")");
			LoggerHelper.logForPerfTest(LOG, "Fin de l'envoi de la piece vers GDN " + piece.getId() + " pour la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
			piece.ecToOk();
			piece.setIdDocGdn(idDocGdn);
			sendDeposedPieceEvent(collect, type.getId().toString(), context, piece, type.getEdocType(), type.getLabel());
			LOG.info("Piece {} well sending to GDN , status {}:", piece.getId(), piece.getStatus());
		} catch (final Exception e) {
			piece.ecToKo();
			LOG.error(e.getMessage(), e);
		}
		pieceRepository.updateStatusAndIdGdn(piece.getId(), piece.getStatus(), piece.getIdDocGdn());

		final Set<Piece> pieces = type.getActivePieces();

		if (pieces.stream().allMatch(p -> !p.getStatus().equals(PieceStatus.DP_EC.getLabel())) && pieces.stream().anyMatch(p -> p.getStatus().equals(PieceStatus.DP_ERR.getLabel()))) {
			final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.ERROR_VERS_GDN, type.getLabel()).setIdType(type.getId()).setIdCollect(collectId).setJourneyCode(collect.getJourneyCode());
			collectEventHandler.sendAuditEvent(auditEvent);
		}

		synchronized (type.getId()) {
			if (!type.isSentGDN() && pieces.stream().allMatch(p -> !p.getStatus().equals(PieceStatus.DP_EC.getLabel())) && pieces.stream().anyMatch(p -> p.getStatus().equals(PieceStatus.DP.getLabel()))) {
				type.setSentGDN(true);
				final Type typeAfterSave = typeRepository.findOne(collectId, type.getId());
				sendDeposedPiecesEvent(collectId, type, context, removedPieces, typeAfterSave, pieces);
			}
		}

		LoggerHelper.logForPerfTest(LOG, "Fin de la méthode savePieceOnGdn " + piece.getId() + " pour la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
		return CompletableFuture.completedFuture(null);
	}

	private void sendDeposedPieceEvent(Collect collect, String typeId, Context context, Piece piece, String edocType, String typeLabel) {
		final PieceSent2Gdn pieceSent2Gdn = new PieceSent2Gdn();

		pieceSent2Gdn.setChannel(context.getCanal());
		pieceSent2Gdn.setUserId(context.getCustomerId());
		pieceSent2Gdn.setCollect(collect);
		pieceSent2Gdn.setMedia(context.getMedia());
		pieceSent2Gdn.setNomenclatureRef(TypeReceivedType.SEND_GDN.getLabel()); // n° event
		pieceSent2Gdn.setPiece(piece);
		pieceSent2Gdn.setTypeId(typeId);

		collectEventHandler.sendGdnPieceEvent(pieceSent2Gdn, edocType, typeLabel);
	}

	private void sendDeposedPiecesEvent(UUID collectId, Type type, Context context, Set<Piece> removedPieces, final Type typeAfterSave, final Set<Piece> pieces) {
		final TypeReceived typeReceived = new TypeReceived();
		final Set<Piece> piecesToSend = pieces.stream().filter(p -> !p.getStatus().equals(PieceStatus.DP_ERR.getLabel()) && !p.getStatus().equals(PieceStatus.TP.getLabel())).collect(Collectors.toSet());
		piecesToSend.addAll(removedPieces);
		typeReceived.setPieces(piecesToSend);

		typeReceived.setChannel(context.getCanal());
		typeReceived.setMedia(context.getMedia());
		typeReceived.setUserId(context.getCustomerId());

		if (Optional.ofNullable(type.getParentId()).isPresent()) {
			typeReceived.setSubType(type);
			typeReceived.setType(typeAfterSave);
		} else {
			typeReceived.setType(type);
		}
		typeReceived.setCollect(collectRepository.findOne(collectId));
		typeReceived.setTypeReceivedType(TypeReceivedType.DEPOSED);

		collectEventHandler.sendTypeReceivedEvent(typeReceived);
	}

	@Override
	public ByteBuffer getPieceData(UUID pieceId, Context context, String idGdn) {
		return pieceGdnRepository.getPieceData(pieceId, context, idGdn);
	}

	private void sendTypeControlledEvent(Collect collect, Context context, Type type, Set<Piece> piecesToRemoveList) {

		final TypeReceived typeReceived = new TypeReceived();

		final Set<Piece> piecesToSend = type.getActivePieces().stream().filter(p -> StringUtils.isNotEmpty(p.getIdDocGdn()) || PieceRecivedFormat.PAP.name().equals(p.getReceivedFormat())).collect(Collectors.toSet());

		piecesToSend.addAll(piecesToRemoveList);
		typeReceived.setPieces(piecesToSend);
		typeReceived.setChannel(context.getCanal());
		typeReceived.setMedia(context.getMedia());
		typeReceived.setUserId(context.getCustomerId());

		if (Optional.ofNullable(type.getParentId()).isPresent()) {
			typeReceived.setSubType(type);
			typeReceived.setType(collect.getTypes().stream().filter(t -> type.getParentId().equals(t.getId())).findAny().orElse(null));
		} else {
			typeReceived.setType(type);
		}
		typeReceived.setCollect(collect);
		typeReceived.setTypeReceivedType(TypeReceivedType.CONTROLLED);

		collectEventHandler.sendTypeReceivedEvent(typeReceived);
	}

	@Override
	@Async("gdnTaskExecutor")
	@Transactional
	public void updateTypeOnGdn(Collect collect, Type type, Piece piece, Set<Piece> piecesToRemoveList, Context context, String newTypeStatus, String refUserId, String refChannel, Instant refAquisitionDate) {
		try {
			final ByteBuffer pieceData = pieceRepository.tryGetPieceNasElseGdn(piece.getId(), context, piece);
			final long start = System.currentTimeMillis();
			LoggerHelper.logForPerfTest(LOG, "Début de l'envoi de la piece vers GDN " + piece.getId() + " pour la collecte " + collect.getId() + " (thread id " + Thread.currentThread().getId() + ")");
			final String idDocGdn = pieceGdnRepository.savePiece(piece, pieceData, collect.getId().toString(), type.getId().toString(), context, collect.getSendingApplicationCode());
			final long duration = System.currentTimeMillis() - start;
			LoggerHelper.logForPerfTest(LOG, "Durée de l'envoi de la piece vers GDN " + piece.getId() + " pour la collecte " + collect.getId() + " : " + duration + " (ms)" + " (thread id " + Thread.currentThread().getId() + ")");
			LoggerHelper.logForPerfTest(LOG, "Fin de l'envoi de la piece vers GDN " + piece.getId() + " pour la collecte " + collect.getId() + " (thread id " + Thread.currentThread().getId() + ")");
			piece.ecToOk();
			piece.setIdDocGdn(idDocGdn);
		} catch (final Exception e) {
			piece.ecToKo();
			LOG.error(e.getMessage(), e);
			try {
				final ValidationPiece validationPiece = new ValidationPiece(DateUtil.todayMidnight(), piece.getId().toString(), type.getId().toString(), collect.getId().toString(), context.getCustomerId(), context.getCanal(), newTypeStatus, 0,
						Optional.ofNullable(piece.getAcquisitionDate()).map(Date::from).orElse(null), piece.getStatus(), piecesToRemoveList);
				validationPieceService.save(validationPiece);
			} catch (final Exception ex) {
				LOG.error(ex.getMessage(), ex);
			}
		}
		pieceRepository.updateStatusAndIdGdn(piece.getId(), piece.getStatus(), piece.getIdDocGdn());

		final Type t = typeRepository.findOne(collect.getId(), type.getId());

		if (t.getActivePieces().stream().allMatch(p -> !p.isStatusEC())) {
			sendTypeControlledEvent(collect, context, type, piecesToRemoveList);
			docReferenceService.saveDocReference(collect.getId(), collect.getJourneyCode(), t, refUserId, refChannel, refAquisitionDate, context, collect.getSendingApplicationCode());
		}
	}

	@Override
	public boolean updateTypeOnGdnForBatch(Collect collect, Type type, Piece piece, Set<Piece> piecesToRemoveList, Context context, String newTypeStatus, String refUserId, String refChannel, Instant refAquisitionDate) {
		boolean retour = false;
		try {
			final ByteBuffer pieceData = pieceRepository.tryGetPieceNasElseGdn(piece.getId(), context, piece);
			final String idDocGdn = pieceGdnRepository.savePiece(piece, pieceData, collect.getId().toString(), type.getId().toString(), context, false, collect.getSendingApplicationCode());
			piece.ecToOk();
			piece.setIdDocGdn(idDocGdn);
			retour = true;
		} catch (final Exception e) {
			LOG.error(e.getMessage(), e);
		}
		pieceRepository.updateStatusAndIdGdn(piece.getId(), piece.getStatus(), piece.getIdDocGdn());

		final Type t = typeRepository.findOne(collect.getId(), type.getId());

		if (t.getActivePieces().stream().allMatch(p -> !p.isStatusEC())) {
			sendTypeControlledEvent(collect, context, type, piecesToRemoveList);
			docReferenceService.saveDocReference(collect.getId(), collect.getJourneyCode(), t, refUserId, refChannel, refAquisitionDate, context, collect.getSendingApplicationCode());
		}
		return retour;
	}

	public DocReferenceService getDocReferenceService() {
		return docReferenceService;
	}

	public void setDocReferenceService(DocReferenceService docReferenceService) {
		this.docReferenceService = docReferenceService;
	}

	public EdocTypeRepository getEdocTypeRepository() {
		return edocTypeRepository;
	}

	public void setEdocTypeRepository(EdocTypeRepository edocTypeRepository) {
		this.edocTypeRepository = edocTypeRepository;
	}

	public NomenclatureService getNomenclatureService() {
		return nomenclatureService;
	}

	public void setNomenclatureService(NomenclatureService nomenclatureService) {
		this.nomenclatureService = nomenclatureService;
	}

	public FeatureManager getFeatureManager() {
		return featureManager;
	}

	public void setFeatureManager(FeatureManager featureManager) {
		this.featureManager = featureManager;
	}

}
