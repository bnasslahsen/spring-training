package com.bnpparibas.bddf.collect.domain.ladrad.enums;

import java.util.Arrays;

public enum StatusDocument {

	CREATED("0"),

	ANALYSIS_IN_PROGRESS("1"),

	ANALYSIS_SUCCESS("2"),

	ANALYSIS_FAILED("-1"),

	DOCUMENT_REJECTED("-2"),

	NOT_ANAYLSED("3"),

	NOT_FOUND("4");

	private final String label;

	private StatusDocument(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	public static StatusDocument fromLabel(String label) {
		return Arrays.asList(values()).stream().filter(t -> t.getLabel().equals(label)).findAny().orElse(null);
	}

}
