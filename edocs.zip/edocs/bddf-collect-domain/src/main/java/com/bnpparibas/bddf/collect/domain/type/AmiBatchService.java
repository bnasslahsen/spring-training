package com.bnpparibas.bddf.collect.domain.type;

import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.DomainService
public interface AmiBatchService {

	void save(AmiBatch amiBatch);

	void update(AmiBatch amiBatch);


}
