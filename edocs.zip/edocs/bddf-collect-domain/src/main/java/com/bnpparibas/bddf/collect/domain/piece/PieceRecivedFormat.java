package com.bnpparibas.bddf.collect.domain.piece;

public enum PieceRecivedFormat {
	NUM(1, "numérique"), PAP(2, "papier");

	private int code;
	private String label;

	PieceRecivedFormat(int code, String label) {
		this.code = code;
		this.label = label;
	}

	public int getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}

}
