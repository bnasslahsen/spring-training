package com.bnpparibas.bddf.collect.domain.piece;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.TypeAutomaticControlService;
import com.bnpparibas.bddf.rest.Context;

@Component
public class PieceAutomaticControlUtils {

	private static final long GDN_AND_JMC_MAX_EXEC_TIME = 1800000;
	private static final Logger LOGGER = LoggerFactory.getLogger(PieceAutomaticControlUtils.class);

	@Autowired
	private PieceGdnService pieceGdnService;

	@Autowired
	private TypeAutomaticControlService typeAutomaticControlService;

	public PieceAutomaticControlUtils() {

	}

	public PieceAutomaticControlUtils(PieceGdnService pieceGdnService, TypeAutomaticControlService typeAutomaticControlService) {
		super();
		this.pieceGdnService = pieceGdnService;
		this.typeAutomaticControlService = typeAutomaticControlService;
	}

	@Async("firstIterationTaskExecutor")
	public void sendPiecesToGdnAndControlFirstIteration(UUID collectId, Context context, final Collect collect, Type type, final Set<Piece> piecesToRemoveList, final Set<Piece> gdnPieces) throws InterruptedException {
		final List<CompletableFuture<Void>> tasks = new ArrayList<>();

		if (CollectionUtils.isNotEmpty(gdnPieces)) {
			for (final Piece piece : gdnPieces) {
				LoggerHelper.logForPerfTest(LOGGER, "Demande d'envoi GDN de la piece " + piece.getId() + " pour la collect " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
				final CompletableFuture<Void> task = pieceGdnService.savePieceOnGdn(collectId, type, piece, context, collect.getJourneyCode(), piecesToRemoveList);
				tasks.add(task);
			}
			final CompletableFuture<Void> task = typeAutomaticControlService.controlFirstIteration(collectId, context, collect.getJourneyCode(), type, collect);
			tasks.add(task);
			joinJmcAndGdnTasks(tasks, collectId, context, type);
		}
	}

	public void joinJmcAndGdnTasks(final List<CompletableFuture<Void>> tasks, UUID collectId, Context context, Type type) {
		try {
			CompletableFuture.allOf(tasks.toArray(new CompletableFuture[0])).get(GDN_AND_JMC_MAX_EXEC_TIME, TimeUnit.MILLISECONDS);
			typeAutomaticControlService.afterSaveFirstIterationAndGdn(collectId, context, type);
		} catch (InterruptedException | ExecutionException | TimeoutException e) {
			LOGGER.error("CompletableFuture of updatePieces in error : ", e);
		}
	}

}
