package com.bnpparibas.bddf.collect.domain.type;

public enum AmiRequest {
	VIDEOCODAGE("Videocodage"), VIDEOTYPAGE("Videotypage");

	private String code;

	AmiRequest(String code) {
		this.code = code;

	}

	public String getCode() {
		return code;
	}

}
