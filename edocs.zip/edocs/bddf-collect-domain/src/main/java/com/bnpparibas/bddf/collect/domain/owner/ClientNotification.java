package com.bnpparibas.bddf.collect.domain.owner;

import java.sql.Timestamp;
import java.util.Optional;
import java.util.UUID;

public class ClientNotification {
	private UUID typeId;
	private UUID collectId;
	private Timestamp creationDate;
	private Timestamp lastNotificationDate;
	private Integer notificationNumber;

	public ClientNotification() {
	}

	public ClientNotification(UUID typeId,UUID collectId, Timestamp creationDate) {
		this.typeId = typeId;
		this.collectId = collectId;
		this.creationDate = Optional.ofNullable(creationDate).map(d -> (Timestamp) d.clone()).orElse(null);
		this.notificationNumber = 0;
	}

	public UUID getTypeId() {
		return typeId;
	}

	public void setTypeId(UUID typeId) {
		this.typeId = typeId;
	}

	public Timestamp getCreationDate() {
		return Optional.ofNullable(this.creationDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setCreationDate(Timestamp initialSent) {
		this.creationDate = Optional.ofNullable(initialSent).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public Timestamp getLastNotificationDate() {
		return Optional.ofNullable(this.lastNotificationDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setLastNotificationDate(Timestamp lastNotificationDate) {
		this.lastNotificationDate = Optional.ofNullable(lastNotificationDate).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public Integer getNotificationNumber() {
		return notificationNumber;
	}

	public void setNotificationNumber(Integer notificationNumber) {
		this.notificationNumber = notificationNumber;
	}

	public UUID getCollectId() {
		return collectId;
	}

	public void setCollectId(UUID collectId) {
		this.collectId = collectId;
	}

}
