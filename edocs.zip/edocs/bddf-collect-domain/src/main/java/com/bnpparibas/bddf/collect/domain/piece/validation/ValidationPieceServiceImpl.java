package com.bnpparibas.bddf.collect.domain.piece.validation;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ValidationPieceServiceImpl implements ValidationPieceService {

	@Autowired
	private ValidationPieceRepository validationPieceRepository;

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void update(ValidationPiece validationPiece) {
		validationPieceRepository.update(validationPiece);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void save(ValidationPiece validationPiece) {
		validationPieceRepository.save(validationPiece);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void delete(ValidationPiece validationPiece) {
		validationPieceRepository.delete(validationPiece);
	}

	@Override
	public List<ValidationPiece> getByCreationDate(Date creationDate) {
		return validationPieceRepository.getByCreationDate(creationDate);
	}

}
