package com.bnpparibas.bddf.collect.domain.type;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.ladrad.ami.dto.AmiRequestDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.PageDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Repository
public interface AmiService {

	void sendAMIFirstIteration(UUID collectId, Type type, String journeyCode);

	void extractIndexesPieceAndCalculateIndicatorsAMI(UUID collectId, Type type, Map<UUID, StatusDocumentDTO> listStatusDocumentJMC, List<Indexe> indexes, String ownerIndex, String documentSet);

	void sendAMISecondIteration(UUID collectId, Type type, boolean isBypassSecondIteration, String journeyCode);

	void addPieceInAmiJasonVideoTypage(AmiRequestDTO amiRequestDTO, PageDTO pageDto, String expectedType);

}
