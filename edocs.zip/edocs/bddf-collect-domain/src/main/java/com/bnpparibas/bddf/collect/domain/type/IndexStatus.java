package com.bnpparibas.bddf.collect.domain.type;

import java.util.Arrays;

public enum IndexStatus {
	OK("OK"), OK_MAN("OK_MAN"), KO("KO"), KO_UNK("KO_UNK"), KO_COHE("KO_COHE"), KO_MULT("KO_MULT"), WARNING_COHE("WARNING_COHE"), WARNING_UNK("WARNING_UNK"), KO_EXTR("KO_EXTR"), WARNING_EXTR("WARNING_EXTR"), WARNING_MULT("WARNING_MULT");

	private String code;

	IndexStatus(String code) {
		this.code = code;

	}

	public String getCode() {
		return code;
	}

	public static boolean isWarning(String statusControl) {
		return Arrays.asList(WARNING_COHE.getCode(), WARNING_UNK.getCode(), WARNING_EXTR.getCode(), WARNING_MULT.getCode()).contains(statusControl);
	}

	public static boolean isKO(String statusControl) {
		return Arrays.asList(KO.getCode(), KO_UNK.getCode(), KO_COHE.getCode(), KO_MULT.getCode(), KO_EXTR.getCode()).contains(statusControl);
	}

	public static boolean isOK(String statusControl) {
		return Arrays.asList(OK.getCode(), OK_MAN.getCode()).contains(statusControl);
	}

}
