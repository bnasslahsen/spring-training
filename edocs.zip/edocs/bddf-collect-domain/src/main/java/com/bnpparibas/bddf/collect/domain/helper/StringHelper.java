package com.bnpparibas.bddf.collect.domain.helper;

import java.util.Set;

public final class StringHelper {

	private static final char DEFAULT_SEPARATOR = '|';

	private StringHelper() {
		super();
	}

	public static String reduceSet(Set<String> set) {
		return reduceSet(set, DEFAULT_SEPARATOR);
	}

	public static String reduceSet(Set<String> set, char separator) {
		final StringBuilder sb = new StringBuilder();
		set.stream().sorted().forEach(s -> {
			if (sb.toString().length() != 0) {
				sb.append(separator);
			}
			sb.append(s);
		});
		return sb.toString();
	}
}
