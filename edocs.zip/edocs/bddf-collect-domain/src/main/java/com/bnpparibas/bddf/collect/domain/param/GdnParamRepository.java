package com.bnpparibas.bddf.collect.domain.param;

import java.util.Map;

public interface GdnParamRepository {

	Map<String, Long> getGdnParam();

}
