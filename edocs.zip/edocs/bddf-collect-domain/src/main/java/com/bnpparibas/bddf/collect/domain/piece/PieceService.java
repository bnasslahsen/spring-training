package com.bnpparibas.bddf.collect.domain.piece;

import java.nio.ByteBuffer;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang3.tuple.Pair;

import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.DomainService
public interface PieceService {

	UUID addPiece(UUID idCollect, UUID idType, Piece piece, ByteBuffer bytes, String contentType, Context context) throws InterruptedException;

	Pair<Piece, ByteBuffer> getPiece(UUID collectId, UUID typeId, UUID pieceId, Context context);

	boolean deletePiece(UUID collectId, UUID typeId, UUID pieceId, Context context);

	void updatePieces(UUID collectId, UUID typeId, Set<Piece> pieces, Context context) throws InterruptedException;

	ByteBuffer getThumbnail(UUID collectId, UUID typeId, UUID pieceId, String channel);

}
