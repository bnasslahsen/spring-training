package com.bnpparibas.bddf.collect.domain.type;

public enum IndexCategory {
	OB("Obligatoire"), ND("Non demandé"), FA( "Facultaif");

	private String label;

	IndexCategory(String label) {
		this.label = label;

	}

	public String getLabel() {
		return label;
	}

}
