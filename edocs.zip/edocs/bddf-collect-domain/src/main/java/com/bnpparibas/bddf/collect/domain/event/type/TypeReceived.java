package com.bnpparibas.bddf.collect.domain.event.type;

import java.util.Set;

import com.bnpparibas.bddf.collect.domain.event.AbstractCollectEvent;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.type.Type;

public class TypeReceived extends AbstractCollectEvent {

	private Type type;
	private Type subType;
	private String userId;
	private TypeReceivedType typeReceivedType;
	private Set<Piece> pieces;

	public TypeReceived() {
		super();
	}

	public TypeReceivedType getTypeReceivedType() {
		return typeReceivedType;
	}

	public void setTypeReceivedType(TypeReceivedType typeReceivedType) {
		this.typeReceivedType = typeReceivedType;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public Type getSubType() {
		return subType;
	}

	public void setSubType(Type subType) {
		this.subType = subType;
	}

	public Set<Piece> getPieces() {
		return pieces;
	}

	public void setPieces(Set<Piece> pieces) {
		this.pieces = pieces;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String getNomenclatureRef() {
		return getTypeReceivedType().getLabel();
	}

}
