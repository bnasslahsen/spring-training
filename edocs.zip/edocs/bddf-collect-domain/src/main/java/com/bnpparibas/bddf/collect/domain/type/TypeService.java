package com.bnpparibas.bddf.collect.domain.type;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.DomainService
public interface TypeService {

	Type getType(UUID collectId, UUID typeId);

	void updateType(UUID collectId, UUID typeId, Type type, Context context) throws InterruptedException;

	void updateFamilies(UUID colllectId, Map<UUID, Type> families, Context context);

	void addFamily(UUID colllectId, Set<Type> familyTypes, Context context) throws InterruptedException;

	void deleteFamily(UUID colllectId, UUID familyId, Context context);

	void addType(UUID collectId, UUID familyId, List<Type> types, Context context) throws InterruptedException;

	void checkStatusControlInProgress(Type type);

	boolean deleteType(UUID idCollect, UUID idType, Context context);

}
