package com.bnpparibas.bddf.collect.domain.event;

import java.util.UUID;

import com.bnpparibas.bddf.collect.domain.audit.event.AuditEvent;
import com.bnpparibas.bddf.collect.domain.event.collect.UpdatedCollect;
import com.bnpparibas.bddf.collect.domain.event.piece.PieceSent2Gdn;
import com.bnpparibas.bddf.collect.domain.event.type.EventSendAMI;
import com.bnpparibas.bddf.collect.domain.event.type.TypeReceived;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.DomainService
public interface CollectEventHandler {

	void sendTypeReceivedEventForBatch(TypeReceived typeReceived, String content, String eventId, int replays);

	void sendAuditEvent(AuditEvent auditEvent);

	void sendAutomaticControlEvent(UUID collectId, Context context, final Type type);

	void sendUpdatedCollectEvent(UpdatedCollect updatedCollect);

	void sendTypeReceivedEvent(TypeReceived typeReceived);

	void sendUpdatedCollectEventForBatch(UpdatedCollect updatedCollect, String content, String evendId, int replays);

	void sendGdnPieceEvent(PieceSent2Gdn pieceSent2Gdn, String edocType, String typeLabel);

	void sendEventAMI(EventSendAMI eventSendAMI);

	void sendAuditEventAttachment(AuditEvent auditEvent);

	void sendGdnPieceEventForBatch(PieceSent2Gdn pieceSent2Gdn, String content, String edocType, String typeLabel, String eventId, int replays);

	void sendEventAMIForBatch(EventSendAMI eventSendAMI, String content, String eventId, int replays);


}
