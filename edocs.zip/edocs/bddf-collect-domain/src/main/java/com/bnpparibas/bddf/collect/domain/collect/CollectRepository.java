package com.bnpparibas.bddf.collect.domain.collect;

import java.util.List;
import java.util.Set;
import java.util.UUID;

public interface CollectRepository {
	Collect findOne(UUID id);

	Collect findOnlyCollect(UUID id);

	Set<UUID> findAll();

	Set<Collect> findByOwners(Set<String> references, List<String> journeyCodes);

	void add(Collect collect);

	void endCollect(Collect collect);

	Set<Owner> getOwnerByCollect(UUID collectId);

	String getJourneyCode(UUID collectId);

	void delete(UUID collectId);

	void updateCollect(Collect collect);

	Integer countByOwners(Set<String> references, String journeyCode);

}
