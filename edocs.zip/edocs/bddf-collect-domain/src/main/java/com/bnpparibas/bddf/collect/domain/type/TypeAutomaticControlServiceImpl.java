package com.bnpparibas.bddf.collect.domain.type;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.togglz.core.manager.FeatureManager;

import com.bnp.schema.edoc.index.Indexes.EdocIndex;
import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditEventService;
import com.bnpparibas.bddf.collect.domain.audit.event.AuditValue;
import com.bnpparibas.bddf.collect.domain.audit.event.LadRadFeature;
import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.collect.CollectRepository;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.ladrad.LadRadValidator;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.DocumentSet;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceControls;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceIndicators;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.TypeControls;
import com.bnpparibas.bddf.collect.domain.nomenclature.Nomenclature;
import com.bnpparibas.bddf.collect.domain.nomenclature.NomenclatureService;
import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceGdnServiceImpl;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.collect.domain.piece.reference.DocReferenceService;
import com.bnpparibas.bddf.errors.TechnicalException;
import com.bnpparibas.bddf.rest.Context;
import com.netflix.hystrix.exception.HystrixRuntimeException;

/**
 *
 * Cette classe contient les services de contrôles automatiques pour la première et deuxième itération avec communication JMC et AMI
 *
 * @author c07130
 *
 */
@Service
public class TypeAutomaticControlServiceImpl implements TypeAutomaticControlService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PieceGdnServiceImpl.class);

	@Autowired
	private TypeLadRadService typeLadRadService;
	@Autowired
	private AmiService amiService;
	@Autowired
	private CollectEventHandler collectEventHandler;
	@Autowired
	private TypeValidator typeValidator;
	@Autowired
	private NomenclatureService nomenclatureService;
	@Autowired
	private EdocIndexRepository edocIndexRepository;

	@Autowired
	private FeatureManager featureManager;

	@Autowired
	private PieceRepository pieceRepository;

	@Autowired
	private PieceGdnRepository pieceGdnRepository;

	@Autowired
	private LadRadValidator ladRadValidator;

	@Autowired
	private EdocTypeRepository edocTypeRepository;

	@Autowired
	private TypeRepository typeRepository;

	@Autowired
	private CollectRepository collectRepository;

	@Autowired
	private DocReferenceService docReferenceService;

	@Autowired
	private LadRadRepository ladRadRepository;

	@Autowired
	private TypeAutomaticControlUtils typeAutomaticControlUtils;

	@Autowired
	private AuditEventService auditEventService;

	@Autowired
	private Environment environment;

	public TypeAutomaticControlServiceImpl(TypeLadRadService typeLadRadService, CollectEventHandler collectEventHandler, TypeValidator typeValidator, NomenclatureService nomenclatureService, EdocIndexRepository edocIndexRepository,
			FeatureManager featureManager, PieceRepository pieceRepository, PieceGdnRepository pieceGdnRepository, LadRadValidator ladRadValidator, EdocTypeRepository edocTypeRepository, TypeRepository typeRepository,
			DocReferenceService docReferenceService, TypeAutomaticControlUtils typeAutomaticControlUtils) {
		super();
		this.typeLadRadService = typeLadRadService;
		this.collectEventHandler = collectEventHandler;
		this.typeValidator = typeValidator;
		this.nomenclatureService = nomenclatureService;
		this.edocIndexRepository = edocIndexRepository;
		this.featureManager = featureManager;
		this.pieceRepository = pieceRepository;
		this.pieceGdnRepository = pieceGdnRepository;
		this.ladRadValidator = ladRadValidator;
		this.edocTypeRepository = edocTypeRepository;
		this.typeRepository = typeRepository;
		this.docReferenceService = docReferenceService;
		this.typeAutomaticControlUtils = typeAutomaticControlUtils;
	}

	@Override
	@Async("jmcTaskExecutor")
	public CompletableFuture<Void> controlFirstIteration(UUID collectId, Context context, String journeyCode, Type type, Collect collect) {
		Integer durationSendsJMC = 0;
		Integer durationSendsAMI = 0;
		// send to JMC if control Required is automatic
		final boolean sendToLadRadEnabled = Optional.ofNullable(LadRadFeature.fromLabel(journeyCode)).map(featureManager::isActive).orElse(false);
		if (sendToLadRadEnabled && type.getControlRequired() == ControlRequired.CONTROL_JMC.getCode() && type.getActivePieces().stream().anyMatch(p -> Arrays.asList(PieceStatus.DP_EC.getLabel(), PieceStatus.DP.getLabel()).contains(p.getStatus()))) {
			try {
				LoggerHelper.logForPerfTest(LOGGER, "Début de l'envoi vers JMC pour type" + type.getId() + " pour la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
				final String documentSet = findDocumentSetFromType(type, edocTypeRepository.findAll());

				final Map<String, List<Indexe>> indexesByOwners = type.getIndexes().stream().collect(Collectors.groupingBy(Indexe::getOwnerIndex));
				// Pièces non encore envoyées vers JMC
				final List<Piece> activedPiecesNotSentToJMC = type.getActivePieces().stream().filter(piece -> piece.getControlIterationAchieved() == 0).collect(Collectors.toList());
				typeAutomaticControlUtils.initControlIterationAchieved(type);
				typeRepository.updateType(collectId, type);
				long start = System.currentTimeMillis();
				indexesByOwners.keySet().forEach(ownerIndex -> {
					final List<Indexe> indexesForAnOwner = indexesByOwners.get(ownerIndex);
					// Création d'un dossier JMC par owner
					typeLadRadService.createFolderIfNotExists(type, indexesForAnOwner, ownerIndex, documentSet, journeyCode);
					// Upload des documents vers JMC
					activedPiecesNotSentToJMC.forEach(pieceIdx -> uploadDocument(collectId, type, indexesForAnOwner, ownerIndex, journeyCode, pieceIdx, context, documentSet));
					final List<Piece> pieces = type.getActivePieces().stream().collect(Collectors.toList());
					// Attendre la fin des traitement JMC
					final Map<UUID, StatusDocumentDTO> listStatusDocumentJMC = typeAutomaticControlUtils.verifyStatusDocuments(pieces, ownerIndex, type.getId(), documentSet);
					// Demande d'analyse du dossier JMC
					typeAutomaticControlUtils.extractIndexesPiece(collectId, type, indexesForAnOwner, ownerIndex, listStatusDocumentJMC, documentSet, false);
				});
				long end = System.currentTimeMillis();
				durationSendsJMC = (int) ((end - start) / 1000);
				// Calcul des indicateurs des indexes, des pièces et du type
				typeAutomaticControlUtils.calculateIndicators(type);
				// Tester si on va envoyer vers AMI premiere iteration
				if (isEligibleToSendToAMI(type)) {
					typeAutomaticControlUtils.initStatusEventAMI(type, collectId, context, collect);
					start = System.currentTimeMillis();
					// Envoi du dossier vers AMI pour typage et réindexation manuelle
					amiService.sendAMIFirstIteration(collectId, type, journeyCode);
					end = System.currentTimeMillis();
					if (VideoCodingDelay.IMMEDIATE.getCode().equals(type.getVideoCodingDelay())) {
						durationSendsAMI = (int) ((end - start) / 1000);
						auditEventService.sendAuditEventLadRADFirstIteration(collectId, context, journeyCode, type, durationSendsJMC, durationSendsAMI, documentSet, activedPiecesNotSentToJMC);
					}

				} else {
					auditEventService.sendAuditEventLadRADFirstIteration(collectId, context, journeyCode, type, durationSendsJMC, durationSendsAMI, documentSet, activedPiecesNotSentToJMC);
				}
			} catch (final TechnicalException | CollectBusinessException | HystrixRuntimeException ex) {
				ladRadValidator.updateTypeWhenError(type);
				typeRepository.updateType(collectId, type);
				auditEventService.sendAuditEventLadRAD(collectId, context, journeyCode, type, AuditValue.LAD_RAD_AUTOMATIC_CONTROL_ERROR, ex.getMessage());
				LOGGER.info(ex.getMessage(), ex);
				return CompletableFuture.completedFuture(null);
			} finally {
				LoggerHelper.logForPerfTest(LOGGER, "Durée l'envoi vers JMC pour type" + type.getId() + " pour la collecte " + collectId + " : " + durationSendsJMC + " s" + " (thread id " + Thread.currentThread().getId() + ")");
				LoggerHelper.logForPerfTest(LOGGER, "Fin de l'envoi vers JMC pour type" + type.getId() + " pour la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
			}

		}
		return CompletableFuture.completedFuture(null);
	}

	@Transactional(transactionManager = "transactionManagerDB")
	@Override
	public void afterSaveFirstIterationAndGdn(UUID collectId, Context context, Type type) {
		if (type.getControlRequired() == ControlRequired.CONTROL_JMC.getCode()) {
			if (type.getActivePieces().stream().allMatch(p -> !Arrays.asList(PieceStatus.DP_EC.getLabel(), PieceStatus.DP_ERR.getLabel()).contains(p.getStatus())) && !isEligibleToSendToAMIDelayed(type)) {
				// Auto-validation des pièces et du type (VA/VA_AUTO), si dossier éligible
				typeAutomaticControlUtils.autoValidateType(collectId, type, context, AuditValue.LAD_RAD_AUTOMATIC_VALIDATION_ITERATION_1);
				// Envoi en back-office des pièces et du type (RC/RC_AUTO), si dossier éligible
				typeAutomaticControlUtils.autoAcceptType(collectId, type, context, AuditValue.LAD_RAD_AUTOMATIC_ACCEPTATION);
			}
			typeRepository.updateType(collectId, type);
			if (!isEligibleToSendToAMIDelayed(type)) {
				collectEventHandler.sendAutomaticControlEvent(collectId, context, type);
			}
		}
	}

	private boolean isEligibleToSendToAMI(final Type type) {
		// Tester si on peut envoyer vers AMI premiere iteration
		return isEligibleToSendToAMIDelayed(type);

	}

	private boolean isEligibleToSendToAMIDelayed(final Type type) {
		final boolean isEligible = isAMIDelayed(type)
				// Au moins un index non indexable à KO
				&& (type.getIndexes().stream().anyMatch(index -> !index.isIndexable() && IndexStatus.isKO(index.getStatusControl()) && index.isVideoCoding()));
		final boolean isToSend = isEligible || (isAMIDelayed(type) && !type.getCompletenessControl().equals(TypeControls.OK.name()));
		return isToSend;
	}

	private boolean isAMIDelayed(final Type type) {
		final boolean isEligible = VideoCodingDelay.DELAYED.getCode().equals(type.getVideoCodingDelay())
				// Aucune pièce à KO_EXP
				&& type.getActivePieces().stream().noneMatch(piece -> PieceIndicators.KO_EXP.getLabel().equals(piece.getTypeControl()));
		return isEligible;
	}

	@Override
	public void controlSecondIteration(Collect collect, Type type, Type updatedType, Context context) {
		final List<EdocType> edocTypes = edocTypeRepository.findAll();
		final String documentSet = findDocumentSetFromType(type, edocTypes);
		final boolean sendToLadRadEnabled = Optional.ofNullable(LadRadFeature.fromLabel(collect.getJourneyCode())).map(featureManager::isActive).orElse(false);
		if (sendToLadRadEnabled && type.getControlRequired() == ControlRequired.CONTROL_JMC.getCode()) {
			typeValidator.updateIndexesType(type, updatedType, edocIndexRepository.findAll(), nomenclatureService.findAll(), collect.getControlIterationAllowed());
			initFromExistingType(updatedType, type);
			typeRepository.updateType(collect.getId(), type);
			typeAutomaticControlUtils.handleSecondIteration(collect, type, context, documentSet);
		}
	}

	private String findDocumentSetFromType(Type type, List<EdocType> edocTypes) {
		return edocTypes.stream().filter(edocTypeL -> edocTypeL.getValue().equals(type.getEdocType())).findAny().map(EdocType::getDocumentSet).orElse(DocumentSet.JMC_SET.getLabel());
	}

	private void initFromExistingType(Type currentType, Type existingType) {
		existingType.setControlDate(new Date().toInstant());
		currentType.getActivePieces().forEach(piece -> {
			if (existingType.getActivePieces() != null && existingType.getActivePieces().contains(piece)) {
				final Piece existingPiece = existingType.getActivePieces().stream().filter(currentExistingPiece -> currentExistingPiece.equals(piece)).findFirst().get();
				if (StringUtils.equals(PieceIndicators.OK_MAN.name(), piece.getTypeControl())) {
					existingPiece.setTypeControl(piece.getTypeControl());
				}
			}
		});
		currentType.getIndexes().forEach(index -> {
			if (existingType.getIndexes() != null && existingType.getIndexes().contains(index)) {
				final Indexe existingIndex = existingType.getIndexes().stream().filter(currentExistingIndex -> currentExistingIndex.equals(index)).findFirst().get();
				if (index.isIndexable()) {
					existingIndex.setCorrectedValue(index.getCorrectedValue());
				}
				if (StringUtils.equals(IndexStatus.OK_MAN.name(), index.getStatusControl())) {
					existingIndex.setStatusControl(index.getStatusControl());
				}
			}
		});

		existingType.setStatusControl(TypeControls.EC.name());
		existingType.getActivePieces().forEach(piece -> {
			piece.setStatusControl(PieceControls.EC.name());
			// RG252
			if (existingType.getIndexes().stream().anyMatch(index -> StringUtils.isNotEmpty(index.getCorrectedValue()) && (!currentType.isGroupIndexesValidation() || StringUtils.isEmpty(index.getGroupLabel())))) {
				piece.setControlIterationAchieved(piece.getControlIterationAchieved() + 1);
			}
		});
		existingType.setGroupIndexesValidation(currentType.isGroupIndexesValidation());
	}

	@Override
	public void updateIndexesOnDeletePieces(Collect collect, Type type, Set<Piece> piecesRemoved, Context context, boolean sendEventAndAutovalidate) {
		final boolean sendToLadRadEnabled = Optional.ofNullable(LadRadFeature.fromLabel(collect.getJourneyCode())).map(featureManager::isActive).orElse(false);
		final boolean existsOneOrMoreSentToJouv = type.getPieces().stream().anyMatch(piece -> !Arrays.asList(PieceStatus.TP.getLabel(), PieceStatus.DF.getLabel(), PieceStatus.DP_ERR.getLabel()).contains(piece.getStatus()));

		if (sendToLadRadEnabled && type.getControlRequired() == ControlRequired.CONTROL_JMC.getCode() && CollectionUtils.isNotEmpty(piecesRemoved) && existsOneOrMoreSentToJouv) {
			try {
				final Map<String, List<Indexe>> indexesByOwners = type.getIndexes().stream().collect(Collectors.groupingBy(Indexe::getOwnerIndex));
				final boolean deleteAll = type.getActivePieces().isEmpty() || type.getActivePieces().equals(piecesRemoved);
				if (deleteAll) {
					// Si suppression de toutes les pièces du type, alros réinitialisation des indicateurs et champs utilisés pour JMC
					type.getIndexes().stream().forEach(Indexe::initControls);
					type.getIndexes().stream().forEach(index -> index.getIndexesJmc().clear());
					type.setCompletenessControl(null);
					type.setCompletenessControlLabel(null);
					type.setStatusControl(null);
				} else {
					indexesByOwners.keySet().forEach(
							ownerIndex -> piecesRemoved.stream().filter(piece -> !piece.getStatus().equals(PieceStatus.TP.getLabel()) && !piece.getStatus().equals(PieceStatus.DF.getLabel())).forEach(piece -> updateIndexesDeleteOnePiece(type, piece)));
					final List<EdocType> edocTypes = edocTypeRepository.findAll();
					final List<EdocIndex> edocIndexes = edocIndexRepository.findAll();
					final List<Nomenclature> nomenclatures = nomenclatureService.findAll();
					ladRadValidator.calculateStatusIndexes(type, edocIndexes);
					type.getActivePieces().stream().forEach(pieceIdx -> ladRadValidator.calculateIndicatorsPieces(pieceIdx, type, edocTypes, edocIndexes));
					ladRadValidator.calculateIndicatorsType(type, edocTypes);
					typeValidator.convertTypesExtractedIndexToEdoc(type.getIndexes(), nomenclatures);
				}
				typeAutomaticControlUtils.deleteOnJMC(type, indexesByOwners, piecesRemoved);
				if (sendEventAndAutovalidate || deleteAll) {
					// Essayer l'autovalidation qui pourrait s'appliquer pour certains cas de suppression de pièces
					typeAutomaticControlUtils.autoValidateType(collect.getId(), type, context, AuditValue.LAD_RAD_AUTOMATIC_VALIDATION_DELETE_PIECE);
					typeRepository.updateType(collect.getId(), type);
					if (typeAutomaticControlUtils.isEligibleForAutoValidation(type, collect.isAutoValidation())) {
						collectEventHandler.sendAutomaticControlEvent(collect.getId(), context, type);
					}
				}
			} catch (final Exception ex) {
				ladRadValidator.updateTypeWhenError(type);
				typeRepository.updateType(collect.getId(), type);
				LOGGER.info(ex.getMessage(), ex);
			}
		}

	}

	private void updateIndexesDeleteOnePiece(Type type, Piece piece) {
		if (StringUtils.isNotEmpty(piece.getTypeControl()) && piece.getTypeControl().equals(PieceIndicators.KO_UNK.name())) {
			ladRadValidator.updateStatusControlType(type);
		} else {
			type.getIndexes().stream().forEach(index -> {
				if (IndexStatus.OK_MAN.getCode().equals(index.getStatusControl()) || index.getIndexesJmc().stream().allMatch(indexJMC -> indexJMC.getIdPiece().equals(piece.getId()))) {
					index.initControls();
					index.getIndexesJmc().clear();
				} else if (index.getIndexesJmc().stream().anyMatch(indexJMC -> indexJMC.getIdPiece().equals(piece.getId()))) {
					index.getIndexesJmc().removeIf(indexJmc -> indexJmc.getIdPiece().equals(piece.getId()));
				}
			});
		}

	}

	private void uploadDocument(UUID collectId, Type type, List<Indexe> indexesForAnOwner, String ownerIndex, String journeyCode, Piece pieceIdx, Context context, String documentSet) {
		if (type.getControlRequired() == ControlRequired.CONTROL_JMC.getCode()) {
			final ByteBuffer pieceData = pieceRepository.tryGetPieceNasElseGdn(pieceIdx.getId(), context, pieceIdx);
			typeLadRadService.uploadDocument(collectId, journeyCode, type, indexesForAnOwner, ownerIndex, pieceIdx, pieceData, documentSet);
		}
	}

	public CollectRepository getCollectRepository() {
		return collectRepository;
	}

	public void setCollectRepository(CollectRepository collectRepository) {
		this.collectRepository = collectRepository;
	}

	public DocReferenceService getDocReferenceService() {
		return docReferenceService;
	}

	public void setDocReferenceService(DocReferenceService docReferenceService) {
		this.docReferenceService = docReferenceService;
	}

	public LadRadRepository getLadRadRepository() {
		return ladRadRepository;
	}

	public void setLadRadRepository(LadRadRepository ladRadRepository) {
		this.ladRadRepository = ladRadRepository;
	}

	public TypeLadRadService getTypeLadRadService() {
		return typeLadRadService;
	}

	public CollectEventHandler getCollectEventHandler() {
		return collectEventHandler;
	}

	public TypeValidator getTypeValidator() {
		return typeValidator;
	}

	public EdocIndexRepository getEdocIndexRepository() {
		return edocIndexRepository;
	}

	public FeatureManager getFeatureManager() {
		return featureManager;
	}

	public PieceRepository getPieceRepository() {
		return pieceRepository;
	}

	public PieceGdnRepository getPieceGdnRepository() {
		return pieceGdnRepository;
	}

	public LadRadValidator getLadRadValidator() {
		return ladRadValidator;
	}

	public EdocTypeRepository getEdocTypeRepository() {
		return edocTypeRepository;
	}

	public TypeRepository getTypeRepository() {
		return typeRepository;
	}

	public TypeAutomaticControlUtils getTypeAutomaticControlUtils() {
		return typeAutomaticControlUtils;
	}

	public void setTypeLadRadService(TypeLadRadService typeLadRadService) {
		this.typeLadRadService = typeLadRadService;
	}

	public void setCollectEventHandler(CollectEventHandler collectEventHandler) {
		this.collectEventHandler = collectEventHandler;
	}

	public void setTypeValidator(TypeValidator typeValidator) {
		this.typeValidator = typeValidator;
	}

	public void setEdocIndexRepository(EdocIndexRepository edocIndexRepository) {
		this.edocIndexRepository = edocIndexRepository;
	}

	public void setFeatureManager(FeatureManager featureManager) {
		this.featureManager = featureManager;
	}

	public void setPieceRepository(PieceRepository pieceRepository) {
		this.pieceRepository = pieceRepository;
	}

	public void setPieceGdnRepository(PieceGdnRepository pieceGdnRepository) {
		this.pieceGdnRepository = pieceGdnRepository;
	}

	public void setLadRadValidator(LadRadValidator ladRadValidator) {
		this.ladRadValidator = ladRadValidator;
	}

	public void setEdocTypeRepository(EdocTypeRepository edocTypeRepository) {
		this.edocTypeRepository = edocTypeRepository;
	}

	public void setTypeRepository(TypeRepository typeRepository) {
		this.typeRepository = typeRepository;
	}

	public void setTypeAutomaticControlUtils(TypeAutomaticControlUtils typeAutomaticControlUtils) {
		this.typeAutomaticControlUtils = typeAutomaticControlUtils;
	}

	public AuditEventService getAuditEventService() {
		return auditEventService;
	}

	public void setAuditEventService(AuditEventService auditEventService) {
		this.auditEventService = auditEventService;
	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

	public NomenclatureService getNomenclatureService() {
		return nomenclatureService;
	}

	public void setNomenclatureService(NomenclatureService nomenclatureService) {
		this.nomenclatureService = nomenclatureService;
	}

}
