package com.bnpparibas.bddf.collect.domain.piece.reference;

import java.time.Instant;
import java.util.UUID;

import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.rest.Context;

public interface DocReferenceService {

	void saveDocReference(UUID collectId, String journeyCode, Type type, String refUserId, String refChannel, Instant refAquisitioDate, Context context, String sendingApplicationCode);

}
