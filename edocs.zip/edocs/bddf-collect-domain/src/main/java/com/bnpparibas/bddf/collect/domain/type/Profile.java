package com.bnpparibas.bddf.collect.domain.type;

public enum Profile {
	BO("BO"), FO("FO");

	private String label;

	Profile(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}
}
