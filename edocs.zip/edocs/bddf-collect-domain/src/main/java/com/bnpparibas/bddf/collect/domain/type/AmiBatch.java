package com.bnpparibas.bddf.collect.domain.type;

import java.sql.Timestamp;
import java.util.Optional;
import java.util.UUID;

public class AmiBatch {
	private UUID typeId;
	private String journeyCode;
	private Timestamp initialSent;
	private Timestamp lastSent;
	private String status;

	public UUID getTypeId() {
		return typeId;
	}

	public void setTypeId(UUID typeId) {
		this.typeId = typeId;
	}

	public Timestamp getInitialSent() {
		return Optional.ofNullable(this.initialSent).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setInitialSent(Timestamp initialSent) {
		this.initialSent = Optional.ofNullable(initialSent).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public Timestamp getLastSent() {
		return Optional.ofNullable(this.lastSent).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public void setLastSent(Timestamp lastSent) {
		this.lastSent = Optional.ofNullable(lastSent).map(d -> (Timestamp) d.clone()).orElse(null);
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getJourneyCode() {
		return journeyCode;
	}

	public void setJourneyCode(String journeyCode) {
		this.journeyCode = journeyCode;
	}
}
