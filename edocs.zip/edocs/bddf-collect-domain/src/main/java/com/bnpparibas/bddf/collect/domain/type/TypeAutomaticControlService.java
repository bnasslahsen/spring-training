package com.bnpparibas.bddf.collect.domain.type;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.domain.ddd.DDD;
import com.bnpparibas.bddf.rest.Context;

@DDD.DomainService
public interface TypeAutomaticControlService {

	CompletableFuture<Void> controlFirstIteration(UUID collectId, Context context, String journeyCode, Type type, Collect collect);

	void controlSecondIteration(final Collect collect, final Type type, Type updatedType, Context context);

	void updateIndexesOnDeletePieces(Collect collect, Type type, Set<Piece> piecesRemoved, Context context, boolean sendEventAndAutovalidate);

	void afterSaveFirstIterationAndGdn(UUID collectId, Context context, Type type);

}
