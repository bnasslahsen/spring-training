package com.bnpparibas.bddf.collect.domain.collect;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;

import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.AggregateRoot
public class Collect {

	private UUID id;
	private String status;
	private Instant creationDate;
	private Instant endDate;
	private String entityLabel;
	private String productLabel;
	private String stepLabel;
	private String journeyCode;
	private Set<String> allowedFile;
	private Set<String> piecesManagementAct;
	private Set<String> familiesManagementAct;
	private Set<String> collectManagementAct;
	private String sendingApplicationCode;
	private Set<Owner> owners;
	private Set<Type> types;
	private String project;
	private boolean autoValidation;
	private boolean autoAcceptationAllowed;
	private int controlIterationAllowed;
	private int autoClosingDelay;
	private boolean notifyOwners;

	public Collect() {
		super();
	}

	public Collect(UUID id, String status, Instant creationDate, Instant endDate, String entityLabel, String productLabel, String stepLabel, String journeyCode, Set<String> allowedFile, Set<String> piecesManagementAct, Set<String> familiesManagementAct,
			Set<String> collectManagementAct, String sendingApplicationCode, boolean autoValidation, boolean autoAcceptationAllowed, int autoClosingDelay, boolean notifyOwners, int controlIterationAllowed) {
		super();
		this.id = id;
		this.status = status;
		this.creationDate = creationDate;
		this.endDate = endDate;
		this.entityLabel = entityLabel;
		this.productLabel = productLabel;
		this.stepLabel = stepLabel;
		this.journeyCode = journeyCode;
		this.allowedFile = allowedFile;
		this.piecesManagementAct = piecesManagementAct;
		this.familiesManagementAct = familiesManagementAct;
		this.collectManagementAct = collectManagementAct;
		this.sendingApplicationCode = sendingApplicationCode;
		this.autoValidation = autoValidation;
		this.autoAcceptationAllowed = autoAcceptationAllowed;
		this.autoClosingDelay = autoClosingDelay;
		this.notifyOwners = notifyOwners;
		this.controlIterationAllowed = controlIterationAllowed;
	}

	public Collect(Collect collect) {
		this(collect.getId(), collect.getStatus(), collect.getCreationDate(), collect.getEndDate(), collect.getEntityLabel(), collect.getProductLabel(), collect.getStepLabel(), collect.getJourneyCode(), collect.getAllowedFile(),
				new HashSet<String>(collect.getPiecesManagementAct()), new HashSet<String>(collect.getFamiliesManagementAct()), collect.getCollectManagementActWithoutInit(), collect.getSendingApplicationCode(), collect.isAutoValidation(),
				collect.isAutoAcceptationAllowed(), collect.getAutoClosingDelay(), collect.isNotifyOwners(), collect.getControlIterationAllowed());
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Set<Owner> getOwners() {
		if (owners == null) {
			owners = new HashSet<>();
		}
		return owners;
	}

	public void setOwners(Set<Owner> owners) {
		this.owners = owners;
	}

	public Set<Type> getTypes() {
		if (types == null) {
			types = new HashSet<>();
		}
		return types;
	}

	public void setTypes(Set<Type> types) {
		this.types = types;
	}

	public Instant getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Instant creationDate) {
		this.creationDate = creationDate;
	}

	public Instant getEndDate() {
		return endDate;
	}

	public void setEndDate(Instant endDate) {
		this.endDate = endDate;
	}

	public String getEntityLabel() {
		return entityLabel;
	}

	public void setEntityLabel(String entityLabel) {
		this.entityLabel = entityLabel;
	}

	public String getProductLabel() {
		return productLabel;
	}

	public void setProductLabel(String productLabel) {
		this.productLabel = productLabel;
	}

	public String getStepLabel() {
		return stepLabel;
	}

	public void setStepLabel(String stepLabel) {
		this.stepLabel = stepLabel;
	}

	public String getJourneyCode() {
		return journeyCode;
	}

	public void setJourneyCode(String journeyCode) {
		this.journeyCode = journeyCode;
	}

	public Set<String> getAllowedFile() {
		if (allowedFile == null) {
			allowedFile = new HashSet<>();
		}
		return allowedFile;
	}

	public void setAllowedFile(Set<String> allowedFile) {
		this.allowedFile = allowedFile;
	}

	public Set<String> getPiecesManagementAct() {
		if (piecesManagementAct == null) {
			piecesManagementAct = new HashSet<>();
		}
		return piecesManagementAct;
	}

	public void setPiecesManagementAct(Set<String> piecesManagementAct) {
		this.piecesManagementAct = piecesManagementAct;
	}

	public Set<String> getFamiliesManagementAct() {
		if (familiesManagementAct == null) {
			familiesManagementAct = new HashSet<>();
		}
		return familiesManagementAct;
	}

	public void setFamiliesManagementAct(Set<String> familiesManagementAct) {
		this.familiesManagementAct = familiesManagementAct;
	}

	public Set<String> getCollectManagementAct() {
		if (collectManagementAct == null) {
			collectManagementAct = new HashSet<>();
		}
		return collectManagementAct;
	}

	public Set<String> getCollectManagementActWithoutInit() {
		return collectManagementAct;
	}

	public void setCollectManagementAct(Set<String> collectManagementAct) {
		this.collectManagementAct = collectManagementAct;
	}

	public String getSendingApplicationCode() {
		return sendingApplicationCode;
	}

	public void setSendingApplicationCode(String sendingApplicationCode) {
		this.sendingApplicationCode = sendingApplicationCode;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public int getControlIterationAllowed() {
		return controlIterationAllowed;
	}

	public void setControlIterationAllowed(int controlIterationAllowed) {
		this.controlIterationAllowed = controlIterationAllowed;
	}

	public int getAutoClosingDelay() {
		return autoClosingDelay;
	}

	public void setAutoClosingDelay(int autoClosingDelay) {
		this.autoClosingDelay = autoClosingDelay;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || (getClass() != obj.getClass())) {
			return false;
		}
		return equalsPart2(obj);
	}

	private boolean equalsPart2(Object obj) {
		final Collect other = (Collect) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	public boolean isEdocType() {
		return getTypes().stream().anyMatch(t -> StringUtils.isNotEmpty(t.getEdocType()));
	}

	public boolean isAutoValidation() {
		return autoValidation;
	}

	public void setAutoValidation(boolean autoValidation) {
		this.autoValidation = autoValidation;
	}

	public boolean isAutoAcceptationAllowed() {
		return autoAcceptationAllowed;
	}

	public void setAutoAcceptationAllowed(boolean autoAcceptationAllowed) {
		this.autoAcceptationAllowed = autoAcceptationAllowed;
	}

	public boolean isNotifyOwners() {
		return notifyOwners;
	}

	public void setNotifyOwners(boolean notifyOwners) {
		this.notifyOwners = notifyOwners;
	}

	@Override
	public String toString() {
		final int numberChar = 204;
		final StringBuilder builder = new StringBuilder(numberChar);
		builder.append("Collect [id=");
		builder.append(id);
		builder.append(", status=");
		builder.append(status);
		builder.append(", creationDate=");
		builder.append(creationDate);
		builder.append(", endDate=");
		builder.append(endDate);
		builder.append(", entityLabel=");
		builder.append(entityLabel);
		builder.append(", productLabel=");
		builder.append(productLabel);
		builder.append(", stepLabel=");
		builder.append(stepLabel);
		builder.append(", journeyCode=");
		builder.append(journeyCode);
		builder.append(", allowedFile=");
		builder.append(allowedFile);
		builder.append(", piecesManagementAct=");
		builder.append(piecesManagementAct);
		builder.append(", familiesManagementAct=");
		builder.append(familiesManagementAct);
		builder.append(", collectManagementAct=");
		builder.append(collectManagementAct);
		builder.append(", sendingApplicationCode=");
		builder.append(familiesManagementAct);
		builder.append(", autoClosingDelay=");
		builder.append(autoClosingDelay);
		builder.append(", notifyOwners=");
		builder.append(notifyOwners);
		builder.append(", owners=");
		builder.append(owners);
		builder.append(", types=");
		builder.append(types);
		builder.append("]");
		return builder.toString();
	}

}
