package com.bnpparibas.bddf.collect.domain.ladrad.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PageDTO implements Comparable<PageDTO> {

	@JsonProperty("pieces")
	private List<PieceDTO> pieces;

	@JsonProperty("processed_pieces")
	private Integer processedPieces;

	@JsonProperty("status")
	private String status;

	@JsonProperty("page_number")
	private Integer pageNumber;

	@JsonProperty("ref_doc_family")
	private String refDocFamily;

	@JsonProperty("business_status")
	private String businessStatus;

	@JsonProperty("reference")
	private String reference;

	public List<PieceDTO> getPieces() {
		return pieces;
	}

	public void setPieces(List<PieceDTO> pieces) {
		this.pieces = pieces;
	}

	public Integer getProcessedPieces() {
		return processedPieces;
	}

	public void setProcessedPieces(Integer processedPieces) {
		this.processedPieces = processedPieces;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}

	public String getRefDocFamily() {
		return refDocFamily;
	}

	public void setRefDocFamily(String refDocFamily) {
		this.refDocFamily = refDocFamily;
	}

	public String getBusinessStatus() {
		return businessStatus;
	}

	public void setBusinessStatus(String businessStatus) {
		this.businessStatus = businessStatus;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	@Override
	public int compareTo(PageDTO pageDTO) {
		return this.pageNumber.compareTo(pageDTO.getPageNumber());
	}

}