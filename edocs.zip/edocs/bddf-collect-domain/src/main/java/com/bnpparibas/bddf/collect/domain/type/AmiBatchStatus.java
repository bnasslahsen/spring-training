package com.bnpparibas.bddf.collect.domain.type;

public enum AmiBatchStatus {
	IN("IN"), IN_PROGRESS("IN_PR"), TIMEOUT("T_OUT"), DONE("DONE"), ERR("ERR");

	private String code;

	AmiBatchStatus(String code) {
		this.code = code;

	}

	public String getCode() {
		return code;
	}
}
