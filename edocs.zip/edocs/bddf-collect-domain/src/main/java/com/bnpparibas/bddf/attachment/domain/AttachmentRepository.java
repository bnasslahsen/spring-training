package com.bnpparibas.bddf.attachment.domain;

import java.nio.ByteBuffer;
import java.util.UUID;

public interface AttachmentRepository {

	void add(Attachment attachment);

	Attachment get(UUID idAttachment);

	void delete(UUID idAttachment);

	/**
	 * Send File to the archive
	 *
	 * @param attachment
	 */
	String sendToArchive(Attachment attachment, ByteBuffer fileData);

}
