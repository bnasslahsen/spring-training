package com.bnpparibas.bddf.collect.domain.audit.event;

import java.time.Instant;
import java.util.UUID;

import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.rest.Context;

public class AuditEvent {

	public static final String CODE_AP = "AP12247";
	public static final String CODE_AT = "AP12247";

	private final Instant dateCreation;
	private final UUID idTech;
	private final String correlationId;
	private final String codeEvent;
	private final String message;
	private final String channel;
	private final String media;
	private final String userId;
	private String codeAP;
	private String codeAT;

	private String journeyCode;
	private UUID idCollect;
	private UUID idFamily;
	private UUID idType;
	private UUID idPiece;
	private String idEvent;
	private String codeError;
	private String edocType;
	private String typeLabel;

	private Integer totalCollect;
	private Integer totalPieces;
	private Integer totalIndex;
	private Integer totalIndexCohe;
	private Integer totalIndexExtr;
	private Integer totalIndexCorr;
	private Integer controlRequired;
	private Integer durationLadRad;
	private Integer durationAmi;
	private Integer iterationLadRad;
	private String documentSet;
	private String videoCodingDelay;

	public AuditEvent(Context context, String codeEvent, String message) {
		this.dateCreation = Instant.now();
		this.idTech = UUID.randomUUID();
		this.correlationId = LoggerHelper.correctionId();
		this.media = context.getMedia();
		this.channel = context.getCanal();
		this.userId = context.getCustomerId();
		this.codeEvent = codeEvent;
		this.message = message;
	}

	public String getEdocType() {
		return edocType;
	}

	public AuditEvent setEdocType(String edocType) {
		this.edocType = edocType;
		return this;
	}

	public String getTypeLabel() {
		return typeLabel;
	}

	public AuditEvent setTypeLabel(String typeLabel) {
		this.typeLabel = typeLabel;
		return this;
	}

	public AuditEvent setIdCollect(UUID idCollect) {
		this.idCollect = idCollect;
		return this;
	}

	public UUID getIdPiece() {
		return idPiece;
	}

	public AuditEvent setIdPiece(UUID idPiece) {
		this.idPiece = idPiece;
		return this;
	}

	public String getUserId() {
		return userId;
	}

	public String getCodeEvent() {
		return codeEvent;
	}

	public String getMessage() {
		return message;
	}

	public Instant getDateCreation() {
		return dateCreation;
	}

	public UUID getIdCollect() {
		return idCollect;
	}

	public String getJourneyCode() {
		return journeyCode;
	}

	public UUID getIdFamily() {
		return idFamily;
	}

	public AuditEvent setIdFamily(UUID idFamily) {
		this.idFamily = idFamily;
		return this;
	}

	public UUID getIdType() {
		return idType;
	}

	public AuditEvent setIdType(UUID idType) {
		this.idType = idType;
		return this;
	}

	public String getIdEvent() {
		return idEvent;
	}

	public AuditEvent setIdEvent(String idEvent) {
		this.idEvent = idEvent;
		return this;
	}

	public AuditEvent setJourneyCode(String journeyCode) {
		this.journeyCode = journeyCode;
		return this;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public String getChannel() {
		return channel;
	}

	public String getMedia() {
		return media;
	}

	public String getCodeError() {
		return codeError;
	}

	public AuditEvent setCodeError(String codeError) {
		this.codeError = codeError;
		return this;
	}

	public UUID getIdTech() {
		return idTech;
	}

	@Override
	public String toString() {
		final int numberChar = 160;
		final StringBuilder builder = new StringBuilder(numberChar);
		builder.append("AuditEvent [dateCreation=");
		builder.append(dateCreation);
		builder.append(", idTech=");
		builder.append(idTech);
		builder.append(", codeEvent=");
		builder.append(codeEvent);
		builder.append(", message=");
		builder.append(message);
		builder.append(", idCollect=");
		builder.append(idCollect);
		builder.append(", journeyCode=");
		builder.append(journeyCode);
		builder.append(", idFamily=");
		builder.append(idFamily);
		builder.append(", idType=");
		builder.append(idType);
		builder.append(", idEvent=");
		builder.append(idEvent);
		builder.append(", correlationId=");
		builder.append(correlationId);
		builder.append(", media=");
		builder.append(media);
		builder.append(", channel=");
		builder.append(channel);
		builder.append(", codeError=");
		builder.append(codeError);
		builder.append(", userId=");
		builder.append(userId);
		builder.append("]");
		return builder.toString();
	}

	public Integer getTotalCollect() {
		return totalCollect;
	}

	public AuditEvent setTotalCollect(Integer totalCollect) {
		this.totalCollect = totalCollect;
		return this;
	}

	public Integer getTotalPieces() {
		return totalPieces;
	}

	public AuditEvent setTotalPieces(Integer totalPieces) {
		this.totalPieces = totalPieces;
		return this;
	}

	public Integer getTotalIndex() {
		return totalIndex;
	}

	public AuditEvent setTotalIndex(Integer totalIndex) {
		this.totalIndex = totalIndex;
		return this;
	}

	public Integer getControlRequired() {
		return controlRequired;
	}

	public AuditEvent setControlRequired(Integer controlRequired) {
		this.controlRequired = controlRequired;
		return this;
	}

	public Integer getDurationLadRad() {
		return durationLadRad;
	}

	public AuditEvent setDurationLadRad(Integer durationLadRad) {
		this.durationLadRad = durationLadRad;
		return this;
	}

	public Integer getIterationLadRad() {
		return iterationLadRad;
	}

	public AuditEvent setIterationLadRad(Integer iterationLadRad) {
		this.iterationLadRad = iterationLadRad;
		return this;
	}

	public String getDocumentSet() {
		return documentSet;
	}

	public AuditEvent setDocumentSet(String documentSet) {
		this.documentSet = documentSet;
		return this;
	}

	public Integer getTotalIndexCohe() {
		return totalIndexCohe;
	}

	public AuditEvent setTotalIndexCohe(Integer totalIndexCohe) {
		this.totalIndexCohe = totalIndexCohe;
		return this;
	}

	public Integer getTotalIndexExtr() {
		return totalIndexExtr;
	}

	public AuditEvent setTotalIndexExtr(Integer totalIndexExtr) {
		this.totalIndexExtr = totalIndexExtr;
		return this;
	}

	public Integer getTotalIndexCorr() {
		return totalIndexCorr;
	}

	public AuditEvent setTotalIndexCorr(Integer totalIndexCorr) {
		this.totalIndexCorr = totalIndexCorr;
		return this;
	}

	public String getVideoCodingDelay() {
		return videoCodingDelay;
	}

	public AuditEvent setVideoCodingDelay(String videoCodingDelay) {
		this.videoCodingDelay = videoCodingDelay;
		return this;
	}

	public Integer getDurationAmi() {
		return durationAmi;
	}

	public AuditEvent setDurationAmi(Integer durationAmi) {
		this.durationAmi = durationAmi;
		return this;
	}

	public String getCodeAP() {
		return codeAP;
	}

	public AuditEvent setCodeAP(String codeAP) {
		this.codeAP = codeAP;
		return this;
	}

	public String getCodeAT() {
		return codeAT;
	}

	public AuditEvent setCodeAT(String codeAT) {
		this.codeAT = codeAT;
		return this;
	}

}
