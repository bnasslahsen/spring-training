package com.bnpparibas.bddf.collect.domain.type;

import java.io.InputStream;
import java.net.URI;
import java.util.UUID;

import org.springframework.http.HttpStatus;

import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusFolderDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusPieceDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.UploadDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.RequestWSJMCType;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.InfrastructureService
public interface LadRadRepository {

	/**
	 * Create a folder (dossier chez JOUVE)
	 *
	 * @param externalRef
	 *            : the external ref
	 * @param createFolderJson
	 *            : The params in JSON format
	 * @param idType
	 *            : The id of type
	 * @return the uri of folder
	 */
	URI createFolder(String externalRef, String createFolderJson, UUID idType);

	/**
	 * Get the status of folder by external Ref
	 *
	 * @param externalRef
	 *            : The id of type
	 * @param idType
	 *            : The id of type
	 * @return the status folder
	 */
	StatusFolderDTO getStatusFolder(String externalRef, UUID idType);

	/**
	 * Get the folder by external Ref
	 *
	 * @param externalRef
	 *            : the external ref
	 * @param idType
	 *            : The id of type
	 * @return The Folder JMC in format JSON
	 */
	String getFolder(String externalRef, UUID idType);

	/**
	 * Analyse the folder by external Ref
	 *
	 * @param externalRef
	 *            : The id of type
	 * @param idType
	 *            : The id of type
	 */
	void analyseFolder(String externalRef, UUID idType);

	/**
	 * Inject Reference Data for the folder
	 *
	 * @param externalRef
	 *            : The type ID
	 * @param fieldsFolderJson
	 *            : Exple : {\"name\" : \"BERTHIER\",\"firstname\" :\"CORINNE\",\"birth_date\" :\"1965-12-06\"}
	 *
	 * @param idType
	 *            : The id of type
	 */
	void injectRefDataFolder(String externalRef, String fieldsFolderJson, UUID idType);

	/**
	 * Upload new Document in folder
	 *
	 * @param uploadDocumentDTO
	 *            : The external ref
	 * @param externalRef
	 *            : The type ID
	 * @param document
	 *            : document in binary format
	 * @param idType
	 *            : The id of type
	 * @return : the uri
	 */

	URI uploadDocument(String externalRef, UploadDocumentDTO uploadDocumentDTO, InputStream document, UUID idType);

	/**
	 * Get the status of document by external Ref
	 *
	 * @param externalRef
	 *            : The id of document (piece)
	 * @param idType
	 *            : The id of type
	 * @return the status of document
	 */
	StatusDocumentDTO getStatusDocument(String externalRef, UUID idType);

	/**
	 *
	 * @param idPieceJMC
	 *            : ID Piece JMC
	 * @param idType
	 *            : The id of type
	 * @return The piece JMC in JSON format
	 */
	String getPiece(String idPieceJMC, UUID idType);

	/**
	 * Get the status of piece JMC by id Piece JMC
	 *
	 * @param idPieceJMC
	 *            : The id of Piece JMC
	 * @param idType
	 *            : The id of type
	 * @return the status of piece
	 */
	StatusPieceDTO getStatusPiece(String idPieceJMC, UUID idType);

	void updatePiece(String correctedIndexes, String pieceId, UUID idType);

	URI createPiece(String typeJmcJason, String pageId, UUID idType);

	void forcePieceType(String typeJmcJason, String idEmptyPieceJmc, UUID idType);

	void deleteFolder(String folderExternalRef, UUID idType);

	void deleteDocument(String externalRef, UUID idType);

	void traceCallWS(String idEntity, UUID idType, RequestWSJMCType requestWSJMCType, HttpStatus httpStatus, String responseBody, String requestBody, Integer duration);

	void sendDocumentToAmi(String documentRef, UUID typeId, String amiJason);

}
