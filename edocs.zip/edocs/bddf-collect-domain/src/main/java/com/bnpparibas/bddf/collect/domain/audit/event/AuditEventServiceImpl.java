package com.bnpparibas.bddf.collect.domain.audit.event;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnpparibas.bddf.collect.domain.error.CollectBusinessException;
import com.bnpparibas.bddf.collect.domain.error.CollectErrorConstants;
import com.bnpparibas.bddf.collect.domain.event.CollectEventHandler;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.DocumentSet;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceIndicators;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.type.ControlRequired;
import com.bnpparibas.bddf.collect.domain.type.IndexStatus;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.collect.domain.type.VideoCodingDelay;
import com.bnpparibas.bddf.errors.BusinessException.Builder;
import com.bnpparibas.bddf.rest.Context;

/**
 *
 * Cette classe présente les méthode de sauvegarde des audit-events
 * 
 */

@Service
public class AuditEventServiceImpl implements AuditEventService {

	@Autowired
	private AuditGenerator auditGenerator;
	@Autowired
	private CollectEventHandler collectEventHandler;

	@Autowired
	private EdocTypeRepository edocTypeRepository;

	@Override
	public void sendAuditEventLadRAD(UUID collectId, Context context, String journeyCode, final Type type, AuditValue typeAuditEvent, String errorCode) {
		final Integer maxIeration = type.getActivePieces().stream().mapToInt(Piece::getControlIterationAchieved).max().getAsInt();
		final AuditEvent auditEvent = auditGenerator.newAudit(context, typeAuditEvent, type.getLabel()).setCodeError(errorCode)
				// Collecte
				.setIdCollect(collectId).setJourneyCode(journeyCode)
				// iteration lad rad
				.setIterationLadRad(maxIeration)
				//
				.setTotalPieces(type.getActivePieces().size())
				//
				.setControlRequired(ControlRequired.CONTROL_JMC.getCode())
				// videoCodingDelay -- IMMEDIATE, DELAYED
				.setVideoCodingDelay(VideoCodingDelay.NOT_ALLOWED.getCode().equals(type.getVideoCodingDelay()) ? "" : type.getVideoCodingDelay())
				//
				.setDocumentSet(findDocumentSetFromType(type))
				// Type
				.setIdType(type.getId()).setEdocType(type.getEdocType()).setTypeLabel(Optional.ofNullable(type.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(type.getLabel()));
		collectEventHandler.sendAuditEvent(auditEvent);

	}

	@Override
	public void sendAuditEventLadRADFirstIteration(UUID collectId, Context context, String journeyCode, final Type type, final Integer durationJMC, final Integer durationAMI, final String documentSet, final List<Piece> activedPiecesSendedToJMC) {
		final Integer nbrIndexesExtraits = (int) type.getIndexes().stream().filter(idx -> StringUtils.isNotEmpty(idx.getExtractedValue())).count();
		final Integer nbrIndexesCoherents = (int) type.getIndexes().stream().filter(idx -> IndexStatus.isOK(idx.getStatusControl())).count();
		final Integer maxIeration = type.getActivePieces().stream().mapToInt(Piece::getControlIterationAchieved).max().orElse(0);
		final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.LAD_RAD_AUTOMATIC_CONTROL, type.getLabel())
				// Collecte
				.setIdCollect(collectId).setJourneyCode(journeyCode)
				// Duration Lad Rad
				.setDurationLadRad(durationJMC).setTotalPieces(activedPiecesSendedToJMC.size())
				// Duration Ami
				.setDurationAmi(durationAMI)
				// nbr Index
				.setTotalIndex(type.getIndexes().size())
				// nbr Indexes Extraits
				.setTotalIndexExtr(nbrIndexesExtraits)
				// Nbr indexes coherents
				.setTotalIndexCohe(nbrIndexesCoherents)
				//
				.setControlRequired(ControlRequired.CONTROL_JMC.getCode())
				// videoCodingDelay -- IMMEDIATE, DELAYED
				.setVideoCodingDelay(VideoCodingDelay.NOT_ALLOWED.getCode().equals(type.getVideoCodingDelay()) ? "" : type.getVideoCodingDelay())
				//
				.setDocumentSet(documentSet)
				//
				.setIterationLadRad(maxIeration)
				// Type
				.setIdType(type.getId()).setEdocType(type.getEdocType()).setTypeLabel(Optional.ofNullable(type.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(type.getLabel()));
		collectEventHandler.sendAuditEvent(auditEvent);

		activedPiecesSendedToJMC.stream().forEach(piece -> {
			if (PieceIndicators.OK.name().equals(piece.getTypeControl())) {
				sendAuditEvent(collectId, context, journeyCode, type, documentSet, piece, piece.getControlIterationAchieved(), AuditValue.LAD_RAD_AUTOMATIC_CONTROL_RECOGNITION);
			}
			if (Arrays.asList(PieceIndicators.WARNING.name(), PieceIndicators.OK.name()).contains(piece.getExtractionControl())) {
				sendAuditEvent(collectId, context, journeyCode, type, documentSet, piece, piece.getControlIterationAchieved(), AuditValue.LAD_RAD_AUTOMATIC_CONTROL_EXTRACTION);
			}
			if (Arrays.asList(PieceIndicators.WARNING.name(), PieceIndicators.OK.name()).contains(piece.getCoherenceControl())) {
				sendAuditEvent(collectId, context, journeyCode, type, documentSet, piece, maxIeration, AuditValue.LAD_RAD_AUTOMATIC_COHERENCE);
			}
		});
	}

	private void sendAuditEvent(UUID collectId, Context context, String journeyCode, final Type type, final String documentSet, Piece piece, Integer nbIteration, AuditValue auditValue) {
		AuditEvent auditEvent2;
		auditEvent2 = auditGenerator.newAudit(context, auditValue, type.getLabel(), piece.getLabel())
				// Collecte
				.setIdCollect(collectId).setJourneyCode(journeyCode)
				// Duration Lad Rad
				.setIdPiece(piece.getId())
				//
				.setControlRequired(ControlRequired.CONTROL_JMC.getCode())
				//
				.setIterationLadRad(nbIteration)
				//
				.setDocumentSet(documentSet)
				// Type
				.setIdType(type.getId()).setEdocType(type.getEdocType()).setTypeLabel(Optional.ofNullable(type.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(type.getLabel()));
		collectEventHandler.sendAuditEvent(auditEvent2);
	}

	@Override
	public void sendAuditEventLadRADSecondIteration(UUID collectId, Context context, String journeyCode, final Type type, final Integer durationJMC, final Integer durationAmi, String documentSet) {
		final Integer nbrIndexesCorrected = (int) type.getIndexes().stream().filter(idx -> StringUtils.isNotEmpty(idx.getCorrectedValue())).count();
		final Integer nbrIndexesCoherents = (int) type.getIndexes().stream().filter(idx -> IndexStatus.isOK(idx.getStatusControl())).count();

		final Integer maxIeration = type.getActivePieces().stream().mapToInt(Piece::getControlIterationAchieved).max().orElse(0);
		final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.LAD_RAD_REINDEX_CONTROL, type.getLabel())
				// Collecte
				.setIdCollect(collectId).setJourneyCode(journeyCode)
				// Duration Lad Rad
				.setDurationLadRad(durationJMC)
				// Duration Ami
				.setDurationAmi(durationAmi)
				// iteration Lad Rad
				.setIterationLadRad(maxIeration)
				// videoCodingDelay -- IMMEDIATE, DELAYED
				.setVideoCodingDelay(VideoCodingDelay.NOT_ALLOWED.getCode().equals(type.getVideoCodingDelay()) ? "" : type.getVideoCodingDelay())
				// nbr Index
				.setTotalIndex(type.getIndexes().size())
				// Nbr indexes coherents
				.setTotalIndexCohe(nbrIndexesCoherents)
				// nbr Indexes Corrected
				.setTotalIndexCorr(nbrIndexesCorrected)
				//
				.setDocumentSet(documentSet).setControlRequired(ControlRequired.CONTROL_JMC.getCode())
				// Type
				.setIdType(type.getId()).setEdocType(type.getEdocType()).setTypeLabel(Optional.ofNullable(type.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(type.getLabel()));
		collectEventHandler.sendAuditEvent(auditEvent);

	}

	@Override
	public boolean sendAuditEventForcedRecognition(UUID collectId, Context context, String journeyCode, final Type updatedType, final Type typeRepo) {
		boolean isEventSent = false;
		final List<Pair<Piece, Piece>> piecesPairs = updatedType.getActivePieces().stream()
				// Map with repository piece
				.map(piece -> buildPair(collectId, updatedType.getId(), piece, typeRepo.getActivePieces())).collect(Collectors.toList());
		for (final Pair<Piece, Piece> pair : piecesPairs) {
			final Piece piece = pair.getLeft();
			final Piece pieceRepo = pair.getRight();
			if (!StringUtils.equals(piece.getTypeControl(), pieceRepo.getTypeControl()) && StringUtils.equals(PieceIndicators.OK_MAN.name(), piece.getTypeControl())) {
				final AuditEvent auditEvent = auditGenerator.newAudit(context, AuditValue.LAD_RAD_FORCED_REGOGNITION, updatedType.getLabel(), piece.getLabel())
						// Collecte
						.setIdCollect(collectId).setJourneyCode(journeyCode)
						// piece
						.setIdPiece(piece.getId())
						//
						.setControlRequired(ControlRequired.CONTROL_JMC.getCode()).setDocumentSet(findDocumentSetFromType(typeRepo))
						// iteration
						.setIterationLadRad(("CT").equals(updatedType.getStatusControl()) ? pieceRepo.getControlIterationAchieved() + 1 : pieceRepo.getControlIterationAchieved())
						// Type
						.setIdType(updatedType.getId()).setEdocType(typeRepo.getEdocType()).setTypeLabel(Optional.ofNullable(typeRepo.getEdocType()).map(edocTypeRepository::byValue).map(EdocType::getLabel).orElse(updatedType.getLabel()));
				collectEventHandler.sendAuditEvent(auditEvent);
				isEventSent = true;
			}
		}
		return isEventSent;

	}

	private String findDocumentSetFromType(Type type) {
		final List<EdocType> edocTypes = edocTypeRepository.findAll();
		return edocTypes.stream().filter(edocTypeL -> edocTypeL.getValue().equals(type.getEdocType())).findAny().map(EdocType::getDocumentSet).orElse(DocumentSet.JMC_SET.getLabel());
	}

	private Pair<Piece, Piece> buildPair(UUID collectId, UUID typeId, Piece piece, Set<Piece> existingPieces) {
		return Pair.of(piece, existingPieces.stream().filter(p -> p.equals(piece)).findAny()
				.orElseThrow(() -> new CollectBusinessException(new Builder(CollectErrorConstants.ERR_COL_PIECE_NOT_FOUND, piece.getId().toString(), collectId.toString(), typeId.toString(), piece.getId().toString()))));
	}

}
