package com.bnpparibas.bddf.collect.domain.audit.event;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.bnpparibas.bddf.rest.Context;

@Component
public class AuditGenerator {

	private final MessageSource messageSource;

	public AuditGenerator(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public AuditEvent newAudit(Context context, AuditValue value, String... params) {
		final String message = messageSource.getMessage(value.getLabel(), params, Locale.FRENCH);
		return new AuditEvent(context, value.getCode(), message);
	}

	public AuditEvent newAudit(Context context, AuditValue value) {
		final String message = messageSource.getMessage(value.getLabel(), new String[] {}, Locale.FRENCH);
		return new AuditEvent(context, value.getCode(), message);
	}

}
