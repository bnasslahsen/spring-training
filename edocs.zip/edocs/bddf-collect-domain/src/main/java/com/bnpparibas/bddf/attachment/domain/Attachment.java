package com.bnpparibas.bddf.attachment.domain;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.UUID;

public class Attachment {
	private UUID id;
	private ArchiveBackEnd archiveBackend;
	private Instant creationDate;
	private String userId;
	private String channel;
	private String sendingApplicationCode;
	private String fileName;
	private long fileSize;
	private String mimeType;
	private ByteBuffer file;

	public Attachment() {
	}

	public Attachment(UUID id, String userId, String sendingApplicationCode, String fileName, String mimeType) {
		super();
		this.id = id;
		this.userId = userId;
		this.sendingApplicationCode = sendingApplicationCode;
		this.fileName = fileName;
		this.mimeType = mimeType;
	}

	public Attachment(String userId, String channel, String sendingApplicationCode, String fileName, String mimeType, long fileSize) {
		super();
		this.userId = userId;
		this.channel = channel;
		this.sendingApplicationCode = sendingApplicationCode;
		this.fileName = fileName;
		this.mimeType = mimeType;
		this.fileSize = fileSize;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public ArchiveBackEnd getArchiveBackend() {
		return archiveBackend;
	}

	public void setArchiveBackend(ArchiveBackEnd archiveBackend) {
		this.archiveBackend = archiveBackend;
	}

	public Instant getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Instant creationDate) {
		this.creationDate = creationDate;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSendingApplicationCode() {
		return sendingApplicationCode;
	}

	public void setSendingApplicationCode(String sendingApplicationCode) {
		this.sendingApplicationCode = sendingApplicationCode;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getMimeType() {
		return mimeType;
	}

	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	public long getFileSize() {
		return fileSize;
	}

	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public ByteBuffer getFile() {
		return file;
	}

	public void setFile(ByteBuffer file) {
		this.file = file;
	}

}
