package com.bnpparibas.bddf.collect.domain.ladrad.enums;

import java.util.Arrays;

public enum StatusFolder {

	CREATED("0"),

	ANALYSIS_SUCCESS("1"),

	NOT_ANALYSED_NO_DOCUMENT("2"),

	NOT_ANALYSED_NO_TYPED_DOCUMENT("4");

	private final String label;

	private StatusFolder(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	public static StatusFolder fromLabel(String label) {
		return Arrays.asList(values()).stream().filter(t -> t.getLabel().equals(label)).findAny().orElse(null);
	}

}
