
package com.bnpparibas.bddf.collect.domain.ladrad.ami.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "links", "type", "fields_to_key", "expected_type" })
public class Piece {

	@JsonProperty("links")
	private Links links;
	@JsonProperty("type")
	private String type;
	@JsonProperty("fields_to_key")
	private List<String> fieldsToKey;
	
	

	public Piece() {
	}

	public Piece(String href, String type, List<String> indexesAmi) {
		this.links = new Links(href);
		this.type = type;
		this.fieldsToKey = indexesAmi;
	}

	@JsonProperty("links")
	public Links getLinks() {
		return links;
	}

	@JsonProperty("links")
	public void setLinks(Links links) {
		this.links = links;
	}

	@JsonProperty("type")
	public String getType() {
		return type;
	}

	@JsonProperty("type")
	public void setType(String type) {
		this.type = type;
	}

	@JsonProperty("fields_to_key")
	public List<String> getFieldsToKey() {
		if (fieldsToKey == null) {
			fieldsToKey = new ArrayList();
		}
		return fieldsToKey;
	}

	@JsonProperty("fields_to_key")
	public void setFieldsToKey(List<String> fieldsToKey) {
		this.fieldsToKey = fieldsToKey;
	}

	@Override
	public String toString() {
		final ObjectMapper objectMapper = new ObjectMapper();
		try {
			return objectMapper.writeValueAsString(this);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
	}

}
