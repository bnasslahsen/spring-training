package com.bnpparibas.bddf.collect.domain.index;

import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.Set;
import java.util.UUID;

import com.bnpparibas.bddf.collect.domain.collect.Collect;
import com.bnpparibas.bddf.collect.domain.type.Type;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Repository
public interface IndexGdnService {

	void savePieceOnGdn(UUID collectId, Type type, Indexe piece, String userId, String channel, Set<Indexe> removesPieces);

	ByteBuffer getPieceData(UUID pieceId, String userId, String userType, String idGdn);

	void updateTypeOnGdn(Collect collect, Type type, Indexe piece, Set<Indexe> piecesToRemoveList, String userId, String channel, String newTypeStatus, String refUserId, String refChannel, Instant refAquisitionDate);

}
