package com.bnpparibas.bddf.collect.domain.collect;

import java.time.LocalDate;

import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.Entity
public class Owner {

	private String reference;
	private String name;
	private String firstname;
	private LocalDate birthDate;
	private Integer nature;
	private String id;
	private String communicationTemplate;

	public Owner() {

	}

	public Owner(String reference, String name, String firstname, LocalDate birthDate, Integer nature, String idOwner, String communicationTemplate) {
		this.reference = reference;
		this.name = name;
		this.firstname = firstname;
		this.birthDate = birthDate;
		this.nature = nature;
		this.id = idOwner;
		this.communicationTemplate = communicationTemplate;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public LocalDate getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(LocalDate birthDate) {
		this.birthDate = birthDate;
	}

	public Integer getNature() {
		return nature;
	}

	public void setNature(Integer nature) {
		this.nature = nature;
	}

	public String getCommunicationTemplate() {
		return communicationTemplate;
	}

	public void setCommunicationTemplate(String communicationTemplate) {
		this.communicationTemplate = communicationTemplate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((reference == null) ? 0 : reference.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || (getClass() != obj.getClass())) {
			return false;
		}
		return equalsPart2(obj);
	}

	private boolean equalsPart2(Object obj) {
		final Owner other = (Owner) obj;
		if (reference == null) {
			if (other.reference != null) {
				return false;
			}
		} else if (!reference.equals(other.reference)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		final int numberChar = 58;
		final StringBuilder builder = new StringBuilder(numberChar);
		builder.append("Owner [reference=");
		builder.append(reference);
		builder.append(", name=");
		builder.append(name);
		builder.append(", firstname=");
		builder.append(firstname);
		builder.append(", birthDate=");
		builder.append(birthDate);
		builder.append(", nature=");
		builder.append(nature);
		builder.append("]");
		return builder.toString();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}