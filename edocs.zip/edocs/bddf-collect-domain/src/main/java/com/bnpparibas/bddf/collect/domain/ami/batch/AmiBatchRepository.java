package com.bnpparibas.bddf.collect.domain.ami.batch;

import com.bnpparibas.bddf.collect.domain.type.AmiBatch;

public interface AmiBatchRepository {
	void saveAmiBatch(AmiBatch amiBatch);

	void update(AmiBatch amiBatch);

}
