package com.bnpparibas.bddf.collect.domain.type;

import java.util.Arrays;

public enum VideoCodingDelay {
	IMMEDIATE("Immediate", "immediat"), DELAYED("Delayed", "standard"), NOT_ALLOWED("NotAllowed", "NotAllowed");

	private String code;
	private String label;

	VideoCodingDelay(String code, String label) {
		this.code = code;
		this.label = label;

	}

	public String getCode() {
		return code;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
	public static VideoCodingDelay fromCode(String code) {
		return Arrays.asList(values()).stream().filter(t -> t.getCode().equals(code)).findAny().orElse(null);
	}

}
