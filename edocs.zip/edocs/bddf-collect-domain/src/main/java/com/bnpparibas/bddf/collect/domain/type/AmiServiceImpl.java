package com.bnpparibas.bddf.collect.domain.type;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.bnp.schema.edoc.index.Indexes.EdocIndex;
import com.bnp.schema.edoc.type.Types.EdocType;
import com.bnp.schema.edoc.type.Types.EdocType.PiecesEdoc;
import com.bnpparibas.bddf.collect.domain.helper.LoggerHelper;
import com.bnpparibas.bddf.collect.domain.index.Indexe;
import com.bnpparibas.bddf.collect.domain.ladrad.LadRadValidator;
import com.bnpparibas.bddf.collect.domain.ladrad.ami.dto.AmiRequestDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.ami.dto.Page;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.PageDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.PieceDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.dto.StatusDocumentDTO;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.PieceIndicators;
import com.bnpparibas.bddf.collect.domain.ladrad.enums.TypeControls;
import com.bnpparibas.bddf.collect.domain.param.EdocIndexRepository;
import com.bnpparibas.bddf.collect.domain.param.EdocTypeRepository;
import com.bnpparibas.bddf.collect.domain.piece.Piece;
import com.bnpparibas.bddf.collect.domain.piece.PieceRepository;
import com.bnpparibas.bddf.collect.domain.piece.PieceStatus;
import com.bnpparibas.bddf.domain.ddd.DDD;

@DDD.RepositoryImpl
@Repository
public class AmiServiceImpl implements AmiService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AmiServiceImpl.class);
	private static final String LADRAD_URL_AMI_STATUS_BASE_PIECE = "ladrad.path.statusAmiBase.piece";
	private static final String LADRAD_URL_AMI_STATUS_BASE_PAGE = "ladrad.path.statusAmiBase.page";
	private static final String LADRAD_URL_AMI_STATUS_END_PIECE = "ladrad.path.statusAmiEnd.piece";
	private static final String LADRAD_URL_AMI_STATUS_END_PAGE = "ladrad.path.statusAmiEnd.page";
	private static final String AMI_AUTHENTIFICATION = "edoc";

	@Autowired
	private LadRadRepository ladRadRepository;

	@Autowired
	private EdocIndexRepository edocIndexRepository;

	@Autowired
	private TypeRepository typeRepository;

	@Autowired
	private EdocTypeRepository edocTypeRepository;

	@Autowired
	private LadRadValidator ladRadValidator;

	@Autowired
	private Environment env;

	@Lazy
	@Autowired
	private TypeAutomaticControlUtils typeAutomaticControlUtils;

	@Autowired
	private PieceRepository pieceRepository;

	@Autowired
	private AmiBatchService amiBatchService;

	public AmiServiceImpl() {
	}

	public AmiServiceImpl(LadRadRepository ladRadRepository, EdocIndexRepository edocIndexRepository, TypeRepository typeRepository, EdocTypeRepository edocTypeRepository, LadRadValidator ladRadValidator) {
		this.ladRadRepository = ladRadRepository;
		this.edocIndexRepository = edocIndexRepository;
		this.typeRepository = typeRepository;
		this.edocTypeRepository = edocTypeRepository;
		this.ladRadValidator = ladRadValidator;
	}

	@Override
	public void sendAMIFirstIteration(UUID collectId, Type type, String journeyCode) {
		LoggerHelper.logForPerfTest(LOGGER, "Début de l'envoi vers AMI ( première iteration)  pour type" + type.getId() + " pour la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
		final String documentSet = "AMI" + "_" + type.getVideoCodingDelay();
		final List<Piece> piecesToBeSentToAMI = type.getActivePieces().stream().filter(piece -> !PieceStatus.RF.getLabel().equals(piece.getStatus())).collect(Collectors.toList());
		final List<Indexe> indexes = new ArrayList<>(type.getIndexes());
		// On envoi à AMI tous les indexes KO (indépendament du videocoding des indexes)
		final Set<Indexe> indexesToBeSentToAMI = indexes.stream().filter(indexe -> !IndexStatus.isOK(indexe.getStatusControl())).collect(Collectors.toSet());
		// TODO: A traiter pour les multiowners
		final String ownerIndex = "1";
		sendAMI(collectId, type, piecesToBeSentToAMI, indexes, indexesToBeSentToAMI, ownerIndex, documentSet, journeyCode);
		LoggerHelper.logForPerfTest(LOGGER, "Fin de l'envoi vers AMI ( première iteration) pour type" + type.getId() + " pour la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");

	}

	private void sendAMI(UUID collectId, Type type, List<Piece> piecesToBeSentToAMI, List<Indexe> indexes, Set<Indexe> indexesToBeSentToAMI, String ownerIndex, String documentSet, String journeyCode) {
		initBeforeSendAmi(piecesToBeSentToAMI);
		final String priority = VideoCodingDelay.fromCode(type.getVideoCodingDelay()).getLabel();
		// Envoi d'un seul postAMI dont le json englobe toutes les pièces
		final AmiRequestDTO amiRequestDTO = new AmiRequestDTO(priority, AMI_AUTHENTIFICATION, journeyCode);
		// Ajout des pièces manquantes en vidéotypage
		prepareAmiVideoTypage(type, piecesToBeSentToAMI, ownerIndex, amiRequestDTO);
		// Ajout des pièces reconnues (OK/OK_MAN) en vidéocodage
		prepareAmiVideoCodage(type, piecesToBeSentToAMI, indexesToBeSentToAMI, ownerIndex, amiRequestDTO);

		final String amiJason = amiRequestDTO.toString();
		ladRadRepository.sendDocumentToAmi(amiRequestDTO.getExternalRef(), type.getId(), amiJason);

		if (VideoCodingDelay.IMMEDIATE.getCode().equals(type.getVideoCodingDelay())) {
			// Vérification du fin de traitement AMI
			final Map<UUID, StatusDocumentDTO> listStatusDocumentJMC = typeAutomaticControlUtils.verifyStatusDocuments(piecesToBeSentToAMI, ownerIndex, type.getId(), documentSet);
			// Recalcul des indicateurs pour AMI
			extractIndexesPieceAndCalculateIndicatorsAMI(collectId, type, listStatusDocumentJMC, indexes, ownerIndex, documentSet);
		} else if (VideoCodingDelay.DELAYED.getCode().equals(type.getVideoCodingDelay())) {
			// Délégation de recalcul des indicateurs AMI pour le batch
			saveAmiBatch(type, journeyCode);
		}
	}

	private void initBeforeSendAmi(List<Piece> piecesToBeSentToAMI) {
		piecesToBeSentToAMI.forEach(piece -> piece.setControlIterationAchieved(9));
		Collections.sort(piecesToBeSentToAMI);
	}

	private void prepareAmiVideoTypage(Type type, List<Piece> piecesToBeSentToAMI, String ownerIndex, final AmiRequestDTO amiRequestDTO) {
		if (!TypeControls.OK.name().equals(type.getCompletenessControl())) {
			// Pour l'envoi en videotypage, on ajoute toutes les pièces non reconnues (indiquées dans completenessControl)
			Arrays.asList(type.getCompletenessControl().split("/")).forEach(completeness -> piecesToBeSentToAMI.forEach(piece -> {
				final StatusDocumentDTO statusDocument = ladRadRepository.getStatusDocument(computeExternalRef(piece.getId(), ownerIndex), type.getId());
				if (piece.getId().equals(piecesToBeSentToAMI.get(0).getId())) {
					// La première pièce, aprés le tri, porte le postAMI
					amiRequestDTO.setExternalRef(statusDocument.getReference());
				}
				// Ajout de la pièce en videotypage dans le json global
				statusDocument.getPages().forEach(pageDto -> addPieceInAmiJasonVideoTypage(amiRequestDTO, pageDto, completeness));
			}));
		}

	}

	private void prepareAmiVideoCodage(Type type, List<Piece> piecesToBeSentToAMI, Set<Indexe> indexesToBeSentToAmi, String ownerIndex, final AmiRequestDTO amiRequestDTO) {
		// On envoi toutes les pèces reconnues en videocodage
		final List<Piece> piecesRecognizedToBeSentToAMI = piecesToBeSentToAMI.stream().filter(piece -> Arrays.asList(PieceIndicators.OK.name(), PieceIndicators.OK_MAN.name()).contains(piece.getTypeControl())).collect(Collectors.toList());
		piecesRecognizedToBeSentToAMI.forEach(piece -> {
			final StatusDocumentDTO statusDocument = ladRadRepository.getStatusDocument(computeExternalRef(piece.getId(), ownerIndex), type.getId());
			if (piece.getId().equals(piecesToBeSentToAMI.get(0).getId())) {
				// La première pièce, aprés le tri, porte le postAMI
				amiRequestDTO.setExternalRef(statusDocument.getReference());
			}
			// Ajout de la pièce en videocodage dans le json global
			statusDocument.getPages().forEach(pageDto -> addPieceInAmiJasonVideoCodage(amiRequestDTO, pageDto, indexesToBeSentToAmi, type));
		});
	}

	private void saveAmiBatch(Type type, String journeyCode) {
		// Sauvegarde de l'enoi AMI différé en base pour prise en compte par le batch AMI Delayed
		final AmiBatch amiBatch = new AmiBatch();
		amiBatch.setInitialSent(Timestamp.from(Instant.now()));
		amiBatch.setTypeId(type.getId());
		amiBatch.setStatus(AmiBatchStatus.IN.getCode());
		amiBatch.setJourneyCode(journeyCode);

		amiBatchService.save(amiBatch);
	}

	@Override
	public void extractIndexesPieceAndCalculateIndicatorsAMI(UUID collectId, Type type, Map<UUID, StatusDocumentDTO> listStatusDocumentJMC, List<Indexe> indexes, String ownerIndex, String documentSet) {
		typeAutomaticControlUtils.extractIndexesPiece(collectId, type, indexes, ownerIndex, listStatusDocumentJMC, documentSet, false);
		typeAutomaticControlUtils.calculateIndicators(type);
	}

	@Override
	public void sendAMISecondIteration(UUID collectId, Type type, boolean isBypassSecondIteration, String journeyCode) {
		final List<Indexe> indexes = new ArrayList<>(type.getIndexes());
		final boolean isToBeSendToAMI = indexes.stream().anyMatch(indexe -> !IndexStatus.OK.getCode().equals(indexe.getStatusControl()) && indexe.isVideoCoding() && !indexe.isIndexable());
		// Actuellement l'envoi AMI en 2eme itération est autorisé pour le mode Immediate seulement
		if (Arrays.asList(VideoCodingDelay.IMMEDIATE.getCode()).contains(type.getVideoCodingDelay()) && isToBeSendToAMI) {
			LoggerHelper.logForPerfTest(LOGGER, "Début de l'envoi vers AMI ( deuxiéme iteration)  pour type" + type.getId() + " pour la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
			final String documentSet = "AMI" + "_" + type.getVideoCodingDelay();
			final List<Piece> piecesToBeSentToAMI = type.getActivePieces().stream().filter(piece -> !PieceStatus.RF.getLabel().equals(piece.getStatus())).collect(Collectors.toList());
			// On envoi à AMI tous les indexes KO (indépendament du videocoding des indexes)
			final Set<Indexe> indexesToBeSentToAMI = indexes.stream().filter(indexe -> !IndexStatus.OK.getCode().equals(indexe.getStatusControl())).collect(Collectors.toSet());
			final String ownerIndex = "1";
			// Un seul envoi AMI pour toutes les pièces
			type.getIndexes().stream().filter(indexe -> !IndexStatus.OK.getCode().equals(indexe.getStatusControl())).forEach(index -> index.setCorrectedValue(""));
			sendAMI(collectId, type, piecesToBeSentToAMI, indexes, indexesToBeSentToAMI, ownerIndex, documentSet, journeyCode);
			LoggerHelper.logForPerfTest(LOGGER, "Fin de l'envoi vers AMI ( deuxiéme iteration)  pour type" + type.getId() + " pour la collecte " + collectId + " (thread id " + Thread.currentThread().getId() + ")");
		}
	}

	@Override
	public void addPieceInAmiJasonVideoTypage(AmiRequestDTO amiRequestDTO, PageDTO pageDto, String expectedType) {
		final String amiRequestStr = convertAmiRequestToString(AmiRequest.VIDEOTYPAGE);
		// Création d'une page par pièce
		final Page pageAmi = new Page(getHrefStatusAmiPage(pageDto.getReference()), pageDto.getPageNumber(), amiRequestStr);
		// Indiquer à AMI le type de pièce attendu
		pageAmi.setExpectedType(expectedType.trim());
		// Ajout de la page dans e json global
		amiRequestDTO.getPages().add(pageAmi);
	}

	public void addPieceInAmiJasonVideoCodage(AmiRequestDTO amiRequestDTO, PageDTO pageDto, Set<Indexe> indexesToBeSentToAmi, Type type) {
		final String amiRequestStr = convertAmiRequestToString(AmiRequest.VIDEOCODAGE);
		final List<String> codeIndexes = indexesToBeSentToAmi.stream().map(Indexe::getCode).collect(Collectors.toList());

		pageDto.getPieces().forEach(pieceJmc -> {
			final Page pageAmi = new Page(getHrefStatusAmiPage(pageDto.getReference()), pageDto.getPageNumber(), amiRequestStr);
			// Liste des indexes paramétrés dans edocType.xml pour la pièce JMC
			final List<String> pieceJmcIndexes = getPieceJmcIndexes(type, edocTypeRepository.findAll(), pieceJmc);
			final List<String> codeIndexesAmi = pieceJmcIndexes.stream().filter(codeIndexes::contains).collect(Collectors.toList());
			final List<String> jmcCodeIndexesAmi = edocIndexRepository.findAll().stream().filter(edocIndex -> codeIndexesAmi.contains(edocIndex.getCode())).map(EdocIndex::getJmcCode).collect(Collectors.toList());
			final com.bnpparibas.bddf.collect.domain.ladrad.ami.dto.Piece pieceAmi = new com.bnpparibas.bddf.collect.domain.ladrad.ami.dto.Piece(getHrefStatusAmiPiece(pieceJmc.getReference()), pieceJmc.getType(), jmcCodeIndexesAmi);
			pageAmi.getPieces().add(pieceAmi);
			// si il y a au moins une pièce alors on l'ajoute dans le JSON
			if (CollectionUtils.isNotEmpty(pageAmi.getPieces())) {
				amiRequestDTO.getPages().add(pageAmi);
			}
		});

	}

	private String convertAmiRequestToString(AmiRequest amiReq) {
		if (AmiRequest.VIDEOCODAGE.equals(amiReq)) {
			return "Videocodage";
		} else if (AmiRequest.VIDEOTYPAGE.equals(amiReq)) {
			return "Videotypage";
		} else {
			throw new IllegalArgumentException();
		}
	}

	private List<String> getPieceJmcIndexes(Type type, List<EdocType> edocTypes, final PieceDTO pieceJmc) {
		List<String> pieceJmcIndexes = new ArrayList<>();
		// Liste des pièces paramétrées dans edocType.xml
		final List<PiecesEdoc.Piece> edocTypePieces = edocTypes.stream().filter(edocType -> edocType.getPiecesEdoc() != null && StringUtils.equals(edocType.getValue(), type.getEdocType())).findFirst().get().getPiecesEdoc().getPiece();
		final Optional<PiecesEdoc.Piece> optionalEdocPieceJmc = edocTypePieces.stream().filter(edocPieceJmc -> StringUtils.equals(edocPieceJmc.getPieceJmc(), pieceJmc.getType())).findFirst();
		if (optionalEdocPieceJmc.isPresent()) {
			// Liste des indexes paramétrés pour la pièce JMC
			pieceJmcIndexes = optionalEdocPieceJmc.get().getIndexes().getIndex();
		}
		return pieceJmcIndexes;
	}

	private String computeExternalRef(UUID id, String ownerIndex) {
		return id.toString() + "-" + ownerIndex;
	}

	private String getHrefStatusAmiPiece(String reference) {
		return env.getProperty(LADRAD_URL_AMI_STATUS_BASE_PIECE) + reference + env.getProperty(LADRAD_URL_AMI_STATUS_END_PIECE);
	}

	private String getHrefStatusAmiPage(String reference) {
		return env.getProperty(LADRAD_URL_AMI_STATUS_BASE_PAGE) + reference + env.getProperty(LADRAD_URL_AMI_STATUS_END_PAGE);
	}

	public LadRadRepository getLadRadRepository() {
		return ladRadRepository;
	}

	public void setLadRadRepository(LadRadRepository ladRadRepository) {
		this.ladRadRepository = ladRadRepository;
	}

	public EdocIndexRepository getEdocIndexRepository() {
		return edocIndexRepository;
	}

	public void setEdocIndexRepository(EdocIndexRepository edocIndexRepository) {
		this.edocIndexRepository = edocIndexRepository;
	}

	public TypeRepository getTypeRepository() {
		return typeRepository;
	}

	public void setTypeRepository(TypeRepository typeRepository) {
		this.typeRepository = typeRepository;
	}

	public EdocTypeRepository getEdocTypeRepository() {
		return edocTypeRepository;
	}

	public void setEdocTypeRepository(EdocTypeRepository edocTypeRepository) {
		this.edocTypeRepository = edocTypeRepository;
	}

	public LadRadValidator getLadRadValidator() {
		return ladRadValidator;
	}

	public void setLadRadValidator(LadRadValidator ladRadValidator) {
		this.ladRadValidator = ladRadValidator;
	}

	public PieceRepository getPieceRepository() {
		return pieceRepository;
	}

	public void setPieceRepository(PieceRepository pieceRepository) {
		this.pieceRepository = pieceRepository;
	}

	public Environment getEnv() {
		return env;
	}

	public void setEnv(Environment env) {
		this.env = env;
	}

	public TypeAutomaticControlUtils getTypeAutomaticControlUtils() {
		return typeAutomaticControlUtils;
	}

	public void setTypeAutomaticControlUtils(TypeAutomaticControlUtils typeAutomaticControlUtils) {
		this.typeAutomaticControlUtils = typeAutomaticControlUtils;
	}

}
